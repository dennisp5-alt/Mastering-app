package com.dennis.aimasteringlab;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.json.*;

/** Restartable at verified base-master and finished-export boundaries. */
final class StudioPipeline {
    static void master(StudioProject p,AudioAnalyzer.Progress progress)throws Exception{
        File input=StudioImports.requireSource(p,progress);
        if(p.validFile("base","base_hash")){progress.update("Resuming from verified base master",100);return;}
        p.state("MASTERING","Building verified base master");
        File work=p.child("base-work-"+System.currentTimeMillis());if(!work.mkdirs())throw new IOException("Cannot create mastering workspace");
        AudioAnalyzer.StreamProvider raw=()->new FileInputStream(input);
        AnalysisResult original=StudioAudio.measure(input,progress);
        original.sourceGuard=SourceGuardModel.analyze(raw,original,progress);
        original.sections=LearnedSectionMapper.analyze(raw,original,progress);
        original.aiDiagnostics=AdaptiveDiagnosticModel.analyze(raw,original,progress);
        File repaired=new File(work,"repaired-source.wav");
        try{
            original.clickDropoutRepair=ClickDropoutRepair.analyze(raw,original,progress);
            if(original.clickDropoutRepair.hasRepairs())ClickDropoutRepair.render(raw,original,original.clickDropoutRepair,repaired,progress);
        }catch(Exception e){StudioAudio.cancel();repaired.delete();original.clickDropoutRepair=new ClickDropoutRepair.Result();original.clickDropoutRepair.status="Repair bypassed: "+e.getMessage();}
        AudioAnalyzer.StreamProvider processing=repaired.isFile()?()->new FileInputStream(repaired):raw;
        AnalysisResult source=repaired.isFile()?TechnicalSourcePreparation.reanalyze(processing,original,progress):original;
        source.nextGenerationIntelligence=NextGenerationMasteringModel.analyze(processing,source,null,null,null,progress);
        AutonomousMasteringBrain.Result brain=AutonomousMasteringBrain.analyze(processing,source,progress);
        FullAiMasteringEngine.Result engine=FullAiMasteringEngine.run(processing,source,brain,work,progress);
        FullAiReleaseQc.Result qc=FullAiReleaseQc.run(processing,source,engine,work,ReleaseFormats.camelBase(p.name()),progress);
        File base=p.child("base-master.wav");StudioProject.copy(new FileInputStream(qc.finalMaster),base);
        if(!Hashing.sha256(base).equals(qc.finalMasterSha256))throw new IOException("Base master copy did not verify");
        File report=p.child("Base_Master_QC.json");StudioProject.atomic(report,FullAiReportWriter.create(source,brain,engine,qc).getBytes(StandardCharsets.UTF_8));
        p.file("base",base);p.file("base_report",report);p.data.put("base_hash",qc.finalMasterSha256)
                .put("base_meters",StudioAudio.meters(qc.finalMasterVerification)).put("base_winner",qc.finalCandidate.strategy);
        p.state("BASE_READY","Verified base master saved; finishing delivery next");
        removeTree(work);
    }
    static void finish(StudioProject p,AudioAnalyzer.Progress progress)throws Exception{
        if(!p.validFile("base","base_hash"))throw new IOException("Verified base master is unavailable");
        p.state("RENDERING","Applying saved edits and verifying delivery");
        File base=p.file("base");AnalysisResult before=StudioAudio.measure(base,progress);StudioRecipe recipe=p.recipe();recipe.validate(before.wav.durationSeconds);
        File run=p.child("render-"+System.currentTimeMillis());if(!run.mkdirs())throw new IOException("Cannot create render workspace");
        StudioLowEnd.Scan beforeLow=null;
        if(recipe.lowEnd&&!p.data.optBoolean("bass_scanned",false)){
            beforeLow=StudioLowEnd.scan(base,progress);
            recipe.edits.addAll(StudioLowEnd.propose(beforeLow));p.data.put("bass_scanned",true);p.recipe(recipe);
        }
        for(StudioRecipe.Edit e:recipe.edits)if(e.automatic&&!recipe.lowEnd)e.enabled=false;
        boolean hasAutomatic=false;for(StudioRecipe.Edit e:recipe.edits)hasAutomatic|=e.enabled&&e.automatic;
        JSONObject autoQc=new JSONObject().put("passed",true).put("events_checked",0);
        File premaster=new File(run,"edited-float.wav");
        StudioAudio.EditResult edited=StudioAudio.edit(base,before,recipe,premaster,progress);
        if(hasAutomatic){
            if(beforeLow==null)beforeLow=StudioLowEnd.scan(base,progress);
            autoQc=StudioLowEnd.verify(beforeLow,StudioLowEnd.scan(premaster,progress),recipe.edits,recipe.trimStart);
            if(!autoQc.optBoolean("passed",false)){
                for(StudioRecipe.Edit e:recipe.edits)if(e.automatic)e.enabled=false;
                autoQc.put("decision","Automatic bass edits rejected; manual edits retained");p.recipe(recipe);
                edited=StudioAudio.edit(base,before,recipe,premaster,progress);
            }else autoQc.put("decision","Automatic bass edits passed measured local benefit checks");
        }
        String name=ReleaseFormats.camelBase(recipe.title);
        File master=new File(run,name+"_Master_24bit-48kHz.wav");
        boolean unchanged=recipe.trimStart==0&&recipe.trimEnd==0&&edited.fadeIn==0&&edited.fadeOut==0;
        for(StudioRecipe.Edit e:recipe.edits)if(e.enabled&&Math.abs(e.db)>1e-9)unchanged=false;
        StudioAudio.Delivery delivered=StudioAudio.deliver(unchanged?base:premaster,unchanged?before:edited.analysis,recipe,master,progress);
        StudioMetadata.wav(master,recipe);delivered.analysis=StudioAudio.measure(master,progress);
        StudioAudio.valid(delivered.analysis,edited.analysis.wav.frames);
        ReleaseFormats.Result formats=ReleaseFormats.create(master,delivered.analysis,run,recipe.title,progress,recipe);
        if(formats.complete()){
            StudioMetadata.wav(formats.wav16,recipe);
            AnalysisResult tagged=StudioAudio.measure(formats.wav16,progress);
            if(tagged.wav.frames!=formats.wav16Qc.wav.frames||Math.abs(tagged.integratedLufs-formats.wav16Qc.integratedLufs)>.00001)throw new IOException("WAV metadata changed audio");
            formats.wav16Qc=tagged;
        }
        File original=p.file("source"),aligned=new File(run,"source-aligned.wav");
        StudioAudio.region(original,aligned,recipe.trimStart,delivered.analysis.wav.durationSeconds,progress);
        AnalysisResult alignedAnalysis=StudioAudio.measure(aligned,progress);
        RadioPreparation.Result radio=RadioPreparation.analyze(()->new FileInputStream(aligned),alignedAnalysis,master,delivered.analysis,progress);
        JSONObject report=new JSONObject().put("app_version","0.14.0").put("project_id",p.dir.getName())
                .put("source_sha256",p.data.getString("source_hash")).put("base_sha256",p.data.getString("base_hash"))
                .put("source_recovery_notice",p.data.optString("source_recovery_notice",""))
                .put("recipe",recipe.json()).put("base_winner",p.data.optString("base_winner"))
                .put("audio_unchanged_before_delivery_gain",unchanged).put("master",StudioAudio.meters(delivered.analysis))
                .put("delivery_note",delivered.note).put("target_lufs",recipe.target).put("peak_ceiling_dbtp",recipe.ceiling)
                .put("fade_in_seconds",edited.fadeIn).put("fade_out_seconds",edited.fadeOut)
                .put("boundary_in_repair",edited.boundaryIn).put("boundary_out_repair",edited.boundaryOut)
                .put("bass_verification",autoQc).put("release_formats",ReleaseFormats.json(formats))
                .put("radio_preparation",RadioPreparation.json(radio).put("target_lufs_i",recipe.target).put("true_peak_ceiling_dbtp",recipe.ceiling))
                .put("verification_scope","Final PCM and decoded MP3 measured; base mastering QC is separate. Listening, broadcaster compliance and edited-master AAC are not certified.");
        if(delivered.render!=null)report.put("limiter_max_reduction_db",delivered.render.maximumLimiterReductionDb)
                .put("limiter_mean_reduction_db",delivered.render.averageLimiterReductionDb).put("limiter_used",delivered.render.limiterUsed);
        File qc=new File(run,name+"_Studio_QC.json"),recipeFile=new File(run,name+"_Recipe.json");
        StudioProject.atomic(qc,report.toString(2).getBytes(StandardCharsets.UTF_8));
        StudioProject.atomic(recipeFile,recipe.json().toString(2).getBytes(StandardCharsets.UTF_8));
        ArrayList<File> files=new ArrayList<>(Arrays.asList(master,qc,recipeFile,p.file("base_report")));
        if(formats.complete()){files.add(formats.wav16);files.add(formats.mp3);}
        File zip=new File(run,name+"_Studio_Release.zip");packageFiles(zip,files,progress);
        // Publish project references only after all final files and their archive have verified.
        p.file("master",master);p.file("report",qc);p.file("package",zip);p.file("aligned_source",aligned);
        p.data.put("aligned_meters",StudioAudio.meters(alignedAnalysis)).put("master_hash",Hashing.sha256(master))
                .put("package_hash",Hashing.sha256(zip)).put("master_meters",StudioAudio.meters(delivered.analysis))
                .put("final_profile",StudioReferences.profile(master,progress)).put("last_recipe",recipe.json())
                .put("rendered_revision",p.data.optInt("revision",0)).put("final_qc",report);
        if(formats.complete()){p.file("wav16",formats.wav16);p.file("mp3",formats.mp3);}else{p.data.remove("wav16");p.data.remove("mp3");}
        p.state(formats.complete()?"COMPLETE":"EXPORT_REVIEW",delivered.note+(formats.complete()?"":"; "+formats.summary()));
        WavRenderIntegrity.discard(premaster);
        if(!p.validFile("source","source_hash")||!p.validFile("base","base_hash"))throw new IOException("Retained source/base integrity changed");
    }
    static void packageFiles(File output,List<File> files,AudioAnalyzer.Progress progress)throws IOException{
        File stage=new File(output.getPath()+".tmp");StringBuilder hashes=new StringBuilder();HashSet<String> names=new HashSet<>();
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(stage),262144))){
            z.setLevel(1);byte[] b=new byte[262144];int i=0;
            for(File f:files){if(f==null||!f.isFile())throw new IOException("Package input missing");if(!names.add(f.getName()))throw new IOException("Duplicate package filename "+f.getName());
                hashes.append(Hashing.sha256(f)).append("  ").append(f.getName()).append('\n');z.putNextEntry(new ZipEntry(f.getName()));
                try(InputStream in=new FileInputStream(f)){int n;while((n=in.read(b))!=-1){z.write(b,0,n);StudioAudio.cancel();}}z.closeEntry();
                progress.update("Packaging verified files",++i*100/files.size());
            }z.putNextEntry(new ZipEntry("SHA256.txt"));z.write(hashes.toString().getBytes(StandardCharsets.UTF_8));z.closeEntry();
        }
        try(ZipFile z=new ZipFile(stage)){byte[] b=new byte[262144];for(File f:files)try(InputStream in=z.getInputStream(z.getEntry(f.getName()))){
            java.security.MessageDigest digest;try{digest=java.security.MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new IOException(e);}
            int n;while((n=in.read(b))!=-1){digest.update(b,0,n);StudioAudio.cancel();}StringBuilder h=new StringBuilder();for(byte v:digest.digest())h.append(String.format(java.util.Locale.US,"%02x",v&255));
            if(!h.toString().equals(Hashing.sha256(f)))throw new IOException("Package checksum mismatch");
        }}
        java.nio.file.Files.move(stage.toPath(),output.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }
    static void removeTree(File file){if(file.isDirectory()){File[] c=file.listFiles();if(c!=null)for(File f:c)removeTree(f);}file.delete();}
}
