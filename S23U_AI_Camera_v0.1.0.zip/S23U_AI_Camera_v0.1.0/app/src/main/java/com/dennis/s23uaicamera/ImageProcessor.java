package com.dennis.s23uaicamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.ByteArrayOutputStream;

public final class ImageProcessor {
    private ImageProcessor() {}

    public static byte[] process(byte[] jpeg, String look, boolean autoLevel, float rollDeg, int jpegOrientation) {
        Bitmap src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
        if (src == null) return jpeg;
        Bitmap work = src.copy(Bitmap.Config.ARGB_8888, true);
        if (work != src) src.recycle();

        if (jpegOrientation != 0) {
            Matrix m = new Matrix();
            m.postRotate(jpegOrientation);
            Bitmap r = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (r != work) work.recycle();
            work = r;
        }

        float correction = 0f;
        if (autoLevel && Math.abs(rollDeg) >= 0.35f && Math.abs(rollDeg) <= 5.0f) correction = -rollDeg;
        if (correction != 0f) {
            int targetW = work.getWidth();
            int targetH = work.getHeight();
            float targetAspect = targetW / (float) targetH;
            Matrix m = new Matrix();
            m.postRotate(correction);
            Bitmap rotated = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (rotated != work) work.recycle();
            work = cropToAspect(rotated, targetAspect);
            if (work != rotated) rotated.recycle();
            if (work.getWidth() != targetW || work.getHeight() != targetH) {
                Bitmap scaled = Bitmap.createScaledBitmap(work, targetW, targetH, true);
                if (scaled != work) work.recycle();
                work = scaled;
            }
        }

        applyLook(work, look);

        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(jpeg.length, 1024 * 1024));
        work.compress(Bitmap.CompressFormat.JPEG, 100, out);
        work.recycle();
        return out.toByteArray();
    }

    private static Bitmap cropToAspect(Bitmap b, float aspect) {
        int w = b.getWidth(), h = b.getHeight();
        float current = w / (float) h;
        if (Math.abs(current - aspect) < 0.0005f) return b;
        if (current > aspect) {
            int nw = Math.max(1, Math.round(h * aspect));
            int x = Math.max(0, (w - nw) / 2);
            return Bitmap.createBitmap(b, x, 0, Math.min(nw, w - x), h);
        } else {
            int nh = Math.max(1, Math.round(w / aspect));
            int y = Math.max(0, (h - nh) / 2);
            return Bitmap.createBitmap(b, 0, y, w, Math.min(nh, h - y));
        }
    }

    private static void applyLook(Bitmap b, String look) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        float contrast = 1.01f, saturation = 0.99f, shadowBias = -1.5f, highlightRoll = 0.08f;
        if ("PRO".equals(look)) {
            contrast = 1.055f; saturation = 1.035f; shadowBias = -2.0f; highlightRoll = 0.11f;
        } else if ("NAT GEO".equals(look)) {
            contrast = 1.075f; saturation = 1.07f; shadowBias = -2.5f; highlightRoll = 0.14f;
        }

        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            int a = (c >>> 24) & 255;
            float r = (c >>> 16) & 255;
            float g = (c >>> 8) & 255;
            float bl = c & 255;
            float y = 0.2126f * r + 0.7152f * g + 0.0722f * bl;

            float rr = y + (r - y) * saturation;
            float gg = y + (g - y) * saturation;
            float bb = y + (bl - y) * saturation;

            rr = (rr - 128f) * contrast + 128f;
            gg = (gg - 128f) * contrast + 128f;
            bb = (bb - 128f) * contrast + 128f;

            if (y < 96f) {
                float t = (96f - y) / 96f;
                rr += shadowBias * t; gg += shadowBias * t; bb += shadowBias * t;
            }
            if (y > 200f) {
                float t = (y - 200f) / 55f;
                float pull = 1f - highlightRoll * Math.min(1f, t);
                rr = 200f + (rr - 200f) * pull;
                gg = 200f + (gg - 200f) * pull;
                bb = 200f + (bb - 200f) * pull;
            }

            if ("NAT GEO".equals(look) && gg > rr * 1.08f && gg > bb * 1.08f) {
                gg = y + (gg - y) * 0.96f;
            }

            int ri = clamp(Math.round(rr));
            int gi = clamp(Math.round(gg));
            int bi = clamp(Math.round(bb));
            px[i] = (a << 24) | (ri << 16) | (gi << 8) | bi;
        }
        b.setPixels(px, 0, w, 0, 0, w, h);
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(v, 255); }
}
