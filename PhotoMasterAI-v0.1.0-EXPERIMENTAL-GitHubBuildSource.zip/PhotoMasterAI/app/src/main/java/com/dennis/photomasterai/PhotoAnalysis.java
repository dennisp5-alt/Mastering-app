package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Arrays;
import java.util.Locale;

public final class PhotoAnalysis {
    public final double meanLum;
    public final double medianLum;
    public final double p05;
    public final double p95;
    public final double p99;
    public final double shadowClip;
    public final double highlightClip;
    public final double avgR;
    public final double avgG;
    public final double avgB;
    public final double avgSat;
    public final double noise;
    public final double detail;
    public final double greenFraction;
    public final double blueTopFraction;
    public final int width;
    public final int height;

    private PhotoAnalysis(double meanLum, double medianLum, double p05, double p95, double p99,
                          double shadowClip, double highlightClip, double avgR, double avgG, double avgB,
                          double avgSat, double noise, double detail, double greenFraction, double blueTopFraction,
                          int width, int height) {
        this.meanLum = meanLum;
        this.medianLum = medianLum;
        this.p05 = p05;
        this.p95 = p95;
        this.p99 = p99;
        this.shadowClip = shadowClip;
        this.highlightClip = highlightClip;
        this.avgR = avgR;
        this.avgG = avgG;
        this.avgB = avgB;
        this.avgSat = avgSat;
        this.noise = noise;
        this.detail = detail;
        this.greenFraction = greenFraction;
        this.blueTopFraction = blueTopFraction;
        this.width = width;
        this.height = height;
    }

    public static PhotoAnalysis analyse(Bitmap source) {
        final int maxSide = 512;
        int w = source.getWidth();
        int h = source.getHeight();
        double scale = Math.min(1.0, maxSide / (double) Math.max(w, h));
        int sw = Math.max(2, (int) Math.round(w * scale));
        int sh = Math.max(2, (int) Math.round(h * scale));
        Bitmap small = (sw == w && sh == h) ? source : Bitmap.createScaledBitmap(source, sw, sh, true);

        int[] px = new int[sw * sh];
        small.getPixels(px, 0, sw, 0, 0, sw, sh);
        int[] hist = new int[256];
        long n = 0;
        double sumLum = 0, sumR = 0, sumG = 0, sumB = 0, sumSat = 0;
        double noiseSum = 0, edgeSum = 0;
        long shadow = 0, highlight = 0, green = 0, blueTop = 0, topCount = 0;
        float[] hsv = new float[3];

        for (int y = 0; y < sh; y++) {
            int row = y * sw;
            for (int x = 0; x < sw; x++) {
                int c = px[row + x];
                int r8 = Color.red(c), g8 = Color.green(c), b8 = Color.blue(c);
                double r = r8 / 255.0, g = g8 / 255.0, b = b8 / 255.0;
                double lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                int bin = Math.max(0, Math.min(255, (int) Math.round(lum * 255.0)));
                hist[bin]++;
                sumLum += lum;
                sumR += r;
                sumG += g;
                sumB += b;
                if (bin <= 3) shadow++;
                if (bin >= 252) highlight++;

                Color.RGBToHSV(r8, g8, b8, hsv);
                sumSat += hsv[1];

                if (g > r * 1.08 && g > b * 1.05 && g > 0.18) green++;
                if (y < sh / 3) {
                    topCount++;
                    if (b > r * 1.10 && b > g * 1.05 && b > 0.22) blueTop++;
                }

                if (x > 0) {
                    int l = px[row + x - 1];
                    double ll = luminance(l);
                    double d = Math.abs(lum - ll);
                    edgeSum += d;
                    if (d < 0.07) noiseSum += channelResidual(c, l);
                }
                if (y > 0) {
                    int u = px[row - sw + x];
                    double ul = luminance(u);
                    double d = Math.abs(lum - ul);
                    edgeSum += d;
                    if (d < 0.07) noiseSum += channelResidual(c, u);
                }
                n++;
            }
        }

        long[] cumulative = new long[256];
        long acc = 0;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            cumulative[i] = acc;
        }
        double median = percentile(cumulative, n, 0.50) / 255.0;
        double p05 = percentile(cumulative, n, 0.05) / 255.0;
        double p95 = percentile(cumulative, n, 0.95) / 255.0;
        double p99 = percentile(cumulative, n, 0.99) / 255.0;
        double pairCount = Math.max(1.0, (sw - 1.0) * sh + (sh - 1.0) * sw);
        double edge = edgeSum / pairCount;
        double noise = noiseSum / pairCount;

        if (small != source) small.recycle();

        return new PhotoAnalysis(
                sumLum / n, median, p05, p95, p99,
                shadow / (double) n, highlight / (double) n,
                sumR / n, sumG / n, sumB / n,
                sumSat / n, noise, edge,
                green / (double) n, blueTop / (double) Math.max(1L, topCount),
                w, h
        );
    }

    private static double luminance(int c) {
        return (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)) / 255.0;
    }

    private static double channelResidual(int a, int b) {
        double dr = Math.abs(Color.red(a) - Color.red(b)) / 255.0;
        double dg = Math.abs(Color.green(a) - Color.green(b)) / 255.0;
        double db = Math.abs(Color.blue(a) - Color.blue(b)) / 255.0;
        double chroma = Math.abs(dr - dg) + Math.abs(db - dg);
        return chroma * 0.5;
    }

    private static int percentile(long[] cumulative, long n, double p) {
        long target = Math.max(1, (long) Math.ceil(n * p));
        int i = Arrays.binarySearch(cumulative, target);
        if (i < 0) i = -i - 1;
        return Math.max(0, Math.min(255, i));
    }

    public String sceneSummary() {
        String light;
        if (medianLum < 0.22) light = "low-light/dark";
        else if (medianLum > 0.68) light = "bright";
        else light = "normal-light";
        String contrast = (p95 - p05 > 0.72) ? "high dynamic range" : ((p95 - p05 < 0.42) ? "low contrast" : "balanced contrast");
        String colour = greenFraction > 0.26 ? "foliage-rich" : (blueTopFraction > 0.30 ? "sky-rich" : "mixed colour");
        return light + ", " + contrast + ", " + colour;
    }

    public String compactMetrics() {
        return String.format(Locale.US,
                "Median %.2f | DR %.2f | clip S %.2f%% / H %.2f%% | sat %.2f | noise %.3f | detail %.3f",
                medianLum, (p95 - p05), shadowClip * 100.0, highlightClip * 100.0, avgSat, noise, detail);
    }
}
