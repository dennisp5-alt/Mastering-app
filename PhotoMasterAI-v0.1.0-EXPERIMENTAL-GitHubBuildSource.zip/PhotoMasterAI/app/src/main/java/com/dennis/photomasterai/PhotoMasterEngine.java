package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Locale;

public final class PhotoMasterEngine {

    public enum Mode { TRUE, PRO, NAT_GEO, LIFE }

    public static final class Result {
        public final Bitmap bitmap;
        public final String report;
        public final PhotoAnalysis outputAnalysis;

        Result(Bitmap bitmap, String report, PhotoAnalysis outputAnalysis) {
            this.bitmap = bitmap;
            this.report = report;
            this.outputAnalysis = outputAnalysis;
        }
    }

    private static final class Params {
        double exposureEv;
        double shadowLift;
        double highlightProtect;
        double contrast;
        double saturation;
        double vibrance;
        double gamma;
        double wbR;
        double wbG;
        double wbB;
        double denoise;
        double sharpen;
        double greenControl;
        double blueControl;
        boolean exposureActive;
        boolean wbActive;
        boolean toneActive;
        boolean denoiseActive;
        boolean sharpenActive;
        boolean colourActive;
    }

    private PhotoMasterEngine() { }

    public static Result master(Bitmap source, PhotoAnalysis a, Mode mode) {
        Params p = buildParams(a, mode);
        Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        renderChunked(source, out, p);

        PhotoAnalysis check = PhotoAnalysis.analyse(out);
        boolean highlightGuard = check.highlightClip > Math.max(a.highlightClip + 0.004, 0.012);
        boolean shadowGuard = check.shadowClip > Math.max(a.shadowClip + 0.008, 0.025);
        boolean saturationGuard = check.avgSat > 0.66 && check.avgSat > a.avgSat + 0.12;

        if (highlightGuard || shadowGuard || saturationGuard) {
            if (highlightGuard) {
                p.exposureEv -= 0.12;
                p.highlightProtect = Math.min(1.0, p.highlightProtect + 0.18);
            }
            if (shadowGuard) p.shadowLift = Math.min(1.0, p.shadowLift + 0.12);
            if (saturationGuard) {
                p.saturation = Math.min(p.saturation, 1.02);
                p.vibrance = Math.min(p.vibrance, 0.04);
            }
            out.recycle();
            out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            renderChunked(source, out, p);
            check = PhotoAnalysis.analyse(out);
        }

        String report = buildReport(a, check, p, mode, highlightGuard, shadowGuard, saturationGuard);
        return new Result(out, report, check);
    }

    private static Params buildParams(PhotoAnalysis a, Mode mode) {
        Params p = new Params();

        double targetMedian = 0.46;
        if (a.medianLum < 0.38 || a.medianLum > 0.60) {
            p.exposureEv = clamp(log2(targetMedian / Math.max(0.08, a.medianLum)), -0.65, 0.85);
            if (a.highlightClip > 0.004 || a.p99 > 0.975) p.exposureEv = Math.min(p.exposureEv, 0.35);
            p.exposureActive = Math.abs(p.exposureEv) >= 0.08;
        }

        p.shadowLift = clamp((0.10 - a.p05) * 4.0 + (0.34 - a.medianLum) * 0.55, 0.0, 0.62);
        p.highlightProtect = clamp((a.p99 - 0.90) * 4.5 + a.highlightClip * 12.0, 0.0, 0.78);
        p.toneActive = p.shadowLift > 0.04 || p.highlightProtect > 0.04 || (a.p95 - a.p05) < 0.48;

        double mean = (a.avgR + a.avgG + a.avgB) / 3.0;
        double rawR = mean / Math.max(0.05, a.avgR);
        double rawG = mean / Math.max(0.05, a.avgG);
        double rawB = mean / Math.max(0.05, a.avgB);
        double imbalance = Math.max(Math.abs(rawR - 1.0), Math.max(Math.abs(rawG - 1.0), Math.abs(rawB - 1.0)));
        double wbStrength = imbalance > 0.055 ? Math.min(0.72, 0.35 + imbalance * 1.8) : 0.0;
        if (a.greenFraction > 0.30) wbStrength *= 0.55;
        if (a.blueTopFraction > 0.34) wbStrength *= 0.72;
        p.wbR = 1.0 + (clamp(rawR, 0.90, 1.12) - 1.0) * wbStrength;
        p.wbG = 1.0 + (clamp(rawG, 0.92, 1.08) - 1.0) * wbStrength;
        p.wbB = 1.0 + (clamp(rawB, 0.90, 1.12) - 1.0) * wbStrength;
        p.wbActive = wbStrength > 0.01;

        p.denoise = clamp((a.noise - 0.010) * 7.5 + (0.26 - a.medianLum) * 0.24, 0.0, 0.28);
        p.denoiseActive = p.denoise > 0.035;

        double lowDetail = clamp((0.060 - a.detail) * 5.0, 0.0, 0.22);
        p.sharpen = clamp(0.035 + lowDetail - p.denoise * 0.20, 0.0, 0.18);
        p.sharpenActive = p.sharpen > 0.045;

        p.contrast = 1.0;
        if ((a.p95 - a.p05) < 0.46) p.contrast += 0.05;
        if ((a.p95 - a.p05) > 0.76) p.contrast -= 0.025;
        p.gamma = 1.0;
        p.saturation = 1.0;
        p.vibrance = 0.0;
        p.greenControl = 1.0;
        p.blueControl = 1.0;

        if (a.avgSat > 0.53) p.saturation *= 0.95;
        else if (a.avgSat < 0.25) p.vibrance += 0.045;

        switch (mode) {
            case TRUE:
                p.contrast *= 1.015;
                p.vibrance += 0.015;
                p.greenControl = 0.995;
                break;
            case PRO:
                p.contrast *= 1.035;
                p.vibrance += 0.045;
                p.saturation *= 1.010;
                p.sharpen = Math.min(0.20, p.sharpen + 0.025);
                break;
            case NAT_GEO:
                p.contrast *= 1.060;
                p.vibrance += 0.055;
                p.saturation *= 1.015;
                p.greenControl = 0.975;
                p.blueControl = 0.990;
                p.highlightProtect = Math.min(0.88, p.highlightProtect + 0.08);
                p.shadowLift = Math.min(0.70, p.shadowLift + 0.035);
                p.sharpen = Math.min(0.20, p.sharpen + 0.030);
                break;
            case LIFE:
                p.contrast *= 1.025;
                p.vibrance += 0.075;
                p.saturation *= 1.025;
                p.shadowLift = Math.min(0.70, p.shadowLift + 0.045);
                p.gamma = 0.995;
                p.sharpen = Math.min(0.20, p.sharpen + 0.018);
                break;
        }

        p.colourActive = p.wbActive || Math.abs(p.saturation - 1.0) > 0.008 || p.vibrance > 0.008
                || p.greenControl < 0.995 || p.blueControl < 0.995;
        return p;
    }

    private static void renderChunked(Bitmap src, Bitmap dst, Params p) {
        final int width = src.getWidth();
        final int height = src.getHeight();
        final int blockRows = 96;

        for (int y0 = 0; y0 < height; y0 += blockRows) {
            int rows = Math.min(blockRows, height - y0);
            int readTop = Math.max(0, y0 - 1);
            int readBottom = Math.min(height, y0 + rows + 1);
            int readRows = readBottom - readTop;
            int[] input = new int[width * readRows];
            int[] output = new int[width * rows];
            src.getPixels(input, 0, width, 0, readTop, width, readRows);

            for (int ry = 0; ry < rows; ry++) {
                int sy = y0 + ry;
                int localY = sy - readTop;
                for (int x = 0; x < width; x++) {
                    int idx = localY * width + x;
                    int c = input[idx];
                    double sourceR = Color.red(c) / 255.0;
                    double sourceG = Color.green(c) / 255.0;
                    double sourceB = Color.blue(c) / 255.0;
                    double r = sourceR;
                    double g = sourceG;
                    double b = sourceB;

                    double meanR = sourceR, meanG = sourceG, meanB = sourceB;
                    if (p.denoiseActive || p.sharpenActive) {
                        int x0 = Math.max(0, x - 1);
                        int x1 = Math.min(width - 1, x + 1);
                        int y0n = Math.max(0, localY - 1);
                        int y1n = Math.min(readRows - 1, localY + 1);
                        int cL = input[localY * width + x0];
                        int cR = input[localY * width + x1];
                        int cU = input[y0n * width + x];
                        int cD = input[y1n * width + x];
                        meanR = (sourceR + Color.red(cL) / 255.0 + Color.red(cR) / 255.0 + Color.red(cU) / 255.0 + Color.red(cD) / 255.0) / 5.0;
                        meanG = (sourceG + Color.green(cL) / 255.0 + Color.green(cR) / 255.0 + Color.green(cU) / 255.0 + Color.green(cD) / 255.0) / 5.0;
                        meanB = (sourceB + Color.blue(cL) / 255.0 + Color.blue(cR) / 255.0 + Color.blue(cU) / 255.0 + Color.blue(cD) / 255.0) / 5.0;
                    }

                    if (p.denoiseActive) {
                        double sourceLum = lum(r, g, b);
                        double meanLum = lum(meanR, meanG, meanB);
                        double delta = Math.abs(sourceLum - meanLum);
                        double edgeProtect = 1.0 - clamp(delta / 0.075, 0.0, 1.0);
                        double d = p.denoise * edgeProtect;
                        r = mix(r, meanR, d);
                        g = mix(g, meanG, d);
                        b = mix(b, meanB, d);
                    }

                    r *= p.wbR;
                    g *= p.wbG;
                    b *= p.wbB;

                    double y = lum(r, g, b);
                    double exp = Math.pow(2.0, p.exposureEv);
                    double tone = clamp(y * exp, 0.0, 1.25);

                    if (p.shadowLift > 0.0) {
                        double mask = Math.pow(1.0 - clamp(tone, 0.0, 1.0), 2.1);
                        tone += p.shadowLift * mask * 0.14;
                    }
                    if (p.highlightProtect > 0.0 && tone > 0.52) {
                        double t = clamp((tone - 0.52) / 0.48, 0.0, 1.3);
                        tone -= p.highlightProtect * t * t * 0.16;
                    }
                    tone = (tone - 0.5) * p.contrast + 0.5;
                    tone = Math.pow(clamp(tone, 0.0, 1.0), p.gamma);

                    double scale = y > 0.008 ? tone / y : 1.0;
                    r *= scale;
                    g *= scale;
                    b *= scale;

                    double gray = lum(r, g, b);
                    double max = Math.max(r, Math.max(g, b));
                    double min = Math.min(r, Math.min(g, b));
                    double chroma = clamp(max - min, 0.0, 1.0);
                    double vib = 1.0 + p.vibrance * (1.0 - chroma);
                    double sat = p.saturation * vib;
                    r = gray + (r - gray) * sat;
                    g = gray + (g - gray) * sat;
                    b = gray + (b - gray) * sat;

                    if (g > r * 1.06 && g > b * 1.03) g *= p.greenControl;
                    if (b > r * 1.08 && b > g * 1.03) b *= p.blueControl;

                    if (p.sharpenActive) {
                        r += p.sharpen * (sourceR - meanR);
                        g += p.sharpen * (sourceG - meanG);
                        b += p.sharpen * (sourceB - meanB);
                    }

                    int a = Color.alpha(c);
                    output[ry * width + x] = Color.argb(a,
                            to8(r), to8(g), to8(b));
                }
            }
            dst.setPixels(output, 0, width, 0, y0, width, rows);
        }
    }

    private static String buildReport(PhotoAnalysis before, PhotoAnalysis after, Params p, Mode mode,
                                      boolean hGuard, boolean sGuard, boolean satGuard) {
        StringBuilder sb = new StringBuilder();
        sb.append("SCENE\n").append(before.sceneSummary()).append("\n").append(before.compactMetrics()).append("\n\n");
        sb.append("REPAIRED / MASTERED\n");
        boolean any = false;
        if (p.exposureActive) {
            sb.append(String.format(Locale.US, "• Exposure %+.2f EV\n", p.exposureEv)); any = true;
        }
        if (p.wbActive) {
            sb.append(String.format(Locale.US, "• Colour cast correction R %.3f / G %.3f / B %.3f\n", p.wbR, p.wbG, p.wbB)); any = true;
        }
        if (p.shadowLift > 0.04) { sb.append("• Shadow recovery\n"); any = true; }
        if (p.highlightProtect > 0.04) { sb.append("• Highlight protection / roll-off\n"); any = true; }
        if (p.denoiseActive) { sb.append(String.format(Locale.US, "• Edge-protected noise reduction %.0f%%\n", p.denoise * 100)); any = true; }
        if (p.sharpenActive) { sb.append(String.format(Locale.US, "• Conservative detail finishing %.0f%%\n", p.sharpen * 100)); any = true; }
        if (p.colourActive) { sb.append("• Selective colour density / vibrance control\n"); any = true; }
        if (!any) sb.append("• No major technical repair required; finish only\n");
        sb.append("• Finish profile: ").append(modeName(mode)).append("\n");

        sb.append("\nCHANGE GUARD\n");
        if (hGuard || sGuard || satGuard) {
            if (hGuard) sb.append("• Highlight guard reduced processing\n");
            if (sGuard) sb.append("• Shadow guard reduced black clipping\n");
            if (satGuard) sb.append("• Saturation guard reduced colour intensity\n");
        } else {
            sb.append("• Output passed clipping and colour safety checks\n");
        }

        sb.append("\nOUTPUT QC\n").append(after.compactMetrics());
        sb.append("\n• Full-resolution render at working bitmap size\n");
        sb.append("• JPEG export quality: 100\n");
        return sb.toString();
    }

    private static String modeName(Mode mode) {
        switch (mode) {
            case PRO: return "PRO";
            case NAT_GEO: return "NAT GEO";
            case LIFE: return "LIFE";
            default: return "TRUE";
        }
    }

    private static double lum(double r, double g, double b) {
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    private static double mix(double a, double b, double t) { return a + (b - a) * t; }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double log2(double v) { return Math.log(v) / Math.log(2.0); }
    private static int to8(double v) { return (int) Math.round(clamp(v, 0.0, 1.0) * 255.0); }
}
