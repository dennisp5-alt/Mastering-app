# Dennis AI Mastering Lab — v0.9.1 handover

Handover date: 2026-08-27  
Owner: Dennis

## Authoritative build

- App: Dennis AI Mastering Lab v0.9.1 (`versionCode 11`)
- Package: `com.dennis.aimasteringlab`
- Minimum/target Android: API 29 / 34
- Signing certificate:
  `2d6822f2d6e3785a03bfe61d73d5139822c78c9b2dedbbc64aa0424ad44eff70`
- Internet access: none
- Install over v0.9.0 without uninstalling

Treat this source archive as authoritative. v0.9.1 keeps v0.9's offline source
guards, repair systems, optional reference and background service, but places
the complete v0.7 result back at the centre of the mastering decision.

## Essential behavior

1. Run the complete established v0.7 decision path.
2. Freeze its winner as the natural sonic reference.
3. Measure later specialist candidates independently.
4. Promote one only after a substantial technical win and explicit musical-
   preservation proof.
5. Keep translation response profiles diagnostic-only.
6. Fail with no winner if any required render is incomplete.

Both learned-profile controls start OFF in this release. Their historical data
is preserved for explicit use, but neutral mastering is deterministic across
devices and installs.

## Validation anchor

The exact selected v0.7 waveform hashes were reproduced for four real songs:
Never Give Up, Never Be Fancy, T-Bar Girls and The Corner Stage. Controlled
v0.7/v0.8/v0.9, continuity, source-integrity, stereo, stems, learned-profile
and background-state regressions passed. See `TEST_RESULTS.md`.

## Remaining device work

Install over v0.9.0 on the S23 Ultra, confirm both learned controls are OFF,
then compare v0.7 and v0.9.1 at matched level. Also test screen-off/background
operation, notification cancellation, document providers, playback and AAC.
