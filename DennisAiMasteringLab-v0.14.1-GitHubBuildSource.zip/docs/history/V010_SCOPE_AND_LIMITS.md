# v0.1.0 scope and honest limits

## Included

- 48 kHz stereo WAV input.
- Objective integrity, loudness, peak, dynamics and phase analysis.
- Offline learned section mapping and local anomaly inference.
- Offline whole-song feature learning.
- Two autonomous, bounded mastering plans.
- Deterministic hybrid AI/DSP rendering.
- 24-bit WAV output, exact loudness convergence when safely achievable and
  verified true-peak ceiling enforcement.
- Transparent reference and immediate in-app A/B switching.
- JSON evidence/report export.

## Not included yet

- A pretrained neural mastering model or NPU delegate.
- Reference-track style transfer.
- Automatic source separation.
- Supplied-stem and Vocal Humanity integration in this secondary app.
- AAC, MP3, SBC, device-response simulations or release ZIP creation.
- Automatic release promotion.
- Physical S23 Ultra interaction or playback validation before Dennis tests it.
- Record-label or definitive human A&R certification.

## Evidence classification

- Loudness, peaks, file properties, correlations, hashes and continuity checks
  are objective measurements made by the app's documented meters.
- AI problem labels and mastering plans are bounded perceptual inferences.
- No physical speaker or headphone listening is performed by the app.
- The true-peak meter is regression validated but is not an externally
  laboratory-certified commercial meter.

