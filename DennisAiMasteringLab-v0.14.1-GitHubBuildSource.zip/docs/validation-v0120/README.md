# Current v0.12 validation

full-gate.log records the complete host regression pass. signed-build.log verifies the delivered final APK. export-retry-check.txt and package-final.log record the checks after the final bounded retry change. claude/ and corner/ contain actual QC reports; independent *-external-checks.json files verify export formats, gapless duration, loudness and peaks with FFmpeg. Historical v0.11 logs elsewhere do not count as current tests. No human listening or Android device run is claimed.
