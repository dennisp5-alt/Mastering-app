package com.dennis.s23uaicamera;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import org.json.JSONObject;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v0.1.4 capture-baseline engine.
 *
 * The still path intentionally mirrors the known-good Auto+ S23U Daylight Lab APK:
 * logical camera 0, physical camera 5 binding, one 4080x3060-class YUV output,
 * in-app NV21/JPEG encoding, then MediaStore save.  AI analysis is kept out of the
 * Camera2 session until the reliable save path is proven on-device.
 */
public final class CameraEngine {
    public interface Listener {
        void onTelemetry(FrameAnalysis analysis, int faceCount, String activePhysicalId, float zoom, int appliedEvSteps);
        void onPhotoSaved(String message);
        void onError(String message, Throwable error);
    }

    private static final String LOGICAL_ID = "0";
    private static final String MAIN_PHYSICAL_ID = "5";

    private final Context context;
    private final TextureView textureView;
    private final Listener listener;
    private final CameraManager manager;
    private final ExecutorService processing = Executors.newSingleThreadExecutor();

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader captureReader;
    private Surface previewSurface;
    private CameraCharacteristics logicalCharacteristics;
    private CameraCharacteristics physicalCharacteristics;
    private Size captureSize = new Size(4080, 3060);
    private Size previewSize = new Size(1440, 1080);
    private boolean physicalBinding = true;
    private volatile boolean captureBusy = false;
    private volatile int captureGeneration = 0;

    // UI state retained for compatibility with the current Activity.
    private volatile boolean aiEnabled = true;
    private volatile boolean autoLevel = true;
    private volatile String look = "TRUE";
    private volatile float rollDeg = 0f;
    private volatile float motion = 0f;
    private volatile float requestedZoom = 1f;

    private final FrameAnalysis baselineAnalysis = new FrameAnalysis(0,0,0,0,0,24,.5f,.5f,0,"CAPTURE_BASELINE");

    public CameraEngine(Context context, TextureView textureView, Listener listener) {
        this.context = context.getApplicationContext();
        this.textureView = textureView;
        this.listener = listener;
        this.manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public void start() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("AutoPlusCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        openCamera();
    }

    public void stop() {
        Handler h = cameraHandler;
        if (h != null) h.post(this::closeCamera);
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(1000); } catch (InterruptedException ignored) {}
        }
        cameraThread = null;
        cameraHandler = null;
    }

    public void shutdown() {
        stop();
        processing.shutdown();
    }

    public void setZoom(float value) {
        requestedZoom = value;
        // Capture-baseline build is deliberately pinned to the proven 1x physical route.
        listener.onPhotoSaved("Capture baseline is locked to the S23U 1× main sensor");
    }
    public void setAiEnabled(boolean value) { aiEnabled = value; }
    public void setAutoLevel(boolean value) { autoLevel = value; }
    public void setLook(String value) { look = value; }
    public void setMotion(float value) { motion = value; }
    public void setRoll(float value) { rollDeg = value; }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        try {
            logicalCharacteristics = manager.getCameraCharacteristics(LOGICAL_ID);
            try {
                physicalCharacteristics = manager.getCameraCharacteristics(MAIN_PHYSICAL_ID);
            } catch (Exception ignored) {
                physicalCharacteristics = null;
            }
            chooseCaptureSize();
            manager.openCamera(LOGICAL_ID, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    camera = c;
                    listener.onPhotoSaved("Camera opened • preparing physical 5 route");
                    createSession(true);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    c.close(); camera = null;
                    notifyError("Camera disconnected", null);
                }
                @Override public void onError(CameraDevice c, int error) {
                    c.close(); camera = null;
                    notifyError("Camera open error " + error, null);
                }
            }, cameraHandler);
        } catch (Exception e) {
            notifyError("Unable to open camera", e);
        }
    }

    private void chooseCaptureSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] yuv = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    .getOutputSizes(ImageFormat.YUV_420_888);
            if (yuv == null || yuv.length == 0) return;
            Size best = null;
            for (Size s : yuv) {
                if (s.getWidth() == 4080 && s.getHeight() == 3060) { best = s; break; }
                if (best == null || (long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
            }
            if (best != null) captureSize = best;
        } catch (Exception ignored) {}
    }

    private void createSession(boolean bindPhysical) {
        if (camera == null || !textureView.isAvailable()) return;
        closeSessionOnly();
        physicalBinding = bindPhysical;
        try {
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            previewSize = choosePreviewSize();
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            refreshPreviewGeometry();
            previewSurface = new Surface(st);

            captureReader = ImageReader.newInstance(captureSize.getWidth(), captureSize.getHeight(), ImageFormat.YUV_420_888, 3);
            captureReader.setOnImageAvailableListener(this::onCaptureYuvAvailable, cameraHandler);

            OutputConfiguration previewOut = new OutputConfiguration(previewSurface);
            OutputConfiguration captureOut = new OutputConfiguration(captureReader.getSurface());
            if (bindPhysical) {
                previewOut.setPhysicalCameraId(MAIN_PHYSICAL_ID);
                captureOut.setPhysicalCameraId(MAIN_PHYSICAL_ID);
            }
            List<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(previewOut);
            outputs.add(captureOut);

            Executor executor = command -> {
                Handler h = cameraHandler;
                if (h != null) h.post(command);
            };
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR,
                    outputs,
                    executor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            if (camera == null) { s.close(); return; }
                            session = s;
                            try {
                                previewBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                previewBuilder.addTarget(previewSurface);
                                applyBaselineAuto(previewBuilder);
                                session.setRepeatingRequest(previewBuilder.build(), null, cameraHandler);
                                listener.onPhotoSaved((physicalBinding ? "Physical 5" : "Logical") +
                                        " route ready • " + captureSize.getWidth() + "×" + captureSize.getHeight());
                                listener.onTelemetry(baselineAnalysis, 0, physicalBinding ? MAIN_PHYSICAL_ID : "logical", 1f, 0);
                            } catch (Exception e) {
                                notifyError("Unable to start preview", e);
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            if (bindPhysical) {
                                listener.onPhotoSaved("Physical camera 5 rejected • trying logical 1× fallback");
                                createSession(false);
                            } else {
                                notifyError("Camera session configuration failed", null);
                            }
                        }
                    });
            camera.createCaptureSession(config);
        } catch (Exception e) {
            if (bindPhysical) {
                listener.onPhotoSaved("Physical route error • trying logical 1× fallback");
                createSession(false);
            } else {
                notifyError("Unable to create capture session", e);
            }
        }
    }

    private Size choosePreviewSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] sizes = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(SurfaceTexture.class);
            if (sizes != null) {
                for (Size s : sizes) if (s.getWidth() == 1440 && s.getHeight() == 1080) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1440) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1080) return s;
                if (sizes.length > 0) return sizes[0];
            }
        } catch (Exception ignored) {}
        return new Size(1440,1080);
    }

    private void applyBaselineAuto(CaptureRequest.Builder b) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        try { b.set(CaptureRequest.CONTROL_ZOOM_RATIO, 1.0f); } catch (Exception ignored) {}
        // Deliberately no OIS forcing, face detection, metering regions, AI EV, NR, or edge overrides here.
    }

    public void capture() {
        listener.onPhotoSaved("CAPTURE requested");
        Handler h = cameraHandler;
        if (h == null) {
            notifyError("Capture unavailable: camera thread is not running", null);
            return;
        }
        h.post(() -> {
            if (captureBusy) {
                listener.onPhotoSaved("Capture already in progress");
                return;
            }
            if (camera == null || session == null || captureReader == null) {
                notifyError("Capture unavailable: session/YUV output not ready", null);
                return;
            }
            captureBusy = true;
            final int gen = ++captureGeneration;
            listener.onPhotoSaved("Submitting 1× YUV still request…");
            try {
                CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(captureReader.getSurface());
                applyBaselineAuto(b);
                b.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
                session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
                        listener.onPhotoSaved("HAL capture completed • waiting for YUV frame…");
                    }
                    @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                        if (captureGeneration == gen) captureBusy = false;
                        notifyError("Still capture failed: reason " + failure.getReason(), null);
                    }
                    @Override public void onCaptureSequenceAborted(CameraCaptureSession s, int sequenceId) {
                        if (captureGeneration == gen) captureBusy = false;
                        notifyError("Still capture sequence aborted", null);
                    }
                }, cameraHandler);

                h.postDelayed(() -> {
                    if (captureBusy && captureGeneration == gen) {
                        captureBusy = false;
                        notifyError("Capture timed out before the YUV frame arrived", null);
                    }
                }, 8000);
            } catch (Exception e) {
                captureBusy = false;
                notifyError("Unable to submit still capture", e);
            }
        });
    }

    private void onCaptureYuvAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) {
                captureBusy = false;
                notifyError("YUV callback fired but no image was available", null);
                return;
            }
            final Image frame = image;
            image = null;
            captureBusy = false;
            final int orientation = jpegOrientation();
            final String mode = look;
            final boolean makeAi = aiEnabled;
            final boolean level = autoLevel;
            final float roll = rollDeg;
            listener.onPhotoSaved("YUV frame arrived • encoding JPEG…");

            processing.execute(() -> {
                try {
                    byte[] jpeg = YuvStillEncoder.encodeJpeg(frame, 100, orientation);
                    listener.onPhotoSaved(String.format(Locale.US, "JPEG encoded %.1f MB • writing MediaStore…", jpeg.length/1048576f));
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
                    String base = "AutoPlus_1x_baseline_" + stamp;
                    Uri ref = saveImage(base + "_REF.jpg", jpeg);
                    listener.onPhotoSaved("SAVED REF ✓  Pictures/AutoPlusAI");

                    if (makeAi) {
                        try {
                            byte[] processed = ImageProcessor.process(jpeg, mode, level, roll, orientation);
                            saveImage(base + "_AI.jpg", processed);
                            listener.onPhotoSaved("SAVED AI ✓  Pictures/AutoPlusAI");
                        } catch (Exception e) {
                            notifyError("Reference saved; AI processing failed", e);
                        }
                    }

                    try {
                        JSONObject d = new JSONObject();
                        d.put("version", "0.1.4-capture-baseline");
                        d.put("logicalCamera", LOGICAL_ID);
                        d.put("physicalCamera", physicalBinding ? MAIN_PHYSICAL_ID : JSONObject.NULL);
                        d.put("captureSize", captureSize.toString());
                        d.put("referenceUri", ref.toString());
                        d.put("requestedZoomBeforeBaselineLock", requestedZoom);
                        d.put("motion", motion);
                        saveJson(base + "_DIAG.json", d.toString(2));
                    } catch (Exception ignored) {}
                } catch (Exception e) {
                    notifyError("YUV encode/save failed", e);
                } finally {
                    try { frame.close(); } catch (Exception ignored) {}
                }
            });
        } catch (Exception e) {
            captureBusy = false;
            notifyError("Unable to acquire YUV frame", e);
        } finally {
            if (image != null) image.close();
        }
    }

    private Uri saveImage(String name, byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0) throw new IllegalArgumentException("JPEG byte array is empty");
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AutoPlusAI");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) throw new IllegalStateException("MediaStore insert returned null");
        boolean ok = false;
        try {
            try (OutputStream os = cr.openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("MediaStore stream returned null");
                os.write(bytes);
                os.flush();
            }
            ContentValues publish = new ContentValues();
            publish.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(uri, publish, null, null);
            ok = true;
            return uri;
        } finally {
            if (!ok) try { cr.delete(uri, null, null); } catch (Exception ignored) {}
        }
    }

    private Uri saveJson(String name, String text) throws Exception {
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, name);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AutoPlusAI");
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) return null;
        try (OutputStream os = cr.openOutputStream(uri)) {
            if (os == null) return null;
            os.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            os.flush();
        }
        ContentValues publish = new ContentValues();
        publish.put(MediaStore.Downloads.IS_PENDING, 0);
        cr.update(uri, publish, null, null);
        return uri;
    }

    private int jpegOrientation() {
        // Portrait-only Activity; S23U rear sensor is 90 degrees.
        return 90;
    }

    public void refreshPreviewGeometry() {
        if (textureView instanceof AspectTextureView) {
            ((AspectTextureView) textureView).setAspectRatio(3, 4);
        }
    }

    private void closeSessionOnly() {
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (captureReader != null) captureReader.close(); } catch (Exception ignored) {}
        try { if (previewSurface != null) previewSurface.release(); } catch (Exception ignored) {}
        session = null;
        captureReader = null;
        previewSurface = null;
        previewBuilder = null;
    }

    private void closeCamera() {
        closeSessionOnly();
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        camera = null;
        captureBusy = false;
    }

    private void notifyError(String message, Throwable error) {
        listener.onError(message, error);
    }
}
