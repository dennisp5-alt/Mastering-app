package com.s23u.procamera;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Rect;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.camera2.interop.Camera2Interop;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.FocusMeteringResult;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.core.ZoomState;
import androidx.camera.extensions.ExtensionMode;
import androidx.camera.extensions.ExtensionsManager;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class MainActivity extends ComponentActivity {
    private static final String VERSION = "0.1.0";
    private static final int CAMERA_PERMISSION_REQUEST = 701;
    private static final long SESSION_START_TIMEOUT_MS = 5000L;
    private static final String OUTPUT_FOLDER = Environment.DIRECTORY_DCIM
            + "/Analysis First Camera";
    private static final String STATE_MODE_TAG = "state_mode_tag";
    private static final String STATE_ZOOM = "state_zoom";
    private static final String STATE_FLASH = "state_flash";
    private static final String STATE_OPTICAL_LOCK = "state_optical_lock";
    private static final String STATE_BLUE_FINISH = "state_blue_finish";
    private static final String STATE_LAST_URI = "state_last_uri";

    private final List<ModeOption> modes = new ArrayList<>();
    private final ExecutorService metadataExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final LiveCameraState liveState = new LiveCameraState();

    private PreviewView previewView;
    private FocusRingView focusRing;
    private Spinner modeSpinner;
    private TextView statusText;
    private TextView metadataText;
    private TextView zoomText;
    private TextView lensText;
    private TextView smartText;
    private Button captureButton;
    private Button flashButton;
    private Button lastPhotoButton;
    private Button opticalLockButton;
    private Button blueFinishButton;

    private ProcessCameraProvider cameraProvider;
    private ExtensionsManager extensionsManager;
    private Camera boundCamera;
    private ImageCapture imageCapture;
    private ImageAnalysis imageAnalysis;
    private SceneAnalyzer sceneAnalyzer;
    private CameraHardwareMap hardwareMap;
    private ModeOption selectedMode;
    private ModeOption activeBoundMode;
    private ModeOption standardMode;
    private ModeOption hdrMode;
    private ModeOption nightMode;
    private float requestedZoom = 1.0f;
    private int flashMode = ImageCapture.FLASH_MODE_AUTO;
    private Uri lastSavedUri;
    private boolean deviceSupported;
    private boolean opticalLockEnabled = true;
    private boolean blueFinishEnabled;
    private boolean captureInProgress;
    private boolean cameraSessionReady;
    private boolean sessionActivationInProgress;
    private String activeOpticalGuardId;
    private String restoredModeTag = "SMART_AUTO";
    private int bindGeneration;
    private Runnable sessionTimeout;
    private long lastLiveUiPostMs;
    private long lastUserMeterMs;
    private long lastFaceMeterMs;
    private int analysisExposureIndex;

    private final CameraCaptureSession.CaptureCallback liveCaptureCallback =
            new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession session,
                                               CaptureRequest request,
                                               TotalCaptureResult result) {
                    liveState.update(result);
                    postLiveUiUpdate();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        restoreUiState(savedInstanceState);
        deviceSupported = DeviceGate.isGalaxyS23Ultra(Build.MANUFACTURER, Build.MODEL);
        buildInterface();

        if (!deviceSupported) {
            statusText.setText("Unsupported device: " + Build.MANUFACTURER + " " + Build.MODEL
                    + "\nThis experiment is locked to Galaxy S23 Ultra (SM-S918 variants).");
            captureButton.setEnabled(false);
            modeSpinner.setEnabled(false);
            return;
        }

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            initialiseCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST);
        }
    }

    private void restoreUiState(Bundle state) {
        if (state == null) return;
        restoredModeTag = state.getString(STATE_MODE_TAG, "SMART_AUTO");
        requestedZoom = state.getFloat(STATE_ZOOM, 1.0f);
        flashMode = state.getInt(STATE_FLASH, ImageCapture.FLASH_MODE_AUTO);
        opticalLockEnabled = state.getBoolean(STATE_OPTICAL_LOCK, true);
        blueFinishEnabled = state.getBoolean(STATE_BLUE_FINISH, false);
        String lastUri = state.getString(STATE_LAST_URI);
        if (lastUri != null && !lastUri.isEmpty()) lastSavedUri = Uri.parse(lastUri);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(STATE_MODE_TAG,
                selectedMode == null ? restoredModeTag : selectedMode.tag);
        outState.putFloat(STATE_ZOOM, requestedZoom);
        outState.putInt(STATE_FLASH, flashMode);
        outState.putBoolean(STATE_OPTICAL_LOCK, opticalLockEnabled);
        outState.putBoolean(STATE_BLUE_FINISH, blueFinishEnabled);
        if (lastSavedUri != null) outState.putString(STATE_LAST_URI, lastSavedUri.toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQUEST) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initialiseCamera();
        } else {
            statusText.setText("Camera permission is required. Reopen the app and grant access.");
            captureButton.setEnabled(false);
        }
    }

    private void buildInterface() {
        int background = Color.rgb(7, 17, 15);
        int surface = Color.rgb(16, 33, 29);
        int accent = Color.rgb(105, 222, 196);
        int text = Color.rgb(242, 246, 244);
        int muted = Color.rgb(183, 200, 194);
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        root.setPadding(dp(landscape ? 8 : 12), dp(8), dp(landscape ? 8 : 12),
                dp(landscape ? 8 : 10));
        root.setBackgroundColor(background);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("Analysis First Camera " + VERSION);
        title.setTextColor(text);
        title.setTextSize(landscape ? 18f : 21f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(landscape ? 36 : 42)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Analyse preview → choose capture plan → snap");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(landscape ? 11f : 13f);
        header.addView(subtitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(landscape ? 22 : 28)));

        modeSpinner = new Spinner(this);
        modeSpinner.setBackgroundColor(surface);
        header.addView(modeSpinner, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(landscape ? 44 : 50)));

        FrameLayout previewFrame = new FrameLayout(this);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        previewView.setBackgroundColor(Color.BLACK);
        previewFrame.addView(previewView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        focusRing = new FocusRingView(this);
        previewFrame.addView(focusRing, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        previewView.setOnTouchListener(this::handlePreviewTouch);

        LinearLayout lowerControls = new LinearLayout(this);
        lowerControls.setOrientation(LinearLayout.VERTICAL);

        LinearLayout zoomRow = new LinearLayout(this);
        zoomRow.setGravity(Gravity.CENTER);
        zoomText = new TextView(this);
        zoomText.setText(String.format(Locale.US, "Requested %.1f×", requestedZoom));
        zoomText.setTextColor(accent);
        zoomText.setGravity(Gravity.CENTER);
        zoomRow.addView(zoomText, new LinearLayout.LayoutParams(0, dp(42), 1.2f));
        addZoomButton(zoomRow, "0.6×", 0.6f);
        addZoomButton(zoomRow, "1×", 1.0f);
        addZoomButton(zoomRow, "3×", 3.0f);
        addZoomButton(zoomRow, "10×", 10.0f);
        lowerControls.addView(zoomRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));

        LinearLayout lensRow = new LinearLayout(this);
        lensRow.setGravity(Gravity.CENTER_VERTICAL);
        lensText = new TextView(this);
        lensText.setText("Live sensor: waiting for metadata");
        lensText.setTextColor(muted);
        lensText.setTextSize(landscape ? 10.5f : 12f);
        lensRow.addView(lensText, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 2.2f));
        opticalLockButton = makeButton(opticalLockEnabled
                ? "Optical lock ON" : "Optical lock OFF");
        opticalLockButton.setOnClickListener(v -> toggleOpticalLock());
        lensRow.addView(opticalLockButton, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        lowerControls.addView(lensRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(landscape ? 58 : 48)));

        LinearLayout smartRow = new LinearLayout(this);
        smartRow.setGravity(Gravity.CENTER_VERTICAL);
        smartText = new TextView(this);
        smartText.setText("Analysis First is reading the scene…");
        smartText.setTextColor(accent);
        smartText.setTextSize(landscape ? 10.5f : 12f);
        smartText.setPadding(dp(4), 0, dp(4), dp(2));
        smartRow.addView(smartText, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 2.2f));
        blueFinishButton = makeButton(blueFinishEnabled
                ? "Blue finish ON" : "Original JPEG");
        blueFinishButton.setOnClickListener(v -> toggleBlueFinish());
        smartRow.addView(blueFinishButton, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        lowerControls.addView(smartRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(landscape ? 46 : 42)));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setGravity(Gravity.CENTER);
        flashButton = makeButton(flashMode == ImageCapture.FLASH_MODE_ON ? "Flash ON"
                : flashMode == ImageCapture.FLASH_MODE_OFF ? "Flash OFF" : "Flash AUTO");
        flashButton.setOnClickListener(v -> cycleFlash());
        actionRow.addView(flashButton, new LinearLayout.LayoutParams(0, dp(56), 1f));

        captureButton = makeButton("ANALYSE + SNAP");
        captureButton.setTextColor(Color.BLACK);
        captureButton.setBackgroundColor(accent);
        captureButton.setEnabled(false);
        captureButton.setOnClickListener(v -> capturePhoto());
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(0, dp(56), 1.6f);
        captureParams.leftMargin = dp(8);
        captureParams.rightMargin = dp(8);
        actionRow.addView(captureButton, captureParams);

        lastPhotoButton = makeButton("Open last");
        lastPhotoButton.setEnabled(lastSavedUri != null);
        lastPhotoButton.setOnClickListener(v -> openLastPhoto());
        actionRow.addView(lastPhotoButton, new LinearLayout.LayoutParams(0, dp(56), 1f));
        lowerControls.addView(actionRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60)));

        statusText = new TextView(this);
        statusText.setText("Starting…");
        statusText.setTextColor(text);
        statusText.setTextSize(13f);
        statusText.setPadding(dp(4), dp(2), dp(4), dp(1));
        lowerControls.addView(statusText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        metadataText = new TextView(this);
        metadataText.setText("Photos save separately to DCIM/Analysis First Camera");
        metadataText.setTextColor(muted);
        metadataText.setTextSize(11f);
        metadataText.setPadding(dp(4), dp(1), dp(4), dp(1));
        lowerControls.addView(metadataText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        if (landscape) {
            LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            previewParams.rightMargin = dp(8);
            root.addView(previewFrame, previewParams);

            LinearLayout controlPanel = new LinearLayout(this);
            controlPanel.setOrientation(LinearLayout.VERTICAL);
            controlPanel.setPadding(dp(6), 0, dp(6), dp(4));
            controlPanel.addView(header, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            controlPanel.addView(lowerControls, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(true);
            scroll.setBackgroundColor(surface);
            scroll.addView(controlPanel, new ScrollView.LayoutParams(
                    ScrollView.LayoutParams.MATCH_PARENT,
                    ScrollView.LayoutParams.WRAP_CONTENT));
            root.addView(scroll, new LinearLayout.LayoutParams(
                    dp(340), LinearLayout.LayoutParams.MATCH_PARENT));
        } else {
            root.addView(header, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
            previewParams.topMargin = dp(6);
            previewParams.bottomMargin = dp(5);
            root.addView(previewFrame, previewParams);
            root.addView(lowerControls, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        setContentView(root);
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11f);
        button.setAllCaps(false);
        return button;
    }

    private void addZoomButton(LinearLayout row, String label, float zoom) {
        Button button = makeButton(label);
        button.setOnClickListener(v -> requestZoom(zoom));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(40), 0.7f);
        params.leftMargin = dp(2);
        row.addView(button, params);
    }

    private void initialiseCamera() {
        statusText.setText("Checking S23U physical lenses and OEM extensions…");
        try {
            hardwareMap = CameraHardwareMap.discover(this);
            metadataText.setText("Public lens map: " + hardwareMap.lensInventory());
        } catch (Exception error) {
            hardwareMap = null;
            metadataText.setText("Physical lens map unavailable: " + readableError(error)
                    + "\nLive focal-length verification remains active.");
        }

        sceneAnalyzer = new SceneAnalyzer(stats -> postLiveUiUpdate());
        ListenableFuture<ProcessCameraProvider> providerFuture =
                ProcessCameraProvider.getInstance(this);
        providerFuture.addListener(() -> {
            try {
                cameraProvider = providerFuture.get();
                ListenableFuture<ExtensionsManager> extensionFuture =
                        ExtensionsManager.getInstanceAsync(this, cameraProvider);
                extensionFuture.addListener(() -> {
                    try {
                        extensionsManager = extensionFuture.get();
                        populateModes();
                        bindSelectedMode();
                    } catch (Exception error) {
                        showFatal("OEM extension discovery failed", error);
                    }
                }, getMainExecutor());
            } catch (Exception error) {
                showFatal("Camera provider failed", error);
            }
        }, getMainExecutor());
    }

    private void populateModes() {
        modes.clear();
        modes.add(new ModeOption("Analysis First 0.1.0 — pre-capture planner", "SMART_AUTO",
                ModeOption.SMART_AUTO));
        standardMode = new ModeOption("Standard 1.0.0 control — unchanged", "STANDARD",
                ModeOption.STANDARD);
        modes.add(standardMode);
        addExtensionIfAvailable("OEM Auto — may alter faces", "OEM_AUTO", ExtensionMode.AUTO);
        hdrMode = addExtensionIfAvailable("OEM HDR — manual test", "OEM_HDR",
                ExtensionMode.HDR);
        nightMode = addExtensionIfAvailable("OEM Night — manual test", "OEM_NIGHT",
                ExtensionMode.NIGHT);
        addExtensionIfAvailable("OEM Bokeh — manual test", "OEM_BOKEH",
                ExtensionMode.BOKEH);

        ArrayAdapter<ModeOption> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, modes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(adapter);
        int restoredIndex = 0;
        for (int index = 0; index < modes.size(); index++) {
            if (modes.get(index).tag.equals(restoredModeTag)) {
                restoredIndex = index;
                break;
            }
        }
        selectedMode = modes.get(restoredIndex);
        modeSpinner.setSelection(restoredIndex, false);
        modeSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                               int position, long id) {
                        if (captureInProgress) return;
                        selectedMode = modes.get(position);
                        restoredModeTag = selectedMode.tag;
                        if (cameraProvider != null) bindSelectedMode();
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) { }
                });
        updateModeControlState();

        StringBuilder supported = new StringBuilder("Available: Analysis First · Standard");
        for (ModeOption mode : modes) {
            if (mode.usesOemExtension()) {
                supported.append(" · ").append(mode.tag.replace("OEM_", ""));
            }
        }
        String geometry = hardwareMap == null ? "firmware default"
                : hardwareMap.captureDistortionLabel().replace('_', ' ').toLowerCase(Locale.US);
        metadataText.setText(supported + "\nSmart geometry: " + geometry
                + " · Standard remains the untouched control path.");
    }

    private ModeOption addExtensionIfAvailable(String label, String tag, int extensionMode) {
        try {
            if (extensionsManager.isExtensionAvailable(
                    CameraSelector.DEFAULT_BACK_CAMERA, extensionMode)) {
                ModeOption option = new ModeOption(label, tag, extensionMode);
                modes.add(option);
                return option;
            }
        } catch (RuntimeException ignored) {
            // Unsupported or broken Samsung modes stay out of the selectable list.
        }
        return null;
    }

    private void bindSelectedMode() {
        bindCameraForMode(selectedMode, null);
    }

    private boolean bindCameraForMode(ModeOption mode, Runnable onReady) {
        if (cameraProvider == null || extensionsManager == null || mode == null) return false;
        int generation = ++bindGeneration;
        cameraSessionReady = false;
        sessionActivationInProgress = false;
        captureButton.setEnabled(false);
        statusText.setText("Binding " + mode.label + "…");
        cancelSessionTimeout();
        previewView.getPreviewStreamState().removeObservers(this);
        liveState.reset();

        boolean smartPreview = mode.isSmartAuto();
        String availablePhysicalId = smartPreview && hardwareMap != null
                ? hardwareMap.physicalIdForZoom(requestedZoom) : null;
        boolean guardEligible = ZoomRouting.shouldGuardOpticalLens(
                smartPreview, opticalLockEnabled, requestedZoom, availablePhysicalId);
        activeOpticalGuardId = guardEligible ? availablePhysicalId : null;

        try {
            cameraProvider.unbindAll();
            imageAnalysis = null;
            CameraSelector selector = CameraSelector.DEFAULT_BACK_CAMERA;
            if (mode.usesOemExtension()) {
                if (!extensionsManager.isExtensionAvailable(selector, mode.extensionMode)) {
                    throw new IllegalStateException("The selected OEM mode is no longer available");
                }
                selector = extensionsManager.getExtensionEnabledCameraSelector(
                        selector, mode.extensionMode);
            }

            int targetRotation = currentTargetRotation();

            Preview.Builder previewBuilder = new Preview.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setTargetRotation(targetRotation);
            Camera2Interop.Extender<Preview> previewInterop =
                    new Camera2Interop.Extender<>(previewBuilder);
            previewInterop.setSessionCaptureCallback(liveCaptureCallback);
            if (smartPreview && hardwareMap != null
                    && hardwareMap.previewDistortionMode >= 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.DISTORTION_CORRECTION_MODE,
                        hardwareMap.previewDistortionMode);
            }
            if (smartPreview && hardwareMap != null && hardwareMap.faceDetectionMode != 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.STATISTICS_FACE_DETECT_MODE,
                        hardwareMap.faceDetectionMode);
            }
            Preview preview = previewBuilder.build();
            preview.setSurfaceProvider(previewView.getSurfaceProvider());

            // Keep CameraX on its proven maximum 4:3 JPEG selection. An explicit
            // 4080x3060 target negotiated only 2992x2244 after rotation on the S23U.
            ImageCapture.Builder captureBuilder = new ImageCapture.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setTargetRotation(targetRotation)
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setFlashMode(flashMode);
            if (smartPreview) {
                if (hardwareMap != null && hardwareMap.captureDistortionMode >= 0) {
                    new Camera2Interop.Extender<>(captureBuilder).setCaptureRequestOption(
                            CaptureRequest.DISTORTION_CORRECTION_MODE,
                            hardwareMap.captureDistortionMode);
                }
            }
            imageCapture = captureBuilder.build();
            if (previewView.getDisplay() != null) {
                imageCapture.setTargetRotation(previewView.getDisplay().getRotation());
            }

            if (smartPreview) {
                ImageAnalysis.Builder analysisBuilder = new ImageAnalysis.Builder()
                        .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                        .setTargetRotation(targetRotation)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888);
                imageAnalysis = analysisBuilder.build();
                imageAnalysis.setAnalyzer(analysisExecutor, sceneAnalyzer);
                boundCamera = cameraProvider.bindToLifecycle(
                        this, selector, preview, imageCapture, imageAnalysis);
            } else {
                boundCamera = cameraProvider.bindToLifecycle(
                        this, selector, preview, imageCapture);
            }

            activeBoundMode = mode;
            boundCamera.getCameraInfo().getZoomState().removeObservers(this);
            boundCamera.getCameraInfo().getZoomState().observe(this,
                    this::showZoomState);
            previewView.getPreviewStreamState().observe(this, state -> {
                if (state == PreviewView.StreamState.STREAMING) {
                    completeBindingAfterStreaming(generation, mode, onReady);
                }
            });
            statusText.setText("Starting " + mode.label + " preview…");
            updateModeControlState();
            postLiveUiUpdate();
            sessionTimeout = () -> handleSessionStartTimeout(generation);
            mainHandler.postDelayed(sessionTimeout, SESSION_START_TIMEOUT_MS);
            return true;
        } catch (Exception error) {
            imageCapture = null;
            imageAnalysis = null;
            boundCamera = null;
            activeBoundMode = null;
            activeOpticalGuardId = null;
            cameraSessionReady = false;
            sessionActivationInProgress = false;
            captureInProgress = false;
            statusText.setText("Mode failed: " + mode.label + "\n"
                    + readableError(error) + "\nChoose Standard to continue.");
            return false;
        }
    }

    private void completeBindingAfterStreaming(int generation, ModeOption mode,
                                               Runnable onReady) {
        if (generation != bindGeneration || cameraSessionReady
                || sessionActivationInProgress || boundCamera == null) return;
        sessionActivationInProgress = true;
        requestZoomOnBoundCamera(requestedZoom, generation, () -> {
            if (generation != bindGeneration) return;
            sessionActivationInProgress = false;
            cameraSessionReady = true;
            cancelSessionTimeout();
            updateCaptureAvailability();
            if (mode.isSmartAuto()) {
                statusText.setText(activeOpticalGuardId == null
                        ? "Analysis First ready · analysing preview before every snap"
                        : String.format(Locale.US,
                        "Optical Lock checking the %.1f× lens · shutter opens when verified",
                        requestedZoom));
            } else {
                statusText.setText(mode.label + " ready · tap preview to focus");
            }
            updateModeControlState();
            postLiveUiUpdate();
            if (onReady != null) onReady.run();
        });
    }

    private void handleSessionStartTimeout(int generation) {
        if (generation != bindGeneration || cameraSessionReady) return;
        sessionActivationInProgress = false;
        captureInProgress = false;
        captureButton.setEnabled(false);
        statusText.setText("Camera preview did not become active · rotate back or select Standard");
        updateModeControlState();
    }

    private void cancelSessionTimeout() {
        if (sessionTimeout == null) return;
        mainHandler.removeCallbacks(sessionTimeout);
        sessionTimeout = null;
    }

    private boolean handlePreviewTouch(View view, MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP || boundCamera == null) return true;
        lastUserMeterMs = SystemClock.elapsedRealtime();
        focusRing.showAt(event.getX(), event.getY());
        MeteringPoint point = previewView.getMeteringPointFactory()
                .createPoint(event.getX(), event.getY());
        FocusMeteringAction action = new FocusMeteringAction.Builder(point,
                FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(4, TimeUnit.SECONDS)
                .build();
        ListenableFuture<FocusMeteringResult> focusFuture =
                boundCamera.getCameraControl().startFocusAndMetering(action);
        statusText.setText("Focusing and metering…");
        focusFuture.addListener(() -> {
            try {
                FocusMeteringResult result = focusFuture.get();
                statusText.setText(result.isFocusSuccessful()
                        ? "Focus confirmed" : "Focus completed without AF confirmation");
            } catch (Exception error) {
                statusText.setText("Focus request failed: " + readableError(error));
            }
        }, getMainExecutor());
        return true;
    }

    private void requestZoom(float wantedZoom) {
        if (captureInProgress) return;
        requestedZoom = wantedZoom;
        zoomText.setText(String.format(Locale.US, "Requested %.1f×", requestedZoom));
        String wantedGuardId = selectedMode != null && selectedMode.isSmartAuto()
                && hardwareMap != null ? hardwareMap.physicalIdForZoom(wantedZoom) : null;
        boolean wantsGuard = ZoomRouting.shouldGuardOpticalLens(
                selectedMode != null && selectedMode.isSmartAuto(), opticalLockEnabled,
                wantedZoom, wantedGuardId);
        String nextGuardId = wantsGuard ? wantedGuardId : null;
        boolean needsGuardRebind = !same(nextGuardId, activeOpticalGuardId);
        if (needsGuardRebind || !cameraSessionReady) {
            bindSelectedMode();
        } else {
            requestZoomOnBoundCamera(wantedZoom, bindGeneration, this::postLiveUiUpdate);
        }
    }

    private void requestZoomOnBoundCamera(float wantedZoom, int generation, Runnable onFinished) {
        if (boundCamera == null) {
            if (onFinished != null) onFinished.run();
            return;
        }
        ZoomState zoomState = boundCamera.getCameraInfo().getZoomState().getValue();
        float cameraRequest = ZoomRouting.cameraZoomRatio(wantedZoom);
        float applied = cameraRequest;
        if (zoomState != null) {
            applied = Math.max(zoomState.getMinZoomRatio(),
                    Math.min(zoomState.getMaxZoomRatio(), cameraRequest));
        }
        float finalApplied = applied;
        ListenableFuture<Void> zoomFuture =
                boundCamera.getCameraControl().setZoomRatio(applied);
        zoomFuture.addListener(() -> {
            if (generation != bindGeneration) return;
            try {
                zoomFuture.get();
                if (Math.abs(finalApplied - cameraRequest) > 0.01f) {
                    statusText.setText(String.format(Locale.US,
                            "Camera ratio %.1f× unavailable; applied %.1f×",
                            cameraRequest, finalApplied));
                }
            } catch (Exception error) {
                statusText.setText("Zoom rejected by this mode: " + readableError(error));
            } finally {
                if (onFinished != null) onFinished.run();
            }
        }, getMainExecutor());
    }

    private void showZoomState(ZoomState state) {
        if (state == null) return;
        zoomText.setText(activeOpticalGuardId == null
                ? String.format(Locale.US, "Requested %.1f× · active %.1f×",
                requestedZoom, state.getZoomRatio())
                : String.format(Locale.US,
                "Requested %.1f× · full-size optical guard · active %.1f×",
                requestedZoom, state.getZoomRatio()));
    }

    private void toggleOpticalLock() {
        if (captureInProgress) return;
        opticalLockEnabled = !opticalLockEnabled;
        opticalLockButton.setText(opticalLockEnabled ? "Optical lock ON" : "Optical lock OFF");
        if (selectedMode != null && selectedMode.isSmartAuto()) bindSelectedMode();
        else statusText.setText("Optical lock applies to Analysis First; Standard remains unchanged");
    }

    private void updateModeControlState() {
        boolean smart = selectedMode != null && selectedMode.isSmartAuto();
        opticalLockButton.setEnabled(smart && !captureInProgress);
        opticalLockButton.setAlpha(smart ? 1.0f : 0.55f);
        blueFinishButton.setEnabled(smart && !captureInProgress);
        blueFinishButton.setAlpha(smart ? 1.0f : 0.55f);
        smartText.setVisibility(smart ? View.VISIBLE : View.GONE);
        blueFinishButton.setVisibility(smart ? View.VISIBLE : View.GONE);
    }

    private void toggleBlueFinish() {
        if (captureInProgress || selectedMode == null || !selectedMode.isSmartAuto()) return;
        blueFinishEnabled = !blueFinishEnabled;
        blueFinishButton.setText(blueFinishEnabled ? "Blue finish ON" : "Original JPEG");
        statusText.setText(blueFinishEnabled
                ? "Optional blue finish ON · Smart JPEG may receive one Q100 re-encode"
                : "Original JPEG path restored · no Analysis First pixel re-encode");
    }

    private boolean opticalGuardRequired() {
        return selectedMode != null && selectedMode.isSmartAuto()
                && opticalLockEnabled && activeOpticalGuardId != null;
    }

    private boolean opticalGuardSatisfied() {
        if (!opticalGuardRequired()) return true;
        if (!liveState.isFresh()) return false;
        return OpticalVerification.matches(
                LensClassifier.expectedForZoom(requestedZoom),
                activeOpticalGuardId,
                liveState.physicalCameraId,
                LensClassifier.fromFocalLength(liveState.focalLengthMm));
    }

    private void updateCaptureAvailability() {
        captureButton.setEnabled(imageCapture != null && cameraSessionReady
                && !captureInProgress && opticalGuardSatisfied());
    }

    private boolean closeWideAnglePortraitRisk() {
        if (selectedMode == null || !selectedMode.isSmartAuto()
                || !liveState.isFresh() || liveState.largestFace == null
                || hardwareMap == null || hardwareMap.activeArray == null) return false;
        return PortraitGeometry.hasCloseWideAngleRisk(requestedZoom,
                liveState.largestFace.width(), hardwareMap.activeArray.width());
    }

    private void cycleFlash() {
        if (captureInProgress) return;
        if (flashMode == ImageCapture.FLASH_MODE_AUTO) {
            flashMode = ImageCapture.FLASH_MODE_OFF;
            flashButton.setText("Flash OFF");
        } else if (flashMode == ImageCapture.FLASH_MODE_OFF) {
            flashMode = ImageCapture.FLASH_MODE_ON;
            flashButton.setText("Flash ON");
        } else {
            flashMode = ImageCapture.FLASH_MODE_AUTO;
            flashButton.setText("Flash AUTO");
        }
        if (imageCapture != null) imageCapture.setFlashMode(flashMode);
        postLiveUiUpdate();
    }

    private void capturePhoto() {
        if (imageCapture == null || selectedMode == null || captureInProgress) return;
        if (!cameraSessionReady) {
            captureButton.setEnabled(false);
            statusText.setText("Camera is still starting · capture will unlock when preview is live");
            return;
        }
        if (!opticalGuardSatisfied()) {
            updateCaptureAvailability();
            statusText.setText("Optical Lock is waiting for "
                    + LensClassifier.expectedForZoom(requestedZoom)
                    + " · step back, add light, or turn Optical Lock OFF");
            return;
        }
        captureInProgress = true;
        captureButton.setEnabled(false);
        updateModeControlState();

        if (selectedMode.isSmartAuto()) {
            runAnalysisThenCapture(0);
        } else {
            performCapture(CaptureRecord.manual(selectedMode, requestedZoom));
        }
    }

    private void runAnalysisThenCapture(int attempt) {
        if (!captureInProgress || selectedMode == null || !selectedMode.isSmartAuto()) return;
        AnalysisFirstPlanner.Plan plan = currentAnalysisPlan();
        if (plan.waitForSettling && attempt < 4) {
            statusText.setText("Analysing scene · waiting for metering/focus to settle…");
            mainHandler.postDelayed(() -> runAnalysisThenCapture(attempt + 1), 160L);
            return;
        }

        ModeOption routeMode = routeMode(plan.decision.route);
        boolean perspectiveWarning = closeWideAnglePortraitRisk();
        String distortionCorrection = routeMode != null && routeMode.usesOemExtension()
                ? "OEM_CONTROLLED"
                : hardwareMap == null ? "FIRMWARE_DEFAULT"
                : hardwareMap.captureDistortionLabel();
        CaptureRecord record = CaptureRecord.smart(plan, requestedZoom,
                routeMode == null ? standardMode : routeMode,
                activeOpticalGuardId, opticalLockEnabled,
                perspectiveWarning, distortionCorrection, blueFinishEnabled);

        statusText.setText("Plan: " + plan.liveLabel());
        if (routeMode != null && routeMode.usesOemExtension()) {
            restoreAnalysisExposure();
            statusText.setText("Analysis selected " + plan.decision.route
                    + " · preparing Samsung extension…");
            boolean ready = bindCameraForMode(routeMode, () -> mainHandler.postDelayed(
                    () -> performCapture(record), 700L));
            if (!ready) recoverSmartCaptureAfterOemFailure(record);
            return;
        }
        applyAnalysisExposure(plan.exposureEv, () -> performCapture(record));
    }

    private ModeOption routeMode(SmartAutoEngine.Route route) {
        if (route == SmartAutoEngine.Route.HDR) return hdrMode;
        if (route == SmartAutoEngine.Route.NIGHT) return nightMode;
        return standardMode;
    }

    private void recoverSmartCaptureAfterOemFailure(CaptureRecord attemptedRecord) {
        CaptureRecord fallback = attemptedRecord.asStandardFallback();
        captureInProgress = true;
        statusText.setText("Samsung " + attemptedRecord.routeTag
                + " handoff failed · recovering with Standard");
        boolean recovered = bindCameraForMode(selectedMode, () -> mainHandler.postDelayed(
                () -> performCapture(fallback), 350L));
        if (!recovered) {
            captureInProgress = false;
            captureButton.setEnabled(false);
            statusText.setText("Analysis First recovery failed · select Standard and try again");
        }
    }

    private SmartAutoEngine.Decision currentSmartDecision() {
        return currentAnalysisPlan().decision;
    }

    private AnalysisFirstPlanner.Plan currentAnalysisPlan() {
        SceneStats scene = sceneAnalyzer == null ? SceneStats.UNAVAILABLE : sceneAnalyzer.latest();
        return AnalysisFirstPlanner.plan(scene, liveState,
                hdrMode != null, nightMode != null, requestedZoom,
                flashMode == ImageCapture.FLASH_MODE_ON);
    }

    private void applyAnalysisExposure(float wantedEv, Runnable onReady) {
        if (boundCamera == null || Math.abs(wantedEv) < 0.05f) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        androidx.camera.core.ExposureState state = boundCamera.getCameraInfo().getExposureState();
        if (state == null || !state.isExposureCompensationSupported()) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        float step = state.getExposureCompensationStep().floatValue();
        if (!(step > 0.0f)) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        android.util.Range<Integer> range = state.getExposureCompensationRange();
        int wantedIndex = Math.round(wantedEv / step);
        int targetIndex = Math.max(range.getLower(), Math.min(range.getUpper(), wantedIndex));
        analysisExposureIndex = targetIndex;
        ListenableFuture<Integer> future = boundCamera.getCameraControl()
                .setExposureCompensationIndex(targetIndex);
        future.addListener(() -> {
            try {
                future.get();
                mainHandler.postDelayed(() -> {
                    if (onReady != null) onReady.run();
                }, 240L);
            } catch (Exception ignored) {
                analysisExposureIndex = 0;
                if (onReady != null) onReady.run();
            }
        }, getMainExecutor());
    }

    private void restoreAnalysisExposure() {
        if (analysisExposureIndex == 0 || boundCamera == null) return;
        analysisExposureIndex = 0;
        try {
            androidx.camera.core.ExposureState state = boundCamera.getCameraInfo().getExposureState();
            if (state != null && state.isExposureCompensationSupported()) {
                boundCamera.getCameraControl().setExposureCompensationIndex(0);
            }
        } catch (RuntimeException ignored) { }
    }

    private void performCapture(CaptureRecord record) {
        if (imageCapture == null || !cameraSessionReady) {
            finishCaptureFailure("Capture mode was not ready", record);
            return;
        }
        statusText.setText("Capturing " + record.fileTag + "…");
        imageCapture.setTargetRotation(currentTargetRotation());

        String time = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String zoomTag = String.format(Locale.US, "%.1fX", record.zoom).replace('.', 'p');
        String filename = "ANALYSIS_FIRST_" + record.fileTag + "_" + zoomTag
                + "_Q100_" + time + ".jpg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, OUTPUT_FOLDER);
        ImageCapture.OutputFileOptions outputOptions =
                new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values).build();

        imageCapture.takePicture(outputOptions, getMainExecutor(),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults output) {
                        restoreAnalysisExposure();
                        Uri uri = output.getSavedUri();
                        if (uri == null) {
                            finishCaptureFailure("Saved, but Android returned no media URI", record);
                            return;
                        }
                        lastSavedUri = uri;
                        lastPhotoButton.setEnabled(true);
                        if (record.temporaryOemRoute) {
                            statusText.setText("Saved · restoring Analysis First preview…");
                            bindCameraForMode(selectedMode, null);
                        } else {
                            statusText.setText(record.smartAuto && record.blueFinishEnabled
                                    ? "Saved · applying optional blue finish…"
                                    : "Saved · preserving original JPEG and reading EXIF…");
                        }
                        metadataExecutor.execute(() -> processAndAnnotate(uri, filename, record));
                    }

                    @Override
                    public void onError(ImageCaptureException error) {
                        restoreAnalysisExposure();
                        finishCaptureFailure("Capture failed: " + readableError(error), record);
                    }
                });
    }

    private void processAndAnnotate(Uri uri, String filename, CaptureRecord record) {
        SmartBlueTamer.Result blue = SmartBlueTamer.Result.skipped(record.smartAuto
                ? "OFF · original JPEG preserved" : "Standard untouched");
        if (record.smartAuto && record.blueFinishEnabled) {
            try {
                blue = SmartBlueTamer.apply(getContentResolver(), uri, getCacheDir());
            } catch (Exception error) {
                blue = SmartBlueTamer.Result.skipped(
                        "blue control safely bypassed: " + readableError(error));
            }
        }
        inspectAndAnnotate(uri, filename, record, blue);
    }

    private void inspectAndAnnotate(Uri uri, String filename, CaptureRecord record,
                                    SmartBlueTamer.Result blue) {
        String result;
        try (ParcelFileDescriptor descriptor =
                     getContentResolver().openFileDescriptor(uri, "rw")) {
            if (descriptor == null) throw new IOException("No file descriptor");
            ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
            double focal = exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, Double.NaN);
            String actualLens = LensClassifier.fromFocalLength(focal);
            String expectedLens = LensClassifier.expectedForZoom(record.zoom);
            String iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
            String exposure = exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME);
            String aperture = exif.getAttribute(ExifInterface.TAG_F_NUMBER);
            int width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, -1);
            int height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, -1);
            if (width <= 0) {
                width = exif.getAttributeInt(ExifInterface.TAG_PIXEL_X_DIMENSION, -1);
            }
            if (height <= 0) {
                height = exif.getAttributeInt(ExifInterface.TAG_PIXEL_Y_DIMENSION, -1);
            }
            String outputSize = OutputResolution.dimensions(width, height);
            boolean outputKnown = width > 0 && height > 0;
            boolean fullSize = OutputResolution.isFullSize(width, height);
            String fullSizeState = outputKnown ? (fullSize ? "YES" : "NO") : "UNKNOWN";
            String guardState = record.opticalGuardId == null ? "NONE"
                    : "EXPECTED:" + record.opticalGuardId;
            String blueState = blue.applied
                    ? String.format(Locale.US, "APPLIED:%.2f%%", blue.affectedPercent)
                    : "BYPASS";
            String diagnostic = "Analysis First Camera " + VERSION
                    + " | MODE=" + record.fileTag
                    + " | ROUTE=" + record.routeTag
                    + " | REASON=" + record.reason
                    + String.format(Locale.US, " | PLAN_EV=%+.1f", record.plannedExposureEv)
                    + " | PROTECTION=" + record.analysisProtection
                    + String.format(Locale.US, " | REQUEST=%.1fX/%s", record.zoom, expectedLens)
                    + " | OPTICAL_GUARD=" + guardState
                    + String.format(Locale.US, " | CAMERA_RATIO=LOGICAL_%.1fX", record.zoom)
                    + String.format(Locale.US, " | ACTUAL=%s/%.2fmm", actualLens, focal)
                    + " | GEOMETRY=" + record.distortionCorrection
                    + (record.perspectiveWarning ? "+CLOSE_1X_WARNING" : "")
                    + " | OUTPUT=" + outputSize + " | FULL_SIZE=" + fullSizeState
                    + " | BLUE=" + blueState
                    + (record.smartAuto && record.blueFinishEnabled
                    ? " | PIXEL_PATH=OPTIONAL_Q100_REENCODE"
                    : " | PIXEL_PATH=ORIGINAL_JPEG")
                    + " | JPEG_Q=100_REQUEST";
            exif.setAttribute(ExifInterface.TAG_SOFTWARE, "Analysis First Camera " + VERSION);
            exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, diagnostic);
            exif.setAttribute(ExifInterface.TAG_USER_COMMENT, diagnostic);
            exif.saveAttributes();

            boolean fallback = !"UNKNOWN".equals(actualLens) && !actualLens.equals(expectedLens);
            result = "Saved " + filename + "\n"
                    + record.routeTag + " · " + record.reason
                    + String.format(Locale.US, " · plan EV %+.1f", record.plannedExposureEv)
                    + " · " + record.analysisProtection + "\n"
                    + "requested " + String.format(Locale.US, "%.1f×", record.zoom)
                    + " · actual " + actualLens + " "
                    + (Double.isFinite(focal) ? String.format(Locale.US, "%.2f mm", focal) : "")
                    + " · ISO " + safe(iso) + " · " + exposureLabel(exposure)
                    + " · f/" + safe(aperture)
                    + "\noutput " + outputSize + " · full-size target " + fullSizeState
                    + (record.smartAuto ? "\nBlue control: " + blue.detail : "")
                    + (record.perspectiveWarning
                    ? "\nCLOSE 1X PERSPECTIVE WARNING WAS ACTIVE" : "")
                    + (fallback ? "\nLENS FALLBACK DETECTED" : "")
                    + (outputKnown && !fullSize ? "\nOUTPUT BELOW 4080x3060 TARGET" : "");
        } catch (Exception error) {
            result = "Saved " + filename + "\nEXIF inspection failed: "
                    + readableError(error);
        }

        String finalResult = result;
        runOnUiThread(() -> {
            captureInProgress = false;
            statusText.setText("Capture complete");
            metadataText.setText(finalResult);
            updateCaptureAvailability();
            updateModeControlState();
            Toast.makeText(this, "Photo saved separately", Toast.LENGTH_SHORT).show();
        });
    }

    private void finishCaptureFailure(String message, CaptureRecord record) {
        restoreAnalysisExposure();
        captureInProgress = false;
        if (record != null && record.temporaryOemRoute && selectedMode != null) {
            bindCameraForMode(selectedMode, null);
        }
        statusText.setText(message);
        updateCaptureAvailability();
        updateModeControlState();
    }

    private void postLiveUiUpdate() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastLiveUiPostMs < 350L) return;
        lastLiveUiPostMs = now;
        runOnUiThread(this::updateLiveUi);
    }

    private void updateLiveUi() {
        if (!liveState.isFresh()) {
            updateCaptureAvailability();
            return;
        }
        String expected = LensClassifier.expectedForZoom(requestedZoom);
        String actual = liveState.actualLens(hardwareMap);
        boolean mismatch = !"UNKNOWN".equals(actual) && !expected.equals(actual);
        String focal = Float.isFinite(liveState.focalLengthMm)
                ? String.format(Locale.US, "%.2f mm", liveState.focalLengthMm) : "focal ?";
        String exposure = exposureLabelNs(liveState.exposureNs);
        StringBuilder lens = new StringBuilder("Live sensor: ")
                .append(actual).append(" · ").append(focal)
                .append(" · ISO ").append(liveState.iso > 0 ? liveState.iso : "?")
                .append(" · ").append(exposure);
        if (activeOpticalGuardId != null) {
            lens.append(" · guard ID ").append(activeOpticalGuardId);
        }
        if (liveState.physicalCameraId != null) {
            lens.append(" · active ID ").append(liveState.physicalCameraId);
        }
        if (opticalGuardRequired() && !opticalGuardSatisfied()) {
            lens.append("\nOptical Lock waiting for ").append(expected)
                    .append(" — step back, add light, or switch lock OFF");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (mismatch) {
            lens.append("\nLens fallback detected before capture");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (liveState.focusWarning() && "TELE_3X".equals(expected)) {
            lens.append("\n3× focus uncertain — step back or tap focus");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (closeWideAnglePortraitRisk()) {
            lens.append("\nClose 1× portrait can distort proportions — step back and use 3×");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else {
            lensText.setTextColor(Color.rgb(183, 200, 194));
        }
        lensText.setText(lens.toString());
        updateCaptureAvailability();

        if (selectedMode != null && selectedMode.isSmartAuto()) {
            AnalysisFirstPlanner.Plan plan = currentAnalysisPlan();
            SceneStats scene = sceneAnalyzer == null ? SceneStats.UNAVAILABLE : sceneAnalyzer.latest();
            String sceneText = scene.valid
                    ? String.format(Locale.US,
                    " · Y %.0f · range %d · shadows %.0f%% · highlights %.1f%% · settle %.0f%%",
                    scene.meanLuma, scene.tonalRange(), scene.shadowFraction * 100.0,
                    scene.highlightFraction * 100.0, scene.stabilityScore * 100.0)
                    : " · scene analysis settling";
            smartText.setText("Capture plan: " + plan.liveLabel() + sceneText
                    + (liveState.faceCount > 0 ? " · face AE active" : ""));
            maybeAutoMeterFace();
        }
    }

    private void maybeAutoMeterFace() {
        if (captureInProgress || !cameraSessionReady || boundCamera == null || selectedMode == null
                || !selectedMode.isSmartAuto() || liveState.largestFace == null
                || hardwareMap == null || hardwareMap.activeArray == null
                || previewView.getWidth() <= 0 || previewView.getHeight() <= 0) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastFaceMeterMs < 3500L || now - lastUserMeterMs < 6000L) return;

        Rect face = liveState.largestFace;
        Rect sensor = hardwareMap.activeArray;
        float nx = (face.exactCenterX() - sensor.left) / sensor.width();
        float ny = (face.exactCenterY() - sensor.top) / sensor.height();
        float[] viewPoint = CoordinateMapper.rotateSensorPoint(nx, ny,
                hardwareMap.sensorOrientation, displayRotationDegrees());
        MeteringPoint point = previewView.getMeteringPointFactory().createPoint(
                viewPoint[0] * previewView.getWidth(), viewPoint[1] * previewView.getHeight());
        FocusMeteringAction action = new FocusMeteringAction.Builder(
                point, FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build();
        lastFaceMeterMs = now;
        boundCamera.getCameraControl().startFocusAndMetering(action);
    }

    private int displayRotationDegrees() {
        int rotation = currentTargetRotation();
        if (rotation == Surface.ROTATION_90) return 90;
        if (rotation == Surface.ROTATION_180) return 180;
        if (rotation == Surface.ROTATION_270) return 270;
        return 0;
    }

    @SuppressWarnings("deprecation")
    private int currentTargetRotation() {
        if (previewView != null && previewView.getDisplay() != null) {
            return previewView.getDisplay().getRotation();
        }
        return getWindowManager().getDefaultDisplay().getRotation();
    }

    private void openLastPhoto() {
        if (lastSavedUri == null) return;
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(lastSavedUri, "image/jpeg");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(view);
        } catch (Exception error) {
            Toast.makeText(this, "No gallery app could open the photo", Toast.LENGTH_LONG).show();
        }
    }

    private void showFatal(String prefix, Exception error) {
        statusText.setText(prefix + ": " + readableError(error));
        captureButton.setEnabled(false);
    }

    private static String exposureLabel(String value) {
        if (value == null || value.isEmpty()) return "shutter unknown";
        try {
            return exposureLabelSeconds(Double.parseDouble(value));
        } catch (NumberFormatException ignored) {
            return value + " s";
        }
    }

    private static String exposureLabelNs(long nanoseconds) {
        if (nanoseconds <= 0L) return "shutter ?";
        return exposureLabelSeconds(nanoseconds / 1_000_000_000.0);
    }

    private static String exposureLabelSeconds(double seconds) {
        if (seconds > 0.0 && seconds < 1.0) {
            return "1/" + Math.max(1, Math.round(1.0 / seconds)) + " s";
        }
        return String.format(Locale.US, "%.2f s", seconds);
    }

    private static String safe(String value) {
        return value == null || value.isEmpty() ? "?" : value;
    }

    private static boolean same(String first, String second) {
        return first == null ? second == null : first.equals(second);
    }

    private static String readableError(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        String message = current.getMessage();
        return message == null || message.trim().isEmpty()
                ? current.getClass().getSimpleName() : message;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bindGeneration++;
        cancelSessionTimeout();
        mainHandler.removeCallbacksAndMessages(null);
        if (imageAnalysis != null) imageAnalysis.clearAnalyzer();
        analysisExecutor.shutdownNow();
        metadataExecutor.shutdownNow();
    }

    private static final class CaptureRecord {
        final String fileTag;
        final String routeTag;
        final String reason;
        final float zoom;
        final boolean smartAuto;
        final boolean temporaryOemRoute;
        final String opticalGuardId;
        final boolean perspectiveWarning;
        final String distortionCorrection;
        final boolean blueFinishEnabled;
        final float plannedExposureEv;
        final String analysisProtection;

        private CaptureRecord(String fileTag, String routeTag, String reason, float zoom,
                              boolean smartAuto, boolean temporaryOemRoute,
                              String opticalGuardId, boolean perspectiveWarning,
                              String distortionCorrection, boolean blueFinishEnabled,
                              float plannedExposureEv, String analysisProtection) {
            this.fileTag = fileTag;
            this.routeTag = routeTag;
            this.reason = reason;
            this.zoom = zoom;
            this.smartAuto = smartAuto;
            this.temporaryOemRoute = temporaryOemRoute;
            this.opticalGuardId = opticalGuardId;
            this.perspectiveWarning = perspectiveWarning;
            this.distortionCorrection = distortionCorrection;
            this.blueFinishEnabled = blueFinishEnabled;
            this.plannedExposureEv = plannedExposureEv;
            this.analysisProtection = analysisProtection;
        }

        static CaptureRecord smart(AnalysisFirstPlanner.Plan plan, float zoom,
                                   ModeOption routeMode, String opticalGuardId,
                                   boolean opticalLockEnabled, boolean perspectiveWarning,
                                   String distortionCorrection, boolean blueFinishEnabled) {
            String route = plan.decision.route.name();
            return new CaptureRecord("ANALYSIS_" + route, route, plan.reason,
                    zoom, true, routeMode != null && routeMode.usesOemExtension(),
                    opticalLockEnabled ? opticalGuardId : null,
                    perspectiveWarning, distortionCorrection, blueFinishEnabled,
                    plan.exposureEv, plan.protection);
        }

        static CaptureRecord manual(ModeOption mode, float zoom) {
            return new CaptureRecord(mode.tag, mode.tag, "manual control", zoom,
                    false, false, null, false, "STANDARD_UNCHANGED", false,
                    0.0f, "manual");
        }

        CaptureRecord asStandardFallback() {
            return new CaptureRecord("ANALYSIS_STANDARD_FALLBACK", "STANDARD_FALLBACK",
                    "Samsung " + routeTag + " handoff unavailable; safe Standard fallback",
                    zoom, true, false, opticalGuardId,
                    perspectiveWarning, distortionCorrection, blueFinishEnabled,
                    plannedExposureEv, analysisProtection);
        }
    }
}
