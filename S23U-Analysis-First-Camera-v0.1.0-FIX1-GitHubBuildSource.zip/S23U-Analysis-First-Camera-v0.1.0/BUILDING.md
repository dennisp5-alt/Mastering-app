# Building Analysis First Camera 0.1.0

Requirements: JDK 17, Android SDK 34 or newer, and Internet access for first Gradle dependency resolution.

From the project root:

```bash
./gradlew clean assembleDebug
```

Expected output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Project versions: Android Gradle Plugin 8.5.2, Gradle 8.7, CameraX 1.4.2.
The GitHub Actions workflow supplied with this project uses a persistent debug
signing key so later Analysis First Camera test builds can update in place.

Build fix 1: corrected Camera2Interop Preview generic type for CameraX 1.4.2 Java compilation.
