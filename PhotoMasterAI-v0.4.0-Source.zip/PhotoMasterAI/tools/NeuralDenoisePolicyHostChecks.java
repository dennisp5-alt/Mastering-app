package com.dennis.photomasterai;

public final class NeuralDenoisePolicyHostChecks {
    public static void main(String[] args) {
        NeuralDenoisePolicy.Decision clean = NeuralDenoisePolicy.decide(
                0.011, 0.020, 0.060, 12_000_000L, false, false, false, false);
        check(!clean.active, "clean/weak-noise image should not run neural denoise");

        NeuralDenoisePolicy.Decision noisy = NeuralDenoisePolicy.decide(
                0.020, 0.032, 0.040, 12_000_000L, false, false, false, false);
        check(noisy.active, "measured noisy image should run neural denoise");
        check(noisy.blend > 0.30 && noisy.blend <= 0.60, "AI Enhance blend must remain bounded");

        NeuralDenoisePolicy.Decision dark = NeuralDenoisePolicy.decide(
                0.025, 0.035, 0.030, 12_000_000L, true, false, true, false);
        check(!dark.active, "dark-field source must be protected");

        NeuralDenoisePolicy.Decision social = NeuralDenoisePolicy.decide(
                0.025, 0.035, 0.030, 2_000_000L, true, true, false, true);
        check(!social.active, "processed/social source must be protected");

        NeuralDenoisePolicy.Decision portrait = NeuralDenoisePolicy.decide(
                0.020, 0.032, 0.040, 12_000_000L, true, true, false, false);
        NeuralDenoisePolicy.Decision nonPortrait = NeuralDenoisePolicy.decide(
                0.020, 0.032, 0.040, 12_000_000L, true, false, false, false);
        check(portrait.active && portrait.blend < nonPortrait.blend,
                "person evidence should reduce neural blend strength");

        NeuralDenoisePolicy.Quality good = NeuralDenoisePolicy.evaluate(
                0.020, 0.032, 0.040, 0.30, 0.45, 0.60, 0.30, 0.01, 0.002,
                0.014, 0.023, 0.039, 0.30, 0.45, 0.60, 0.30, 0.009, 0.002,
                noisy);
        check(good.accepted, "beneficial detail-safe neural output should pass");

        NeuralDenoisePolicy.Quality detailLoss = NeuralDenoisePolicy.evaluate(
                0.020, 0.032, 0.040, 0.30, 0.45, 0.60, 0.30, 0.01, 0.002,
                0.014, 0.023, 0.033, 0.30, 0.45, 0.60, 0.30, 0.009, 0.002,
                noisy);
        check(!detailLoss.accepted, "large detail loss must roll neural output back");

        System.out.println("Neural denoise policy host checks passed");
    }

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
