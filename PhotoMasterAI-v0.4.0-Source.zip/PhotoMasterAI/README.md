# Photo Master AI v0.4.0 — Dark-Field + Social Source Guard

v0.4.0 is a narrow refinement of the v0.3.2 baseline.

## Dark-field fix

- adds relative-bright-subject evidence derived from the image histogram
- moon/stage/dark-field scenes no longer require near-white pixels to be recognised
- intentional black backgrounds receive 0 EV global lift and no shadow opening
- dark-field TRUE finishing cannot add vibrance, contrast or synthetic-looking colour
- aggressive repair/detail is withheld on these scenes

## Social / screenshot guard

- extreme ringing can identify already-processed/social sources even at higher resolution
- graphic/text/UI edges are not fed into halo-repair logic
- modest noise cleanup remains available
- detail recovery and sharpening pressure are reduced

The v0.3.2 exposure guard and full repair rollback remain intact.


## v0.4.0 true neural denoise

AI ENHANCE / AI MAX can now invoke a real NAFNet-SIDD-width32 LiteRT model when measured luma/chroma noise crosses the neural gate. The 62.5 MB fp16 model is hash-pinned and bundled into the APK at build time. Dark-field, social/already-processed and clean sources are excluded. Neural output is edge/person-aware blended, re-analysed, and rolled back before conventional finishing if noise benefit is insufficient or detail/ringing/tone regress.
