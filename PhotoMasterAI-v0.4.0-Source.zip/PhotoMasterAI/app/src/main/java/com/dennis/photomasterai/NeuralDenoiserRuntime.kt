package com.dennis.photomasterai

import android.content.Context
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.Environment
import com.google.ai.edge.litert.TensorBuffer

/**
 * Thin synchronous LiteRT 2.2 wrapper. MainActivity owns a single background
 * executor, so model creation and every inference remain on the same worker.
 */
class NeuralDenoiserRuntime(context: Context) : AutoCloseable {
    private val env: Environment = Environment.create(context)
    private val model: CompiledModel = CompiledModel.create(
        context.assets,
        MODEL_NAME,
        CompiledModel.Options(Accelerator.GPU),
        env
    )
    private val inputs: List<TensorBuffer> = model.createInputBuffers()
    private val outputs: List<TensorBuffer> = model.createOutputBuffers()

    val acceleratorLabel: String = "LiteRT GPU"

    fun run(input: FloatArray): FloatArray {
        require(input.size == ELEMENTS) { "NAFNet input must contain $ELEMENTS floats" }
        inputs[0].writeFloat(input)
        model.run(inputs, outputs)
        val out = outputs[0].readFloat()
        require(out.size >= ELEMENTS) { "NAFNet output had ${out.size} floats" }
        return out
    }

    override fun close() {
        inputs.forEach { it.close() }
        outputs.forEach { it.close() }
        model.close()
        env.close()
    }

    companion object {
        const val MODEL_NAME = "nafnet_sidd_width32_fp16.tflite"
        const val TILE = 256
        const val ELEMENTS = TILE * TILE * 3
    }
}
