package com.dennis.photomasterai;

/**
 * Android-free gate and QC policy for the first true neural restoration stage.
 * The neural model is deliberately noise-only: softness, ringing and JPEG damage
 * are still handled by the deterministic v0.3.3 safety baseline.
 */
public final class NeuralDenoisePolicy {

    public static final class Decision {
        public final boolean active;
        public final double noiseScore;
        public final double blend;
        public final double confidence;
        public final boolean personLike;
        public final String reason;

        Decision(boolean active, double noiseScore, double blend, double confidence,
                 boolean personLike, String reason) {
            this.active = active;
            this.noiseScore = clamp01(noiseScore);
            this.blend = clamp(blend, 0.0, 0.82);
            this.confidence = clamp01(confidence);
            this.personLike = personLike;
            this.reason = reason == null ? "" : reason;
        }
    }

    public static final class Quality {
        public final boolean accepted;
        public final double lumaBenefit;
        public final double chromaBenefit;
        public final double detailRatio;
        public final String reason;

        Quality(boolean accepted, double lumaBenefit, double chromaBenefit,
                double detailRatio, String reason) {
            this.accepted = accepted;
            this.lumaBenefit = lumaBenefit;
            this.chromaBenefit = chromaBenefit;
            this.detailRatio = detailRatio;
            this.reason = reason == null ? "" : reason;
        }
    }

    private NeuralDenoisePolicy() { }

    public static Decision decide(double noise, double flatChromaNoise, double detail,
                                  long pixels, boolean aiMax, boolean personLike,
                                  boolean darkField, boolean processedSource) {
        double baseNoise = smooth((noise - 0.010) / 0.020);
        double chromaNoise = smooth((flatChromaNoise - 0.010) / 0.030);
        double score = Math.max(baseNoise, chromaNoise);

        if (darkField) {
            return new Decision(false, score, 0.0, 1.0, personLike,
                    "dark-field / isolated-bright-subject protection");
        }
        if (processedSource) {
            return new Decision(false, score, 0.0, 1.0, personLike,
                    "already-processed / social-source protection");
        }
        if (pixels < 320L * 320L) {
            return new Decision(false, score, 0.0, 1.0, personLike,
                    "source too small for safe tiled neural restoration");
        }

        boolean strongNoise = noise >= (aiMax ? 0.0135 : 0.0150);
        boolean strongChroma = flatChromaNoise >= (aiMax ? 0.0215 : 0.0240);
        double threshold = aiMax ? 0.26 : 0.34;
        boolean justified = score >= threshold && (strongNoise || strongChroma);

        // Very obvious measured noise may enter even if one estimator is conservative.
        if (noise >= 0.021 || flatChromaNoise >= 0.031) justified = true;

        if (!justified) {
            return new Decision(false, score, 0.0, clamp01(0.45 + score * 0.45), personLike,
                    "measured noise below neural threshold; v0.3.3 repair remains sufficient");
        }

        double blend = (aiMax ? 0.72 : 0.58) * (0.76 + 0.24 * score);
        if (personLike) blend *= 0.84;
        if (detail >= 0.075) blend *= 0.92;
        if (detail <= 0.020 && score < 0.45) blend *= 0.90;
        blend = clamp(blend, aiMax ? 0.42 : 0.34, aiMax ? 0.74 : 0.60);

        double confidence = clamp01(0.58 + score * 0.42);
        return new Decision(true, score, blend, confidence, personLike,
                "measured real-image noise crossed the neural gate");
    }

    public static Quality evaluate(double beforeNoise, double beforeChroma, double beforeDetail,
                                   double beforeRinging, double beforeMedian, double beforeDr,
                                   double beforeSat, double beforeShadowClip, double beforeHighlightClip,
                                   double afterNoise, double afterChroma, double afterDetail,
                                   double afterRinging, double afterMedian, double afterDr,
                                   double afterSat, double afterShadowClip, double afterHighlightClip,
                                   Decision decision) {
        double lumaBenefit = beforeNoise > 0.0001
                ? (beforeNoise - afterNoise) / beforeNoise : 0.0;
        double chromaBenefit = beforeChroma > 0.0001
                ? (beforeChroma - afterChroma) / beforeChroma : 0.0;
        double detailRatio = beforeDetail > 0.0001 ? afterDetail / beforeDetail : 1.0;
        double bestBenefit = Math.max(lumaBenefit, chromaBenefit);

        boolean meaningful = (beforeNoise - afterNoise) >= 0.0006
                || (beforeChroma - afterChroma) >= 0.0012
                || bestBenefit >= 0.075;
        double minDetail = bestBenefit >= 0.25 ? 0.92 : (decision.personLike ? 0.95 : 0.935);
        boolean detailSafe = detailRatio >= minDetail;
        boolean ringingSafe = afterRinging <= beforeRinging + 0.025;
        boolean toneSafe = Math.abs(afterMedian - beforeMedian) <= 0.025
                && Math.abs(afterDr - beforeDr) <= 0.045
                && Math.abs(afterSat - beforeSat) <= 0.040;
        boolean clipSafe = afterHighlightClip <= beforeHighlightClip + 0.0035
                && afterShadowClip <= beforeShadowClip + 0.0060;
        boolean chromaNotWorse = afterChroma <= beforeChroma + 0.0015;
        boolean lumaNotWorse = afterNoise <= beforeNoise + 0.0012;

        if (!meaningful) {
            return new Quality(false, lumaBenefit, chromaBenefit, detailRatio,
                    "neural output did not produce a meaningful measured noise benefit");
        }
        if (!detailSafe) {
            return new Quality(false, lumaBenefit, chromaBenefit, detailRatio,
                    "neural output removed too much measured real detail");
        }
        if (!ringingSafe) {
            return new Quality(false, lumaBenefit, chromaBenefit, detailRatio,
                    "neural output increased ringing / halo evidence");
        }
        if (!toneSafe || !clipSafe) {
            return new Quality(false, lumaBenefit, chromaBenefit, detailRatio,
                    "neural output changed tone or clipping outside the denoise safety envelope");
        }
        if (!chromaNotWorse || !lumaNotWorse) {
            return new Quality(false, lumaBenefit, chromaBenefit, detailRatio,
                    "one noise channel regressed after neural processing");
        }
        return new Quality(true, lumaBenefit, chromaBenefit, detailRatio,
                "accepted by neural denoise QC");
    }

    private static double smooth(double x) {
        x = clamp01(x);
        return x * x * (3.0 - 2.0 * x);
    }

    private static double clamp01(double v) { return clamp(v, 0.0, 1.0); }
    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
