# Photo Master Natural v1.0

Standalone lightweight companion app based on the Photo Master AI v0.1.1 natural/repair engine.

Purpose:
- natural correction for already-good photographs
- fast, conservative, predictable processing
- no neural models
- no cloud processing
- no generative reconstruction

Preserved v0.1.1 rendering:
- TRUE / PRO / NAT GEO / LIFE
- confidence-gated exposure/tone correction
- neutral-reference white balance
- conservative denoise/detail finishing
- healthy-image preservation
- output change guards

Modern shell:
- separate package: com.dennis.photomasternatural
- installs alongside Photo Master AI
- Android 15 target / Android 16 compatible
- Photo Picker
- JPEG quality 100
- useful EXIF copy
- dedicated Photo Master Natural adaptive icon
- improved cast diagnostics that distinguish no cast from insufficient evidence while retaining v0.1.1 correction caps
