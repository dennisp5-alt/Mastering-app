package com.dennis.photomasterai;

public final class NaturalCastPolicyHostChecks {
    public static void main(String[] args) {
        NaturalCastPolicy a = NaturalCastPolicy.decide(0.05, 0.08, 0.90);
        require(a.status == NaturalCastPolicy.Status.INSUFFICIENT_EVIDENCE && a.cap == 0.0,
                "insufficient neutral evidence must never correct");

        NaturalCastPolicy b = NaturalCastPolicy.decide(0.90, 0.010, 0.90);
        require(b.status == NaturalCastPolicy.Status.NO_CAST && b.cap == 0.0,
                "balanced neutrals must be reported as no cast, not rejected");

        NaturalCastPolicy c = NaturalCastPolicy.decide(0.90, 0.040, 0.20);
        require(c.status == NaturalCastPolicy.Status.LOW_CONFIDENCE_CAST && c.cap == 0.0,
                "weak-confidence cast must be withheld");

        NaturalCastPolicy d = NaturalCastPolicy.decide(0.90, 0.050, 0.50);
        require(d.status == NaturalCastPolicy.Status.APPLY && Math.abs(d.cap - 0.015) < 1e-9,
                "mid-confidence correction must preserve v0.1.1 1.5% cap");

        NaturalCastPolicy e = NaturalCastPolicy.decide(0.95, 0.080, 0.90);
        require(e.status == NaturalCastPolicy.Status.APPLY && Math.abs(e.cap - 0.050) < 1e-9,
                "high-confidence correction must preserve v0.1.1 5% maximum cap");

        System.out.println("Photo Master Natural cast-policy checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
