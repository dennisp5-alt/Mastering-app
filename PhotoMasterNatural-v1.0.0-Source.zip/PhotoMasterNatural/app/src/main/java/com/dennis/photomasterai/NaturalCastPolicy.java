package com.dennis.photomasterai;

/**
 * Keeps the original v0.1.1 correction caps, but separates neutral evidence,
 * actual cast strength and cast confidence so "balanced" is not confused with
 * "insufficient evidence".
 */
public final class NaturalCastPolicy {
    public enum Status { INSUFFICIENT_EVIDENCE, NO_CAST, LOW_CONFIDENCE_CAST, APPLY }

    public final Status status;
    public final double cap;

    private NaturalCastPolicy(Status status, double cap) {
        this.status = status;
        this.cap = cap;
    }

    public static NaturalCastPolicy decide(double evidence, double strength, double confidence) {
        if (evidence < 0.10) return new NaturalCastPolicy(Status.INSUFFICIENT_EVIDENCE, 0.0);
        if (strength < 0.018) return new NaturalCastPolicy(Status.NO_CAST, 0.0);
        if (confidence < 0.35) return new NaturalCastPolicy(Status.LOW_CONFIDENCE_CAST, 0.0);
        if (confidence < 0.60) return new NaturalCastPolicy(Status.APPLY, 0.015);
        if (confidence < 0.80) return new NaturalCastPolicy(Status.APPLY, 0.030);
        return new NaturalCastPolicy(Status.APPLY, 0.050);
    }
}
