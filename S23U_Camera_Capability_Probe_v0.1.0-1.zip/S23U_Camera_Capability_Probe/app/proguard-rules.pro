# Capability probe: no shrinking rules required.
