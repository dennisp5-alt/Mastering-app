package com.dennis.s23ucameraprobe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 40;
    private static final int REQ_SAVE_JSON = 41;
    private static final int REQ_SAVE_TEXT = 42;

    private TextView status;
    private TextView report;
    private Button scanButton;
    private Button exportJsonButton;
    private Button exportTextButton;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String jsonResult;
    private String textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        report = findViewById(R.id.report);
        scanButton = findViewById(R.id.scanButton);
        exportJsonButton = findViewById(R.id.exportJsonButton);
        exportTextButton = findViewById(R.id.exportTextButton);

        scanButton.setOnClickListener(v -> ensurePermissionAndScan());
        exportJsonButton.setOnClickListener(v -> createDocument("application/json", "S23U_Camera_Capabilities.json", REQ_SAVE_JSON));
        exportTextButton.setOnClickListener(v -> createDocument("text/plain", "S23U_Camera_Capabilities.txt", REQ_SAVE_TEXT));
    }

    private void ensurePermissionAndScan() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            runScan();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private void runScan() {
        scanButton.setEnabled(false);
        exportJsonButton.setEnabled(false);
        exportTextButton.setEnabled(false);
        status.setText("Scanning Camera2 capabilities…");
        report.setText("Reading logical cameras, physical cameras, stream maps and OEM extensions.\nThis can take a few seconds.");

        executor.execute(() -> {
            try {
                CameraCapabilityProbe.Result result = CameraCapabilityProbe.run(this);
                jsonResult = result.json;
                textResult = result.text;
                runOnUiThread(() -> {
                    report.setText(textResult);
                    status.setText("Scan complete. Save BOTH files and upload them to the chat.");
                    exportJsonButton.setEnabled(true);
                    exportTextButton.setEnabled(true);
                    scanButton.setEnabled(true);
                });
            } catch (Throwable t) {
                runOnUiThread(() -> {
                    status.setText("Scan failed: " + t.getClass().getSimpleName());
                    report.setText(android.util.Log.getStackTraceString(t));
                    scanButton.setEnabled(true);
                });
            }
        });
    }

    private void createDocument(String type, String filename, int requestCode) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        i.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(i, requestCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                runScan();
            } else {
                status.setText("Camera permission is required to inspect the complete camera capability set.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        String payload = requestCode == REQ_SAVE_JSON ? jsonResult : textResult;
        if (payload == null) return;
        Uri uri = data.getData();
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Unable to open destination");
            out.write(payload.getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
