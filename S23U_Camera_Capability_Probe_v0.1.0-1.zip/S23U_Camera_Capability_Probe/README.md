# S23U Camera Capability Probe v0.1.0

Purpose: inspect the actual Camera2 and OEM Camera Extensions capabilities exposed by a Samsung Galaxy S23 Ultra before building the Auto+ AI Camera.

## Build
The included GitHub Actions workflow builds a debug APK. Push this project to a GitHub repository, open **Actions**, run **Build S23U Camera Probe APK**, then download the artifact.

## Run
1. Install the APK on the S23 Ultra.
2. Grant Camera permission.
3. Tap **RUN FULL CAMERA SCAN**.
4. Tap **SAVE JSON** and **SAVE REPORT**.
5. Upload both generated files back to ChatGPT.

The JSON is authoritative. It contains full stream configuration information and exposed vendor request/result key names. The TXT file is a compact summary for quick review.
