# AutoFix True Colour Lab v0.7.0

AutoFix True Colour Lab is a separate, fully offline Android experiment built on the proven AutoFix Histogram v1.3 correction path. It combines two independent choices:

- a **SAFE** or **LAB** colour base; and
- a **NATURAL** or **NATURE EDITORIAL** finish.

Every new photo starts with the automatic SAFE/LAB recommendation and the unchanged Natural finish. Nature Editorial is optional and can be applied to either colour base. The original is never modified.

The app uses deterministic image processing rather than generative AI. It has no network connection, training data, account, analytics, ads or cloud service.

## Nature Editorial finish

Nature Editorial is a restrained, camera-independent finish intended to evoke polished natural-history and travel photography without copying a particular publication's preset. It works on the already-corrected sRGB image, so Kodak scans, Lumix JPEGs, Samsung photos and files from other cameras use the same scene-adaptive logic.

The finishing stage adds:

- a gentle S-shaped tonal response for clearer midtone separation;
- broad luminance depth from a heavily smoothed low-resolution guide;
- selective vibrance rather than uniform saturation;
- extra protection for skin-like hues, foliage, blue skies and highly saturated colours;
- shadow, highlight and individual RGB-channel protection; and
- hue-preserving gamut compression before output.

The guide is deliberately too coarse to sharpen edges or create artificial clarity. Scene statistics automatically reduce the effect on low-key, high-key and already high-contrast images. The existing Correction strength control scales both the selected colour base and finish, and 0% remains an exact unchanged output.

Saved filenames record both choices, for example `TrueColour_LAB_NATURE_...jpg` or `TrueColour_SAFE_NATURAL_...jpg`.

## True Colour experiment

The colour engine compares five colour-constancy estimates:

- weighted low-chroma neutral evidence;
- weighted grey-world evidence;
- shades-of-grey evidence;
- bright low-chroma references; and
- a chromaticity-mode estimate.

At least three agreeing estimates, backed by independent estimator families, are required before the global LAB correction activates automatically. Low confidence, weak evidence, estimator disagreement and already-neutral colour all cause a safe hold.

An accepted illuminant estimate is converted to a Bradford chromatic-adaptation matrix and applied in linear sRGB toward D65. Confidence controls its strength. Equivalent global channel movement is capped at 12% and includes saturated-colour, likely-skin, highlight and gamut protection.

When regions independently support different illuminants, a softly overlapping 3×3 residual colour field can correct mixed light. Regional movement is smoothly blended and capped at 4.5% per channel.

## SAFE and LAB colour bases

- **SAFE** uses the complete proven AutoFix Histogram v1.3 colour and tone correction.
- **LAB** uses the experimental reconstruction plus the same proven tone, local-light and RGB-highlight protection.

The automatic recommendation remains selected when a photo opens. If strict LAB consensus was rejected but at least one usable estimate exists, **LAB preview** exposes a guarded audition marked **LAB\***. Its evidence is shown, global movement is limited to 8%, and all existing colour safeguards remain active. LAB is unavailable when the engine has no defensible candidate.

Changing SAFE/LAB does not change Natural/Nature Editorial. This makes four useful comparisons possible:

- SAFE + Natural;
- LAB + Natural;
- SAFE + Nature Editorial; and
- LAB + Nature Editorial.

## Safe fallback and status

True Colour is deliberately allowed to say no. SAFE retains the complete v1.3 correction path, including conservative RGB balance, overlapping 3×3 light balance, mixed-light restraint and RGB highlight protection.

The status card reports:

- **NATURE** — Nature Editorial is selected over the named SAFE, LAB or LAB\* base;
- **LAB** — the consensus reconstruction is active;
- **LAB\*** — a guarded, non-recommended LAB audition is selected;
- **SAFE** — the proven correction is selected;
- **READY** — the measured image is already balanced; or
- **OFF** — correction strength is 0%.

Correction details show both the colour-base decision and selected finish.

## App behaviour

- Installs beside AutoFix Histogram; it does not replace the stable app.
- Package: `com.dennis.autofixcolourlab`
- Version code 9; version name 0.7.2
- Minimum Android 10 / API 29; target API 34
- No Android permissions or internet capability
- Uses the Android photo/document picker and optional camera intent
- Copies save to `Pictures/AutoFix True Colour Lab`
- JPEG quality 100 with normalized sRGB output
- Safe camera, date, exposure and GPS EXIF fields are copied where Android permits
- EXIF orientation is rendered into the pixels and reset to normal
- Full save runs again from the source rather than enlarging the preview
- **Next photo** opens the picker after saving without a blocking confirmation

Normal 12 MP photos are processed at full resolution. Larger sources remain full resolution while memory allows and are reduced only when necessary to avoid an out-of-memory failure; the save result reports the actual dimensions. HDR gain maps, RAW data and 10-bit HEIC output are not retained because output is a compatible SDR JPEG.

## Important limitations

No algorithm can prove real-world colour from a finished JPEG without a calibrated reference, known illuminant or RAW sensor data. True Colour is therefore a guarded estimate, not scientific colourimetry.

Nature Editorial is an original descriptive mode, not an official National Geographic product, preset or affiliation. Its aim is a broadly useful natural-history editorial character while keeping the user's original and Natural rendering available.

## Build

The project uses Android platform APIs only and builds without Gradle or downloaded dependencies. It requires Java 17 with the `jdk.compiler` module and Android SDK platform/build-tools 34.

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
./build-apk.sh
```

The included key is for private testing, not Play Store production. The package and signer are unchanged from v0.2.0, so v0.7.0 installs directly over it.

## Verification

`run-tests.sh` performs 892 deterministic checks: 338 histogram/tone checks, 43 True Colour checks and 511 Nature Editorial checks. Coverage includes consensus and abstention, mixed-light bounds, exact 0% behavior, alpha preservation, neutral-axis preservation, saturated-red and highlight safety, protected skin/green/blue handling, low-key restraint, guide smoothness and a one-million-pixel benchmark.

Full-resolution rose and parrot trials showed modest controlled saturation gains with no exact luminance or red-channel clipping. The Natural renders of both supplied photos were byte-identical to v0.2.0, confirming that the new finish does not alter the default path.


### v0.7.2 cross-camera refinement
- Separates measurable `shaded / low-key` scenes from true night; darkness alone is never labelled night.
- Camera Character Recovery now uses more selective colour-rendering evidence and weak edge corroboration.
- Raises the CCR activation gate to reduce false positives on naturally vivid conventional-camera JPEGs.
- Keeps SAFE/True Colour, LAB, Image Integrity and Quality Guard architecture unchanged.
