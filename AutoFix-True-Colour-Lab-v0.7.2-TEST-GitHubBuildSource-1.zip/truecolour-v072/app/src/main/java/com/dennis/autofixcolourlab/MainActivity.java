package com.dennis.autofixcolourlab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A clean native Android shell for the deterministic colour and histogram engines.
 * No network permission, account, analytics, model or upload path is present.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_PICK_PHOTO = 1001;
    private static final int REQUEST_TAKE_PHOTO = 1002;

    private static final int NAVY = Color.rgb(16, 42, 67);
    private static final int BLUE = Color.rgb(0, 150, 154);
    private static final int BLUE_PRESSED = Color.rgb(0, 118, 123);
    private static final int SKY = Color.rgb(229, 249, 247);
    private static final int CANVAS = Color.rgb(247, 250, 252);
    private static final int WHITE = Color.WHITE;
    private static final int SLATE = Color.rgb(98, 125, 152);
    private static final int MUTED = Color.rgb(130, 154, 177);
    private static final int BORDER = Color.rgb(217, 229, 240);
    private static final int GREEN = Color.rgb(47, 180, 119);
    private static final int AMBER = Color.rgb(210, 126, 22);

    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private Uri sourceUri;
    private Uri pendingCameraUri;
    private Bitmap originalPreview;
    private Bitmap correctedPreview;
    private PhotoPipeline.CorrectionAnalysis analysis;
    private int correctionStrength = 100;
    private boolean useLabLook;
    private boolean useNatureEditorial;
    private boolean useDocumentaryEditorial;
    private boolean saveLosslessPng;
    private int workGeneration;
    private boolean editorVisible;
    private boolean busy;

    private ImageView previewView;
    private View processingOverlay;
    private TextView processingMessage;
    private TextView autoTitle;
    private TextView autoDescription;
    private TextView autoBadge;
    private TextView toneAnalysis;
    private TextView colourAnalysis;
    private LinearLayout analysisDetails;
    private TextView detailsToggle;
    private TextView strengthValue;
    private SeekBar strengthSeek;
    private TextView safeLookButton;
    private TextView labLookButton;
    private TextView naturalFinishButton;
    private TextView natureFinishButton;
    private TextView documentaryFinishButton;
    private TextView jpegOutputButton;
    private TextView pngOutputButton;
    private TextView finishAnalysis;
    private View applyButton;
    private TextView photosButton;
    private TextView resetButton;
    private TextView saveButton;
    private TextView saveStatus;
    private TextView compareButton;
    private boolean detailsExpanded;
    private boolean currentResultSaved;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        showHome();
    }

    private void configureWindow() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(NAVY);
        window.setNavigationBarColor(CANVAS);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void showHome() {
        editorVisible = false;
        busy = false;
        workGeneration++;
        releasePreviewBitmaps();
        sourceUri = null;
        analysis = null;
        useLabLook = false;
        useNatureEditorial = false;
        useDocumentaryEditorial = false;
        saveLosslessPng = false;
        currentResultSaved = false;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CANVAS);
        LinearLayout content = verticalLayout();
        content.setPadding(dp(22), dp(24), dp(22), dp(24));
        scroll.addView(content, matchWrap());

        LinearLayout brand = horizontalLayout();
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_brand_mark);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(54), dp(54));
        iconParams.rightMargin = dp(14);
        brand.addView(icon, iconParams);
        LinearLayout brandText = verticalLayout();
        brandText.addView(text("AutoFix True Colour Lab", 23, NAVY, true), matchWrap());
        TextView subtitle = text(
                "Experimental offline colour reconstruction", 13, SLATE, false);
        subtitle.setPadding(0, dp(3), 0, 0);
        brandText.addView(subtitle, matchWrap());
        brand.addView(brandText, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        content.addView(brand, matchWithBottom(34));

        LinearLayout startCard = verticalLayout();
        startCard.setPadding(dp(20), dp(20), dp(20), dp(20));
        startCard.setBackground(rounded(WHITE, 20, 1, BORDER));
        startCard.setElevation(dp(2));
        startCard.addView(text("Correct a photo", 22, NAVY, true), matchWithBottom(7));
        TextView intro = text(
                "Histogram correction with experimental true-colour consensus.",
                14, SLATE, false);
        intro.setLineSpacing(dp(3), 1.0f);
        startCard.addView(intro, matchWithBottom(22));

        TextView choose = actionButton("Choose a photo", true);
        choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchPhotoPicker();
            }
        });
        startCard.addView(choose, matchWithBottom(10));

        content.addView(startCard, matchWithBottom(20));

        TextView buildInfo = text("v0.7.2 TEST  •  Camera Character Recovery", 11, MUTED, false);
        buildInfo.setGravity(Gravity.CENTER);
        content.addView(buildInfo, matchWithBottom(10));

        TextView footer = text("EXPERIMENTAL  •  OFFLINE  •  ORIGINAL SAFE  •  COLOUR MANAGED",
                12, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer, matchWrap());

        setContentView(scroll);
    }

    private void showEditorShell() {
        editorVisible = true;
        detailsExpanded = false;

        LinearLayout root = verticalLayout();
        root.setBackgroundColor(CANVAS);

        LinearLayout header = horizontalLayout();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(2), dp(10), dp(2));
        header.setBackgroundColor(WHITE);
        header.setElevation(dp(2));
        photosButton = headerButton("Photos");
        photosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!busy) {
                    launchPhotoPicker();
                }
            }
        });
        header.addView(photosButton, new LinearLayout.LayoutParams(dp(64), dp(52)));

        TextView editorTitle = centeredText("True Colour Lab", 17, NAVY, true);
        header.addView(editorTitle, new LinearLayout.LayoutParams(0, dp(52), 1f));

        resetButton = headerButton("Reset");
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setCorrectionStrength(0, false);
            }
        });
        header.addView(resetButton, new LinearLayout.LayoutParams(dp(64), dp(52)));
        root.addView(header, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CANVAS);
        LinearLayout content = verticalLayout();
        content.setPadding(dp(16), dp(14), dp(16), dp(18));
        scroll.addView(content, matchWrap());

        FrameLayout imageFrame = new FrameLayout(this);
        imageFrame.setBackground(rounded(NAVY, 18, 0, 0));
        imageFrame.setClipToOutline(true);
        imageFrame.setElevation(dp(2));
        previewView = new ImageView(this);
        previewView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageFrame.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        processingOverlay = new LinearLayout(this);
        ((LinearLayout) processingOverlay).setOrientation(LinearLayout.VERTICAL);
        ((LinearLayout) processingOverlay).setGravity(Gravity.CENTER);
        processingOverlay.setBackgroundColor(Color.argb(185, 16, 42, 67));
        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(WHITE));
        ((LinearLayout) processingOverlay).addView(progress,
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        processingMessage = centeredText("Reading photo…", 13, WHITE, true);
        processingMessage.setPadding(dp(12), dp(12), dp(12), 0);
        ((LinearLayout) processingOverlay).addView(processingMessage, matchWrap());
        imageFrame.addView(processingOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int previewHeight = Math.min(dp(390), Math.max(
                dp(300), getResources().getDisplayMetrics().widthPixels - dp(32)));
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, previewHeight);
        imageParams.bottomMargin = dp(14);
        content.addView(imageFrame, imageParams);

        LinearLayout autoCard = horizontalLayout();
        autoCard.setGravity(Gravity.CENTER_VERTICAL);
        autoCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        autoCard.setBackground(stateRounded(WHITE, SKY, 16, BORDER));
        autoCard.setElevation(dp(1));
        applyButton = autoCard;
        autoBadge = centeredText("LAB", 10, WHITE, true);
        autoBadge.setLetterSpacing(0.08f);
        autoBadge.setBackground(rounded(BLUE, 99, 0, 0));
        autoCard.addView(autoBadge, new LinearLayout.LayoutParams(dp(52), dp(28)));
        LinearLayout applyTexts = verticalLayout();
        applyTexts.setPadding(dp(12), 0, dp(6), 0);
        autoTitle = text("Measuring photo…", 14, NAVY, true);
        autoDescription = text("Checking independent colour estimates", 12, SLATE, false);
        applyTexts.addView(autoTitle, matchWrap());
        applyTexts.addView(autoDescription, wrapWithTop(2));
        autoCard.addView(applyTexts, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        autoCard.addView(text("›", 25, MUTED, false), wrap());
        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int smartStrength = analysis == null
                        ? 100 : analysis.recommendedStrengthPercent;
                boolean selectionChanged = false;
                if (analysis != null && useLabLook != analysis.trueColourActive) {
                    useLabLook = analysis.trueColourActive;
                    selectionChanged = true;
                }
                if (useNatureEditorial) {
                    useNatureEditorial = false;
                    selectionChanged = true;
                }
                if (selectionChanged) {
                    markCurrentResultUnsaved();
                    updateLookControls();
                }
                setCorrectionStrength(smartStrength, true);
            }
        });
        content.addView(applyButton, matchWithBottom(12));

        LinearLayout lookCard = verticalLayout();
        lookCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        lookCard.setBackground(rounded(WHITE, 16, 1, BORDER));
        lookCard.setElevation(dp(1));
        TextView lookTitle = text("Preview and save", 13, NAVY, true);
        lookCard.addView(lookTitle, matchWithBottom(10));
        TextView baseLabel = text("Colour base", 11, SLATE, true);
        lookCard.addView(baseLabel, matchWithBottom(6));
        LinearLayout lookButtons = horizontalLayout();
        safeLookButton = lookButton("SAFE");
        safeLookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectLook(false);
            }
        });
        LinearLayout.LayoutParams safeParams = new LinearLayout.LayoutParams(
                0, dp(42), 1f);
        safeParams.rightMargin = dp(8);
        lookButtons.addView(safeLookButton, safeParams);
        labLookButton = lookButton("LAB preview");
        labLookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectLook(true);
            }
        });
        lookButtons.addView(labLookButton, new LinearLayout.LayoutParams(
                0, dp(42), 1f));
        lookCard.addView(lookButtons, matchWithBottom(11));

        TextView finishLabel = text("Finish", 11, SLATE, true);
        lookCard.addView(finishLabel, matchWithBottom(6));
        LinearLayout finishButtons = horizontalLayout();
        naturalFinishButton = lookButton("NATURAL");
        naturalFinishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectFinish(false);
            }
        });
        LinearLayout.LayoutParams naturalParams = new LinearLayout.LayoutParams(
                0, dp(42), 1f);
        naturalParams.rightMargin = dp(8);
        finishButtons.addView(naturalFinishButton, naturalParams);
        natureFinishButton = lookButton("NATURE EDITORIAL");
        natureFinishButton.setTextSize(12);
        natureFinishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectFinish(true);
            }
        });
        finishButtons.addView(natureFinishButton, new LinearLayout.LayoutParams(
                0, dp(42), 1f));
        documentaryFinishButton = lookButton("NAT GEO");
        documentaryFinishButton.setTextSize(12);
        documentaryFinishButton.setOnClickListener(v -> selectDocumentaryFinish());
        LinearLayout.LayoutParams docParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        docParams.leftMargin = dp(8);
        finishButtons.addView(documentaryFinishButton, docParams);
        lookCard.addView(finishButtons, matchWithBottom(11));
        TextView outputLabel = text("Output", 11, SLATE, true);
        lookCard.addView(outputLabel, matchWithBottom(6));
        LinearLayout outputButtons = horizontalLayout();
        jpegOutputButton = lookButton("JPEG 100");
        jpegOutputButton.setOnClickListener(v -> selectOutput(false));
        LinearLayout.LayoutParams jpegParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        jpegParams.rightMargin = dp(8);
        outputButtons.addView(jpegOutputButton, jpegParams);
        pngOutputButton = lookButton("PNG LOSSLESS");
        pngOutputButton.setOnClickListener(v -> selectOutput(true));
        outputButtons.addView(pngOutputButton, new LinearLayout.LayoutParams(0, dp(42), 1f));
        lookCard.addView(outputButtons, matchWrap());
        content.addView(lookCard, matchWithBottom(12));

        LinearLayout strengthCard = verticalLayout();
        strengthCard.setPadding(dp(14), dp(13), dp(14), dp(9));
        strengthCard.setBackground(rounded(WHITE, 16, 1, BORDER));
        strengthCard.setElevation(dp(1));
        LinearLayout strengthHeader = horizontalLayout();
        strengthHeader.setGravity(Gravity.CENTER_VERTICAL);
        strengthHeader.addView(text("Correction strength", 14, NAVY, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        strengthValue = text("100%", 14, BLUE, true);
        strengthHeader.addView(strengthValue, wrap());
        strengthCard.addView(strengthHeader, matchWrap());
        strengthSeek = new SeekBar(this);
        strengthSeek.setMax(100);
        strengthSeek.setProgress(correctionStrength);
        strengthSeek.setProgressTintList(ColorStateList.valueOf(BLUE));
        strengthSeek.setThumbTintList(ColorStateList.valueOf(BLUE));
        strengthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                strengthValue.setText(progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                setCorrectionStrength(seekBar.getProgress(), true);
            }
        });
        strengthCard.addView(strengthSeek, matchWithTop(4));
        content.addView(strengthCard, matchWithBottom(12));

        LinearLayout detailsCard = verticalLayout();
        detailsCard.setBackground(rounded(WHITE, 16, 1, BORDER));
        detailsCard.setElevation(dp(1));
        LinearLayout detailsHeader = horizontalLayout();
        detailsHeader.setGravity(Gravity.CENTER_VERTICAL);
        detailsHeader.setPadding(dp(14), dp(14), dp(14), dp(14));
        detailsHeader.addView(text("Correction details", 14, NAVY, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        detailsToggle = text("Show", 13, BLUE, true);
        detailsHeader.addView(detailsToggle, wrap());
        detailsCard.addView(detailsHeader, matchWrap());

        analysisDetails = verticalLayout();
        analysisDetails.setPadding(dp(14), 0, dp(14), dp(14));
        toneAnalysis = text("Reading luminance histogram…", 12, NAVY, true);
        toneAnalysis.setLineSpacing(dp(3), 1f);
        colourAnalysis = text("Finding reliable neutral colour evidence…", 12, SLATE, false);
        colourAnalysis.setPadding(0, dp(8), 0, 0);
        colourAnalysis.setLineSpacing(dp(3), 1f);
        finishAnalysis = text("Finish: Natural", 12, SLATE, false);
        finishAnalysis.setPadding(0, dp(8), 0, 0);
        finishAnalysis.setLineSpacing(dp(3), 1f);
        analysisDetails.addView(toneAnalysis, matchWrap());
        analysisDetails.addView(colourAnalysis, matchWrap());
        analysisDetails.addView(finishAnalysis, matchWrap());
        analysisDetails.setVisibility(View.GONE);
        detailsCard.addView(analysisDetails, matchWrap());
        detailsHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                detailsExpanded = !detailsExpanded;
                analysisDetails.setVisibility(detailsExpanded ? View.VISIBLE : View.GONE);
                detailsToggle.setText(detailsExpanded ? "Hide" : "Show");
            }
        });
        content.addView(detailsCard, matchWithBottom(12));

        saveStatus = centeredText("JPEG 100  •  Original preserved",
                11, MUTED, true);
        content.addView(saveStatus, matchWithBottom(4));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bottomBar = horizontalLayout();
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(dp(16), dp(10), dp(16), dp(10));
        bottomBar.setBackgroundColor(WHITE);
        bottomBar.setElevation(dp(12));

        compareButton = actionButton("Hold original", false);
        compareButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (busy || originalPreview == null) {
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    previewView.setImageBitmap(originalPreview);
                    compareButton.setText("Original");
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP
                        || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    previewView.setImageBitmap(currentDisplayBitmap());
                    compareButton.setText("Hold original");
                    return true;
                }
                return true;
            }
        });
        LinearLayout.LayoutParams compareLayout = new LinearLayout.LayoutParams(0, dp(54), 1f);
        compareLayout.rightMargin = dp(10);
        bottomBar.addView(compareButton, compareLayout);

        saveButton = actionButton("Save copy", true);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleSaveOrNext();
            }
        });
        bottomBar.addView(saveButton, new LinearLayout.LayoutParams(0, dp(54), 1.25f));
        root.addView(bottomBar, matchWrap());

        setContentView(root);
        setBusy(true, "Reading photo…");
    }

    private void loadPhoto(final Uri uri) {
        sourceUri = uri;
        correctionStrength = 100;
        useNatureEditorial = false;
        saveLosslessPng = false;
        currentResultSaved = false;
        final int generation = ++workGeneration;
        releasePreviewBitmaps();
        showEditorShell();
        setBusy(true, "Measuring light and colour consensus…");

        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final PhotoPipeline.DecodedBitmap decoded = PhotoPipeline.decodePreview(
                            MainActivity.this, uri);
                    final PhotoPipeline.CorrectionAnalysis measured =
                            PhotoPipeline.analyse(decoded.bitmap);
                    final int smartStrength = measured.recommendedStrengthPercent;
                    final boolean smartLabLook = measured.trueColourActive;
                    final Bitmap rendered = smartStrength == 0
                            ? null
                            : PhotoPipeline.renderPreview(
                                    decoded.bitmap, measured, smartStrength, smartLabLook);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation != workGeneration || !editorVisible) {
                                decoded.bitmap.recycle();
                                if (rendered != null) {
                                    rendered.recycle();
                                }
                                return;
                            }
                            originalPreview = decoded.bitmap;
                            correctedPreview = rendered;
                            analysis = measured;
                            correctionStrength = smartStrength;
                            useLabLook = smartLabLook;
                            strengthSeek.setProgress(correctionStrength);
                            strengthValue.setText(correctionStrength + "%");
                            previewView.setImageBitmap(currentDisplayBitmap());
                            updateLookControls();
                            updateAnalysisUi();
                            setBusy(false, null);
                        }
                    });
                } catch (final Throwable failure) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation != workGeneration) {
                                return;
                            }
                            showHome();
                            showError("Photo unavailable", readableError(failure));
                        }
                    });
                }
            }
        });
    }

    private void setCorrectionStrength(final int requestedStrength, boolean render) {
        if (analysis == null || originalPreview == null || busy) {
            return;
        }
        int boundedStrength = Math.max(0, Math.min(100, requestedStrength));
        if (boundedStrength != correctionStrength) {
            markCurrentResultUnsaved();
        }
        correctionStrength = boundedStrength;
        strengthSeek.setProgress(correctionStrength);
        strengthValue.setText(correctionStrength + "%");

        if (correctionStrength == 0) {
            workGeneration++;
            previewView.setImageBitmap(originalPreview);
            if (analysis.alreadyBalanced) {
                setAutoBadge("READY", GREEN);
                autoTitle.setText("Already balanced");
                autoDescription.setText("No correction needed");
            } else {
                setAutoBadge("OFF", SLATE);
                autoTitle.setText("Correction off");
                autoDescription.setText("Tap to restore the smart result");
            }
            return;
        }

        if (!render) {
            return;
        }
        final int generation = ++workGeneration;
        final int strength = correctionStrength;
        final boolean labLook = useLabLook;
        final boolean natureEditorial = useNatureEditorial;
        final boolean documentaryEditorial = useDocumentaryEditorial;
        final Bitmap source = originalPreview;
        final PhotoPipeline.CorrectionAnalysis measured = analysis;
        setBusy(true, "Rendering " + (labLook ? "LAB" : "SAFE")
                + (natureEditorial ? " + Nature Editorial" : "")
                + " at " + strength + "%…");
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final Bitmap rendered = PhotoPipeline.renderPreview(
                            source, measured, strength, labLook, natureEditorial, documentaryEditorial);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation != workGeneration || !editorVisible) {
                                rendered.recycle();
                                return;
                            }
                            if (correctedPreview != null
                                    && correctedPreview != originalPreview
                                    && correctedPreview != rendered
                                    && !correctedPreview.isRecycled()) {
                                correctedPreview.recycle();
                            }
                            correctedPreview = rendered;
                            previewView.setImageBitmap(correctedPreview);
                            updateAnalysisUi();
                            setBusy(false, null);
                        }
                    });
                } catch (final Throwable failure) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation == workGeneration) {
                                setBusy(false, null);
                                showError("Correction unavailable", readableError(failure));
                            }
                        }
                    });
                }
            }
        });
    }

    private void selectLook(boolean labLook) {
        if (analysis == null || originalPreview == null || busy) {
            return;
        }
        if (labLook && !analysis.labCandidateAvailable) {
            Toast.makeText(
                    this,
                    "No distinct LAB candidate was available for this photo.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (useLabLook == labLook) {
            return;
        }
        useLabLook = labLook;
        markCurrentResultUnsaved();
        updateLookControls();
        if (labLook && correctionStrength == 0) {
            setCorrectionStrength(85, true);
            return;
        }
        if (correctionStrength == 0) {
            updateAnalysisUi();
            return;
        }
        setCorrectionStrength(correctionStrength, true);
    }

    private void selectFinish(boolean natureEditorial) {
        if (analysis == null || originalPreview == null || busy
                || useNatureEditorial == natureEditorial) {
            return;
        }
        useNatureEditorial = natureEditorial;
        useDocumentaryEditorial = false;
        markCurrentResultUnsaved();
        updateLookControls();
        if (natureEditorial && correctionStrength == 0) {
            setCorrectionStrength(85, true);
            return;
        }
        if (correctionStrength == 0) {
            updateAnalysisUi();
            return;
        }
        setCorrectionStrength(correctionStrength, true);
    }

    private void selectDocumentaryFinish() {
        if (analysis == null || originalPreview == null || busy || useDocumentaryEditorial) return;
        useNatureEditorial = false;
        useDocumentaryEditorial = true;
        markCurrentResultUnsaved();
        updateLookControls();
        if (correctionStrength == 0) { setCorrectionStrength(85, true); return; }
        setCorrectionStrength(correctionStrength, true);
    }

    private void selectOutput(boolean losslessPng) {
        if (busy || saveLosslessPng == losslessPng) return;
        saveLosslessPng = losslessPng;
        markCurrentResultUnsaved();
        updateLookControls();
        updateAnalysisUi();
    }

    private void updateLookControls() {
        if (safeLookButton == null || labLookButton == null
                || naturalFinishButton == null || natureFinishButton == null || documentaryFinishButton == null
                || jpegOutputButton == null || pngOutputButton == null) {
            return;
        }
        boolean candidateAvailable = analysis != null && analysis.labCandidateAvailable;
        styleLookButton(safeLookButton, !useLabLook, !busy);
        styleLookButton(labLookButton, useLabLook, candidateAvailable && !busy);
        styleLookButton(naturalFinishButton, !useNatureEditorial && !useDocumentaryEditorial, !busy);
        styleLookButton(
                natureFinishButton,
                useNatureEditorial,
                !busy,
                AMBER);
        styleLookButton(documentaryFinishButton, useDocumentaryEditorial, !busy, GREEN);
        styleLookButton(jpegOutputButton, !saveLosslessPng, !busy);
        styleLookButton(pngOutputButton, saveLosslessPng, !busy, GREEN);
        if (analysis != null && !analysis.trueColourActive) {
            labLookButton.setText(candidateAvailable ? "LAB preview" : "LAB unavailable");
        } else {
            labLookButton.setText("LAB");
        }
    }

    private void styleLookButton(TextView button, boolean selected, boolean enabled) {
        styleLookButton(button, selected, enabled, BLUE);
    }

    private void styleLookButton(
            TextView button,
            boolean selected,
            boolean enabled,
            int selectedColour) {
        button.setTextColor(selected ? WHITE : (enabled ? NAVY : MUTED));
        button.setBackground(selected
                ? rounded(selectedColour, 12, 0, 0)
                : rounded(CANVAS, 12, 1, BORDER));
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.55f);
    }

    private void updateAnalysisUi() {
        if (analysis == null) {
            return;
        }
        toneAnalysis.setText(analysis.toneSummary());
        colourAnalysis.setText(analysis.colourSummary(useLabLook) + "\n\n" + analysis.confidenceSummary());
        finishAnalysis.setText(useNatureEditorial
                ? "Finish: Nature Editorial\nAdaptive tone depth  •  luminance texture  •  selective protected colour"
                : "Finish: Natural  •  no creative finishing stage");
        updateLookControls();
        if (!currentResultSaved && saveStatus != null) {
            saveStatus.setText(selectedLookName()
                    + " selected  •  " + (saveLosslessPng ? "PNG lossless" : "JPEG 100") + "  •  Original preserved");
            saveStatus.setTextColor(MUTED);
        }
        if (correctionStrength == 0) {
            if (analysis.alreadyBalanced) {
                setAutoBadge("READY", GREEN);
                autoTitle.setText("Already balanced");
                autoDescription.setText("No correction needed");
            } else {
                setAutoBadge("OFF", SLATE);
                autoTitle.setText("Correction off");
                autoDescription.setText("Tap to restore the smart result");
            }
        } else {
            if (useNatureEditorial) {
                String base = useLabLook && analysis.labCandidateAvailable
                        ? (analysis.labCandidate.previewOnly ? "LAB*" : "LAB")
                        : "SAFE";
                setAutoBadge("NATURE", AMBER);
                autoTitle.setText(base + " + Nature Editorial — "
                        + correctionStrength + "%");
                autoDescription.setText(
                        "Adaptive natural-history finish selected for saving");
            } else if (useLabLook && analysis.labCandidateAvailable) {
                boolean previewOnly = analysis.labCandidate.previewOnly;
                setAutoBadge(previewOnly ? "LAB*" : "LAB", previewOnly ? AMBER : BLUE);
                autoTitle.setText((previewOnly ? "LAB preview — " : "True Colour applied — ")
                        + correctionStrength + "%");
                if (previewOnly) {
                    autoDescription.setText(
                            "Not auto-selected • Save copy will save this LAB look");
                } else if (analysis.labCandidate.spatialActive && analysis.multiZoneActive) {
                    autoDescription.setText(
                            "Spatial true colour and local light balance");
                } else if (analysis.labCandidate.spatialActive) {
                    autoDescription.setText(
                            "Overlapping mixed-light colour correction");
                } else if (analysis.channelHighlightGuarded) {
                    autoDescription.setText(
                            "Consensus true colour with RGB highlight protection");
                } else {
                    autoDescription.setText(
                            "Consensus true colour and histogram correction");
                }
            } else {
                setAutoBadge("SAFE", BLUE);
                autoTitle.setText((analysis.trueColourActive
                        ? "SAFE comparison — " : "SAFE recommended — ")
                        + correctionStrength + "%");
                if (analysis.channelHighlightGuarded && analysis.multiZoneActive) {
                    autoDescription.setText(
                            "Proven local correction and RGB highlight protection");
                } else if (analysis.channelHighlightGuarded) {
                    autoDescription.setText(
                            "Proven correction with RGB highlight protection");
                } else if (analysis.multiZoneActive) {
                    autoDescription.setText(
                            "Proven correction with local light balance");
                } else {
                    autoDescription.setText(
                            analysis.trueColourActive
                                    ? "Proven AutoFix colour path selected for saving"
                                    : "Experimental colour held • proven correction retained");
                }
            }
        }
    }

    private void setAutoBadge(String label, int colour) {
        if (autoBadge != null) {
            autoBadge.setText(label);
            autoBadge.setBackground(rounded(colour, 99, 0, 0));
        }
    }

    private Bitmap currentDisplayBitmap() {
        if (correctionStrength == 0 || correctedPreview == null) {
            return originalPreview;
        }
        return correctedPreview;
    }

    private void handleSaveOrNext() {
        if (busy) {
            return;
        }
        if (currentResultSaved) {
            launchPhotoPicker();
        } else {
            performSave();
        }
    }

    private void performSave() {
        if (busy || sourceUri == null || analysis == null) {
            return;
        }
        final Uri input = sourceUri;
        final PhotoPipeline.CorrectionAnalysis measured = analysis;
        final int strength = correctionStrength;
        final boolean labLook = useLabLook && measured.labCandidateAvailable;
        final boolean natureEditorial = useNatureEditorial;
        final boolean documentaryEditorial = useDocumentaryEditorial;
        final boolean losslessPng = saveLosslessPng;
        final int generation = workGeneration;
        final String look = (labLook ? "LAB" : "SAFE")
                + (natureEditorial ? " + NATURE" : (documentaryEditorial ? " + NAT GEO" : ""));
        setBusy(true, "Saving the selected " + look + " look…");
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    final PhotoPipeline.SavedPhoto saved = PhotoPipeline.saveEditedCopy(
                            MainActivity.this,
                            input,
                            measured,
                            strength,
                            labLook,
                            natureEditorial,
                            documentaryEditorial,
                            losslessPng
                                    ? PhotoPipeline.OutputFormat.PNG_LOSSLESS
                                    : PhotoPipeline.OutputFormat.JPEG_100);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation != workGeneration || !editorVisible) {
                                return;
                            }
                            setBusy(false, null);
                            String size = saved.width + " × " + saved.height;
                            String detail;
                            if (saved.scaledForMemory) {
                                detail = "Saved " + size + " as " + (losslessPng ? "lossless PNG" : "JPEG 100") + ". Android reduced this very large "
                                        + saved.sourceWidth + " × " + saved.sourceHeight
                                        + " source to remain memory-safe.";
                            } else {
                                detail = "Saved at the full source resolution: " + size
                                        + ", " + (losslessPng ? "lossless PNG." : "JPEG quality 100.");
                            }
                            currentResultSaved = true;
                            saveButton.setText("Next photo");
                            String status = saved.scaledForMemory
                                    ? "Saved " + look + " ✓  " + size
                                            + "  •  Memory-safe " + (losslessPng ? "PNG" : "JPEG 100")
                                    : "Saved " + look + " ✓  " + size + "  •  " + (losslessPng ? "PNG lossless" : "JPEG 100");
                            saveStatus.setText(status);
                            saveStatus.setTextColor(GREEN);
                            Toast.makeText(
                                    MainActivity.this,
                                    look + " look saved.\n" + detail + "\nOriginal preserved.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (final Throwable failure) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (generation == workGeneration) {
                                setBusy(false, null);
                                showError("Unable to save", readableError(failure));
                            }
                        }
                    });
                }
            }
        });
    }

    private String selectedLookName() {
        return (useLabLook ? "LAB" : "SAFE")
                + (useNatureEditorial ? " + NATURE" : "");
    }

    private void markCurrentResultUnsaved() {
        currentResultSaved = false;
        if (saveButton != null) {
            saveButton.setText("Save copy");
        }
        if (saveStatus != null) {
            saveStatus.setText(selectedLookName()
                    + " selected  •  " + (saveLosslessPng ? "PNG lossless" : "JPEG 100") + "  •  Original preserved");
            saveStatus.setTextColor(MUTED);
        }
    }

    private void launchPhotoPicker() {
        Intent intent;
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("image/*");
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try {
            startActivityForResult(intent, REQUEST_PICK_PHOTO);
        } catch (RuntimeException failure) {
            showError("Photo picker unavailable", readableError(failure));
        }
    }

    private void launchCamera() {
        ContentValues values = new ContentValues();
        String name = "TrueColour_Capture_" + new SimpleDateFormat(
                "yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH,
                "Pictures/AutoFix True Colour Lab/Captures");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        pendingCameraUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (pendingCameraUri == null) {
            showError("Camera unavailable", "Android could not create a local capture file.");
            return;
        }

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
        intent.setClipData(ClipData.newRawUri("AutoFix capture", pendingCameraUri));
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (intent.resolveActivity(getPackageManager()) == null) {
            getContentResolver().delete(pendingCameraUri, null, null);
            pendingCameraUri = null;
            showError("Camera unavailable", "No compatible camera application was found.");
            return;
        }
        startActivityForResult(intent, REQUEST_TAKE_PHOTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_PHOTO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                int flags = data.getFlags()
                        & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                if ((flags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                    try {
                        getContentResolver().takePersistableUriPermission(uri, flags);
                    } catch (RuntimeException ignored) {
                        // The Android photo picker grants a temporary URI that is sufficient here.
                    }
                }
                loadPhoto(uri);
            }
            return;
        }

        if (requestCode == REQUEST_TAKE_PHOTO && pendingCameraUri != null) {
            Uri captured = pendingCameraUri;
            pendingCameraUri = null;
            if (resultCode == RESULT_OK) {
                ContentValues publish = new ContentValues();
                publish.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(captured, publish, null, null);
                loadPhoto(captured);
            } else {
                getContentResolver().delete(captured, null, null);
            }
        }
    }

    private void setBusy(boolean isBusy, String message) {
        busy = isBusy;
        if (processingOverlay != null) {
            processingOverlay.setVisibility(isBusy ? View.VISIBLE : View.GONE);
        }
        if (processingMessage != null && message != null) {
            processingMessage.setText(message);
        }
        setEnabled(applyButton, !isBusy);
        setEnabled(photosButton, !isBusy);
        setEnabled(resetButton, !isBusy);
        setEnabled(saveButton, !isBusy);
        setEnabled(compareButton, !isBusy);
        if (strengthSeek != null) {
            strengthSeek.setEnabled(!isBusy);
            strengthSeek.setAlpha(isBusy ? 0.55f : 1f);
        }
        updateLookControls();
    }

    private void setEnabled(View view, boolean enabled) {
        if (view != null) {
            view.setEnabled(enabled);
            view.setAlpha(enabled ? 1f : 0.55f);
        }
    }

    private void releasePreviewBitmaps() {
        if (correctedPreview != null
                && correctedPreview != originalPreview
                && !correctedPreview.isRecycled()) {
            correctedPreview.recycle();
        }
        if (originalPreview != null && !originalPreview.isRecycled()) {
            originalPreview.recycle();
        }
        correctedPreview = null;
        originalPreview = null;
    }

    private void showError(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String readableError(Throwable failure) {
        String message = failure.getMessage();
        if (message == null || message.trim().isEmpty()) {
            return "This photo could not be processed safely on this device.";
        }
        return message;
    }

    @Override
    public void onBackPressed() {
        if (editorVisible) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        workGeneration++;
        releasePreviewBitmaps();
        worker.shutdownNow();
        super.onDestroy();
    }

    private LinearLayout verticalLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontalLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }

    private TextView text(String value, float size, int colour, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(colour);
        view.setTypeface(Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        view.setIncludeFontPadding(false);
        return view;
    }

    private TextView centeredText(String value, float size, int colour, boolean bold) {
        TextView view = text(value, size, colour, bold);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private TextView actionButton(String value, boolean primary) {
        TextView button = centeredText(value, 15, primary ? WHITE : NAVY, true);
        button.setMinHeight(dp(54));
        button.setPadding(dp(18), dp(12), dp(18), dp(12));
        button.setBackground(primary
                ? stateRounded(BLUE, BLUE_PRESSED, 16, 0)
                : stateRounded(WHITE, SKY, 16, BORDER));
        return button;
    }

    private TextView headerButton(String value) {
        TextView button = centeredText(value, 14, BLUE, true);
        button.setBackground(stateRounded(Color.TRANSPARENT, SKY, 14, 0));
        return button;
    }

    private TextView lookButton(String value) {
        TextView button = centeredText(value, 13, NAVY, true);
        button.setPadding(dp(10), dp(8), dp(10), dp(8));
        button.setBackground(rounded(CANVAS, 12, 1, BORDER));
        return button;
    }

    private GradientDrawable rounded(int colour, int radiusDp, int strokeWidthDp, int strokeColour) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(colour);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeWidthDp > 0) {
            drawable.setStroke(dp(strokeWidthDp), strokeColour);
        }
        return drawable;
    }

    private StateListDrawable stateRounded(
            int normalColour,
            int pressedColour,
            int radiusDp,
            int strokeColour) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[] {android.R.attr.state_pressed},
                rounded(pressedColour, radiusDp, strokeColour == 0 ? 0 : 1, strokeColour));
        states.addState(new int[] {},
                rounded(normalColour, radiusDp, strokeColour == 0 ? 0 : 1, strokeColour));
        return states;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWithBottom(int marginDp) {
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = dp(marginDp);
        return params;
    }

    private LinearLayout.LayoutParams matchWithTop(int marginDp) {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(marginDp);
        return params;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams wrapWithTop(int marginDp) {
        LinearLayout.LayoutParams params = wrap();
        params.topMargin = dp(marginDp);
        return params;
    }
}
