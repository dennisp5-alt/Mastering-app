package com.dennis.autofixcolourlab;
public final class CameraCharacterRecoveryEngineTest {
  private static int checks=0;
  private static void ok(boolean v,String m){checks++; if(!v) throw new AssertionError(m);}
  private static int rgb(int r,int g,int b){return 0xff000000|(r<<16)|(g<<8)|b;}
  public static void main(String[] args){
    CameraCharacterRecoveryEngine.Accumulator neutral=new CameraCharacterRecoveryEngine.Accumulator();
    for(int i=0;i<2000;i++){int v=20+(i%210); neutral.addPixel(rgb(v,Math.min(255,v+2),Math.max(0,v-2)));}
    CameraCharacterRecoveryEngine.Analysis n=neutral.finish(); ok(!n.active,"neutral image must bypass");
    CameraCharacterRecoveryEngine.Accumulator baked=new CameraCharacterRecoveryEngine.Accumulator();
    for(int i=0;i<3000;i++){ if(i%4==0)baked.addPixel(rgb(255,25,18)); else if(i%4==1)baked.addPixel(rgb(8,8,8)); else baked.addPixel(rgb(240,110,25)); }
    CameraCharacterRecoveryEngine.Analysis a=baked.finish(); ok(a.active,"strong baked signature should activate"); ok(a.overSaturation>0.1,"oversaturation evidence");
    CameraCharacterRecoveryEngine.Processor p=new CameraCharacterRecoveryEngine.Processor(a,1.0); int in=rgb(245,80,25),out=p.apply(in); ok(out!=in,"active recovery should make bounded change");
    System.out.println("CameraCharacterRecoveryEngineTest: "+checks+" checks passed");
  }
}
