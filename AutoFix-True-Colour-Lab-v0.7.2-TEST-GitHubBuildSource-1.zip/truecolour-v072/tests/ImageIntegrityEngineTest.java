package com.dennis.autofixcolourlab;
public final class ImageIntegrityEngineTest {
  static int checks=0;
  static void ok(boolean v,String m){checks++; if(!v) throw new AssertionError(m);}
  static int rgb(int r,int g,int b){return 0xff000000|(r<<16)|(g<<8)|b;}
  public static void main(String[] args){
    SceneIntelligence.Accumulator a=new SceneIntelligence.Accumulator();
    for(int i=0;i<700;i++) a.addPixel(rgb(28,30,34));
    for(int i=0;i<200;i++) a.addPixel(rgb(248,238,220));
    for(int i=0;i<100;i++) a.addPixel(rgb(110,78,60));
    SceneIntelligence.Analysis scene=a.finish();
    ok(scene.scene.equals("shaded / low-key"),"dark frame must not be called night without night evidence");
    ImageIntegrityEngine.Analysis q=ImageIntegrityEngine.analyse(scene);
    ok(q.qualityGuardActive,"guard active"); ok(q.noiseRisk>0,"noise evidence");
    ImageIntegrityEngine.Processor p=new ImageIntegrityEngine.Processor(q,1.0);
    int in=rgb(35,22,28), out=p.apply(in,.5,.5);
    ok(out!=0,"valid output");
    int r=(out>>>16)&255,g=(out>>>8)&255,b=out&255;
    ok(r>=0&&r<=255&&g>=0&&g<=255&&b>=0&&b<=255,"gamut bounded");
    int white=p.apply(rgb(255,255,255),.5,.5);
    ok(((white>>>16)&255)<=255,"highlight bounded");
    System.out.println("ImageIntegrityEngineTest: "+checks+" checks passed");
  }
}
