# AutoFix True Colour Lab v0.3.0 — device test checklist

Test on the Galaxy S23 Ultra first, then repeat the starred core cases on the Galaxy A54. Keep AutoFix Histogram v1.3.0 installed for comparison.

1. ★ Install v0.3.0 over Lab v0.2.0 and confirm stable **AutoFix Histogram** remains installed beside it.
2. Confirm the Lab icon remains distinct in normal, Samsung round and themed-icon modes.
3. ★ Enable airplane mode, launch the app, choose a local photo and save it successfully.
4. Check the editor at default and large font/display sizes. The fixed **Photos / Reset** header and **Hold original / Save copy** bar must remain accessible.
5. Confirm **Colour base** shows SAFE/LAB and **Finish** shows NATURAL/NATURE EDITORIAL as two independent rows.
6. ★ Open a new photo. Confirm the automatic SAFE/LAB recommendation is selected and Finish always starts at NATURAL.
7. Select Nature Editorial, open another photo and confirm the new photo returns to Natural rather than silently carrying a creative finish forward.
8. Expand **Correction details** and confirm both colour and finish decisions are readable.
9. ★ Switch SAFE/LAB while Nature Editorial is selected. Confirm the finish remains selected and the preview rerenders cleanly.
10. Switch Natural/Nature while SAFE is selected, then repeat with LAB or LAB\*. Framing, strength and Hold original comparison must remain stable.
11. Tap the main status card. Confirm it restores the automatic colour recommendation, Natural finish and smart strength.
12. Move Correction strength through 0%, the smart value and 100%. At 0%, Hold original must reveal no changed pixels.
13. Select Nature Editorial from 0%. Confirm strength rises to 85% so the look can be auditioned.
14. ★ Test ordinary daylight scenery. Nature should add restrained depth and colour without looking like a heavy filter.
15. Test foliage in sunlight and shade. Check leaf separation, green hue and yellow-green transitions; avoid fluorescent or uniformly painted greens.
16. Test blue sky, water and distant haze. Check that blue remains graduated and does not become cyan, electric or posterized.
17. ★ Test a portrait in daylight, shade and warm indoor light. Inspect skin hue, lips, eyes and pale clothing in SAFE/LAB × Natural/Nature.
18. Test a photograph containing people within a colourful landscape. Nature should enrich the environment without making skin orange or red.
19. Test flowers, birds and saturated red subjects. Confirm fine colour variation remains and no channel becomes a broad flat block.
20. ★ Recheck the supplied parrot in SAFE + Nature and LAB\* + Nature. RGB highlight protection and red feather variation must remain intact.
21. ★ Recheck the supplied rose. The black background should stay low-key and no new blue/cyan edge fringe or halo should appear.
22. Test a deliberately dark or night photograph. Nature should reduce itself rather than opening the whole scene or crushing shadows.
23. Test snow, white birds, clouds and bright sand. Highlights should retain gradation without grey-looking whites.
24. Test a high-contrast backlit scene. Inspect subject boundaries at 100% for bright/dark halos or artificial clarity.
25. Test fine branches, feathers, fur and architecture. Nature uses broad luminance depth only; it should not introduce oversharpened edge outlines.
26. Test mixed window and artificial light. SAFE/LAB behavior and smooth 3×3 colour transitions must remain unchanged.
27. ★ Save SAFE + Natural and SAFE + Nature from one source. Confirm both files exist and filenames include `SAFE_NATURAL` and `SAFE_NATURE`.
28. Save LAB + Natural and LAB + Nature where LAB is available. Confirm the files include `LAB_NATURAL` and `LAB_NATURE`.
29. After saving, confirm the saved message names the selected combination, dimensions and JPEG 100, then **Save copy** becomes **Next photo**.
30. Change the finish or colour base after saving and confirm **Next photo** changes back to **Save copy**.
31. ★ Tap **Next photo**, choose another image and confirm it opens directly. Cancel once and confirm the current editor remains intact.
32. Inspect saved files in Gallery for location, dimensions, JPEG type, capture date and camera metadata where available.
33. Compare at least one Kodak-origin scan/JPEG, Panasonic Lumix JPEG and Samsung JPEG. The finish should behave by image content rather than brand.
34. Test one 50 MP S23 Ultra image. Record dimensions, preview time, save time, heat and whether memory-safe scaling was needed.
35. ★ On the A54, record preview time, save time, heat and any failure for a 12 MP Nature render.

For a useful verdict, compare 20–30 varied photographs and record the four-way preference where available: SAFE + Natural, LAB + Natural, SAFE + Nature, or LAB + Nature. Also note any skin shift, clipped saturated colour, halo, blocked shadow or scene where the Nature finish is simply too strong.
