# AutoFix True Colour Lab v0.4.0 TEST

Bulk-test engineering release based on untouched v0.3.0 processing.

- Explicit colour-managed decode: embedded source colour space is converted by Android ImageDecoder to the engine's defined sRGB working space before deterministic correction.
- Added True Colour confidence/evidence diagnostics: consensus, independent families, neutral evidence, mixed-light score, spatial decision and hold/accept reason.
- Added lossless PNG output beside JPEG 100. JPEG remains the default comparison output.
- Nature Editorial remains an independent optional finish and is never folded into True Colour reconstruction.
- Removed the home-screen camera shortcut so the app remains focused on correcting authoritative source files.
- Removed `largeHeap`; memory budget now reflects the normal app heap rather than masking pressure.
- Preserved memory-aware full-resolution decode and strip processing. Files above the safe bitmap budget are still downscaled and explicitly reported; true region decoding is not safe across every supported HEIC/JPEG source on API 29, so this TEST build does not pretend otherwise.
- Expanded metadata preservation list remains best-effort; orientation is rendered into pixels and reset to normal.
- Modernized Java compile target to 17.
- Package/signing identity unchanged so this test build installs over v0.3.0.
