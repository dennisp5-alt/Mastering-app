package com.dennis.autofixcolourlab;

public final class HistogramEngineTest {
    private static int checks;

    public static void main(String[] args) {
        testBalancedGradientIsConservative();
        testDarkSceneReceivesLift();
        testWarmNeutralCastIsReduced();
        testColourDominatedSceneIsProtected();
        testHighlightClippingBlocksExtraLift();
        testAlreadyBalancedStopsCleanly();
        testBacklitCentreGetsBoundedLocalLift();
        testOverlappingWindowsIncreaseRegionalCoverage();
        testBoundaryEvidenceIsSharedWithoutChangingGlobalCount();
        testMixedLightReducesGlobalColourShift();
        testUniformCastKeepsColourCorrection();
        testLocalLiftProtectsHighlights();
        testRgbHighlightGuardPreservesSaturatedChannelHeadroom();
        testRgbHighlightGuardIgnoresSparseRisk();
        testToneCurveIsMonotonic();
        testZeroStrengthIsBitExact();
        testAlphaIsPreserved();
        benchmarkOneMillionPixels();
        System.out.println("HistogramEngineTest: " + checks + " checks passed");
    }

    private static void testBalancedGradientIsConservative() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int repeat = 0; repeat < 100; repeat++) {
            for (int value = 0; value < 256; value++) {
                accumulator.addPixel(argb(value, value, value));
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(Math.abs(analysis.exposureEv) < 0.12, "balanced gradient exposure is conservative");
        check(Math.abs(analysis.redGain - 1.0) < 0.002, "neutral red gain remains neutral");
        check(Math.abs(analysis.blueGain - 1.0) < 0.002, "neutral blue gain remains neutral");
    }

    private static void testDarkSceneReceivesLift() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int repeat = 0; repeat < 160; repeat++) {
            for (int value = 8; value <= 118; value++) {
                accumulator.addPixel(argb(value, value, value));
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        HistogramEngine.Processor processor = new HistogramEngine.Processor(analysis, 1.0);
        int corrected = processor.apply(argb(60, 60, 60));
        check(analysis.exposureEv > 0.30, "dark scene receives positive exposure");
        check(red(corrected) > 70, "dark midtone is visibly lifted");
    }

    private static void testWarmNeutralCastIsReduced() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int repeat = 0; repeat < 300; repeat++) {
            for (int value = 60; value <= 200; value += 4) {
                int red = Math.min(255, (int) Math.round(value * 1.10));
                int green = value;
                int blue = (int) Math.round(value * 0.86);
                accumulator.addPixel(argb(red, green, blue));
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        HistogramEngine.Processor processor = new HistogramEngine.Processor(analysis, 1.0);
        int source = argb(165, 150, 129);
        int corrected = processor.apply(source);
        int sourceSpread = red(source) - blue(source);
        int correctedSpread = red(corrected) - blue(corrected);
        check(analysis.redGain < 1.0, "warm cast reduces red gain");
        check(analysis.blueGain > 1.0, "warm cast raises blue gain");
        check(correctedSpread < sourceSpread, "warm neutral channel spread is reduced");
    }

    private static void testColourDominatedSceneIsProtected() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 30000; i++) {
            accumulator.addPixel(argb(205, 35 + (i % 15), 30));
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(analysis.colourConfidence < 0.08, "saturated scene has no false neutral confidence");
        check(Math.abs(analysis.redGain - 1.0) < 0.001, "saturated red scene is not grey-balanced");
    }

    private static void testHighlightClippingBlocksExtraLift() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 12000; i++) {
            int value = i < 1800 ? 255 : 55 + (i % 70);
            accumulator.addPixel(argb(value, value, value));
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(analysis.highlightClipRate > 0.10, "fixture contains clipped highlights");
        check(analysis.exposureEv <= 0.001, "clipped highlights block extra global lift");
    }

    private static void testAlreadyBalancedStopsCleanly() {
        HistogramEngine.SpatialAccumulator accumulator = new HistogramEngine.SpatialAccumulator();
        for (int zone = 0; zone < 9; zone++) {
            for (int repeat = 0; repeat < 30; repeat++) {
                for (int value = 0; value < 256; value++) {
                    accumulator.addPixel(argb(value, value, value), zone);
                }
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(analysis.alreadyBalanced, "balanced broad-range scene is left alone");
        check(analysis.recommendedStrengthPercent == 0,
                "already-balanced result recommends zero correction");
        check(!analysis.multiZoneActive, "uniform zones do not trigger local tone correction");
    }

    private static void testBacklitCentreGetsBoundedLocalLift() {
        HistogramEngine.Analysis analysis = backlitAnalysis();
        check(analysis.multiZoneActive, "backlit fixture triggers multi-zone correction");
        check(analysis.zoneExposureEv[4] > 0.12,
                "dark centre receives a meaningful local lift");
        for (int zone = 0; zone < 9; zone++) {
            check(analysis.zoneExposureEv[zone] <= 0.300001,
                    "local lift remains below +0.30 EV in zone " + zone);
            check(analysis.zoneExposureEv[zone] >= -0.200001,
                    "local darkening remains above -0.20 EV in zone " + zone);
        }
        check(analysis.recommendedStrengthPercent >= 85
                        && analysis.recommendedStrengthPercent <= 100,
                "smart strength remains conservative and useful");
    }

    private static void testOverlappingWindowsIncreaseRegionalCoverage() {
        int width = 240;
        int height = 240;
        HistogramEngine.SpatialAccumulator accumulator =
                new HistogramEngine.SpatialAccumulator();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                accumulator.addPixelAt(
                        argb(128, 128, 128),
                        (x + 0.5) / width,
                        (y + 0.5) / height);
            }
        }

        double[] evidence = accumulator.zoneEvidenceWeights();
        double oldHardZoneShare = width * height / 9.0;
        for (int zone = 0; zone < evidence.length; zone++) {
            check(evidence[zone] > oldHardZoneShare * 1.18,
                    "overlap increases effective evidence in zone " + zone);
            check(evidence[zone] < width * height * 0.18,
                    "overlap remains restrained in zone " + zone);
        }
        check(evidence[4] > evidence[0] * 1.15,
                "centre window gains symmetric overlap while edge windows remain bounded");
    }

    private static void testBoundaryEvidenceIsSharedWithoutChangingGlobalCount() {
        HistogramEngine.SpatialAccumulator accumulator =
                new HistogramEngine.SpatialAccumulator();
        HistogramEngine.Accumulator globalReference = new HistogramEngine.Accumulator();
        for (int repeat = 0; repeat < 100; repeat++) {
            int pixel = argb(92, 92, 92);
            accumulator.addPixelAt(pixel, 1.0 / 3.0, 0.5);
            globalReference.addPixel(pixel);
        }

        double[] evidence = accumulator.zoneEvidenceWeights();
        HistogramEngine.Analysis analysis = accumulator.finish();
        HistogramEngine.Analysis reference = globalReference.finish();
        check(evidence[3] > 99.9,
                "a vertical-boundary sample remains full evidence for the left zone");
        check(evidence[4] > 99.9,
                "a vertical-boundary sample is also shared with the neighbouring zone");
        check(analysis.sampleCount == 100,
                "overlapping regional evidence does not double-count the global histogram");
        check(analysis.median == reference.median,
                "overlap leaves the global midpoint measurement unchanged");
        check(Math.abs(analysis.exposureEv - reference.exposureEv) < 0.000000001,
                "overlap leaves the global exposure measurement unchanged");
    }

    private static void testMixedLightReducesGlobalColourShift() {
        HistogramEngine.SpatialAccumulator spatial = new HistogramEngine.SpatialAccumulator();
        HistogramEngine.Accumulator global = new HistogramEngine.Accumulator();
        for (int zone = 0; zone < 9; zone++) {
            boolean warm = (zone % 2) == 0;
            for (int repeat = 0; repeat < 80; repeat++) {
                for (int value = 72; value <= 188; value += 4) {
                    int red = warm
                            ? (int) Math.round(value * 1.08)
                            : (int) Math.round(value * 0.92);
                    int blue = warm
                            ? (int) Math.round(value * 0.91)
                            : (int) Math.round(value * 1.08);
                    int pixel = argb(red, value, blue);
                    spatial.addPixel(pixel, zone);
                    global.addPixel(pixel);
                }
            }
        }
        HistogramEngine.Analysis guarded = spatial.finish();
        HistogramEngine.Analysis unguarded = global.finish();
        double guardedShift = largestGainShift(guarded);
        double unguardedShift = largestGainShift(unguarded);
        check(guarded.mixedLightGuarded, "opposing warm and cool zones trigger the safeguard");
        check(guarded.mixedLightScore > 0.35, "mixed-light disagreement is measurable");
        check(guardedShift <= unguardedShift + 0.000001,
                "safeguard never increases the global colour correction");
        check(guarded.recommendedStrengthPercent <= 90,
                "mixed light receives a restrained smart strength");
    }

    private static void testUniformCastKeepsColourCorrection() {
        HistogramEngine.SpatialAccumulator accumulator = new HistogramEngine.SpatialAccumulator();
        for (int zone = 0; zone < 9; zone++) {
            for (int repeat = 0; repeat < 80; repeat++) {
                for (int value = 72; value <= 188; value += 4) {
                    accumulator.addPixel(argb(
                            (int) Math.round(value * 1.08),
                            value,
                            (int) Math.round(value * 0.91)), zone);
                }
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(!analysis.mixedLightGuarded, "uniform warm light does not trigger mixed-light guard");
        check(analysis.mixedLightScore < 0.05, "uniform zone estimates agree");
        check(analysis.redGain < 0.99 && analysis.blueGain > 1.01,
                "uniform warm cast retains useful global colour correction");
    }

    private static void testLocalLiftProtectsHighlights() {
        HistogramEngine.Processor processor = new HistogramEngine.Processor(backlitAnalysis(), 1.0);
        int midtoneWithoutLocal = processor.apply(argb(100, 100, 100), 0.0);
        int midtoneWithLocal = processor.apply(argb(100, 100, 100), 0.30);
        int highlightWithoutLocal = processor.apply(argb(245, 245, 245), 0.0);
        int highlightWithLocal = processor.apply(argb(245, 245, 245), 0.30);
        check(red(midtoneWithLocal) > red(midtoneWithoutLocal) + 8,
                "local exposure visibly lifts a midtone");
        check(red(highlightWithLocal) - red(highlightWithoutLocal) <= 3,
                "local exposure fades out near highlights");
    }

    private static void testRgbHighlightGuardPreservesSaturatedChannelHeadroom() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 7000; i++) {
            int value = 34 + (i % 58);
            accumulator.addPixel(argb(value, value, value));
        }
        for (int i = 0; i < 3000; i++) {
            accumulator.addPixel(argb(228 + (i % 22), 72 + (i % 11), 48 + (i % 9)));
        }

        HistogramEngine.Analysis analysis = accumulator.finish();
        HistogramEngine.Processor processor = new HistogramEngine.Processor(
                analysis, analysis.recommendedStrengthPercent / 100.0);
        HistogramEngine.Processor fullStrengthProcessor =
                new HistogramEngine.Processor(analysis, 1.0);
        int source = argb(240, 76, 54);
        int corrected = processor.apply(source);
        int fullStrength = fullStrengthProcessor.apply(source);

        check(analysis.exposureEv > 0.30,
                "saturated-highlight fixture still receives useful positive exposure");
        check(analysis.channelHighlightRiskRate > 0.10,
                "saturated-highlight fixture exposes measurable channel risk");
        check(analysis.channelHighlightGuarded,
                "saturated coloured highlights activate RGB protection");
        check(red(corrected) >= red(source),
                "RGB protection does not darken the dominant channel below its source value");
        check(red(corrected) <= 252,
                "RGB protection preserves dominant-channel headroom instead of making 255");
        check(red(fullStrength) <= 252,
                "RGB protection remains safe at the manual 100 percent setting");
        check(red(corrected) > green(corrected) && green(corrected) > blue(corrected),
                "RGB protection retains the source channel ordering");
        check(analysis.toneSummary().contains("RGB highlight protection"),
                "active RGB protection is reported in correction details");
    }

    private static void testRgbHighlightGuardIgnoresSparseRisk() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 10000; i++) {
            int value = 30 + (i % 110);
            accumulator.addPixel(argb(value, value, value));
        }
        for (int i = 0; i < 10; i++) {
            accumulator.addPixel(argb(238, 70, 52));
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        check(analysis.channelHighlightRiskRate < 0.004,
                "isolated saturated pixels remain below the image-level risk threshold");
        check(!analysis.channelHighlightGuarded,
                "isolated saturated pixels do not activate an unnecessary image-level guard");
    }

    private static HistogramEngine.Analysis backlitAnalysis() {
        HistogramEngine.SpatialAccumulator accumulator = new HistogramEngine.SpatialAccumulator();
        for (int zone = 0; zone < 9; zone++) {
            for (int repeat = 0; repeat < 90; repeat++) {
                if (zone == 4) {
                    for (int value = 38; value <= 98; value += 3) {
                        accumulator.addPixel(argb(value, value, value), zone);
                    }
                } else {
                    for (int value = 108; value <= 228; value += 4) {
                        accumulator.addPixel(argb(value, value, value), zone);
                    }
                }
            }
        }
        return accumulator.finish();
    }

    private static double largestGainShift(HistogramEngine.Analysis analysis) {
        return Math.max(Math.abs(analysis.redGain - 1.0),
                Math.max(Math.abs(analysis.greenGain - 1.0),
                        Math.abs(analysis.blueGain - 1.0)));
    }

    private static void testToneCurveIsMonotonic() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 10000; i++) {
            int value = 30 + (i % 180);
            accumulator.addPixel(argb(value, value, value));
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        for (int i = 1; i < 256; i++) {
            check(analysis.toneLut[i] >= analysis.toneLut[i - 1], "tone curve remains monotonic at " + i);
        }
        check(analysis.toneLut[255] == 255, "white endpoint remains 255");
    }

    private static void testZeroStrengthIsBitExact() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 20; i < 220; i++) {
            accumulator.addPixel(argb(i, i - 5, i - 12));
        }
        HistogramEngine.Processor processor = new HistogramEngine.Processor(accumulator.finish(), 0.0);
        int source = 0x7f9a8064;
        check(processor.apply(source) == source, "zero strength preserves the exact ARGB pixel");
    }

    private static void testAlphaIsPreserved() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 1000; i++) {
            accumulator.addPixel(argb(80, 90, 100));
        }
        HistogramEngine.Processor processor = new HistogramEngine.Processor(accumulator.finish(), 1.0);
        int corrected = processor.apply(0x4a506478);
        check(((corrected >>> 24) & 0xff) == 0x4a, "alpha channel is preserved");
    }

    private static void benchmarkOneMillionPixels() {
        HistogramEngine.Accumulator accumulator = new HistogramEngine.Accumulator();
        for (int i = 0; i < 10000; i++) {
            accumulator.addPixel(argb(60 + i % 150, 55 + i % 145, 50 + i % 140));
        }
        HistogramEngine.Processor processor = new HistogramEngine.Processor(accumulator.finish(), 1.0);
        int pixel = argb(145, 132, 119);
        long start = System.nanoTime();
        int checksum = 0;
        for (int i = 0; i < 1_000_000; i++) {
            checksum ^= processor.apply(pixel + (i & 7));
        }
        long elapsedMs = (System.nanoTime() - start) / 1_000_000L;
        check(elapsedMs < 5000L, "one-million-pixel benchmark completes in under five seconds");
        System.out.println("Pixel benchmark: " + elapsedMs + " ms; checksum=" + checksum);
    }

    private static int argb(int red, int green, int blue) {
        return 0xff000000 | (clamp(red) << 16) | (clamp(green) << 8) | clamp(blue);
    }

    private static int red(int argb) {
        return (argb >>> 16) & 0xff;
    }

    private static int green(int argb) {
        return (argb >>> 8) & 0xff;
    }

    private static int blue(int argb) {
        return argb & 0xff;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
