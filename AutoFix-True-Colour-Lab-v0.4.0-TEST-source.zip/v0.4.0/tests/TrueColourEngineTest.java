package com.dennis.autofixcolourlab;

public final class TrueColourEngineTest {
    private static int checks;

    public static void main(String[] args) {
        testNeutralGradientIsHeld();
        testUniformWarmCastReachesConsensus();
        testColourDominatedSceneIsRejected();
        testHeldDecisionCanExposeGuardedPreview();
        testMixedLightBuildsBoundedSpatialMap();
        testZeroStrengthAndAlphaArePreserved();
        testSaturatedColourRemainsInGamut();
        benchmarkOneMillionPixels();
        System.out.println("TrueColourEngineTest: " + checks + " checks passed");
    }

    private static void testNeutralGradientIsHeld() {
        TrueColourEngine.Accumulator accumulator = new TrueColourEngine.Accumulator();
        for (int repeat = 0; repeat < 120; repeat++) {
            for (int value = 24; value <= 232; value += 3) {
                accumulator.addPixel(argb(value, value, value));
            }
        }
        TrueColourEngine.Analysis analysis = accumulator.finish();
        check(!analysis.globalActive, "neutral gradient does not receive an unnecessary adaptation");
        check("already neutral".equals(analysis.holdReason),
                "neutral gradient reports that colour is already neutral");
        check(analysis.agreeingMethods >= 3,
                "neutral gradient is held because it is neutral, not because evidence failed");
    }

    private static void testUniformWarmCastReachesConsensus() {
        TrueColourEngine.Analysis analysis = warmAnalysis();
        TrueColourEngine.Analysis preview = warmPreviewAnalysis();
        TrueColourEngine.Processor processor = new TrueColourEngine.Processor(analysis, 1.0);
        int source = argb(176, 154, 128);
        int corrected = processor.apply(source);

        check(analysis.globalActive, "uniform warm cast activates true-colour adaptation");
        check(analysis.agreeingMethods >= 3, "three or more estimators agree on the warm cast");
        check(analysis.independentFamilies >= 2,
                "consensus is supported by independent estimator families");
        check(analysis.redGain < 0.995, "warm cast receives a lower equivalent red gain");
        check(analysis.blueGain > 1.005, "warm cast receives a higher equivalent blue gain");
        check(red(corrected) - blue(corrected) < red(source) - blue(source),
                "linear adaptation reduces the warm red-blue spread");
        check(preview.active && !preview.previewOnly,
                "an accepted LAB result remains the normal candidate rather than a forced preview");
        check(Math.abs(preview.redGain - analysis.redGain) < 1.0e-12
                        && Math.abs(preview.blueGain - analysis.blueGain) < 1.0e-12,
                "accepted automatic and LAB candidate gains are identical");
    }

    private static void testColourDominatedSceneIsRejected() {
        TrueColourEngine.Accumulator accumulator = new TrueColourEngine.Accumulator();
        for (int index = 0; index < 30000; index++) {
            accumulator.addPixel(argb(212, 38 + index % 11, 29));
        }
        TrueColourEngine.Analysis analysis = accumulator.finish();
        TrueColourEngine.Analysis preview = accumulator.finishPreview();
        check(!analysis.active, "strongly red scene is not mistaken for a white-balance cast");
        check(analysis.availableMethods < 3,
                "strongly red scene lacks enough independent neutral evidence");
        check(!preview.active,
                "a scene with no usable neutral candidate does not invent a LAB preview");
    }

    private static void testHeldDecisionCanExposeGuardedPreview() {
        TrueColourEngine.Accumulator accumulator = new TrueColourEngine.Accumulator();
        for (int repeat = 0; repeat < 500; repeat++) {
            accumulator.addPixel(argb(205, 125, 82));
            accumulator.addPixel(argb(198, 119, 78));
            accumulator.addPixel(argb(151, 160, 181));
            accumulator.addPixel(argb(123, 149, 128));
            accumulator.addPixel(argb(183, 166, 149));
        }
        TrueColourEngine.Analysis automatic = accumulator.finish();
        TrueColourEngine.Analysis preview = accumulator.finishPreview();
        System.out.println("Preview fixture: automatic=" + automatic.active
                + " reason=" + automatic.holdReason
                + " preview=" + preview.active
                + " confidence=" + preview.confidence);
        check(!automatic.active,
                "conflicting colour evidence remains held by the automatic decision");
        check(preview.active && preview.previewOnly,
                "the held decision exposes a separately marked preview candidate");
        check(preview.redGain >= 0.92 && preview.redGain <= 1.08
                        && preview.greenGain >= 0.92 && preview.greenGain <= 1.08
                        && preview.blueGain >= 0.92 && preview.blueGain <= 1.08,
                "preview candidate remains inside the guarded eight-percent gain cap");
    }

    private static void testMixedLightBuildsBoundedSpatialMap() {
        TrueColourEngine.SpatialAccumulator accumulator =
                new TrueColourEngine.SpatialAccumulator();
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                boolean warm = column == 0;
                boolean cool = column == 2;
                for (int repeat = 0; repeat < 180; repeat++) {
                    for (int value = 62; value <= 202; value += 5) {
                        int red = warm
                                ? (int) Math.round(value * 1.10)
                                : cool ? (int) Math.round(value * 0.91) : value;
                        int blue = warm
                                ? (int) Math.round(value * 0.86)
                                : cool ? (int) Math.round(value * 1.10) : value;
                        accumulator.addPixelAt(
                                argb(red, value, blue),
                                (column + 0.5) / 3.0,
                                (row + 0.5) / 3.0);
                    }
                }
            }
        }
        TrueColourEngine.Analysis analysis = accumulator.finish();
        System.out.println("Mixed-light fixture: active=" + analysis.spatialActive
                + " score=" + analysis.mixedLightScore
                + " maxLocal=" + analysis.maxLocalGainPercent);
        check(analysis.spatialActive,
                "opposing warm and cool regions activate the spatial colour map");
        check(analysis.mixedLightScore >= 0.15,
                "mixed-light disagreement clears the activation threshold");
        check(analysis.maxLocalGainPercent >= 0.8
                        && analysis.maxLocalGainPercent <= 4.7,
                "spatial colour correction remains inside its restrained cap");
        for (int index = 0; index < 9; index++) {
            check(analysis.zoneRedGain[index] >= 0.955
                            && analysis.zoneRedGain[index] <= 1.048,
                    "red regional gain remains bounded in zone " + index);
            check(analysis.zoneBlueGain[index] >= 0.955
                            && analysis.zoneBlueGain[index] <= 1.048,
                    "blue regional gain remains bounded in zone " + index);
        }
    }

    private static void testZeroStrengthAndAlphaArePreserved() {
        TrueColourEngine.Analysis analysis = warmAnalysis();
        int source = 0x4a9f8068;
        TrueColourEngine.Processor zero = new TrueColourEngine.Processor(analysis, 0.0);
        TrueColourEngine.Processor full = new TrueColourEngine.Processor(analysis, 1.0);
        check(zero.apply(source) == source, "zero strength is bit exact");
        check(((full.apply(source) >>> 24) & 0xff) == 0x4a,
                "true-colour processing preserves alpha");
    }

    private static void testSaturatedColourRemainsInGamut() {
        TrueColourEngine.Processor processor =
                new TrueColourEngine.Processor(warmAnalysis(), 1.0);
        int corrected = processor.apply(argb(248, 62, 48));
        check(red(corrected) <= 255 && green(corrected) <= 255 && blue(corrected) <= 255,
                "saturated output remains in RGB gamut");
        check(red(corrected) > green(corrected) && green(corrected) > blue(corrected),
                "saturated red retains its channel ordering");
    }

    private static TrueColourEngine.Analysis warmAnalysis() {
        TrueColourEngine.Accumulator accumulator = new TrueColourEngine.Accumulator();
        for (int repeat = 0; repeat < 260; repeat++) {
            for (int value = 42; value <= 214; value += 4) {
                accumulator.addPixel(argb(
                        (int) Math.round(value * 1.10),
                        value,
                        (int) Math.round(value * 0.84)));
            }
        }
        return accumulator.finish();
    }

    private static TrueColourEngine.Analysis warmPreviewAnalysis() {
        TrueColourEngine.Accumulator accumulator = new TrueColourEngine.Accumulator();
        for (int repeat = 0; repeat < 260; repeat++) {
            for (int value = 42; value <= 214; value += 4) {
                accumulator.addPixel(argb(
                        (int) Math.round(value * 1.10),
                        value,
                        (int) Math.round(value * 0.84)));
            }
        }
        return accumulator.finishPreview();
    }

    private static void benchmarkOneMillionPixels() {
        TrueColourEngine.Processor processor =
                new TrueColourEngine.Processor(warmAnalysis(), 1.0);
        int source = argb(153, 132, 111);
        long start = System.nanoTime();
        int checksum = 0;
        for (int index = 0; index < 1_000_000; index++) {
            checksum ^= processor.apply(source + (index & 7));
        }
        long elapsedMs = (System.nanoTime() - start) / 1_000_000L;
        check(elapsedMs < 5000L,
                "one-million-pixel true-colour benchmark completes in under five seconds");
        System.out.println("True-colour pixel benchmark: "
                + elapsedMs + " ms; checksum=" + checksum);
    }

    private static int argb(int red, int green, int blue) {
        return 0xff000000
                | (clamp(red) << 16)
                | (clamp(green) << 8)
                | clamp(blue);
    }

    private static int red(int argb) {
        return (argb >>> 16) & 0xff;
    }

    private static int green(int argb) {
        return (argb >>> 8) & 0xff;
    }

    private static int blue(int argb) {
        return argb & 0xff;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
