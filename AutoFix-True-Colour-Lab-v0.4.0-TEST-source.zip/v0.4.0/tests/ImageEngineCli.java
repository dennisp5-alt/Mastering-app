package com.dennis.autofixcolourlab;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Small desktop fixture runner used during development; it is not packaged in the APK. */
public final class ImageEngineCli {
    public static void main(String[] args) throws Exception {
        if (args.length < 2 || args.length > 5) {
            throw new IllegalArgumentException(
                    "usage: ImageEngineCli INPUT OUTPUT [STRENGTH_PERCENT] "
                            + "[AUTO|SAFE|LAB] [NATURAL|NATURE]");
        }
        BufferedImage input = ImageIO.read(new File(args[0]));
        if (input == null) {
            throw new IllegalArgumentException("unsupported input image");
        }
        HistogramEngine.SpatialAccumulator accumulator = new HistogramEngine.SpatialAccumulator();
        TrueColourEngine.SpatialAccumulator colourAccumulator =
                new TrueColourEngine.SpatialAccumulator();
        for (int y = 0; y < input.getHeight(); y++) {
            for (int x = 0; x < input.getWidth(); x++) {
                double normalizedX = (x + 0.5) / input.getWidth();
                double normalizedY = (y + 0.5) / input.getHeight();
                accumulator.addPixelAt(
                        input.getRGB(x, y),
                        normalizedX,
                        normalizedY);
                colourAccumulator.addPixelAt(
                        input.getRGB(x, y),
                        normalizedX,
                        normalizedY);
            }
        }
        HistogramEngine.Analysis analysis = accumulator.finish();
        TrueColourEngine.Analysis automaticColour = colourAccumulator.finish();
        TrueColourEngine.Analysis labCandidate = automaticColour.active
                ? automaticColour : colourAccumulator.finishPreview();
        int smartStrength = recommendedStrength(analysis, automaticColour);
        int strengthPercent = args.length >= 3
                ? clamp(Integer.parseInt(args[2]), 0, 100)
                : smartStrength;
        String requestedLook = args.length >= 4 ? args[3].toUpperCase() : "AUTO";
        String requestedFinish = args.length >= 5 ? args[4].toUpperCase() : "NATURAL";
        boolean useLab = "LAB".equals(requestedLook)
                || ("AUTO".equals(requestedLook) && automaticColour.active);
        if (!"AUTO".equals(requestedLook)
                && !"SAFE".equals(requestedLook)
                && !"LAB".equals(requestedLook)) {
            throw new IllegalArgumentException("look must be AUTO, SAFE or LAB");
        }
        if (useLab && !labCandidate.active) {
            useLab = false;
        }
        boolean useNature = "NATURE".equals(requestedFinish);
        if (!"NATURAL".equals(requestedFinish) && !useNature) {
            throw new IllegalArgumentException("finish must be NATURAL or NATURE");
        }
        HistogramEngine.Processor toneProcessor = new HistogramEngine.Processor(
                analysis,
                strengthPercent / 100.0,
                !useLab);
        TrueColourEngine.Processor colourProcessor = new TrueColourEngine.Processor(
                labCandidate, useLab ? strengthPercent / 100.0 : 0.0);
        BufferedImage output = new BufferedImage(
                input.getWidth(), input.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < input.getHeight(); y++) {
            for (int x = 0; x < input.getWidth(); x++) {
                double localEv = localExposureAt(
                        analysis.zoneExposureEv, x, y, input.getWidth(), input.getHeight());
                double localRed = localValueAt(
                        labCandidate.zoneRedGain,
                        x,
                        y,
                        input.getWidth(),
                        input.getHeight());
                double localGreen = localValueAt(
                        labCandidate.zoneGreenGain,
                        x,
                        y,
                        input.getWidth(),
                        input.getHeight());
                double localBlue = localValueAt(
                        labCandidate.zoneBlueGain,
                        x,
                        y,
                        input.getWidth(),
                        input.getHeight());
                int colourCorrected = colourProcessor.apply(
                        input.getRGB(x, y), localRed, localGreen, localBlue);
                output.setRGB(x, y, toneProcessor.apply(colourCorrected, localEv));
            }
        }
        NatureEditorialEngine.Analysis editorialAnalysis = null;
        if (useNature && strengthPercent > 0) {
            int width = output.getWidth();
            int height = output.getHeight();
            int[] row = new int[width];
            NatureEditorialEngine.GuideAccumulator editorialAccumulator =
                    new NatureEditorialEngine.GuideAccumulator(width, height);
            for (int y = 0; y < height; y++) {
                output.getRGB(0, y, width, 1, row, 0, width);
                editorialAccumulator.addRow(row, 0, y, width);
            }
            editorialAnalysis = editorialAccumulator.finish();
            NatureEditorialEngine.Sampler sampler =
                    editorialAnalysis.createSampler(width, height);
            NatureEditorialEngine.Processor editorialProcessor =
                    new NatureEditorialEngine.Processor(
                            editorialAnalysis, strengthPercent / 100.0);
            double[] localLuminance = new double[width];
            for (int y = 0; y < height; y++) {
                output.getRGB(0, y, width, 1, row, 0, width);
                sampler.fillRow(y, localLuminance);
                for (int x = 0; x < width; x++) {
                    row[x] = editorialProcessor.apply(row[x], localLuminance[x]);
                }
                output.setRGB(0, y, width, 1, row, 0, width);
            }
        }
        ImageIO.write(output, "png", new File(args[1]));
        System.out.println(analysis.toneSummary());
        System.out.println("Automatic: " + automaticColour.summary());
        System.out.println("LAB candidate: " + labCandidate.summary());
        System.out.printf(
                "True Colour diagnostics: methods %d/%d  families %d  agreement %.1f%%  confidence %.1f%%%n",
                labCandidate.agreeingMethods,
                labCandidate.availableMethods,
                labCandidate.independentFamilies,
                labCandidate.agreement * 100.0,
                labCandidate.confidence * 100.0);
        System.out.println("Rendered " + (useLab ? "LAB" : "SAFE")
                + (useNature ? " + NATURE" : " + NATURAL")
                + " at strength " + strengthPercent
                + "%  •  smart recommendation "
                + smartStrength + "%");
        System.out.printf("RGB highlight risk %.2f%%  •  protection %s%n",
                analysis.channelHighlightRiskRate * 100.0,
                analysis.channelHighlightGuarded ? "active" : "not needed");
        if (editorialAnalysis != null) {
            System.out.println(editorialAnalysis.summary());
        }
        if (Boolean.getBoolean("autofix.diagnostics")) {
            printCandidateDiagnostics(input);
        }
    }

    private static int recommendedStrength(
            HistogramEngine.Analysis histogram,
            TrueColourEngine.Analysis colour) {
        if (histogram.alreadyBalanced && !colour.active) {
            return 0;
        }
        if (histogram.recommendedStrengthPercent > 0) {
            int strength = histogram.recommendedStrengthPercent;
            if (colour.active && colour.confidence < 0.45) {
                strength = Math.min(strength, 85);
            }
            return strength;
        }
        return colour.confidence >= 0.65 ? 90 : 85;
    }

    private static double localExposureAt(
            double[] zones, int x, int y, int width, int height) {
        double gridX = ((x + 0.5) * 3.0 / width) - 0.5;
        double gridY = ((y + 0.5) * 3.0 / height) - 0.5;
        int left = clamp((int) Math.floor(gridX), 0, 2);
        int right = clamp(left + 1, 0, 2);
        int top = clamp((int) Math.floor(gridY), 0, 2);
        int bottom = clamp(top + 1, 0, 2);
        double xFraction = gridX <= 0.0 || gridX >= 2.0 ? 0.0 : gridX - left;
        double yFraction = gridY <= 0.0 || gridY >= 2.0 ? 0.0 : gridY - top;
        double upper = zones[top * 3 + left]
                + (zones[top * 3 + right] - zones[top * 3 + left]) * xFraction;
        double lower = zones[bottom * 3 + left]
                + (zones[bottom * 3 + right] - zones[bottom * 3 + left]) * xFraction;
        return upper + (lower - upper) * yFraction;
    }

    private static double localValueAt(
            double[] zones, int x, int y, int width, int height) {
        double gridX = ((x + 0.5) * 3.0 / width) - 0.5;
        double gridY = ((y + 0.5) * 3.0 / height) - 0.5;
        int left = clamp((int) Math.floor(gridX), 0, 2);
        int right = clamp(left + 1, 0, 2);
        int top = clamp((int) Math.floor(gridY), 0, 2);
        int bottom = clamp(top + 1, 0, 2);
        double xFraction = gridX <= 0.0 || gridX >= 2.0 ? 0.0 : gridX - left;
        double yFraction = gridY <= 0.0 || gridY >= 2.0 ? 0.0 : gridY - top;
        double upper = zones[top * 3 + left]
                + (zones[top * 3 + right] - zones[top * 3 + left]) * xFraction;
        double lower = zones[bottom * 3 + left]
                + (zones[bottom * 3 + right] - zones[bottom * 3 + left]) * xFraction;
        return upper + (lower - upper) * yFraction;
    }

    private static void printCandidateDiagnostics(BufferedImage input) {
        double[] thresholds = {0.12, 0.18, 0.24, 0.30, 0.36};
        int[] minimumLuminance = {28, 100, 135, 170};
        for (double threshold : thresholds) {
            for (int minimum : minimumLuminance) {
                long count = 0;
                double red = 0.0;
                double green = 0.0;
                double blue = 0.0;
                for (int y = 0; y < input.getHeight(); y++) {
                    for (int x = 0; x < input.getWidth(); x++) {
                        int pixel = input.getRGB(x, y);
                        int r = (pixel >>> 16) & 0xff;
                        int g = (pixel >>> 8) & 0xff;
                        int b = pixel & 0xff;
                        int maximum = Math.max(r, Math.max(g, b));
                        int minimumChannel = Math.min(r, Math.min(g, b));
                        double saturation = maximum == 0 ? 0.0
                                : (maximum - minimumChannel) / (double) maximum;
                        int luminance = (int) Math.round(r * 0.2126 + g * 0.7152 + b * 0.0722);
                        if (saturation < threshold && luminance >= minimum && luminance <= 238) {
                            count++;
                            red += r;
                            green += g;
                            blue += b;
                        }
                    }
                }
                if (count > 0) {
                    System.out.printf("candidate s<%.2f y>=%d: %.2f%% rgb %.1f/%.1f/%.1f%n",
                            threshold, minimum,
                            count * 100.0 / (input.getWidth() * (double) input.getHeight()),
                            red / count, green / count, blue / count);
                }
            }
        }
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
