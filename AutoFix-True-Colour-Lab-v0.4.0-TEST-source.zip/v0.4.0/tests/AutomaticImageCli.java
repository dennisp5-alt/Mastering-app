package com.dennis.autofixcolourlab;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Lean automatic-path renderer used for cross-version pixel regression.
 * It intentionally calls only engine APIs shared with v0.1.0.
 */
public final class AutomaticImageCli {
    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException(
                    "usage: AutomaticImageCli INPUT OUTPUT STRENGTH_PERCENT");
        }
        BufferedImage input = ImageIO.read(new File(args[0]));
        if (input == null) {
            throw new IllegalArgumentException("unsupported input image");
        }
        HistogramEngine.SpatialAccumulator toneAccumulator =
                new HistogramEngine.SpatialAccumulator();
        TrueColourEngine.SpatialAccumulator colourAccumulator =
                new TrueColourEngine.SpatialAccumulator();
        for (int y = 0; y < input.getHeight(); y++) {
            for (int x = 0; x < input.getWidth(); x++) {
                int pixel = input.getRGB(x, y);
                double normalizedX = (x + 0.5) / input.getWidth();
                double normalizedY = (y + 0.5) / input.getHeight();
                toneAccumulator.addPixelAt(pixel, normalizedX, normalizedY);
                colourAccumulator.addPixelAt(pixel, normalizedX, normalizedY);
            }
        }
        HistogramEngine.Analysis tone = toneAccumulator.finish();
        TrueColourEngine.Analysis colour = colourAccumulator.finish();
        double strength = clamp(Integer.parseInt(args[2]), 0, 100) / 100.0;
        HistogramEngine.Processor toneProcessor = new HistogramEngine.Processor(
                tone, strength, !colour.active);
        TrueColourEngine.Processor colourProcessor = new TrueColourEngine.Processor(
                colour, strength);
        BufferedImage output = new BufferedImage(
                input.getWidth(), input.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < input.getHeight(); y++) {
            for (int x = 0; x < input.getWidth(); x++) {
                double localExposure = localValueAt(
                        tone.zoneExposureEv, x, y, input.getWidth(), input.getHeight());
                double localRed = localValueAt(
                        colour.zoneRedGain, x, y, input.getWidth(), input.getHeight());
                double localGreen = localValueAt(
                        colour.zoneGreenGain, x, y, input.getWidth(), input.getHeight());
                double localBlue = localValueAt(
                        colour.zoneBlueGain, x, y, input.getWidth(), input.getHeight());
                int colourCorrected = colourProcessor.apply(
                        input.getRGB(x, y), localRed, localGreen, localBlue);
                output.setRGB(x, y, toneProcessor.apply(colourCorrected, localExposure));
            }
        }
        ImageIO.write(output, "png", new File(args[1]));
        System.out.println((colour.active ? "LAB" : "SAFE")
                + " rendered at " + Math.round(strength * 100.0) + "%");
    }

    private static double localValueAt(
            double[] zones, int x, int y, int width, int height) {
        double gridX = ((x + 0.5) * 3.0 / width) - 0.5;
        double gridY = ((y + 0.5) * 3.0 / height) - 0.5;
        int left = clamp((int) Math.floor(gridX), 0, 2);
        int right = clamp(left + 1, 0, 2);
        int top = clamp((int) Math.floor(gridY), 0, 2);
        int bottom = clamp(top + 1, 0, 2);
        double xFraction = gridX <= 0.0 || gridX >= 2.0 ? 0.0 : gridX - left;
        double yFraction = gridY <= 0.0 || gridY >= 2.0 ? 0.0 : gridY - top;
        double upper = zones[top * 3 + left]
                + (zones[top * 3 + right] - zones[top * 3 + left]) * xFraction;
        double lower = zones[bottom * 3 + left]
                + (zones[bottom * 3 + right] - zones[bottom * 3 + left]) * xFraction;
        return upper + (lower - upper) * yFraction;
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
