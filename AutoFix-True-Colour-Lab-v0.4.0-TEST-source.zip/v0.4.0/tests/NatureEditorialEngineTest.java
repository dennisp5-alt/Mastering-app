package com.dennis.autofixcolourlab;

public final class NatureEditorialEngineTest {
    private static int checks;

    public static void main(String[] args) {
        testZeroStrengthAndAlphaAreExact();
        testNeutralRampRemainsNeutral();
        testHighlightAndSaturatedColourProtection();
        testSelectiveColourBehaviour();
        testAdaptiveToneDepth();
        testLowKeyShadowProtection();
        testGuideSamplingIsSmoothAndBounded();
        benchmarkOneMillionPixels();
        System.out.println("NatureEditorialEngineTest: " + checks + " checks passed");
    }

    private static void testZeroStrengthAndAlphaAreExact() {
        NatureEditorialEngine.Analysis analysis = flatAnalysis(96, 72, argb(128, 128, 128));
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 0.0);
        int source = 0x5ac98457;
        check(processor.apply(source, 0.5) == source,
                "zero editorial strength is bit exact");
        NatureEditorialEngine.Processor full =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        check(((full.apply(source, 0.5) >>> 24) & 0xff) == 0x5a,
                "editorial processing preserves alpha");
    }

    private static void testNeutralRampRemainsNeutral() {
        int width = 192;
        int height = 64;
        NatureEditorialEngine.GuideAccumulator accumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int value = 10 + x * 235 / (width - 1);
                row[x] = argb(value, value, value);
            }
            accumulator.addRow(row, 0, y, width);
        }
        NatureEditorialEngine.Analysis analysis = accumulator.finish();
        NatureEditorialEngine.Sampler sampler = analysis.createSampler(width, height);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        double[] local = new double[width];
        sampler.fillRow(height / 2, local);
        for (int x = 0; x < width; x += 3) {
            int value = 10 + x * 235 / (width - 1);
            int output = processor.apply(argb(value, value, value), local[x]);
            check(red(output) == green(output) && green(output) == blue(output),
                    "neutral ramp remains free of colour cast at sample " + x);
        }
    }

    private static void testHighlightAndSaturatedColourProtection() {
        NatureEditorialEngine.Analysis analysis = gradientAnalysis(160, 96);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        int pale = processor.apply(argb(248, 246, 243), 0.96);
        check(red(pale) < 255 && green(pale) < 255 && blue(pale) < 255,
                "near-white neutral detail is not pushed into clipping");
        check(red(pale) >= green(pale) && green(pale) >= blue(pale),
                "near-white channel ordering is retained");

        int redFeather = processor.apply(argb(252, 62, 45), 0.43);
        check(red(redFeather) <= 254,
                "already-bright saturated red does not acquire new exact clipping");
        check(red(redFeather) > green(redFeather)
                        && green(redFeather) > blue(redFeather),
                "saturated red retains its hue ordering");
        check(channelRange(redFeather) >= 150,
                "saturated red remains visibly saturated rather than turning grey");
    }

    private static void testSelectiveColourBehaviour() {
        NatureEditorialEngine.Analysis analysis = gradientAnalysis(160, 96);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        int blueSource = argb(76, 124, 188);
        int greenSource = argb(72, 158, 78);
        int skinSource = argb(191, 142, 112);
        int blueOutput = processor.apply(blueSource, luminance(blueSource));
        int greenOutput = processor.apply(greenSource, luminance(greenSource));
        int skinOutput = processor.apply(skinSource, luminance(skinSource));

        check(saturation(blueOutput) >= saturation(blueSource),
                "moderate blue receives restrained editorial richness");
        check(saturation(blueOutput) - saturation(blueSource) <= 0.09,
                "blue enrichment remains inside a natural limit");
        check(saturation(greenOutput) - saturation(greenSource) <= 0.035,
                "foliage green avoids a neon saturation jump");
        check(Math.abs(saturation(skinOutput) - saturation(skinSource)) <= 0.025,
                "likely skin colour receives strong chroma protection");
        check(red(skinOutput) > green(skinOutput) && green(skinOutput) > blue(skinOutput),
                "protected skin retains warm channel ordering");
    }

    private static void testAdaptiveToneDepth() {
        NatureEditorialEngine.Analysis analysis = gradientAnalysis(192, 96);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        int shadowSource = argb(78, 78, 78);
        int highlightSource = argb(182, 182, 182);
        int shadowOutput = processor.apply(shadowSource, 0.36);
        int highlightOutput = processor.apply(highlightSource, 0.64);
        int sourceSeparation = red(highlightSource) - red(shadowSource);
        int outputSeparation = red(highlightOutput) - red(shadowOutput);
        check(outputSeparation > sourceSeparation,
                "editorial tone curve increases useful midtone separation");
        check(outputSeparation - sourceSeparation <= 18,
                "midtone depth remains restrained rather than harsh");
    }

    private static void testLowKeyShadowProtection() {
        int width = 120;
        int height = 80;
        NatureEditorialEngine.GuideAccumulator accumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int value = 8 + x * 48 / (width - 1);
                row[x] = argb(value, value, value);
            }
            accumulator.addRow(row, 0, y, width);
        }
        NatureEditorialEngine.Analysis analysis = accumulator.finish();
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        int output = processor.apply(argb(20, 20, 20), 0.09);
        check(red(output) >= 16,
                "low-key shadow detail is not crushed by the editorial curve");
        check(analysis.sceneStrength < 0.80,
                "low-key analysis automatically reduces creative strength");
    }

    private static void testGuideSamplingIsSmoothAndBounded() {
        int width = 144;
        int height = 96;
        NatureEditorialEngine.GuideAccumulator accumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int value = 35 + x * 180 / (width - 1);
                row[x] = argb(value, value, value);
            }
            accumulator.addRow(row, 0, y, width);
        }
        NatureEditorialEngine.Analysis analysis = accumulator.finish();
        NatureEditorialEngine.Sampler sampler = analysis.createSampler(width, height);
        double[] local = new double[width];
        sampler.fillRow(height / 2, local);
        double previous = local[0];
        for (int x = 0; x < width; x++) {
            check(local[x] >= 0.0 && local[x] <= 1.0,
                    "guide luminance remains bounded at column " + x);
            if (x > 0) {
                check(local[x] + 1.0e-9 >= previous,
                        "guide interpolation remains monotonic at column " + x);
                check(Math.abs(local[x] - previous) < 0.04,
                        "guide interpolation has no cell seam at column " + x);
            }
            previous = local[x];
        }
    }

    private static void benchmarkOneMillionPixels() {
        NatureEditorialEngine.Analysis analysis = gradientAnalysis(192, 96);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(analysis, 1.0);
        int source = argb(112, 139, 174);
        long start = System.nanoTime();
        int checksum = 0;
        for (int index = 0; index < 1_000_000; index++) {
            checksum ^= processor.apply(source + (index & 7), 0.53);
        }
        long elapsedMs = (System.nanoTime() - start) / 1_000_000L;
        check(elapsedMs < 5000L,
                "one-million-pixel editorial benchmark completes in under five seconds");
        System.out.println("Nature-editorial pixel benchmark: "
                + elapsedMs + " ms; checksum=" + checksum);
    }

    private static NatureEditorialEngine.Analysis flatAnalysis(
            int width, int height, int pixel) {
        NatureEditorialEngine.GuideAccumulator accumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        int[] row = new int[width];
        for (int x = 0; x < width; x++) {
            row[x] = pixel;
        }
        for (int y = 0; y < height; y++) {
            accumulator.addRow(row, 0, y, width);
        }
        return accumulator.finish();
    }

    private static NatureEditorialEngine.Analysis gradientAnalysis(int width, int height) {
        NatureEditorialEngine.GuideAccumulator accumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int value = 18 + x * 222 / (width - 1);
                row[x] = argb(value, value, value);
            }
            accumulator.addRow(row, 0, y, width);
        }
        return accumulator.finish();
    }

    private static int argb(int red, int green, int blue) {
        return 0xff000000
                | (clamp(red) << 16)
                | (clamp(green) << 8)
                | clamp(blue);
    }

    private static int red(int argb) {
        return (argb >>> 16) & 0xff;
    }

    private static int green(int argb) {
        return (argb >>> 8) & 0xff;
    }

    private static int blue(int argb) {
        return argb & 0xff;
    }

    private static int channelRange(int argb) {
        int maximum = Math.max(red(argb), Math.max(green(argb), blue(argb)));
        int minimum = Math.min(red(argb), Math.min(green(argb), blue(argb)));
        return maximum - minimum;
    }

    private static double saturation(int argb) {
        int maximum = Math.max(red(argb), Math.max(green(argb), blue(argb)));
        int minimum = Math.min(red(argb), Math.min(green(argb), blue(argb)));
        return maximum == 0 ? 0.0 : (maximum - minimum) / (double) maximum;
    }

    private static double luminance(int argb) {
        return (red(argb) * 0.2126 + green(argb) * 0.7152 + blue(argb) * 0.0722)
                / 255.0;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
