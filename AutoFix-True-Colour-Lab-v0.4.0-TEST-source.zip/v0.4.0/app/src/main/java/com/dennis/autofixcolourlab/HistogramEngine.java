package com.dennis.autofixcolourlab;

import java.util.Locale;

/** Deterministic, offline histogram and colour-cast correction. */
public final class HistogramEngine {
    private static final double LOG_2 = Math.log(2.0);
    private static final double[] SRGB_TO_LINEAR = new double[256];
    private static final double ZONE_CORE_HALF_SPAN = 1.0 / 6.0;
    private static final double ZONE_SUPPORT_HALF_SPAN = 0.24;
    private static final double GLOBAL_LOCAL_BLEND = 0.20;
    private static final int CHANNEL_RISK_MINIMUM = 225;
    private static final int CHANNEL_RISK_MAXIMUM = 254;
    private static final double CHANNEL_RISK_MINIMUM_SATURATION = 0.30;
    private static final double CHANNEL_GUARD_TRIGGER_RATE = 0.004;
    private static final double CHANNEL_GUARD_KNEE_START = 218.0;
    private static final double CHANNEL_GUARD_KNEE_END = 234.0;
    private static final double CHANNEL_GUARD_SATURATION_START = 0.22;
    private static final double CHANNEL_GUARD_SATURATION_END = 0.42;
    private static final double CHANNEL_GUARD_HEADROOM_USE = 0.68;
    private static final double[] ZONE_WEIGHTS = new double[] {
            0.45, 0.65, 0.45,
            0.65, 1.00, 0.65,
            0.55, 0.75, 0.55
    };

    static {
        for (int i = 0; i < 256; i++) {
            double value = i / 255.0;
            SRGB_TO_LINEAR[i] = value <= 0.04045
                    ? value / 12.92
                    : Math.pow((value + 0.055) / 1.055, 2.4);
        }
    }

    private HistogramEngine() {
    }

    public static final class Analysis {
        public final int[] toneLut;
        public final double redGain;
        public final double greenGain;
        public final double blueGain;
        public final double saturation;
        public final double exposureEv;
        public final double neutralCoverage;
        public final double colourConfidence;
        public final double shadowClipRate;
        public final double highlightClipRate;
        public final double channelHighlightRiskRate;
        public final double averageSaturation;
        public final int blackPoint;
        public final int whitePoint;
        public final int percentile01;
        public final int median;
        public final int percentile99;
        public final long sampleCount;
        public final double[] zoneExposureEv;
        public final boolean multiZoneActive;
        public final double maxLocalEv;
        public final double mixedLightScore;
        public final boolean mixedLightGuarded;
        public final boolean channelHighlightGuarded;
        public final boolean alreadyBalanced;
        public final int recommendedStrengthPercent;

        private Analysis(
                int[] toneLut,
                double redGain,
                double greenGain,
                double blueGain,
                double saturation,
                double exposureEv,
                double neutralCoverage,
                double colourConfidence,
                double shadowClipRate,
                double highlightClipRate,
                double channelHighlightRiskRate,
                double averageSaturation,
                int blackPoint,
                int whitePoint,
                int percentile01,
                int median,
                int percentile99,
                long sampleCount,
                double[] zoneExposureEv,
                boolean multiZoneActive,
                double maxLocalEv,
                double mixedLightScore,
                boolean mixedLightGuarded,
                boolean channelHighlightGuarded,
                boolean alreadyBalanced,
                int recommendedStrengthPercent) {
            this.toneLut = toneLut;
            this.redGain = redGain;
            this.greenGain = greenGain;
            this.blueGain = blueGain;
            this.saturation = saturation;
            this.exposureEv = exposureEv;
            this.neutralCoverage = neutralCoverage;
            this.colourConfidence = colourConfidence;
            this.shadowClipRate = shadowClipRate;
            this.highlightClipRate = highlightClipRate;
            this.channelHighlightRiskRate = channelHighlightRiskRate;
            this.averageSaturation = averageSaturation;
            this.blackPoint = blackPoint;
            this.whitePoint = whitePoint;
            this.percentile01 = percentile01;
            this.median = median;
            this.percentile99 = percentile99;
            this.sampleCount = sampleCount;
            this.zoneExposureEv = zoneExposureEv.clone();
            this.multiZoneActive = multiZoneActive;
            this.maxLocalEv = maxLocalEv;
            this.mixedLightScore = mixedLightScore;
            this.mixedLightGuarded = mixedLightGuarded;
            this.channelHighlightGuarded = channelHighlightGuarded;
            this.alreadyBalanced = alreadyBalanced;
            this.recommendedStrengthPercent = recommendedStrengthPercent;
        }

        public String toneSummary() {
            if (alreadyBalanced) {
                return String.format(
                        Locale.US,
                        "Already balanced  •  midpoint %d  •  highlights %d",
                        median,
                        percentile99);
            }
            String global = String.format(
                    Locale.US,
                    "Light %+.2f EV  •  shadows %d  •  midpoint %d  •  highlights %d",
                    exposureEv,
                    percentile01,
                    median,
                    percentile99);
            String result = global;
            if (multiZoneActive) {
                result += String.format(
                        Locale.US,
                        "\nOverlapping 3×3 light balance  •  local limit ±%.2f EV",
                        maxLocalEv);
            }
            if (channelHighlightGuarded) {
                result += "\nRGB highlight protection  •  saturated colours protected";
            }
            return result;
        }

        public String colourSummary() {
            if (colourConfidence < 0.08) {
                return "Colour balance held — no reliable neutral reference";
            }
            String measured = String.format(
                    Locale.US,
                    "Colour R %.1f%%  G %.1f%%  B %.1f%%  •  confidence %.0f%%",
                    redGain * 100.0,
                    greenGain * 100.0,
                    blueGain * 100.0,
                    colourConfidence * 100.0);
            if (mixedLightGuarded) {
                return measured + "\nMixed-light safeguard reduced the global colour shift";
            }
            return measured;
        }
    }

    /** Incremental analyser used to sample large images without allocating a second full bitmap. */
    public static final class Accumulator {
        private final double[] luminanceHistogram = new double[256];
        private double sampleWeight;
        private double saturationSum;
        private double neutralCandidateWeight;
        private double neutralWeight;
        private double neutralRed;
        private double neutralGreen;
        private double neutralBlue;
        private double channelHighlightRiskWeight;

        public void addPixel(int argb) {
            addPixel(argb, 1.0);
        }

        private void addPixel(int argb, double evidenceWeight) {
            if (evidenceWeight <= 0.0) {
                return;
            }
            int alpha = (argb >>> 24) & 0xff;
            if (alpha < 16) {
                return;
            }

            int red = (argb >>> 16) & 0xff;
            int green = (argb >>> 8) & 0xff;
            int blue = argb & 0xff;
            int maximum = Math.max(red, Math.max(green, blue));
            int minimum = Math.min(red, Math.min(green, blue));
            int luminance = clampInt((int) Math.round(
                    red * 0.2126 + green * 0.7152 + blue * 0.0722), 0, 255);

            luminanceHistogram[luminance] += evidenceWeight;
            sampleWeight += evidenceWeight;

            double pixelSaturation = maximum == 0
                    ? 0.0 : (maximum - minimum) / (double) maximum;
            saturationSum += pixelSaturation * evidenceWeight;
            if (maximum >= CHANNEL_RISK_MINIMUM
                    && maximum <= CHANNEL_RISK_MAXIMUM
                    && pixelSaturation >= CHANNEL_RISK_MINIMUM_SATURATION) {
                channelHighlightRiskWeight += evidenceWeight;
            }

            // Midtone, low-chroma pixels are the safest non-semantic white-balance evidence.
            if (luminance >= 28 && luminance <= 238 && pixelSaturation < 0.22) {
                neutralCandidateWeight += evidenceWeight;
                double chromaWeight = 1.0 - pixelSaturation / 0.22;
                chromaWeight = 0.15 + 0.85 * chromaWeight * chromaWeight;
                double distance = Math.abs(luminance - 133.0) / 110.0;
                double midtoneWeight = 0.35 + 0.65 * (1.0 - clamp(distance, 0.0, 1.0));
                double weight = chromaWeight * midtoneWeight * evidenceWeight;
                neutralWeight += weight;
                neutralRed += SRGB_TO_LINEAR[red] * weight;
                neutralGreen += SRGB_TO_LINEAR[green] * weight;
                neutralBlue += SRGB_TO_LINEAR[blue] * weight;
            }
        }

        public Analysis finish() {
            if (sampleWeight <= 0.0) {
                return identityAnalysis();
            }

            int low005 = percentile(luminanceHistogram, sampleWeight, 0.005);
            int p01 = percentile(luminanceHistogram, sampleWeight, 0.01);
            int median = percentile(luminanceHistogram, sampleWeight, 0.50);
            int p99 = percentile(luminanceHistogram, sampleWeight, 0.99);
            int high995 = percentile(luminanceHistogram, sampleWeight, 0.995);
            double shadowClip = sum(luminanceHistogram, 0, 3) / sampleWeight;
            double highlightClip = sum(luminanceHistogram, 252, 255) / sampleWeight;
            int dynamicRange = high995 - low005;

            int blackPoint = 0;
            if (dynamicRange < 220 && low005 > 4 && shadowClip < 0.004) {
                blackPoint = clampInt(low005 - 3, 0, 18);
            }

            int whitePoint = 255;
            if (dynamicRange < 220 && high995 < 252 && highlightClip < 0.004) {
                whitePoint = clampInt(high995 + 4, 238, 252);
            }

            double rawEv = log2(122.0 / Math.max(18.0, median));
            double exposureEv = clamp(rawEv, -0.45, 0.65);
            if (exposureEv > 0.0 && p99 > 244) {
                double headroomFactor = clamp((255.0 - p99) / 11.0, 0.12, 1.0);
                exposureEv *= headroomFactor;
            }
            if (exposureEv > 0.0 && highlightClip > 0.008) {
                exposureEv = 0.0;
            }
            if (exposureEv < 0.0 && shadowClip > 0.02) {
                exposureEv *= 0.55;
            }

            double desiredMedian = clamp(
                    median * Math.pow(2.0, exposureEv), 70.0, 160.0);
            int outputAtWhitePoint = whitePoint >= 253 ? 255 : 250;
            double normalizedMedian = (median - blackPoint)
                    / (double) Math.max(1, whitePoint - blackPoint);
            normalizedMedian = clamp(normalizedMedian, 0.015, 0.985);
            double desiredNormalized = clamp(
                    desiredMedian / outputAtWhitePoint, 0.02, 0.98);
            double gamma = Math.log(desiredNormalized) / Math.log(normalizedMedian);
            gamma = clamp(gamma, 0.72, 1.35);

            int[] toneLut = new int[256];
            int previous = 0;
            for (int input = 0; input < 256; input++) {
                double output;
                if (input <= blackPoint) {
                    output = blackPoint == 0 ? 0.0 : input * (2.0 / blackPoint);
                } else if (input <= whitePoint) {
                    double normalized = (input - blackPoint)
                            / (double) Math.max(1, whitePoint - blackPoint);
                    output = Math.pow(clamp(normalized, 0.0, 1.0), gamma)
                            * outputAtWhitePoint;
                } else {
                    output = outputAtWhitePoint
                            + (input - whitePoint)
                            * ((255.0 - outputAtWhitePoint) / Math.max(1, 255 - whitePoint));
                }
                int mapped = clampInt((int) Math.round(output), 0, 255);
                if (mapped < previous) {
                    mapped = previous;
                }
                toneLut[input] = mapped;
                previous = mapped;
            }
            toneLut[255] = 255;

            double coverage = neutralCandidateWeight / sampleWeight;
            double colourConfidence = clamp((coverage - 0.002) / 0.050, 0.0, 1.0);
            double redGain = 1.0;
            double greenGain = 1.0;
            double blueGain = 1.0;
            if (neutralWeight > 1.0 && colourConfidence > 0.0) {
                double meanRed = neutralRed / neutralWeight;
                double meanGreen = neutralGreen / neutralWeight;
                double meanBlue = neutralBlue / neutralWeight;
                double neutralGrey = Math.cbrt(Math.max(1.0e-12,
                        meanRed * meanGreen * meanBlue));
                double correctionStrength = 0.72 * colourConfidence;
                redGain = Math.pow(neutralGrey / Math.max(1.0e-9, meanRed), correctionStrength);
                greenGain = Math.pow(neutralGrey / Math.max(1.0e-9, meanGreen), correctionStrength);
                blueGain = Math.pow(neutralGrey / Math.max(1.0e-9, meanBlue), correctionStrength);
                double gainNorm = Math.cbrt(redGain * greenGain * blueGain);
                redGain = clamp(redGain / gainNorm, 0.93, 1.075);
                greenGain = clamp(greenGain / gainNorm, 0.93, 1.075);
                blueGain = clamp(blueGain / gainNorm, 0.93, 1.075);
            }

            double averageSaturation = saturationSum / sampleWeight;
            double channelHighlightRiskRate = channelHighlightRiskWeight / sampleWeight;
            double saturation = clamp(
                    1.0 + (0.22 - averageSaturation) * 0.20, 0.96, 1.05);

            return makeAnalysis(
                    toneLut, redGain, greenGain, blueGain, saturation, exposureEv,
                    coverage, colourConfidence, shadowClip, highlightClip,
                    channelHighlightRiskRate, averageSaturation,
                    blackPoint, whitePoint, p01, median, p99,
                    Math.max(1L, Math.round(sampleWeight)),
                    new double[9], false, 0.0, 0.0, false);
        }
    }

    /** Global plus 3×3 regional analysis for conservative, smoothly blended light correction. */
    public static final class SpatialAccumulator {
        private final Accumulator global = new Accumulator();
        private final Accumulator[] zones = new Accumulator[9];

        public SpatialAccumulator() {
            for (int index = 0; index < zones.length; index++) {
                zones[index] = new Accumulator();
            }
        }

        public void addPixel(int argb, int zoneIndex) {
            global.addPixel(argb);
            if (zoneIndex >= 0 && zoneIndex < zones.length) {
                zones[zoneIndex].addPixel(argb);
            }
        }

        /**
         * Adds one global sample and softly shares its regional evidence across nearby zones.
         * Each zone keeps its original one-third core and gains a tapered overlap beyond it.
         */
        public void addPixelAt(int argb, double normalizedX, double normalizedY) {
            global.addPixel(argb);
            double x = clamp(normalizedX, 0.0, 1.0);
            double y = clamp(normalizedY, 0.0, 1.0);
            double x0 = regionalEvidenceWeight(Math.abs(x - (0.5 / 3.0)));
            double x1 = regionalEvidenceWeight(Math.abs(x - (1.5 / 3.0)));
            double x2 = regionalEvidenceWeight(Math.abs(x - (2.5 / 3.0)));
            double y0 = regionalEvidenceWeight(Math.abs(y - (0.5 / 3.0)));
            double y1 = regionalEvidenceWeight(Math.abs(y - (1.5 / 3.0)));
            double y2 = regionalEvidenceWeight(Math.abs(y - (2.5 / 3.0)));

            zones[0].addPixel(argb, x0 * y0);
            zones[1].addPixel(argb, x1 * y0);
            zones[2].addPixel(argb, x2 * y0);
            zones[3].addPixel(argb, x0 * y1);
            zones[4].addPixel(argb, x1 * y1);
            zones[5].addPixel(argb, x2 * y1);
            zones[6].addPixel(argb, x0 * y2);
            zones[7].addPixel(argb, x1 * y2);
            zones[8].addPixel(argb, x2 * y2);
        }

        double[] zoneEvidenceWeights() {
            double[] weights = new double[zones.length];
            for (int index = 0; index < zones.length; index++) {
                weights[index] = zones[index].sampleWeight;
            }
            return weights;
        }

        public Analysis finish() {
            Analysis globalAnalysis = global.finish();
            if (globalAnalysis.sampleCount == 0) {
                return globalAnalysis;
            }
            Analysis[] zoneAnalyses = new Analysis[9];
            for (int index = 0; index < zones.length; index++) {
                zoneAnalyses[index] = zones[index].finish();
            }
            return addSpatialSafeguards(globalAnalysis, zoneAnalyses);
        }
    }

    /** Precomputed per-render processor, efficient enough for full-resolution strip processing. */
    public static final class Processor {
        private final int[] redMap = new int[256];
        private final int[] greenMap = new int[256];
        private final int[] blueMap = new int[256];
        private final int[] toneMap = new int[256];
        private final double saturation;
        private final double strength;
        private final boolean channelHighlightGuarded;

        public Processor(Analysis analysis, double requestedStrength) {
            this(analysis, requestedStrength, true);
        }

        public Processor(
                Analysis analysis,
                double requestedStrength,
                boolean applyHistogramColour) {
            strength = clamp(requestedStrength, 0.0, 1.0);
            saturation = applyHistogramColour
                    ? 1.0 + (analysis.saturation - 1.0) * strength
                    : 1.0;
            channelHighlightGuarded = analysis.channelHighlightGuarded;
            double redGain = applyHistogramColour
                    ? Math.pow(analysis.redGain, strength) : 1.0;
            double greenGain = applyHistogramColour
                    ? Math.pow(analysis.greenGain, strength) : 1.0;
            double blueGain = applyHistogramColour
                    ? Math.pow(analysis.blueGain, strength) : 1.0;

            for (int value = 0; value < 256; value++) {
                redMap[value] = gainChannel(value, redGain);
                greenMap[value] = gainChannel(value, greenGain);
                blueMap[value] = gainChannel(value, blueGain);
                toneMap[value] = clampInt((int) Math.round(
                        value + (analysis.toneLut[value] - value) * strength), 0, 255);
            }
        }

        public int apply(int argb) {
            return apply(argb, 0.0);
        }

        public int apply(int argb, double localExposureEv) {
            if (strength <= 0.0) {
                return argb;
            }
            int alpha = (argb >>> 24) & 0xff;
            int sourceRed = (argb >>> 16) & 0xff;
            int sourceGreen = (argb >>> 8) & 0xff;
            int sourceBlue = argb & 0xff;
            int red = redMap[sourceRed];
            int green = greenMap[sourceGreen];
            int blue = blueMap[sourceBlue];
            int luminance = clampInt((int) Math.round(
                    red * 0.2126 + green * 0.7152 + blue * 0.0722), 0, 255);
            double targetLuminance = toneMap[luminance];

            double effectiveLocalEv = clamp(localExposureEv, -0.20, 0.30) * strength;
            if (effectiveLocalEv > 0.0) {
                effectiveLocalEv *= 1.0 - smoothStep(168.0, 250.0, targetLuminance);
            } else if (effectiveLocalEv < 0.0) {
                effectiveLocalEv *= smoothStep(14.0, 66.0, targetLuminance);
            }
            if (Math.abs(effectiveLocalEv) > 0.0001) {
                targetLuminance = clamp(
                        targetLuminance * Math.pow(2.0, effectiveLocalEv), 0.0, 255.0);
            }

            double outputRed = targetLuminance + (red - luminance) * saturation;
            double outputGreen = targetLuminance + (green - luminance) * saturation;
            double outputBlue = targetLuminance + (blue - luminance) * saturation;

            double maximum = Math.max(outputRed, Math.max(outputGreen, outputBlue));
            double minimum = Math.min(outputRed, Math.min(outputGreen, outputBlue));

            // Luminance can remain safe while a saturated red, green or blue subject
            // is driven into a broad 255 plateau. Preserve part of that source
            // channel's remaining headroom and scale RGB together, retaining hue and
            // local detail while normal shadow and midtone correction remains intact.
            if (channelHighlightGuarded && maximum > 0.0) {
                int sourceMaximum = Math.max(sourceRed, Math.max(sourceGreen, sourceBlue));
                int sourceMinimum = Math.min(sourceRed, Math.min(sourceGreen, sourceBlue));
                double sourceSaturation = sourceMaximum == 0
                        ? 0.0 : (sourceMaximum - sourceMinimum) / (double) sourceMaximum;
                if (sourceMaximum >= CHANNEL_GUARD_KNEE_START
                        && sourceMaximum < 255
                        && sourceSaturation > CHANNEL_GUARD_SATURATION_START) {
                    double channelWeight = smoothStep(
                            CHANNEL_GUARD_KNEE_START,
                            CHANNEL_GUARD_KNEE_END,
                            sourceMaximum);
                    double saturationWeight = smoothStep(
                            CHANNEL_GUARD_SATURATION_START,
                            CHANNEL_GUARD_SATURATION_END,
                            sourceSaturation);
                    double guardWeight = channelWeight * saturationWeight;
                    double protectedMaximum = sourceMaximum
                            + (255.0 - sourceMaximum) * CHANNEL_GUARD_HEADROOM_USE;
                    double allowedMaximum = 255.0
                            + (protectedMaximum - 255.0) * guardWeight;
                    if (maximum > allowedMaximum) {
                        double headroomScale = allowedMaximum / maximum;
                        outputRed *= headroomScale;
                        outputGreen *= headroomScale;
                        outputBlue *= headroomScale;
                        maximum *= headroomScale;
                        minimum *= headroomScale;
                        targetLuminance *= headroomScale;
                    }
                }
            }

            double chromaScale = 1.0;
            if (maximum > 255.0 && maximum > targetLuminance) {
                chromaScale = Math.min(chromaScale,
                        (255.0 - targetLuminance) / (maximum - targetLuminance));
            }
            if (minimum < 0.0 && minimum < targetLuminance) {
                chromaScale = Math.min(chromaScale,
                        targetLuminance / (targetLuminance - minimum));
            }
            chromaScale = clamp(chromaScale, 0.0, 1.0);
            outputRed = targetLuminance + (outputRed - targetLuminance) * chromaScale;
            outputGreen = targetLuminance + (outputGreen - targetLuminance) * chromaScale;
            outputBlue = targetLuminance + (outputBlue - targetLuminance) * chromaScale;

            return (alpha << 24)
                    | (clampInt((int) Math.round(outputRed), 0, 255) << 16)
                    | (clampInt((int) Math.round(outputGreen), 0, 255) << 8)
                    | clampInt((int) Math.round(outputBlue), 0, 255);
        }
    }

    private static Analysis addSpatialSafeguards(Analysis global, Analysis[] zones) {
        boolean[] reliableZone = new boolean[9];
        double[] weighted = new double[9];
        long minimumZoneSamples = Math.max(24L, global.sampleCount / 90L);

        for (int index = 0; index < zones.length; index++) {
            Analysis zone = zones[index];
            reliableZone[index] = zone.sampleCount >= minimumZoneSamples;
            if (!reliableZone[index]) {
                continue;
            }
            // Pull local decisions 20% toward the whole-image measurement. This keeps
            // overlap useful near boundaries without letting a small patch dominate.
            double residual = (zone.exposureEv - global.exposureEv)
                    * (1.0 - GLOBAL_LOCAL_BLEND);
            if (residual > 0.0 && zone.percentile99 > 244) {
                residual *= clamp((255.0 - zone.percentile99) / 11.0, 0.0, 1.0);
            }
            if (residual > 0.0 && zone.highlightClipRate > 0.008) {
                residual = 0.0;
            }
            weighted[index] = clamp(residual, -0.20, 0.30) * ZONE_WEIGHTS[index];
        }

        double[] smoothed = new double[9];
        for (int index = 0; index < 9; index++) {
            if (!reliableZone[index]) {
                continue;
            }
            int row = index / 3;
            int column = index % 3;
            double neighbourSum = 0.0;
            int neighbourCount = 0;
            for (int deltaRow = -1; deltaRow <= 1; deltaRow++) {
                for (int deltaColumn = -1; deltaColumn <= 1; deltaColumn++) {
                    if (Math.abs(deltaRow) + Math.abs(deltaColumn) != 1) {
                        continue;
                    }
                    int neighbourRow = row + deltaRow;
                    int neighbourColumn = column + deltaColumn;
                    if (neighbourRow >= 0 && neighbourRow < 3
                            && neighbourColumn >= 0 && neighbourColumn < 3) {
                        int neighbour = neighbourRow * 3 + neighbourColumn;
                        if (reliableZone[neighbour]) {
                            neighbourSum += weighted[neighbour];
                            neighbourCount++;
                        }
                    }
                }
            }
            double neighbourAverage = neighbourCount == 0
                    ? weighted[index] : neighbourSum / neighbourCount;
            smoothed[index] = weighted[index] * 0.76 + neighbourAverage * 0.24;
        }

        double fieldMean = 0.0;
        int reliableCount = 0;
        for (int index = 0; index < 9; index++) {
            if (reliableZone[index]) {
                fieldMean += smoothed[index];
                reliableCount++;
            }
        }
        if (reliableCount > 0) {
            fieldMean /= reliableCount;
        }

        double minimumLocal = Double.POSITIVE_INFINITY;
        double maximumLocal = Double.NEGATIVE_INFINITY;
        double maxLocalEv = 0.0;
        for (int index = 0; index < 9; index++) {
            if (reliableZone[index]) {
                smoothed[index] = clamp(smoothed[index] - fieldMean, -0.20, 0.30);
            } else {
                smoothed[index] = 0.0;
            }
            minimumLocal = Math.min(minimumLocal, smoothed[index]);
            maximumLocal = Math.max(maximumLocal, smoothed[index]);
            maxLocalEv = Math.max(maxLocalEv, Math.abs(smoothed[index]));
        }
        boolean multiZoneActive = reliableCount >= 5
                && maxLocalEv >= 0.06
                && maximumLocal - minimumLocal >= 0.11;
        if (!multiZoneActive) {
            smoothed = new double[9];
            maxLocalEv = 0.0;
        }

        double maximumColourDistance = 0.0;
        int colourZoneCount = 0;
        for (int first = 0; first < 9; first++) {
            if (!reliableZone[first] || zones[first].colourConfidence < 0.15) {
                continue;
            }
            colourZoneCount++;
            double firstRed = Math.log(zones[first].redGain / zones[first].greenGain);
            double firstBlue = Math.log(zones[first].blueGain / zones[first].greenGain);
            for (int second = first + 1; second < 9; second++) {
                if (!reliableZone[second] || zones[second].colourConfidence < 0.15) {
                    continue;
                }
                double secondRed = Math.log(zones[second].redGain / zones[second].greenGain);
                double secondBlue = Math.log(zones[second].blueGain / zones[second].greenGain);
                double deltaRed = firstRed - secondRed;
                double deltaBlue = firstBlue - secondBlue;
                maximumColourDistance = Math.max(maximumColourDistance,
                        Math.sqrt(deltaRed * deltaRed + deltaBlue * deltaBlue));
            }
        }
        double mixedLightScore = colourZoneCount >= 3
                ? clamp((maximumColourDistance - 0.025) / 0.105, 0.0, 1.0)
                : 0.0;
        boolean mixedLightGuarded = mixedLightScore >= 0.15;
        double redGain = global.redGain;
        double greenGain = global.greenGain;
        double blueGain = global.blueGain;
        if (mixedLightGuarded) {
            double retainedCorrection = clamp(1.0 - 0.82 * mixedLightScore, 0.18, 1.0);
            redGain = Math.exp(Math.log(redGain) * retainedCorrection);
            greenGain = Math.exp(Math.log(greenGain) * retainedCorrection);
            blueGain = Math.exp(Math.log(blueGain) * retainedCorrection);
            double gainNorm = Math.cbrt(redGain * greenGain * blueGain);
            redGain /= gainNorm;
            greenGain /= gainNorm;
            blueGain /= gainNorm;
        }

        return makeAnalysis(
                global.toneLut, redGain, greenGain, blueGain, global.saturation,
                global.exposureEv, global.neutralCoverage, global.colourConfidence,
                global.shadowClipRate, global.highlightClipRate,
                global.channelHighlightRiskRate, global.averageSaturation,
                global.blackPoint, global.whitePoint, global.percentile01, global.median,
                global.percentile99, global.sampleCount, smoothed, multiZoneActive,
                maxLocalEv, mixedLightScore, mixedLightGuarded);
    }

    private static Analysis makeAnalysis(
            int[] toneLut,
            double redGain,
            double greenGain,
            double blueGain,
            double saturation,
            double exposureEv,
            double neutralCoverage,
            double colourConfidence,
            double shadowClipRate,
            double highlightClipRate,
            double channelHighlightRiskRate,
            double averageSaturation,
            int blackPoint,
            int whitePoint,
            int percentile01,
            int median,
            int percentile99,
            long sampleCount,
            double[] zoneExposureEv,
            boolean multiZoneActive,
            double maxLocalEv,
            double mixedLightScore,
            boolean mixedLightGuarded) {
        double largestGainShift = Math.max(
                Math.abs(redGain - 1.0),
                Math.max(Math.abs(greenGain - 1.0), Math.abs(blueGain - 1.0)));
        boolean toneNeeded = Math.abs(exposureEv) >= 0.08
                || blackPoint >= 5
                || whitePoint <= 250;
        boolean colourNeeded = colourConfidence >= 0.15 && largestGainShift >= 0.012;
        boolean saturationNeeded = averageSaturation > 0.05
                && Math.abs(saturation - 1.0) >= 0.015;
        boolean alreadyBalanced = !toneNeeded
                && !colourNeeded
                && !saturationNeeded
                && !multiZoneActive;
        boolean channelHighlightGuarded = exposureEv > 0.08
                && channelHighlightRiskRate >= CHANNEL_GUARD_TRIGGER_RATE;

        int recommendedStrength = 100;
        if (alreadyBalanced) {
            recommendedStrength = 0;
        } else {
            if (Math.abs(exposureEv) > 0.50 || maxLocalEv > 0.20) {
                recommendedStrength = Math.min(recommendedStrength, 90);
            }
            if (highlightClipRate > 0.004 || shadowClipRate > 0.015) {
                recommendedStrength = Math.min(recommendedStrength, 90);
            }
            if (mixedLightScore > 0.35) {
                recommendedStrength = Math.min(recommendedStrength, 90);
            }
            if (mixedLightScore > 0.72) {
                recommendedStrength = Math.min(recommendedStrength, 85);
            }
        }

        return new Analysis(
                toneLut, redGain, greenGain, blueGain, saturation, exposureEv,
                neutralCoverage, colourConfidence, shadowClipRate, highlightClipRate,
                channelHighlightRiskRate, averageSaturation, blackPoint, whitePoint,
                percentile01, median, percentile99,
                sampleCount, zoneExposureEv, multiZoneActive, maxLocalEv, mixedLightScore,
                mixedLightGuarded, channelHighlightGuarded,
                alreadyBalanced, recommendedStrength);
    }

    private static Analysis identityAnalysis() {
        int[] identity = new int[256];
        for (int i = 0; i < identity.length; i++) {
            identity[i] = i;
        }
        return new Analysis(
                identity, 1.0, 1.0, 1.0, 1.0, 0.0,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0, 255, 0, 128, 255, 0,
                new double[9], false, 0.0, 0.0, false, false, true, 0);
    }

    private static int gainChannel(int value, double gain) {
        double linear = clamp(SRGB_TO_LINEAR[value] * gain, 0.0, 1.0);
        double srgb = linear <= 0.0031308
                ? linear * 12.92
                : 1.055 * Math.pow(linear, 1.0 / 2.4) - 0.055;
        return clampInt((int) Math.round(srgb * 255.0), 0, 255);
    }

    private static int percentile(double[] histogram, double count, double fraction) {
        double target = Math.max(1.0e-12, count * fraction);
        double cumulative = 0.0;
        for (int value = 0; value < histogram.length; value++) {
            cumulative += histogram[value];
            if (cumulative >= target) {
                return value;
            }
        }
        return 255;
    }

    private static double sum(double[] histogram, int from, int to) {
        double result = 0.0;
        for (int index = from; index <= to; index++) {
            result += histogram[index];
        }
        return result;
    }

    private static double log2(double value) {
        return Math.log(value) / LOG_2;
    }

    private static double smoothStep(double edge0, double edge1, double value) {
        double normalized = clamp((value - edge0) / (edge1 - edge0), 0.0, 1.0);
        return normalized * normalized * (3.0 - 2.0 * normalized);
    }

    private static double regionalEvidenceWeight(double distanceFromCentre) {
        if (distanceFromCentre <= ZONE_CORE_HALF_SPAN) {
            return 1.0;
        }
        if (distanceFromCentre >= ZONE_SUPPORT_HALF_SPAN) {
            return 0.0;
        }
        return 1.0 - smoothStep(
                ZONE_CORE_HALF_SPAN, ZONE_SUPPORT_HALF_SPAN, distanceFromCentre);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static int clampInt(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
