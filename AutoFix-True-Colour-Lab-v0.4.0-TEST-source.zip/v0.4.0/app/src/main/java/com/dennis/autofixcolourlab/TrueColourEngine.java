package com.dennis.autofixcolourlab;

import java.util.Locale;

/**
 * Experimental, deterministic colour-constancy engine.
 *
 * Several independent estimators must agree before a Bradford chromatic
 * adaptation is applied. Mixed illuminants can receive a restrained,
 * overlapping 3x3 residual colour field. Everything runs offline.
 */
public final class TrueColourEngine {
    private static final double EPSILON = 1.0e-9;
    private static final int METHOD_CAPACITY = 5;
    private static final int MODE_BINS = 19;
    private static final double MODE_RANGE = 0.36;
    private static final double CONSENSUS_DISTANCE = 0.075;
    private static final double MAX_EQUIVALENT_GAIN = 1.12;
    private static final double MAX_LOCAL_GAIN = 1.045;
    private static final double ZONE_CORE_HALF_SPAN = 1.0 / 6.0;
    private static final double ZONE_SUPPORT_HALF_SPAN = 0.24;
    private static final double[] SRGB_TO_LINEAR = new double[256];
    private static final int LINEAR_LUT_SIZE = 8192;
    private static final int[] LINEAR_TO_SRGB = new int[LINEAR_LUT_SIZE + 1];

    private static final double[] IDENTITY = new double[] {
            1.0, 0.0, 0.0,
            0.0, 1.0, 0.0,
            0.0, 0.0, 1.0
    };

    private static final double[] RGB_TO_XYZ = new double[] {
            0.4124564, 0.3575761, 0.1804375,
            0.2126729, 0.7151522, 0.0721750,
            0.0193339, 0.1191920, 0.9503041
    };

    private static final double[] XYZ_TO_RGB = new double[] {
            3.2404542, -1.5371385, -0.4985314,
            -0.9692660, 1.8760108, 0.0415560,
            0.0556434, -0.2040259, 1.0572252
    };

    private static final double[] BRADFORD = new double[] {
            0.8951, 0.2664, -0.1614,
            -0.7502, 1.7135, 0.0367,
            0.0389, -0.0685, 1.0296
    };

    private static final double[] BRADFORD_INVERSE = new double[] {
            0.9869929, -0.1470543, 0.1599627,
            0.4323053, 0.5183603, 0.0492912,
            -0.0085287, 0.0400428, 0.9684867
    };

    private static final double[] D65_XYZ = new double[] {
            0.95047, 1.0, 1.08883
    };

    static {
        for (int value = 0; value < 256; value++) {
            double encoded = value / 255.0;
            SRGB_TO_LINEAR[value] = encoded <= 0.04045
                    ? encoded / 12.92
                    : Math.pow((encoded + 0.055) / 1.055, 2.4);
        }
        for (int index = 0; index <= LINEAR_LUT_SIZE; index++) {
            double linear = index / (double) LINEAR_LUT_SIZE;
            double encoded = linear <= 0.0031308
                    ? linear * 12.92
                    : 1.055 * Math.pow(linear, 1.0 / 2.4) - 0.055;
            LINEAR_TO_SRGB[index] = clampInt(
                    (int) Math.round(encoded * 255.0), 0, 255);
        }
    }

    private TrueColourEngine() {
    }

    public static final class Analysis {
        public final double[] adaptationMatrix;
        public final double redGain;
        public final double greenGain;
        public final double blueGain;
        public final double confidence;
        public final double agreement;
        public final int agreeingMethods;
        public final int availableMethods;
        public final int independentFamilies;
        public final double neutralCoverage;
        public final long sampleCount;
        public final boolean globalActive;
        public final boolean active;
        public final boolean previewOnly;
        public final String holdReason;
        public final double[] zoneRedGain;
        public final double[] zoneGreenGain;
        public final double[] zoneBlueGain;
        public final boolean spatialActive;
        public final double mixedLightScore;
        public final double maxLocalGainPercent;

        private Analysis(
                double[] adaptationMatrix,
                double redGain,
                double greenGain,
                double blueGain,
                double confidence,
                double agreement,
                int agreeingMethods,
                int availableMethods,
                int independentFamilies,
                double neutralCoverage,
                long sampleCount,
                boolean globalActive,
                boolean previewOnly,
                String holdReason,
                double[] zoneRedGain,
                double[] zoneGreenGain,
                double[] zoneBlueGain,
                boolean spatialActive,
                double mixedLightScore,
                double maxLocalGainPercent) {
            this.adaptationMatrix = adaptationMatrix.clone();
            this.redGain = redGain;
            this.greenGain = greenGain;
            this.blueGain = blueGain;
            this.confidence = confidence;
            this.agreement = agreement;
            this.agreeingMethods = agreeingMethods;
            this.availableMethods = availableMethods;
            this.independentFamilies = independentFamilies;
            this.neutralCoverage = neutralCoverage;
            this.sampleCount = sampleCount;
            this.globalActive = globalActive;
            this.spatialActive = spatialActive;
            this.active = globalActive || spatialActive;
            this.previewOnly = previewOnly;
            this.holdReason = holdReason;
            this.zoneRedGain = zoneRedGain.clone();
            this.zoneGreenGain = zoneGreenGain.clone();
            this.zoneBlueGain = zoneBlueGain.clone();
            this.mixedLightScore = mixedLightScore;
            this.maxLocalGainPercent = maxLocalGainPercent;
        }

        public String summary() {
            if (!active) {
                if ("already neutral".equals(holdReason)) {
                    return String.format(
                            Locale.US,
                            "True Colour held — measured colour is already neutral  •  confidence %.0f%%",
                            confidence * 100.0);
                }
                return "True Colour held — " + holdReason;
            }

            String result;
            if (globalActive) {
                if (previewOnly) {
                    result = String.format(
                            Locale.US,
                            "LAB preview candidate  •  evidence %.0f%%\n"
                                    + "Guarded adaptation R %.1f%%  G %.1f%%  B %.1f%%",
                            confidence * 100.0,
                            redGain * 100.0,
                            greenGain * 100.0,
                            blueGain * 100.0);
                } else {
                    result = String.format(
                            Locale.US,
                            "True Colour consensus %d/%d  •  confidence %.0f%%\n"
                                    + "Linear adaptation R %.1f%%  G %.1f%%  B %.1f%%",
                            agreeingMethods,
                            availableMethods,
                            confidence * 100.0,
                            redGain * 100.0,
                            greenGain * 100.0,
                            blueGain * 100.0);
                }
            } else {
                result = String.format(
                        Locale.US,
                        "True Colour regional consensus  •  confidence %.0f%%",
                        confidence * 100.0);
            }
            if (spatialActive) {
                result += String.format(
                        Locale.US,
                        "\nOverlapping 3×3 colour map  •  local limit ±%.1f%%",
                        maxLocalGainPercent);
            }
            return result;
        }
    }

    private static final class Candidate {
        final double logRedGreen;
        final double logBlueGreen;
        final double reliability;
        final int family;

        Candidate(
                double logRedGreen,
                double logBlueGreen,
                double reliability,
                int family) {
            this.logRedGreen = logRedGreen;
            this.logBlueGreen = logBlueGreen;
            this.reliability = reliability;
            this.family = family;
        }
    }

    public static final class Accumulator {
        private double sampleWeight;

        private double neutralCandidateWeight;
        private double neutralWeight;
        private double neutralRed;
        private double neutralGreen;
        private double neutralBlue;

        private double greyWeight;
        private double greyRed;
        private double greyGreen;
        private double greyBlue;

        private double shadesWeight;
        private double shadesRed;
        private double shadesGreen;
        private double shadesBlue;

        private double brightWeight;
        private double brightRed;
        private double brightGreen;
        private double brightBlue;

        private final double[] modeWeight = new double[MODE_BINS * MODE_BINS];
        private final double[] modeLogRed = new double[MODE_BINS * MODE_BINS];
        private final double[] modeLogBlue = new double[MODE_BINS * MODE_BINS];

        public void addPixel(int argb) {
            addPixel(argb, 1.0);
        }

        private void addPixel(int argb, double evidenceWeight) {
            if (evidenceWeight <= 0.0 || ((argb >>> 24) & 0xff) < 16) {
                return;
            }

            int red8 = (argb >>> 16) & 0xff;
            int green8 = (argb >>> 8) & 0xff;
            int blue8 = argb & 0xff;
            int maximum = Math.max(red8, Math.max(green8, blue8));
            int minimum = Math.min(red8, Math.min(green8, blue8));
            double saturation = maximum == 0
                    ? 0.0 : (maximum - minimum) / (double) maximum;
            double luminance = red8 * 0.2126 + green8 * 0.7152 + blue8 * 0.0722;
            double red = SRGB_TO_LINEAR[red8];
            double green = SRGB_TO_LINEAR[green8];
            double blue = SRGB_TO_LINEAR[blue8];
            sampleWeight += evidenceWeight;

            if (luminance >= 26.0 && luminance <= 238.0 && saturation < 0.22) {
                neutralCandidateWeight += evidenceWeight;
                double chromaWeight = 1.0 - saturation / 0.22;
                chromaWeight = 0.12 + 0.88 * chromaWeight * chromaWeight;
                double middle = 1.0 - Math.abs(luminance - 132.0) / 116.0;
                double weight = chromaWeight
                        * (0.32 + 0.68 * clamp(middle, 0.0, 1.0))
                        * evidenceWeight;
                neutralWeight += weight;
                neutralRed += red * weight;
                neutralGreen += green * weight;
                neutralBlue += blue * weight;
            }

            if (luminance >= 14.0 && luminance <= 245.0 && saturation < 0.75) {
                double chromaWeight = 1.0
                        - 0.68 * smoothStep(0.18, 0.75, saturation);
                double levelWeight = smoothStep(10.0, 42.0, luminance)
                        * (1.0 - 0.45 * smoothStep(220.0, 248.0, luminance));
                double weight = chromaWeight * levelWeight * evidenceWeight;
                greyWeight += weight;
                greyRed += red * weight;
                greyGreen += green * weight;
                greyBlue += blue * weight;

                double shadesEvidence = (0.35 + 0.65 * chromaWeight)
                        * levelWeight * evidenceWeight;
                shadesWeight += shadesEvidence;
                shadesRed += Math.pow(red, 6.0) * shadesEvidence;
                shadesGreen += Math.pow(green, 6.0) * shadesEvidence;
                shadesBlue += Math.pow(blue, 6.0) * shadesEvidence;
            }

            if (luminance >= 145.0 && luminance <= 246.0 && saturation < 0.35) {
                double chromaWeight = 1.0 - saturation / 0.35;
                double weight = (0.15 + 0.85 * chromaWeight * chromaWeight)
                        * (0.25 + 0.75 * smoothStep(145.0, 220.0, luminance))
                        * evidenceWeight;
                brightWeight += weight;
                brightRed += red * weight;
                brightGreen += green * weight;
                brightBlue += blue * weight;
            }

            if (luminance >= 34.0 && luminance <= 236.0
                    && saturation < 0.34 && green > 0.0002) {
                double logRed = Math.log((red + 0.0004) / (green + 0.0004));
                double logBlue = Math.log((blue + 0.0004) / (green + 0.0004));
                if (Math.abs(logRed) <= MODE_RANGE && Math.abs(logBlue) <= MODE_RANGE) {
                    int redBin = clampInt((int) Math.floor(
                            (logRed + MODE_RANGE) * MODE_BINS / (2.0 * MODE_RANGE)),
                            0, MODE_BINS - 1);
                    int blueBin = clampInt((int) Math.floor(
                            (logBlue + MODE_RANGE) * MODE_BINS / (2.0 * MODE_RANGE)),
                            0, MODE_BINS - 1);
                    double chromaWeight = 1.0 - saturation / 0.34;
                    double weight = (0.18 + 0.82 * chromaWeight * chromaWeight)
                            * evidenceWeight;
                    int index = blueBin * MODE_BINS + redBin;
                    modeWeight[index] += weight;
                    modeLogRed[index] += logRed * weight;
                    modeLogBlue[index] += logBlue * weight;
                }
            }
        }

        public Analysis finish() {
            return finish(false);
        }

        /**
         * Returns the guarded LAB audition candidate even when automatic
         * consensus deliberately abstains. The normal finish() result remains
         * unchanged and continues to drive the automatic SAFE/LAB decision.
         */
        public Analysis finishPreview() {
            return finish(true);
        }

        private Analysis finish(boolean allowPreviewCandidate) {
            if (sampleWeight <= 0.0) {
                return identityAnalysis("no usable pixels", 0L);
            }

            Candidate[] candidates = new Candidate[METHOD_CAPACITY];
            int count = 0;
            double neutralCoverage = neutralCandidateWeight / sampleWeight;

            if (neutralWeight >= 4.0 && neutralCoverage >= 0.0010) {
                candidates[count++] = candidateFromMeans(
                        neutralRed / neutralWeight,
                        neutralGreen / neutralWeight,
                        neutralBlue / neutralWeight,
                        clamp((neutralCoverage - 0.001) / 0.045, 0.22, 1.0),
                        0);
            }

            if (greyWeight >= 8.0) {
                candidates[count++] = candidateFromMeans(
                        greyRed / greyWeight,
                        greyGreen / greyWeight,
                        greyBlue / greyWeight,
                        0.46,
                        1);
            }

            if (shadesWeight >= 8.0) {
                candidates[count++] = candidateFromMeans(
                        Math.pow(Math.max(EPSILON, shadesRed / shadesWeight), 1.0 / 6.0),
                        Math.pow(Math.max(EPSILON, shadesGreen / shadesWeight), 1.0 / 6.0),
                        Math.pow(Math.max(EPSILON, shadesBlue / shadesWeight), 1.0 / 6.0),
                        0.40,
                        1);
            }

            double brightCoverage = brightWeight / sampleWeight;
            if (brightWeight >= 3.0 && brightCoverage >= 0.0006) {
                candidates[count++] = candidateFromMeans(
                        brightRed / brightWeight,
                        brightGreen / brightWeight,
                        brightBlue / brightWeight,
                        clamp((brightCoverage - 0.0006) / 0.025, 0.25, 0.82),
                        2);
            }

            int peak = 0;
            for (int index = 1; index < modeWeight.length; index++) {
                if (modeWeight[index] > modeWeight[peak]) {
                    peak = index;
                }
            }
            double modeCoverage = modeWeight[peak] / sampleWeight;
            if (modeWeight[peak] >= 2.0 && modeCoverage >= 0.0005) {
                candidates[count++] = new Candidate(
                        modeLogRed[peak] / modeWeight[peak],
                        modeLogBlue[peak] / modeWeight[peak],
                        clamp((modeCoverage - 0.0005) / 0.018, 0.28, 0.90),
                        3);
            }

            if (count < 3) {
                if (allowPreviewCandidate && count > 0) {
                    int previewMedoid = 0;
                    int previewFamilyMask = 0;
                    for (int index = 0; index < count; index++) {
                        previewFamilyMask |= 1 << candidates[index].family;
                        if (candidates[index].reliability
                                > candidates[previewMedoid].reliability) {
                            previewMedoid = index;
                        }
                    }
                    return buildPreviewAnalysis(
                            candidates,
                            count,
                            previewMedoid,
                            1,
                            Integer.bitCount(previewFamilyMask),
                            neutralCoverage,
                            Math.max(1L, Math.round(sampleWeight)));
                }
                return heldAnalysis(
                        "insufficient independent colour evidence",
                        count,
                        0,
                        0,
                        neutralCoverage,
                        Math.max(1L, Math.round(sampleWeight)),
                        0.0,
                        0.0);
            }

            int medoid = 0;
            double bestDistance = Double.POSITIVE_INFINITY;
            for (int first = 0; first < count; first++) {
                double distanceSum = 0.0;
                for (int second = 0; second < count; second++) {
                    if (first == second) {
                        continue;
                    }
                    distanceSum += colourDistance(candidates[first], candidates[second])
                            * candidates[second].reliability;
                }
                if (distanceSum < bestDistance) {
                    bestDistance = distanceSum;
                    medoid = first;
                }
            }

            boolean[] inlier = new boolean[count];
            int agreeing = 0;
            int familyMask = 0;
            double weightSum = 0.0;
            double consensusRed = 0.0;
            double consensusBlue = 0.0;
            for (int index = 0; index < count; index++) {
                if (colourDistance(candidates[index], candidates[medoid])
                        <= CONSENSUS_DISTANCE) {
                    inlier[index] = true;
                    agreeing++;
                    familyMask |= 1 << candidates[index].family;
                    weightSum += candidates[index].reliability;
                    consensusRed += candidates[index].logRedGreen
                            * candidates[index].reliability;
                    consensusBlue += candidates[index].logBlueGreen
                            * candidates[index].reliability;
                }
            }

            int families = Integer.bitCount(familyMask);
            boolean hasReferenceFamily = (familyMask & ((1 << 0) | (1 << 2) | (1 << 3))) != 0;
            boolean independentlySupported = agreeing >= 3
                    && hasReferenceFamily
                    && (families >= 3 || (agreeing >= 4 && families >= 2));
            if (!independentlySupported || weightSum <= 0.0) {
                if (allowPreviewCandidate) {
                    return buildPreviewAnalysis(
                            candidates,
                            count,
                            medoid,
                            agreeing,
                            families,
                            neutralCoverage,
                            Math.max(1L, Math.round(sampleWeight)));
                }
                return heldAnalysis(
                        "colour estimators did not reach consensus",
                        count,
                        agreeing,
                        families,
                        neutralCoverage,
                        Math.max(1L, Math.round(sampleWeight)),
                        0.0,
                        0.0);
            }

            consensusRed /= weightSum;
            consensusBlue /= weightSum;
            double spread = 0.0;
            for (int index = 0; index < count; index++) {
                if (!inlier[index]) {
                    continue;
                }
                double redDelta = candidates[index].logRedGreen - consensusRed;
                double blueDelta = candidates[index].logBlueGreen - consensusBlue;
                spread += (redDelta * redDelta + blueDelta * blueDelta)
                        * candidates[index].reliability;
            }
            spread = Math.sqrt(spread / weightSum);
            double agreement = clamp(1.0 - spread / CONSENSUS_DISTANCE, 0.0, 1.0);
            double methodConfidence = clamp((agreeing - 2.0) / 2.0, 0.45, 1.0);
            double familyConfidence = clamp((families - 1.0) / 3.0, 0.45, 1.0);
            double evidenceConfidence = clamp(weightSum / 2.4, 0.35, 1.0);
            double confidence = clamp(
                    agreement * methodConfidence * familyConfidence * evidenceConfidence,
                    0.0,
                    1.0);

            Analysis result = buildGlobalAnalysis(
                    consensusRed,
                    consensusBlue,
                    confidence,
                    agreement,
                    agreeing,
                    count,
                    families,
                    neutralCoverage,
                    Math.max(1L, Math.round(sampleWeight)));
            if (allowPreviewCandidate
                    && !result.active
                    && !"already neutral".equals(result.holdReason)) {
                return buildPreviewAnalysis(
                        candidates,
                        count,
                        medoid,
                        agreeing,
                        families,
                        neutralCoverage,
                        Math.max(1L, Math.round(sampleWeight)));
            }
            return result;
        }
    }

    public static final class SpatialAccumulator {
        private final Accumulator global = new Accumulator();
        private final Accumulator[] zones = new Accumulator[9];

        public SpatialAccumulator() {
            for (int index = 0; index < zones.length; index++) {
                zones[index] = new Accumulator();
            }
        }

        public void addPixelAt(int argb, double normalizedX, double normalizedY) {
            global.addPixel(argb);
            double x = clamp(normalizedX, 0.0, 1.0);
            double y = clamp(normalizedY, 0.0, 1.0);
            double x0 = regionalEvidenceWeight(Math.abs(x - (0.5 / 3.0)));
            double x1 = regionalEvidenceWeight(Math.abs(x - (1.5 / 3.0)));
            double x2 = regionalEvidenceWeight(Math.abs(x - (2.5 / 3.0)));
            double y0 = regionalEvidenceWeight(Math.abs(y - (0.5 / 3.0)));
            double y1 = regionalEvidenceWeight(Math.abs(y - (1.5 / 3.0)));
            double y2 = regionalEvidenceWeight(Math.abs(y - (2.5 / 3.0)));
            zones[0].addPixel(argb, x0 * y0);
            zones[1].addPixel(argb, x1 * y0);
            zones[2].addPixel(argb, x2 * y0);
            zones[3].addPixel(argb, x0 * y1);
            zones[4].addPixel(argb, x1 * y1);
            zones[5].addPixel(argb, x2 * y1);
            zones[6].addPixel(argb, x0 * y2);
            zones[7].addPixel(argb, x1 * y2);
            zones[8].addPixel(argb, x2 * y2);
        }

        public Analysis finish() {
            Analysis globalAnalysis = global.finish();
            Analysis[] zoneAnalysis = new Analysis[9];
            for (int index = 0; index < zones.length; index++) {
                zoneAnalysis[index] = zones[index].finish();
            }
            return addSpatialColour(globalAnalysis, zoneAnalysis);
        }

        public Analysis finishPreview() {
            Analysis globalAnalysis = global.finishPreview();
            Analysis[] zoneAnalysis = new Analysis[9];
            // Regional colour is still admitted only through normal consensus;
            // the best-effort relaxation applies to the global audition only.
            for (int index = 0; index < zones.length; index++) {
                zoneAnalysis[index] = zones[index].finish();
            }
            return addSpatialColour(globalAnalysis, zoneAnalysis);
        }
    }

    public static final class Processor {
        private final double[] matrix = new double[9];
        private final double strength;
        private final boolean active;

        public Processor(Analysis analysis, double requestedStrength) {
            strength = clamp(requestedStrength, 0.0, 1.0);
            active = analysis.active && strength > 0.0;
            for (int index = 0; index < matrix.length; index++) {
                double identity = IDENTITY[index];
                matrix[index] = identity
                        + (analysis.adaptationMatrix[index] - identity) * strength;
            }
        }

        public int apply(int argb) {
            return apply(argb, 1.0, 1.0, 1.0);
        }

        public int apply(
                int argb,
                double localRedGain,
                double localGreenGain,
                double localBlueGain) {
            if (!active) {
                return argb;
            }
            int alpha = (argb >>> 24) & 0xff;
            int red8 = (argb >>> 16) & 0xff;
            int green8 = (argb >>> 8) & 0xff;
            int blue8 = argb & 0xff;
            double red = SRGB_TO_LINEAR[red8];
            double green = SRGB_TO_LINEAR[green8];
            double blue = SRGB_TO_LINEAR[blue8];

            double correctedRed = matrix[0] * red + matrix[1] * green + matrix[2] * blue;
            double correctedGreen = matrix[3] * red + matrix[4] * green + matrix[5] * blue;
            double correctedBlue = matrix[6] * red + matrix[7] * green + matrix[8] * blue;

            int maximum8 = Math.max(red8, Math.max(green8, blue8));
            int minimum8 = Math.min(red8, Math.min(green8, blue8));
            double saturation = maximum8 == 0
                    ? 0.0 : (maximum8 - minimum8) / (double) maximum8;
            double protection = 1.0 - 0.30 * smoothStep(0.48, 0.88, saturation);
            if (looksLikeSkin(red8, green8, blue8, saturation)) {
                protection *= 0.88;
            }
            if (maximum8 >= 246) {
                protection *= 0.82;
            }

            correctedRed = red + (correctedRed - red) * protection;
            correctedGreen = green + (correctedGreen - green) * protection;
            correctedBlue = blue + (correctedBlue - blue) * protection;

            double redLocal = 1.0 + (localRedGain - 1.0) * strength * protection;
            double greenLocal = 1.0 + (localGreenGain - 1.0) * strength * protection;
            double blueLocal = 1.0 + (localBlueGain - 1.0) * strength * protection;
            correctedRed *= redLocal;
            correctedGreen *= greenLocal;
            correctedBlue *= blueLocal;

            double luminance = correctedRed * 0.2126
                    + correctedGreen * 0.7152
                    + correctedBlue * 0.0722;
            double maximum = Math.max(
                    correctedRed, Math.max(correctedGreen, correctedBlue));
            double minimum = Math.min(
                    correctedRed, Math.min(correctedGreen, correctedBlue));
            double chromaScale = 1.0;
            if (maximum > 1.0 && maximum > luminance) {
                chromaScale = Math.min(
                        chromaScale,
                        (1.0 - luminance) / Math.max(EPSILON, maximum - luminance));
            }
            if (minimum < 0.0 && minimum < luminance) {
                chromaScale = Math.min(
                        chromaScale,
                        luminance / Math.max(EPSILON, luminance - minimum));
            }
            chromaScale = clamp(chromaScale, 0.0, 1.0);
            correctedRed = luminance + (correctedRed - luminance) * chromaScale;
            correctedGreen = luminance + (correctedGreen - luminance) * chromaScale;
            correctedBlue = luminance + (correctedBlue - luminance) * chromaScale;

            return (alpha << 24)
                    | (linearToSrgb(correctedRed) << 16)
                    | (linearToSrgb(correctedGreen) << 8)
                    | linearToSrgb(correctedBlue);
        }
    }

    private static Analysis buildPreviewAnalysis(
            Candidate[] candidates,
            int count,
            int medoid,
            int agreeingMethods,
            int families,
            double neutralCoverage,
            long sampleCount) {
        if (count <= 0) {
            return heldAnalysis(
                    "no distinct LAB candidate",
                    0,
                    0,
                    0,
                    neutralCoverage,
                    sampleCount,
                    0.0,
                    0.0);
        }

        int boundedMedoid = clampInt(medoid, 0, count - 1);
        double weightSum = 0.0;
        double consensusRed = 0.0;
        double consensusBlue = 0.0;
        for (int index = 0; index < count; index++) {
            double distance = colourDistance(candidates[index], candidates[boundedMedoid]);
            double normalized = distance / 0.14;
            double robustWeight = candidates[index].reliability
                    / (1.0 + normalized * normalized);
            weightSum += robustWeight;
            consensusRed += candidates[index].logRedGreen * robustWeight;
            consensusBlue += candidates[index].logBlueGreen * robustWeight;
        }
        if (weightSum <= EPSILON) {
            return heldAnalysis(
                    "no distinct LAB candidate",
                    count,
                    agreeingMethods,
                    families,
                    neutralCoverage,
                    sampleCount,
                    0.0,
                    0.0);
        }
        consensusRed /= weightSum;
        consensusBlue /= weightSum;

        double spread = 0.0;
        for (int index = 0; index < count; index++) {
            double redDelta = candidates[index].logRedGreen - consensusRed;
            double blueDelta = candidates[index].logBlueGreen - consensusBlue;
            double distance = colourDistance(candidates[index], candidates[boundedMedoid]);
            double normalized = distance / 0.14;
            double robustWeight = candidates[index].reliability
                    / (1.0 + normalized * normalized);
            spread += (redDelta * redDelta + blueDelta * blueDelta) * robustWeight;
        }
        spread = Math.sqrt(spread / weightSum);
        double agreement = clamp(1.0 - spread / 0.18, 0.0, 1.0);
        double methodEvidence = clamp(count / 5.0, 0.20, 1.0);
        double familyEvidence = clamp(families / 4.0, 0.20, 1.0);
        double confidence = clamp(
                0.08 + agreement * methodEvidence * familyEvidence * 0.42,
                0.08,
                0.48);

        double sourceRed = Math.exp(consensusRed);
        double sourceGreen = 1.0;
        double sourceBlue = Math.exp(consensusBlue);
        double geometric = Math.cbrt(sourceRed * sourceGreen * sourceBlue);
        double rawRedGain = geometric / sourceRed;
        double rawGreenGain = geometric / sourceGreen;
        double rawBlueGain = geometric / sourceBlue;
        double largestRawLog = Math.max(
                Math.abs(Math.log(rawRedGain)),
                Math.max(Math.abs(Math.log(rawGreenGain)), Math.abs(Math.log(rawBlueGain))));

        // A rejected candidate is intentionally an audition, not an override.
        // It is made visible enough to compare while remaining inside an 8%
        // equivalent-gain ceiling and all downstream gamut/skin/highlight guards.
        double correctionStrength = 0.42 + confidence * 0.38;
        if (largestRawLog > EPSILON) {
            correctionStrength = Math.min(
                    correctionStrength,
                    Math.log(1.08) / largestRawLog);
        }
        correctionStrength = clamp(correctionStrength, 0.0, 0.60);

        double redGain = Math.exp(Math.log(rawRedGain) * correctionStrength);
        double greenGain = Math.exp(Math.log(rawGreenGain) * correctionStrength);
        double blueGain = Math.exp(Math.log(rawBlueGain) * correctionStrength);
        double gainNorm = Math.cbrt(redGain * greenGain * blueGain);
        redGain /= gainNorm;
        greenGain /= gainNorm;
        blueGain /= gainNorm;
        double largestGainShift = Math.max(
                Math.abs(redGain - 1.0),
                Math.max(Math.abs(greenGain - 1.0), Math.abs(blueGain - 1.0)));
        if (largestGainShift < 0.006) {
            return heldAnalysis(
                    "no distinct LAB candidate",
                    count,
                    agreeingMethods,
                    families,
                    neutralCoverage,
                    sampleCount,
                    confidence,
                    agreement);
        }

        double[] fullMatrix = bradfordMatrix(sourceRed, sourceGreen, sourceBlue);
        double[] appliedMatrix = new double[9];
        for (int index = 0; index < appliedMatrix.length; index++) {
            appliedMatrix[index] = IDENTITY[index]
                    + (fullMatrix[index] - IDENTITY[index]) * correctionStrength;
        }
        return new Analysis(
                appliedMatrix,
                redGain,
                greenGain,
                blueGain,
                confidence,
                agreement,
                agreeingMethods,
                count,
                families,
                neutralCoverage,
                sampleCount,
                true,
                true,
                "preview candidate",
                ones(),
                ones(),
                ones(),
                false,
                0.0,
                0.0);
    }

    private static Analysis buildGlobalAnalysis(
            double logRedGreen,
            double logBlueGreen,
            double confidence,
            double agreement,
            int agreeingMethods,
            int availableMethods,
            int families,
            double neutralCoverage,
            long sampleCount) {
        double sourceRed = Math.exp(logRedGreen);
        double sourceGreen = 1.0;
        double sourceBlue = Math.exp(logBlueGreen);
        double geometric = Math.cbrt(sourceRed * sourceGreen * sourceBlue);
        double rawRedGain = geometric / sourceRed;
        double rawGreenGain = geometric / sourceGreen;
        double rawBlueGain = geometric / sourceBlue;
        double largestRawLog = Math.max(
                Math.abs(Math.log(rawRedGain)),
                Math.max(Math.abs(Math.log(rawGreenGain)), Math.abs(Math.log(rawBlueGain))));
        double correctionStrength = 0.82 * confidence;
        if (largestRawLog > EPSILON) {
            correctionStrength = Math.min(
                    correctionStrength,
                    Math.log(MAX_EQUIVALENT_GAIN) / largestRawLog);
        }
        correctionStrength = clamp(correctionStrength, 0.0, 0.88);

        double redGain = Math.exp(Math.log(rawRedGain) * correctionStrength);
        double greenGain = Math.exp(Math.log(rawGreenGain) * correctionStrength);
        double blueGain = Math.exp(Math.log(rawBlueGain) * correctionStrength);
        double gainNorm = Math.cbrt(redGain * greenGain * blueGain);
        redGain /= gainNorm;
        greenGain /= gainNorm;
        blueGain /= gainNorm;
        double largestGainShift = Math.max(
                Math.abs(redGain - 1.0),
                Math.max(Math.abs(greenGain - 1.0), Math.abs(blueGain - 1.0)));

        if (confidence < 0.24) {
            return heldAnalysis(
                    "consensus confidence was too low",
                    availableMethods,
                    agreeingMethods,
                    families,
                    neutralCoverage,
                    sampleCount,
                    confidence,
                    agreement);
        }
        if (largestGainShift < 0.008) {
            return new Analysis(
                    IDENTITY,
                    1.0,
                    1.0,
                    1.0,
                    confidence,
                    agreement,
                    agreeingMethods,
                    availableMethods,
                    families,
                    neutralCoverage,
                    sampleCount,
                    false,
                    false,
                    "already neutral",
                    ones(),
                    ones(),
                    ones(),
                    false,
                    0.0,
                    0.0);
        }

        double[] fullMatrix = bradfordMatrix(sourceRed, sourceGreen, sourceBlue);
        double[] appliedMatrix = new double[9];
        for (int index = 0; index < appliedMatrix.length; index++) {
            appliedMatrix[index] = IDENTITY[index]
                    + (fullMatrix[index] - IDENTITY[index]) * correctionStrength;
        }
        return new Analysis(
                appliedMatrix,
                redGain,
                greenGain,
                blueGain,
                confidence,
                agreement,
                agreeingMethods,
                availableMethods,
                families,
                neutralCoverage,
                sampleCount,
                true,
                false,
                "",
                ones(),
                ones(),
                ones(),
                false,
                0.0,
                0.0);
    }

    private static Analysis addSpatialColour(Analysis global, Analysis[] zones) {
        boolean[] reliable = new boolean[9];
        int reliableCount = 0;
        double maximumDistance = 0.0;
        long minimumSamples = Math.max(20L, global.sampleCount / 110L);
        for (int index = 0; index < zones.length; index++) {
            reliable[index] = zones[index].globalActive
                    && zones[index].confidence >= 0.24
                    && zones[index].sampleCount >= minimumSamples;
            if (reliable[index]) {
                reliableCount++;
            }
        }

        for (int first = 0; first < zones.length; first++) {
            if (!reliable[first]) {
                continue;
            }
            double firstRed = Math.log(zones[first].redGain / zones[first].greenGain);
            double firstBlue = Math.log(zones[first].blueGain / zones[first].greenGain);
            for (int second = first + 1; second < zones.length; second++) {
                if (!reliable[second]) {
                    continue;
                }
                double redDelta = firstRed
                        - Math.log(zones[second].redGain / zones[second].greenGain);
                double blueDelta = firstBlue
                        - Math.log(zones[second].blueGain / zones[second].greenGain);
                maximumDistance = Math.max(
                        maximumDistance,
                        Math.sqrt(redDelta * redDelta + blueDelta * blueDelta));
            }
        }
        double mixedLightScore = reliableCount >= 5
                ? clamp((maximumDistance - 0.018) / 0.105, 0.0, 1.0)
                : 0.0;

        if (mixedLightScore < 0.15) {
            return new Analysis(
                    global.adaptationMatrix,
                    global.redGain,
                    global.greenGain,
                    global.blueGain,
                    global.confidence,
                    global.agreement,
                    global.agreeingMethods,
                    global.availableMethods,
                    global.independentFamilies,
                    global.neutralCoverage,
                    global.sampleCount,
                    global.globalActive,
                    global.previewOnly,
                    global.holdReason,
                    ones(),
                    ones(),
                    ones(),
                    false,
                    mixedLightScore,
                    0.0);
        }

        double referenceRed = 0.0;
        double referenceGreen = 0.0;
        double referenceBlue = 0.0;
        if (global.globalActive) {
            referenceRed = Math.log(global.redGain);
            referenceGreen = Math.log(global.greenGain);
            referenceBlue = Math.log(global.blueGain);
        } else {
            for (int index = 0; index < zones.length; index++) {
                if (!reliable[index]) {
                    continue;
                }
                referenceRed += Math.log(zones[index].redGain);
                referenceGreen += Math.log(zones[index].greenGain);
                referenceBlue += Math.log(zones[index].blueGain);
            }
            referenceRed /= reliableCount;
            referenceGreen /= reliableCount;
            referenceBlue /= reliableCount;
        }

        double[] redLog = new double[9];
        double[] greenLog = new double[9];
        double[] blueLog = new double[9];
        double localLimit = Math.log(MAX_LOCAL_GAIN);
        for (int index = 0; index < zones.length; index++) {
            if (!reliable[index]) {
                continue;
            }
            redLog[index] = clamp(
                    Math.log(zones[index].redGain) - referenceRed,
                    -localLimit,
                    localLimit);
            greenLog[index] = clamp(
                    Math.log(zones[index].greenGain) - referenceGreen,
                    -localLimit,
                    localLimit);
            blueLog[index] = clamp(
                    Math.log(zones[index].blueGain) - referenceBlue,
                    -localLimit,
                    localLimit);
        }
        redLog = smoothField(redLog, reliable);
        greenLog = smoothField(greenLog, reliable);
        blueLog = smoothField(blueLog, reliable);

        double meanRed = meanReliable(redLog, reliable);
        double meanGreen = meanReliable(greenLog, reliable);
        double meanBlue = meanReliable(blueLog, reliable);
        double[] zoneRed = ones();
        double[] zoneGreen = ones();
        double[] zoneBlue = ones();
        double maxLocalPercent = 0.0;
        for (int index = 0; index < zones.length; index++) {
            if (!reliable[index]) {
                continue;
            }
            double r = clamp(redLog[index] - meanRed, -localLimit, localLimit);
            double g = clamp(greenLog[index] - meanGreen, -localLimit, localLimit);
            double b = clamp(blueLog[index] - meanBlue, -localLimit, localLimit);
            double logNorm = (r + g + b) / 3.0;
            r -= logNorm;
            g -= logNorm;
            b -= logNorm;
            double maximumLog = Math.max(
                    Math.abs(r), Math.max(Math.abs(g), Math.abs(b)));
            if (maximumLog > localLimit) {
                double scale = localLimit / maximumLog;
                r *= scale;
                g *= scale;
                b *= scale;
            }
            zoneRed[index] = Math.exp(r);
            zoneGreen[index] = Math.exp(g);
            zoneBlue[index] = Math.exp(b);
            maxLocalPercent = Math.max(
                    maxLocalPercent,
                    Math.max(
                            Math.abs(zoneRed[index] - 1.0),
                            Math.max(
                                    Math.abs(zoneGreen[index] - 1.0),
                                    Math.abs(zoneBlue[index] - 1.0))) * 100.0);
        }
        boolean spatialActive = maxLocalPercent >= 0.8;
        if (!spatialActive) {
            zoneRed = ones();
            zoneGreen = ones();
            zoneBlue = ones();
            maxLocalPercent = 0.0;
        }
        double regionalConfidence = 0.0;
        for (int index = 0; index < zones.length; index++) {
            if (reliable[index]) {
                regionalConfidence += zones[index].confidence;
            }
        }
        regionalConfidence = reliableCount == 0
                ? 0.0 : regionalConfidence / reliableCount;
        return new Analysis(
                global.adaptationMatrix,
                global.redGain,
                global.greenGain,
                global.blueGain,
                Math.max(global.confidence, regionalConfidence * 0.85),
                global.agreement,
                global.agreeingMethods,
                global.availableMethods,
                global.independentFamilies,
                global.neutralCoverage,
                global.sampleCount,
                global.globalActive,
                global.previewOnly,
                global.holdReason,
                zoneRed,
                zoneGreen,
                zoneBlue,
                spatialActive,
                mixedLightScore,
                maxLocalPercent);
    }

    private static Candidate candidateFromMeans(
            double red,
            double green,
            double blue,
            double reliability,
            int family) {
        return new Candidate(
                Math.log((red + EPSILON) / (green + EPSILON)),
                Math.log((blue + EPSILON) / (green + EPSILON)),
                clamp(reliability, 0.05, 1.0),
                family);
    }

    private static double colourDistance(Candidate first, Candidate second) {
        double red = first.logRedGreen - second.logRedGreen;
        double blue = first.logBlueGreen - second.logBlueGreen;
        return Math.sqrt(red * red + blue * blue);
    }

    private static Analysis heldAnalysis(
            String reason,
            int availableMethods,
            int agreeingMethods,
            int families,
            double neutralCoverage,
            long sampleCount,
            double confidence,
            double agreement) {
        return new Analysis(
                IDENTITY,
                1.0,
                1.0,
                1.0,
                confidence,
                agreement,
                agreeingMethods,
                availableMethods,
                families,
                neutralCoverage,
                sampleCount,
                false,
                false,
                reason,
                ones(),
                ones(),
                ones(),
                false,
                0.0,
                0.0);
    }

    private static Analysis identityAnalysis(String reason, long sampleCount) {
        return heldAnalysis(reason, 0, 0, 0, 0.0, sampleCount, 0.0, 0.0);
    }

    private static double[] bradfordMatrix(
            double sourceRed,
            double sourceGreen,
            double sourceBlue) {
        double[] sourceXyz = multiplyVector(
                RGB_TO_XYZ,
                new double[] {sourceRed, sourceGreen, sourceBlue});
        double sourceY = Math.max(EPSILON, sourceXyz[1]);
        for (int index = 0; index < sourceXyz.length; index++) {
            sourceXyz[index] /= sourceY;
        }
        double[] sourceLms = multiplyVector(BRADFORD, sourceXyz);
        double[] targetLms = multiplyVector(BRADFORD, D65_XYZ);
        double[] diagonal = new double[] {
                clamp(targetLms[0] / Math.max(EPSILON, sourceLms[0]), 0.80, 1.25), 0.0, 0.0,
                0.0, clamp(targetLms[1] / Math.max(EPSILON, sourceLms[1]), 0.80, 1.25), 0.0,
                0.0, 0.0, clamp(
                        targetLms[2] / Math.max(EPSILON, sourceLms[2]), 0.80, 1.25)
        };
        double[] adaptationXyz = multiplyMatrices(
                multiplyMatrices(BRADFORD_INVERSE, diagonal),
                BRADFORD);
        return multiplyMatrices(
                multiplyMatrices(XYZ_TO_RGB, adaptationXyz),
                RGB_TO_XYZ);
    }

    private static double[] multiplyMatrices(double[] first, double[] second) {
        double[] result = new double[9];
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                double value = 0.0;
                for (int inner = 0; inner < 3; inner++) {
                    value += first[row * 3 + inner] * second[inner * 3 + column];
                }
                result[row * 3 + column] = value;
            }
        }
        return result;
    }

    private static double[] multiplyVector(double[] matrix, double[] vector) {
        return new double[] {
                matrix[0] * vector[0] + matrix[1] * vector[1] + matrix[2] * vector[2],
                matrix[3] * vector[0] + matrix[4] * vector[1] + matrix[5] * vector[2],
                matrix[6] * vector[0] + matrix[7] * vector[1] + matrix[8] * vector[2]
        };
    }

    private static double[] smoothField(double[] values, boolean[] reliable) {
        double[] result = new double[9];
        for (int index = 0; index < values.length; index++) {
            if (!reliable[index]) {
                continue;
            }
            int row = index / 3;
            int column = index % 3;
            double neighbours = 0.0;
            int count = 0;
            for (int deltaRow = -1; deltaRow <= 1; deltaRow++) {
                for (int deltaColumn = -1; deltaColumn <= 1; deltaColumn++) {
                    if (Math.abs(deltaRow) + Math.abs(deltaColumn) != 1) {
                        continue;
                    }
                    int neighbourRow = row + deltaRow;
                    int neighbourColumn = column + deltaColumn;
                    if (neighbourRow < 0 || neighbourRow >= 3
                            || neighbourColumn < 0 || neighbourColumn >= 3) {
                        continue;
                    }
                    int neighbour = neighbourRow * 3 + neighbourColumn;
                    if (reliable[neighbour]) {
                        neighbours += values[neighbour];
                        count++;
                    }
                }
            }
            double neighbourAverage = count == 0 ? values[index] : neighbours / count;
            result[index] = values[index] * 0.76 + neighbourAverage * 0.24;
        }
        return result;
    }

    private static double meanReliable(double[] values, boolean[] reliable) {
        double result = 0.0;
        int count = 0;
        for (int index = 0; index < values.length; index++) {
            if (reliable[index]) {
                result += values[index];
                count++;
            }
        }
        return count == 0 ? 0.0 : result / count;
    }

    private static boolean looksLikeSkin(
            int red,
            int green,
            int blue,
            double saturation) {
        if (saturation < 0.07 || saturation > 0.72) {
            return false;
        }
        double luminance = red * 0.299 + green * 0.587 + blue * 0.114;
        double cb = 128.0 - 0.168736 * red - 0.331264 * green + 0.5 * blue;
        double cr = 128.0 + 0.5 * red - 0.418688 * green - 0.081312 * blue;
        return luminance >= 32.0 && luminance <= 242.0
                && cb >= 76.0 && cb <= 135.0
                && cr >= 133.0 && cr <= 181.0;
    }

    private static int linearToSrgb(double linear) {
        double bounded = clamp(linear, 0.0, 1.0);
        int index = clampInt(
                (int) Math.round(bounded * LINEAR_LUT_SIZE),
                0,
                LINEAR_LUT_SIZE);
        return LINEAR_TO_SRGB[index];
    }

    private static double[] ones() {
        return new double[] {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
    }

    private static double regionalEvidenceWeight(double distanceFromCentre) {
        if (distanceFromCentre <= ZONE_CORE_HALF_SPAN) {
            return 1.0;
        }
        if (distanceFromCentre >= ZONE_SUPPORT_HALF_SPAN) {
            return 0.0;
        }
        return 1.0 - smoothStep(
                ZONE_CORE_HALF_SPAN,
                ZONE_SUPPORT_HALF_SPAN,
                distanceFromCentre);
    }

    private static double smoothStep(double edge0, double edge1, double value) {
        double normalized = clamp((value - edge0) / (edge1 - edge0), 0.0, 1.0);
        return normalized * normalized * (3.0 - 2.0 * normalized);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static int clampInt(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
