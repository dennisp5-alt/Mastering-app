package com.dennis.autofixcolourlab;

import java.util.Locale;

/**
 * Deterministic natural-history editorial finishing engine.
 *
 * The engine is deliberately camera-independent. It works on the corrected
 * sRGB result, builds a very low-resolution luminance guide for restrained
 * local depth, and applies hue-preserving tone and selective-colour changes.
 * It does not sharpen edges, identify camera models or use a creative LUT.
 */
public final class NatureEditorialEngine {
    private static final int GUIDE_MIN = 24;
    private static final int GUIDE_MAX = 96;

    private NatureEditorialEngine() {
    }

    public static final class GuideAccumulator {
        private final int imageWidth;
        private final int imageHeight;
        private final int guideWidth;
        private final int guideHeight;
        private final int[] xCell;
        private final double[] luminanceSum;
        private final int[] count;
        private final long[] histogram = new long[256];
        private long pixelCount;

        public GuideAccumulator(int imageWidth, int imageHeight) {
            if (imageWidth <= 0 || imageHeight <= 0) {
                throw new IllegalArgumentException("image dimensions must be positive");
            }
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
            int minimumGuideWidth = Math.min(GUIDE_MIN, imageWidth);
            int minimumGuideHeight = Math.min(GUIDE_MIN, imageHeight);
            int maximumGuideWidth = Math.min(GUIDE_MAX, imageWidth);
            int maximumGuideHeight = Math.min(GUIDE_MAX, imageHeight);
            guideWidth = clampInt(
                    (imageWidth + 47) / 48,
                    minimumGuideWidth,
                    maximumGuideWidth);
            guideHeight = clampInt(
                    (imageHeight + 47) / 48,
                    minimumGuideHeight,
                    maximumGuideHeight);
            xCell = new int[imageWidth];
            for (int x = 0; x < imageWidth; x++) {
                xCell[x] = Math.min(
                        guideWidth - 1,
                        (int) ((long) x * guideWidth / imageWidth));
            }
            luminanceSum = new double[guideWidth * guideHeight];
            count = new int[guideWidth * guideHeight];
        }

        public void addRow(int[] pixels, int offset, int y, int width) {
            if (pixels == null || y < 0 || y >= imageHeight || width != imageWidth
                    || offset < 0 || offset + width > pixels.length) {
                throw new IllegalArgumentException("row does not match the guide image");
            }
            int cellY = Math.min(
                    guideHeight - 1,
                    (int) ((long) y * guideHeight / imageHeight));
            int cellRow = cellY * guideWidth;
            for (int x = 0; x < width; x++) {
                int argb = pixels[offset + x];
                if (((argb >>> 24) & 0xff) < 16) {
                    continue;
                }
                int red = (argb >>> 16) & 0xff;
                int green = (argb >>> 8) & 0xff;
                int blue = argb & 0xff;
                int luminance8 = clampInt(
                        (54 * red + 183 * green + 19 * blue + 128) >> 8,
                        0,
                        255);
                int cell = cellRow + xCell[x];
                luminanceSum[cell] += luminance8 / 255.0;
                count[cell]++;
                histogram[luminance8]++;
                pixelCount++;
            }
        }

        public Analysis finish() {
            if (pixelCount == 0L) {
                double[] neutralGuide = new double[guideWidth * guideHeight];
                for (int index = 0; index < neutralGuide.length; index++) {
                    neutralGuide[index] = 0.5;
                }
                return new Analysis(
                        imageWidth,
                        imageHeight,
                        guideWidth,
                        guideHeight,
                        neutralGuide,
                        0.0,
                        0.5,
                        1.0,
                        1.0);
            }

            double percentile05 = percentile(histogram, pixelCount, 0.05) / 255.0;
            double median = percentile(histogram, pixelCount, 0.50) / 255.0;
            double percentile95 = percentile(histogram, pixelCount, 0.95) / 255.0;
            double[] guide = new double[luminanceSum.length];
            for (int index = 0; index < guide.length; index++) {
                guide[index] = count[index] == 0
                        ? median : luminanceSum[index] / count[index];
            }
            guide = boxBlur(guide, guideWidth, guideHeight, 2);

            double dynamicRange = percentile95 - percentile05;
            double contrastSafety = 1.0
                    - 0.42 * smoothStep(0.56, 0.84, dynamicRange);
            double lowKeySafety = 0.58
                    + 0.42 * smoothStep(0.10, 0.34, median);
            double highKeySafety = 1.0
                    - 0.22 * smoothStep(0.72, 0.92, median);
            double sceneStrength = clamp(
                    Math.min(contrastSafety, Math.min(lowKeySafety, highKeySafety)),
                    0.55,
                    1.0);
            double localContrastStrength = 0.14
                    * (1.0 - 0.24 * smoothStep(0.62, 0.88, dynamicRange));
            return new Analysis(
                    imageWidth,
                    imageHeight,
                    guideWidth,
                    guideHeight,
                    guide,
                    percentile05,
                    median,
                    percentile95,
                    sceneStrength,
                    localContrastStrength);
        }
    }

    public static final class Analysis {
        private final int imageWidth;
        private final int imageHeight;
        private final int guideWidth;
        private final int guideHeight;
        private final double[] guide;
        public final double percentile05;
        public final double median;
        public final double percentile95;
        public final double sceneStrength;
        public final double localContrastStrength;

        private Analysis(
                int imageWidth,
                int imageHeight,
                int guideWidth,
                int guideHeight,
                double[] guide,
                double percentile05,
                double median,
                double percentile95,
                double sceneStrength) {
            this(
                    imageWidth,
                    imageHeight,
                    guideWidth,
                    guideHeight,
                    guide,
                    percentile05,
                    median,
                    percentile95,
                    sceneStrength,
                    0.14);
        }

        private Analysis(
                int imageWidth,
                int imageHeight,
                int guideWidth,
                int guideHeight,
                double[] guide,
                double percentile05,
                double median,
                double percentile95,
                double sceneStrength,
                double localContrastStrength) {
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
            this.guideWidth = guideWidth;
            this.guideHeight = guideHeight;
            this.guide = guide.clone();
            this.percentile05 = percentile05;
            this.median = median;
            this.percentile95 = percentile95;
            this.sceneStrength = sceneStrength;
            this.localContrastStrength = localContrastStrength;
        }

        public Sampler createSampler(int outputWidth, int outputHeight) {
            if (outputWidth != imageWidth || outputHeight != imageHeight) {
                throw new IllegalArgumentException("sampler dimensions must match analysis");
            }
            return new Sampler(this);
        }

        public String summary() {
            return String.format(
                    Locale.US,
                    "Nature Editorial  •  adaptive strength %.0f%%\n"
                            + "Luminance depth %.0f%%  •  selective colour and highlight protection",
                    sceneStrength * 100.0,
                    localContrastStrength * 100.0);
        }
    }

    public static final class Sampler {
        private final Analysis analysis;
        private final int[] left;
        private final int[] right;
        private final double[] fraction;

        private Sampler(Analysis analysis) {
            this.analysis = analysis;
            left = new int[analysis.imageWidth];
            right = new int[analysis.imageWidth];
            fraction = new double[analysis.imageWidth];
            for (int x = 0; x < analysis.imageWidth; x++) {
                double guideX = ((x + 0.5) * analysis.guideWidth
                        / (double) analysis.imageWidth) - 0.5;
                if (guideX <= 0.0) {
                    left[x] = 0;
                    right[x] = 0;
                    fraction[x] = 0.0;
                } else if (guideX >= analysis.guideWidth - 1.0) {
                    left[x] = analysis.guideWidth - 1;
                    right[x] = analysis.guideWidth - 1;
                    fraction[x] = 0.0;
                } else {
                    left[x] = (int) Math.floor(guideX);
                    right[x] = left[x] + 1;
                    fraction[x] = guideX - left[x];
                }
            }
        }

        public void fillRow(int y, double[] output) {
            if (y < 0 || y >= analysis.imageHeight
                    || output == null || output.length < analysis.imageWidth) {
                throw new IllegalArgumentException("invalid guide output row");
            }
            double guideY = ((y + 0.5) * analysis.guideHeight
                    / (double) analysis.imageHeight) - 0.5;
            int upper;
            int lower;
            double verticalFraction;
            if (guideY <= 0.0) {
                upper = 0;
                lower = 0;
                verticalFraction = 0.0;
            } else if (guideY >= analysis.guideHeight - 1.0) {
                upper = analysis.guideHeight - 1;
                lower = analysis.guideHeight - 1;
                verticalFraction = 0.0;
            } else {
                upper = (int) Math.floor(guideY);
                lower = upper + 1;
                verticalFraction = guideY - upper;
            }
            int upperOffset = upper * analysis.guideWidth;
            int lowerOffset = lower * analysis.guideWidth;
            for (int x = 0; x < analysis.imageWidth; x++) {
                double upperValue = analysis.guide[upperOffset + left[x]]
                        + (analysis.guide[upperOffset + right[x]]
                        - analysis.guide[upperOffset + left[x]]) * fraction[x];
                double lowerValue = analysis.guide[lowerOffset + left[x]]
                        + (analysis.guide[lowerOffset + right[x]]
                        - analysis.guide[lowerOffset + left[x]]) * fraction[x];
                output[x] = upperValue
                        + (lowerValue - upperValue) * verticalFraction;
            }
        }
    }

    public static final class Processor {
        private final Analysis analysis;
        private final double strength;

        public Processor(Analysis analysis, double requestedStrength) {
            if (analysis == null) {
                throw new IllegalArgumentException("analysis is required");
            }
            this.analysis = analysis;
            strength = clamp(requestedStrength, 0.0, 1.0) * analysis.sceneStrength;
        }

        public int apply(int argb, double localMeanLuminance) {
            if (strength <= 0.0 || ((argb >>> 24) & 0xff) < 16) {
                return argb;
            }
            int alpha = (argb >>> 24) & 0xff;
            int red8 = (argb >>> 16) & 0xff;
            int green8 = (argb >>> 8) & 0xff;
            int blue8 = argb & 0xff;
            double red = red8 / 255.0;
            double green = green8 / 255.0;
            double blue = blue8 / 255.0;
            double luminance = red * 0.2126 + green * 0.7152 + blue * 0.0722;
            double maximum = Math.max(red, Math.max(green, blue));
            double minimum = Math.min(red, Math.min(green, blue));
            double saturation = maximum <= 0.0
                    ? 0.0 : (maximum - minimum) / maximum;

            double curveDelta = 0.36
                    * (luminance - 0.5) * luminance * (1.0 - luminance);
            if (curveDelta < 0.0) {
                double pixelShadowSafety = 0.32
                        + 0.68 * smoothStep(0.025, 0.30, luminance);
                double sceneShadowSafety = 0.58
                        + 0.42 * smoothStep(0.08, 0.28, analysis.median);
                curveDelta *= pixelShadowSafety * sceneShadowSafety;
            } else {
                curveDelta *= 1.0
                        - 0.78 * smoothStep(0.76, 0.985, luminance);
            }

            double localDelta = luminance - clamp(localMeanLuminance, 0.0, 1.0);
            double edgeProtection = 1.0
                    - 0.82 * smoothStep(0.07, 0.26, Math.abs(localDelta));
            double rangeProtection = smoothStep(0.025, 0.17, luminance)
                    * (1.0 - smoothStep(0.82, 0.995, luminance));
            double localAdjustment = clamp(
                    localDelta * analysis.localContrastStrength
                            * strength * edgeProtection * rangeProtection,
                    -0.018,
                    0.018);
            double targetLuminance = clamp(
                    luminance + curveDelta * strength + localAdjustment,
                    0.0,
                    1.0);

            boolean skin = looksLikeSkin(red8, green8, blue8, saturation);
            boolean greenDominant = green8 > red8 * 1.04
                    && green8 > blue8 * 1.06;
            boolean blueDominant = blue8 > red8 * 1.05
                    && blue8 > green8 * 1.04;
            double colourEvidence = smoothStep(0.025, 0.16, saturation);
            double vibrance = 0.105 * strength
                    * colourEvidence * Math.pow(1.0 - saturation, 1.35);
            if (skin) {
                vibrance *= 0.24;
            } else if (greenDominant) {
                vibrance *= 0.42;
            } else if (blueDominant) {
                vibrance = Math.min(0.095 * strength, vibrance * 1.18 + 0.012 * strength);
                double blueDepth = 0.006 * strength
                        * smoothStep(0.16, 0.62, saturation)
                        * (1.0 - smoothStep(0.76, 0.96, luminance));
                targetLuminance = Math.max(0.0, targetLuminance - blueDepth);
            }

            double chromaFactor = 1.0 + vibrance;
            if (greenDominant && saturation > 0.55) {
                chromaFactor *= 1.0
                        - 0.022 * strength * smoothStep(0.55, 0.92, saturation);
            }
            if (saturation > 0.72) {
                chromaFactor *= 1.0
                        - 0.026 * strength * smoothStep(0.72, 1.0, saturation);
            }
            if (maximum > 0.95) {
                chromaFactor = 1.0 + (chromaFactor - 1.0)
                        * (1.0 - 0.72 * smoothStep(0.95, 1.0, maximum));
            }

            double redDeviation = (red - luminance) * chromaFactor;
            double greenDeviation = (green - luminance) * chromaFactor;
            double blueDeviation = (blue - luminance) * chromaFactor;
            double maximumDeviation = Math.max(
                    redDeviation, Math.max(greenDeviation, blueDeviation));
            double minimumDeviation = Math.min(
                    redDeviation, Math.min(greenDeviation, blueDeviation));
            double gamutScale = 1.0;
            if (targetLuminance + maximumDeviation > 1.0 && maximumDeviation > 0.0) {
                gamutScale = Math.min(
                        gamutScale,
                        (1.0 - targetLuminance) / maximumDeviation);
            }
            if (targetLuminance + minimumDeviation < 0.0 && minimumDeviation < 0.0) {
                gamutScale = Math.min(
                        gamutScale,
                        targetLuminance / -minimumDeviation);
            }
            gamutScale = clamp(gamutScale, 0.0, 1.0);
            int outputRed = to8(targetLuminance + redDeviation * gamutScale);
            int outputGreen = to8(targetLuminance + greenDeviation * gamutScale);
            int outputBlue = to8(targetLuminance + blueDeviation * gamutScale);
            return (alpha << 24) | (outputRed << 16) | (outputGreen << 8) | outputBlue;
        }
    }

    private static double[] boxBlur(double[] source, int width, int height, int radius) {
        double[] horizontal = new double[source.length];
        double[] result = new double[source.length];
        for (int y = 0; y < height; y++) {
            int row = y * width;
            for (int x = 0; x < width; x++) {
                double sum = 0.0;
                int samples = 0;
                for (int offset = -radius; offset <= radius; offset++) {
                    int sampleX = x + offset;
                    if (sampleX >= 0 && sampleX < width) {
                        sum += source[row + sampleX];
                        samples++;
                    }
                }
                horizontal[row + x] = sum / samples;
            }
        }
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                double sum = 0.0;
                int samples = 0;
                for (int offset = -radius; offset <= radius; offset++) {
                    int sampleY = y + offset;
                    if (sampleY >= 0 && sampleY < height) {
                        sum += horizontal[sampleY * width + x];
                        samples++;
                    }
                }
                result[y * width + x] = sum / samples;
            }
        }
        return result;
    }

    private static int percentile(long[] histogram, long total, double fraction) {
        long target = Math.max(1L, (long) Math.ceil(total * fraction));
        long cumulative = 0L;
        for (int index = 0; index < histogram.length; index++) {
            cumulative += histogram[index];
            if (cumulative >= target) {
                return index;
            }
        }
        return 255;
    }

    private static boolean looksLikeSkin(
            int red, int green, int blue, double saturation) {
        if (saturation < 0.08 || saturation > 0.68
                || red < 44 || green < 28 || blue < 18) {
            return false;
        }
        return red > green * 1.035
                && green > blue * 1.025
                && red - blue >= 18
                && red - green <= 92
                && green - blue <= 76;
    }

    private static double smoothStep(double low, double high, double value) {
        if (high <= low) {
            return value >= high ? 1.0 : 0.0;
        }
        double normalized = clamp((value - low) / (high - low), 0.0, 1.0);
        return normalized * normalized * (3.0 - 2.0 * normalized);
    }

    private static int to8(double value) {
        return clampInt((int) Math.round(clamp(value, 0.0, 1.0) * 255.0), 0, 255);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static int clampInt(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
