# v0.5.4 validation

Primary test: rotate the S23 Ultra between portrait and landscape repeatedly.

Pass criteria:
- landscape preview occupies the majority of the screen
- shutter/gallery/More appear in a right-side rail
- mode strip remains usable without a large black lower panel
- READY/HOLD/SHAKE and zoom overlays do not obscure the preview
- portrait UI remains unchanged
- captured photo orientation remains correct
- 0.6x / 1x / 3x / 10x still work
- Optical Lock and True Colour still work
- no image-processing or capture-policy regression
