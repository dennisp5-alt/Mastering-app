# Building Analysis First Camera 0.5.4

Package: com.dennis.analysisfirstcamera
Version: 0.5.4
versionCode: 12
CameraX: 1.6.2
compileSdk: 36
targetSdk: 34
AGP: 9.1.1
Gradle: 9.3.1
Java: 17
