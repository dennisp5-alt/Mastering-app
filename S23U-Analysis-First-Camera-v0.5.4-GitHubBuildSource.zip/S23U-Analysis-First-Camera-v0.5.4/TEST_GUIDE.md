# v0.5.4 test guide

1. Open in portrait and verify normal layout.
2. Rotate left to landscape and verify the preview fills most of the display.
3. Rotate right to landscape and repeat.
4. Test 0.6x, 1x, 3x and 10x.
5. Take photos in landscape and verify saved orientation is correct.
6. Verify shutter, last photo, More, mode strip, Optical Lock and True Colour.
7. Rotate back to portrait and verify state survives recreation.
