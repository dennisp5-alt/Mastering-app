# Analysis First Camera 0.5.4

v0.5.4 is a UI-only hotfix on the proven v0.5.3 CameraX 1.6.2 platform baseline.

## Landscape UI Hotfix

Changed only in landscape:
- Preview uses nearly the full available height.
- Shutter, last-photo and More controls move to a compact right-side rail.
- Mode strip becomes a low-profile 36 dp bar beneath the preview instead of a large bottom control panel.
- READY/HOLD/SHAKE status pill is compact and centred.
- Zoom pill is compact and centred over the lower preview.
- Top controls remain visible and compact.

Unchanged:
- CameraX 1.6.2 / CameraPipe platform
- full-resolution JPEG Q100
- True Colour
- per-lens calibration
- Natural Tone
- Lens/ISO Detail IQ
- computational capture policy
- difficult-light exposure policy
- optical correction
- Standard baseline
- photo orientation and EXIF rotation logic
