# Recovery baseline

v0.5.3 is the known-good platform/rendering baseline. v0.5.4 changes UI layout only. If a camera or imaging regression appears, compare against v0.5.3 before changing image tuning.
