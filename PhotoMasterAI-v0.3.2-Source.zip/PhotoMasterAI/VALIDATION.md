# Photo Master AI v0.3.2 validation

Retest these exact stress cases:

1. Bright duck / water scene
   - exposure should remain near 0 EV when highlights are safe
   - no unnecessary global darkening

2. Pool / social-media image
   - already-processed guard should reduce aggressive detail/halo treatment
   - detail loss should stay inside the safety envelope

3. Dark cave group portrait
   - global lift should be capped; prefer selective shadow recovery
   - no excessive skin/highlight push

4. Moon against black sky
   - dark-field protection should activate
   - black sky stays black
   - no global +EV lift
   - halo repair should be withheld if ringing does not improve

5. Any repair source
   - if output noise rises, real detail falls materially, or ringing worsens,
     full repair rollback must occur and be reported.
