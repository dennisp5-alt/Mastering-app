package com.dennis.photomasterai;

/**
 * Pure-Java scene safety policy used by v0.3.2. Kept Android-free so the
 * exposure/dark-field/social-source decisions can be host-tested in CI.
 */
public final class RepairSafetyPolicy {
    private RepairSafetyPolicy() { }

    public static boolean isDarkField(double blackFraction, double medianLum,
                                      double brightFraction, double p99) {
        return blackFraction >= 0.45
                && medianLum <= 0.08
                && brightFraction >= 0.008
                && brightFraction <= 0.42
                && p99 >= 0.68;
    }

    public static boolean isProcessedSource(long pixels, double ringing,
                                            double avgSat, double blockiness,
                                            boolean darkField) {
        return !darkField
                && pixels < 3_000_000L
                && ringing >= 0.55
                && (avgSat >= 0.18 || blockiness >= 0.06);
    }

    public static double exposureEv(double medianLum, double highlightClip,
                                    double p99, double brightFraction,
                                    boolean healthyPreserve, boolean darkField) {
        if (healthyPreserve || darkField) return 0.0;
        if (medianLum < 0.20) {
            return clamp(log2(0.28 / Math.max(0.08, medianLum)), 0.0, 0.40);
        }
        if (medianLum < 0.32) {
            return clamp(log2(0.36 / Math.max(0.10, medianLum)), 0.0, 0.35);
        }
        if (medianLum > 0.72
                && (highlightClip > 0.012 || (p99 > 0.995 && brightFraction > 0.18))) {
            return clamp(log2(0.64 / medianLum), -0.22, 0.0);
        }
        return 0.0;
    }

    public static boolean brightExposureProtected(double medianLum, double exposureEv,
                                                    boolean darkField) {
        return !darkField && medianLum > 0.62 && Math.abs(exposureEv) < 0.001;
    }

    public static double capShadowLift(double proposed, double medianLum,
                                       boolean processedSource, boolean darkField) {
        if (darkField) return 0.0;
        double out = proposed;
        if (medianLum < 0.20) out = Math.min(out, 0.22);
        if (processedSource) out = Math.min(out, 0.15);
        return out;
    }

    private static double log2(double v) {
        return Math.log(v) / Math.log(2.0);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
