package com.dennis.photomasterai;

import android.graphics.Bitmap;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * v0.2.0 real-ML stage. Uses bundled ML Kit neural models so inference works
 * after installation without a cloud service. Pixel finishing remains local and
 * deterministic; AI is used for scene/object understanding and person masks.
 */
public final class AiVisionAnalyzer {

    public static final class LabelScore {
        public final String label;
        public final float confidence;
        LabelScore(String label, float confidence) {
            this.label = label == null ? "" : label;
            this.confidence = confidence;
        }
    }

    public static final class Result {
        public final boolean available;
        public final String error;
        public final List<LabelScore> labels;
        public final int faceCount;
        public final float[] personMask;
        public final int maskWidth;
        public final int maskHeight;
        public final double personCoverage;
        public final double personMeanConfidence;
        public final boolean natureLike;
        public final boolean plantLike;
        public final boolean skyLike;
        public final boolean waterLike;
        public final boolean animalLike;
        public final boolean insectLike;
        public final boolean foodLike;
        public final boolean vehicleLike;
        public final boolean buildingLike;
        public final boolean personLike;
        public final double topConfidence;

        Result(boolean available, String error, List<LabelScore> labels, int faceCount,
               float[] personMask, int maskWidth, int maskHeight,
               double personCoverage, double personMeanConfidence,
               boolean natureLike, boolean plantLike, boolean skyLike, boolean waterLike,
               boolean animalLike, boolean insectLike, boolean foodLike, boolean vehicleLike,
               boolean buildingLike, boolean personLike, double topConfidence) {
            this.available = available;
            this.error = error;
            this.labels = labels;
            this.faceCount = faceCount;
            this.personMask = personMask;
            this.maskWidth = maskWidth;
            this.maskHeight = maskHeight;
            this.personCoverage = personCoverage;
            this.personMeanConfidence = personMeanConfidence;
            this.natureLike = natureLike;
            this.plantLike = plantLike;
            this.skyLike = skyLike;
            this.waterLike = waterLike;
            this.animalLike = animalLike;
            this.insectLike = insectLike;
            this.foodLike = foodLike;
            this.vehicleLike = vehicleLike;
            this.buildingLike = buildingLike;
            this.personLike = personLike;
            this.topConfidence = topConfidence;
        }

        public static Result none() {
            return new Result(false, "AI vision not requested", Collections.emptyList(), 0,
                    null, 0, 0, 0.0, 0.0,
                    false, false, false, false, false, false, false, false, false, false, 0.0);
        }

        public float subjectAt(int x, int y, int imageWidth, int imageHeight) {
            if (personMask == null || maskWidth <= 0 || maskHeight <= 0 || imageWidth <= 0 || imageHeight <= 0) return 0f;
            int mx = Math.max(0, Math.min(maskWidth - 1, (int) ((x / (double) imageWidth) * maskWidth)));
            int my = Math.max(0, Math.min(maskHeight - 1, (int) ((y / (double) imageHeight) * maskHeight)));
            return clamp01(personMask[my * maskWidth + mx]);
        }

        public String labelsSummary() {
            if (labels == null || labels.isEmpty()) return "No confident scene labels";
            StringBuilder sb = new StringBuilder();
            int n = Math.min(5, labels.size());
            for (int i = 0; i < n; i++) {
                if (i > 0) sb.append(", ");
                LabelScore s = labels.get(i);
                sb.append(s.label).append(" ").append(String.format(Locale.US, "%.0f%%", s.confidence * 100f));
            }
            return sb.toString();
        }

        public String sceneTags() {
            ArrayList<String> tags = new ArrayList<>();
            if (personLike) tags.add("person");
            if (insectLike) tags.add("insect");
            else if (animalLike) tags.add("animal");
            if (plantLike) tags.add("plant");
            if (skyLike) tags.add("sky");
            if (waterLike) tags.add("water");
            if (foodLike) tags.add("food");
            if (vehicleLike) tags.add("vehicle");
            if (buildingLike) tags.add("building");
            if (natureLike && !plantLike && !skyLike && !waterLike) tags.add("nature");
            if (tags.isEmpty()) return "general scene";
            return join(tags);
        }
    }

    private AiVisionAnalyzer() { }

    public static Result analyse(Bitmap source) {
        Bitmap small = source;
        ImageLabeler labeler = null;
        FaceDetector faceDetector = null;
        Segmenter segmenter = null;
        try {
            int w = source.getWidth();
            int h = source.getHeight();
            int maxSide = 768;
            double scale = Math.min(1.0, maxSide / (double) Math.max(w, h));
            if (scale < 1.0) {
                small = Bitmap.createScaledBitmap(source,
                        Math.max(2, (int) Math.round(w * scale)),
                        Math.max(2, (int) Math.round(h * scale)), true);
            }
            InputImage input = InputImage.fromBitmap(small, 0);

            labeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                    .setConfidenceThreshold(0.45f)
                    .build());
            List<ImageLabel> rawLabels = Tasks.await(labeler.process(input), 20, TimeUnit.SECONDS);
            ArrayList<LabelScore> labels = new ArrayList<>();
            for (ImageLabel l : rawLabels) labels.add(new LabelScore(l.getText(), l.getConfidence()));
            labels.sort((a, b) -> Float.compare(b.confidence, a.confidence));

            FaceDetectorOptions faceOptions = new FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                    .setMinFaceSize(0.08f)
                    .build();
            faceDetector = FaceDetection.getClient(faceOptions);
            List<Face> faces = Tasks.await(faceDetector.process(input), 20, TimeUnit.SECONDS);

            SelfieSegmenterOptions segmentOptions = new SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                    .enableRawSizeMask()
                    .build();
            segmenter = Segmentation.getClient(segmentOptions);
            SegmentationMask mask = Tasks.await(segmenter.process(input), 25, TimeUnit.SECONDS);
            int mw = mask.getWidth();
            int mh = mask.getHeight();
            int count = Math.max(0, mw * mh);
            float[] personMask = count > 0 ? new float[count] : null;
            double coverage = 0.0;
            double confSum = 0.0;
            if (personMask != null) {
                ByteBuffer bb = mask.getBuffer();
                bb.rewind();
                int n = Math.min(personMask.length, bb.remaining() / 4);
                long fg = 0;
                for (int i = 0; i < n; i++) {
                    float v = clamp01(bb.getFloat());
                    personMask[i] = v;
                    confSum += v;
                    if (v >= 0.55f) fg++;
                }
                coverage = fg / (double) Math.max(1, n);
                confSum /= Math.max(1, n);
            }

            double top = labels.isEmpty() ? 0.0 : labels.get(0).confidence;
            boolean plant = hasAny(labels, 0.48f, "plant", "flower", "tree", "grass", "vegetation", "leaf", "garden");
            boolean sky = hasAny(labels, 0.48f, "sky", "cloud", "sunset", "sunrise");
            boolean water = hasAny(labels, 0.48f, "water", "lake", "river", "sea", "ocean", "pond", "waterfall");
            boolean insect = hasAny(labels, 0.42f, "insect", "grasshopper", "butterfly", "bee", "beetle", "dragonfly", "spider");
            boolean animal = insect || hasAny(labels, 0.48f, "animal", "bird", "dog", "cat", "wildlife", "pet");
            boolean food = hasAny(labels, 0.48f, "food", "fruit", "vegetable", "dish", "meal", "dessert");
            boolean vehicle = hasAny(labels, 0.48f, "vehicle", "car", "truck", "motorcycle", "bicycle", "tractor", "train", "aircraft");
            boolean building = hasAny(labels, 0.48f, "building", "architecture", "house", "bridge", "tower", "city");
            boolean person = !faces.isEmpty() || coverage > 0.025 || hasAny(labels, 0.45f, "person", "people", "human", "portrait", "face", "selfie");
            boolean nature = plant || sky || water || animal || hasAny(labels, 0.48f, "nature", "landscape", "outdoor", "mountain", "forest");

            return new Result(true, null, labels, faces.size(), personMask, mw, mh,
                    coverage, confSum, nature, plant, sky, water, animal, insect, food,
                    vehicle, building, person, top);
        } catch (Throwable t) {
            return new Result(false, t.getClass().getSimpleName() + ": " + safeMessage(t), Collections.emptyList(), 0,
                    null, 0, 0, 0.0, 0.0,
                    false, false, false, false, false, false, false, false, false, false, 0.0);
        } finally {
            try { if (labeler != null) labeler.close(); } catch (Throwable ignored) { }
            try { if (faceDetector != null) faceDetector.close(); } catch (Throwable ignored) { }
            try { if (segmenter != null) segmenter.close(); } catch (Throwable ignored) { }
            if (small != source && small != null && !small.isRecycled()) small.recycle();
        }
    }

    private static boolean hasAny(List<LabelScore> labels, float min, String... terms) {
        if (labels == null) return false;
        for (LabelScore score : labels) {
            if (score.confidence < min) continue;
            String s = score.label.toLowerCase(Locale.US);
            for (String term : terms) if (s.contains(term)) return true;
        }
        return false;
    }

    private static String safeMessage(Throwable t) {
        String s = t.getMessage();
        return (s == null || s.trim().isEmpty()) ? "unknown error" : s;
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private static String join(List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(items.get(i));
        }
        return sb.toString();
    }
}
