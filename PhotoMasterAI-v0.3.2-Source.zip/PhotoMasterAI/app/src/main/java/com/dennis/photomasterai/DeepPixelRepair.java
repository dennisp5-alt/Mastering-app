package com.dennis.photomasterai;

import java.util.Locale;

/**
 * Measured, non-generative restoration planner.
 *
 * v0.3.1 focuses on smarter detection and safer gating:
 * - flat-region chroma speckle detection
 * - ringing/resampling/compression detection beyond classic 8x8 blocks
 * - more conservative detail recovery when people are present
 * - bounded repair only; never generative or super-resolution
 */
public final class DeepPixelRepair {

    public static final class Plan {
        public final boolean active;
        public final double noiseScore;
        public final double softnessScore;
        public final double blockScore;
        public final double ringingScore;
        public final double lumaDenoise;
        public final double chromaDenoise;
        public final double deblock;
        public final double detailRecovery;
        public final double confidence;
        public final boolean lowResolutionSource;

        Plan(boolean active, double noiseScore, double softnessScore, double blockScore,
             double ringingScore, double lumaDenoise, double chromaDenoise, double deblock,
             double detailRecovery, double confidence, boolean lowResolutionSource) {
            this.active = active;
            this.noiseScore = clamp01(noiseScore);
            this.softnessScore = clamp01(softnessScore);
            this.blockScore = clamp01(blockScore);
            this.ringingScore = clamp01(ringingScore);
            this.lumaDenoise = clamp(lumaDenoise, 0.0, 0.32);
            this.chromaDenoise = clamp(chromaDenoise, 0.0, 0.42);
            this.deblock = clamp(deblock, 0.0, 0.30);
            this.detailRecovery = clamp(detailRecovery, 0.0, 0.18);
            this.confidence = clamp01(confidence);
            this.lowResolutionSource = lowResolutionSource;
        }

        public static Plan none() {
            return new Plan(false, 0, 0, 0, 0, 0, 0, 0, 0, 0, false);
        }

        public String summary() {
            if (!active) return "not required";
            return String.format(Locale.US,
                    "%.0f%% confidence | noise %.0f%% | softness %.0f%% | JPEG blocks %.0f%% | halos %.0f%%",
                    confidence * 100.0, noiseScore * 100.0,
                    softnessScore * 100.0, blockScore * 100.0, ringingScore * 100.0);
        }
    }

    private DeepPixelRepair() { }

    public static Plan plan(double noise, double flatChromaNoise, double detail, double blockiness,
                            double ringing, int width, int height,
                            boolean aiMode, boolean aiMax, boolean personLike) {
        double baseNoiseScore = smooth((noise - 0.010) / 0.020);
        double chromaNoiseScore = smooth((flatChromaNoise - 0.010) / 0.030);
        double noiseScore = clamp01(Math.max(baseNoiseScore, chromaNoiseScore));
        double softnessScore = smooth((0.055 - detail) / 0.035);
        double blockScore = smooth((blockiness - 0.10) / 0.55);
        double ringingScore = smooth((ringing - 0.10) / 0.60);
        double compressionScore = Math.max(blockScore, ringingScore * 0.90);

        long pixels = Math.max(1L, (long) width * Math.max(1L, (long) height));
        boolean lowResolution = pixels < 3_000_000L;

        // High noise and compression can masquerade as detail; do not sharpen those defects back in.
        double recoverEvidence = softnessScore
                * (1.0 - 0.65 * noiseScore)
                * (1.0 - 0.35 * compressionScore);
        double modeScale = aiMode ? (aiMax ? 1.28 : 1.12) : 1.0;

        double luma = 0.17 * noiseScore * modeScale;
        double chroma = 0.32 * noiseScore * modeScale;
        double deblock = (0.17 * blockScore + 0.14 * ringingScore) * modeScale;
        double detailRecover = 0.115 * recoverEvidence * modeScale;

        if (personLike) {
            detailRecover = Math.min(detailRecover, aiMax ? 0.078 : 0.062);
            chroma *= 0.92;
            luma *= 0.95;
        }

        if (lowResolution && recoverEvidence > 0.35 && compressionScore < 0.42) {
            detailRecover = Math.min(0.14, detailRecover + 0.018);
        }

        boolean active = noiseScore >= 0.16 || softnessScore >= 0.28 || blockScore >= 0.24 || ringingScore >= 0.18;
        double defectEvidence = Math.max(Math.max(noiseScore, softnessScore), Math.max(blockScore, ringingScore));
        double confidence = active ? clamp01(0.42 + 0.58 * defectEvidence) : 0.0;

        if (luma < 0.030) luma = 0.0;
        if (chroma < 0.045) chroma = 0.0;
        if (deblock < 0.035) deblock = 0.0;
        if (detailRecover < 0.030) detailRecover = 0.0;

        active = active && (luma > 0.0 || chroma > 0.0 || deblock > 0.0 || detailRecover > 0.0);
        return new Plan(active, noiseScore, softnessScore, blockScore, ringingScore,
                luma, chroma, deblock, detailRecover, confidence, lowResolution);
    }

    private static double smooth(double x) {
        x = clamp01(x);
        return x * x * (3.0 - 2.0 * x);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
