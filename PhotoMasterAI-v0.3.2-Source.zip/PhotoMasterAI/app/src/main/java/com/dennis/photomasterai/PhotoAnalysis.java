package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Arrays;
import java.util.Locale;

public final class PhotoAnalysis {
    public final double meanLum;
    public final double medianLum;
    public final double p05;
    public final double p95;
    public final double p99;
    public final double shadowClip;
    public final double highlightClip;
    public final double avgR;
    public final double avgG;
    public final double avgB;
    public final double avgSat;
    public final double noise;
    public final double detail;
    public final double blockiness;
    public final double flatChromaNoise;
    public final double ringing;
    public final double blackFraction;
    public final double brightFraction;
    public final double greenFraction;
    public final double blueTopFraction;
    public final double neutralR;
    public final double neutralG;
    public final double neutralB;
    public final double neutralFraction;
    public final double neutralEvidenceConfidence;
    public final double neutralCastStrength;
    public final double neutralCastConsistency;
    public final double neutralCastConfidence;
    public final int width;
    public final int height;

    private PhotoAnalysis(double meanLum, double medianLum, double p05, double p95, double p99,
                          double shadowClip, double highlightClip, double avgR, double avgG, double avgB,
                          double avgSat, double noise, double detail, double blockiness,
                          double flatChromaNoise, double ringing,
                          double blackFraction, double brightFraction,
                          double greenFraction, double blueTopFraction,
                          double neutralR, double neutralG, double neutralB, double neutralFraction,
                          double neutralEvidenceConfidence, double neutralCastStrength, double neutralCastConsistency,
                          double neutralCastConfidence, int width, int height) {
        this.meanLum = meanLum;
        this.medianLum = medianLum;
        this.p05 = p05;
        this.p95 = p95;
        this.p99 = p99;
        this.shadowClip = shadowClip;
        this.highlightClip = highlightClip;
        this.avgR = avgR;
        this.avgG = avgG;
        this.avgB = avgB;
        this.avgSat = avgSat;
        this.noise = noise;
        this.detail = detail;
        this.blockiness = blockiness;
        this.flatChromaNoise = flatChromaNoise;
        this.ringing = ringing;
        this.blackFraction = blackFraction;
        this.brightFraction = brightFraction;
        this.greenFraction = greenFraction;
        this.blueTopFraction = blueTopFraction;
        this.neutralR = neutralR;
        this.neutralG = neutralG;
        this.neutralB = neutralB;
        this.neutralFraction = neutralFraction;
        this.neutralEvidenceConfidence = neutralEvidenceConfidence;
        this.neutralCastStrength = neutralCastStrength;
        this.neutralCastConsistency = neutralCastConsistency;
        this.neutralCastConfidence = neutralCastConfidence;
        this.width = width;
        this.height = height;
    }

    public static PhotoAnalysis analyse(Bitmap source) {
        final int maxSide = 512;
        int w = source.getWidth();
        int h = source.getHeight();
        double blockiness = estimateBlockiness(source);
        double scale = Math.min(1.0, maxSide / (double) Math.max(w, h));
        int sw = Math.max(2, (int) Math.round(w * scale));
        int sh = Math.max(2, (int) Math.round(h * scale));
        Bitmap small = (sw == w && sh == h) ? source : Bitmap.createScaledBitmap(source, sw, sh, true);

        int[] px = new int[sw * sh];
        small.getPixels(px, 0, sw, 0, 0, sw, sh);
        int[] hist = new int[256];
        long n = 0;
        double sumLum = 0, sumR = 0, sumG = 0, sumB = 0, sumSat = 0;
        double noiseSum = 0, edgeSum = 0;
        double flatChromaSum = 0.0;
        long flatChromaCount = 0;
        double ringSum = 0.0;
        long ringCount = 0;
        long shadow = 0, highlight = 0, blackField = 0, brightField = 0, green = 0, blueTop = 0, topCount = 0;
        long neutralCount = 0;
        double neutralWeight = 0, neutralSumR = 0, neutralSumG = 0, neutralSumB = 0;
        double neutralDeltaR = 0, neutralDeltaG = 0, neutralDeltaB = 0;
        double neutralDeltaR2 = 0, neutralDeltaG2 = 0, neutralDeltaB2 = 0;
        float[] hsv = new float[3];

        for (int y = 0; y < sh; y++) {
            int row = y * sw;
            for (int x = 0; x < sw; x++) {
                int c = px[row + x];
                int r8 = Color.red(c), g8 = Color.green(c), b8 = Color.blue(c);
                double r = r8 / 255.0, g = g8 / 255.0, b = b8 / 255.0;
                double lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                int bin = Math.max(0, Math.min(255, (int) Math.round(lum * 255.0)));
                hist[bin]++;
                sumLum += lum;
                sumR += r;
                sumG += g;
                sumB += b;
                if (bin <= 3) shadow++;
                if (bin >= 252) highlight++;
                if (lum <= 0.030) blackField++;
                if (lum >= 0.75) brightField++;

                Color.RGBToHSV(r8, g8, b8, hsv);
                sumSat += hsv[1];

                boolean skyLike = y < sh / 3 && b > r * 1.06 && b > g * 1.03 && b > 0.22;
                boolean foliageLike = g > r * 1.07 && g > b * 1.04 && g > 0.18;
                if (!skyLike && !foliageLike && hsv[1] <= 0.22f && lum >= 0.16 && lum <= 0.94) {
                    double weight = Math.max(0.05, 1.0 - hsv[1] / 0.22);
                    neutralWeight += weight;
                    neutralSumR += r * weight;
                    neutralSumG += g * weight;
                    neutralSumB += b * weight;
                    double pm = Math.max(0.04, (r + g + b) / 3.0);
                    double dR = r / pm - 1.0;
                    double dG = g / pm - 1.0;
                    double dB = b / pm - 1.0;
                    neutralDeltaR += dR * weight;
                    neutralDeltaG += dG * weight;
                    neutralDeltaB += dB * weight;
                    neutralDeltaR2 += dR * dR * weight;
                    neutralDeltaG2 += dG * dG * weight;
                    neutralDeltaB2 += dB * dB * weight;
                    neutralCount++;
                }

                if (g > r * 1.08 && g > b * 1.05 && g > 0.18) green++;
                if (y < sh / 3) {
                    topCount++;
                    if (b > r * 1.10 && b > g * 1.05 && b > 0.22) blueTop++;
                }

                double leftDiff = 1.0;
                double upDiff = 1.0;
                if (x > 0) {
                    int l = px[row + x - 1];
                    double ll = luminance(l);
                    double d = Math.abs(lum - ll);
                    leftDiff = d;
                    edgeSum += d;
                    if (d < 0.07) noiseSum += channelResidual(c, l);
                }
                if (y > 0) {
                    int u = px[row - sw + x];
                    double ul = luminance(u);
                    double d = Math.abs(lum - ul);
                    upDiff = d;
                    edgeSum += d;
                    if (d < 0.07) noiseSum += channelResidual(c, u);
                }

                // v0.3.1: flat-region chroma noise estimator. This catches coloured speckle
                // and processed JPEG grain that may be hidden inside otherwise detailed images.
                if (x > 0 && y > 0 && lum >= 0.10 && lum <= 0.92) {
                    double flatness = Math.max(leftDiff, upDiff);
                    if (flatness < 0.040) {
                        int l = px[row + x - 1];
                        int u = px[row - sw + x];
                        double meanNr = (Color.red(l) + Color.red(u)) / (255.0 * 2.0);
                        double meanNg = (Color.green(l) + Color.green(u)) / (255.0 * 2.0);
                        double meanNb = (Color.blue(l) + Color.blue(u)) / (255.0 * 2.0);
                        double centreCb = b - lum;
                        double centreCr = r - lum;
                        double nLum = 0.2126 * meanNr + 0.7152 * meanNg + 0.0722 * meanNb;
                        double meanCb = meanNb - nLum;
                        double meanCr = meanNr - nLum;
                        flatChromaSum += Math.abs(centreCb - meanCb) + Math.abs(centreCr - meanCr);
                        flatChromaCount++;
                    }
                }

                // v0.3.1: ringing / resampling / compression artifact detector.
                // We look for local peaks/valleys against similar neighbours, which often appear
                // around sharpened edges, haloing and resampled social-media images.
                if (x > 0 && x < sw - 1) {
                    double l1 = luminance(px[row + x - 1]);
                    double r1 = luminance(px[row + x + 1]);
                    double neighborMean = (l1 + r1) * 0.5;
                    double neighborGap = Math.abs(l1 - r1);
                    double overshoot = Math.abs(lum - neighborMean);
                    if (neighborGap < 0.050 && overshoot > 0.045) {
                        ringSum += overshoot - neighborGap * 0.5;
                        ringCount++;
                    }
                }
                if (y > 0 && y < sh - 1) {
                    double u1 = luminance(px[row - sw + x]);
                    double d1 = luminance(px[row + sw + x]);
                    double neighborMean = (u1 + d1) * 0.5;
                    double neighborGap = Math.abs(u1 - d1);
                    double overshoot = Math.abs(lum - neighborMean);
                    if (neighborGap < 0.050 && overshoot > 0.045) {
                        ringSum += overshoot - neighborGap * 0.5;
                        ringCount++;
                    }
                }
                n++;
            }
        }

        long[] cumulative = new long[256];
        long acc = 0;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            cumulative[i] = acc;
        }
        double median = percentile(cumulative, n, 0.50) / 255.0;
        double p05 = percentile(cumulative, n, 0.05) / 255.0;
        double p95 = percentile(cumulative, n, 0.95) / 255.0;
        double p99 = percentile(cumulative, n, 0.99) / 255.0;
        double pairCount = Math.max(1.0, (sw - 1.0) * sh + (sh - 1.0) * sw);
        double edge = edgeSum / pairCount;
        double noise = noiseSum / pairCount;
        double flatChroma = flatChromaCount > 0 ? flatChromaSum / flatChromaCount : 0.0;
        double ringing = ringCount > 0 ? clamp((ringSum / ringCount - 0.030) / 0.070, 0.0, 1.0) : 0.0;

        double nR = neutralWeight > 0.0 ? neutralSumR / neutralWeight : sumR / n;
        double nG = neutralWeight > 0.0 ? neutralSumG / neutralWeight : sumG / n;
        double nB = neutralWeight > 0.0 ? neutralSumB / neutralWeight : sumB / n;
        double nMean = (nR + nG + nB) / 3.0;
        double nImbalance = Math.max(Math.abs(nR / Math.max(0.03, nMean) - 1.0),
                Math.max(Math.abs(nG / Math.max(0.03, nMean) - 1.0),
                        Math.abs(nB / Math.max(0.03, nMean) - 1.0)));
        double nFraction = neutralCount / (double) Math.max(1L, n);

        double meanDR = neutralWeight > 0.0 ? neutralDeltaR / neutralWeight : 0.0;
        double meanDG = neutralWeight > 0.0 ? neutralDeltaG / neutralWeight : 0.0;
        double meanDB = neutralWeight > 0.0 ? neutralDeltaB / neutralWeight : 0.0;
        double stdR = neutralWeight > 0.0 ? Math.sqrt(Math.max(0.0, neutralDeltaR2 / neutralWeight - meanDR * meanDR)) : 1.0;
        double stdG = neutralWeight > 0.0 ? Math.sqrt(Math.max(0.0, neutralDeltaG2 / neutralWeight - meanDG * meanDG)) : 1.0;
        double stdB = neutralWeight > 0.0 ? Math.sqrt(Math.max(0.0, neutralDeltaB2 / neutralWeight - meanDB * meanDB)) : 1.0;
        double avgStd = (stdR + stdG + stdB) / 3.0;
        double consistency = clamp(1.0 - avgStd / 0.12, 0.15, 1.0);

        double coverageEvidence = clamp((nFraction - 0.003) / 0.047, 0.0, 1.0);
        double evidenceConfidence = coverageEvidence * (0.65 + 0.35 * consistency);
        double castSignal = clamp((nImbalance - 0.012) / 0.060, 0.0, 1.0);
        double castConfidence = castSignal * (0.40 + 0.60 * evidenceConfidence) * (0.75 + 0.25 * consistency);

        if (small != source) small.recycle();

        return new PhotoAnalysis(
                sumLum / n, median, p05, p95, p99,
                shadow / (double) n, highlight / (double) n,
                sumR / n, sumG / n, sumB / n,
                sumSat / n, noise, edge, blockiness, flatChroma, ringing,
                blackField / (double) n, brightField / (double) n,
                green / (double) n, blueTop / (double) Math.max(1L, topCount),
                nR, nG, nB, nFraction, evidenceConfidence, nImbalance, consistency, castConfidence, w, h
        );
    }

    private static double estimateBlockiness(Bitmap source) {
        int w = source.getWidth();
        int h = source.getHeight();
        if (w < 32 || h < 32) return 0.0;

        int yStep = Math.max(1, h / 240);
        int xStep = Math.max(1, w / 240);
        double boundary = 0.0, interior = 0.0;
        long boundaryN = 0, interiorN = 0;

        int[] row = new int[w];
        for (int y = 0; y < h; y += yStep) {
            source.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 8; x < w; x += 8 * xStep) {
                int bx = Math.min(w - 1, x);
                int ix = Math.min(w - 2, Math.max(2, x - 4));
                double bd = Math.abs(luminance(row[bx]) - luminance(row[bx - 1]));
                double id = Math.abs(luminance(row[ix]) - luminance(row[ix - 1]));
                if (bd < 0.12) { boundary += bd; boundaryN++; }
                if (id < 0.12) { interior += id; interiorN++; }
            }
        }

        int[] upper = new int[w];
        int[] lower = new int[w];
        for (int y = 8; y < h; y += 8 * yStep) {
            source.getPixels(upper, 0, w, 0, y - 1, w, 1);
            source.getPixels(lower, 0, w, 0, y, w, 1);
            int iy = Math.min(h - 2, Math.max(2, y - 4));
            int[] interiorA = new int[w];
            int[] interiorB = new int[w];
            source.getPixels(interiorA, 0, w, 0, iy - 1, w, 1);
            source.getPixels(interiorB, 0, w, 0, iy, w, 1);
            for (int x = 0; x < w; x += xStep) {
                double bd = Math.abs(luminance(lower[x]) - luminance(upper[x]));
                double id = Math.abs(luminance(interiorB[x]) - luminance(interiorA[x]));
                if (bd < 0.12) { boundary += bd; boundaryN++; }
                if (id < 0.12) { interior += id; interiorN++; }
            }
        }

        if (boundaryN < 20 || interiorN < 20) return 0.0;
        double b = boundary / boundaryN;
        double i = interior / interiorN;
        return clamp((b - i * 1.10) / 0.035, 0.0, 1.0);
    }

    private static double luminance(int c) {
        return (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)) / 255.0;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static double channelResidual(int a, int b) {
        double dr = Math.abs(Color.red(a) - Color.red(b)) / 255.0;
        double dg = Math.abs(Color.green(a) - Color.green(b)) / 255.0;
        double db = Math.abs(Color.blue(a) - Color.blue(b)) / 255.0;
        double chroma = Math.abs(dr - dg) + Math.abs(db - dg);
        return chroma * 0.5;
    }

    private static int percentile(long[] cumulative, long n, double p) {
        long target = Math.max(1, (long) Math.ceil(n * p));
        int i = Arrays.binarySearch(cumulative, target);
        if (i < 0) i = -i - 1;
        return Math.max(0, Math.min(255, i));
    }

    public String sceneSummary() {
        String light;
        if (medianLum < 0.22) light = "low-light/dark";
        else if (medianLum > 0.68) light = "bright";
        else light = "normal-light";
        String contrast = (p95 - p05 > 0.72) ? "high dynamic range" : ((p95 - p05 < 0.42) ? "low contrast" : "balanced contrast");
        String colour = greenFraction > 0.26 ? "foliage-rich" : (blueTopFraction > 0.30 ? "sky-rich" : "mixed colour");
        return light + ", " + contrast + ", " + colour;
    }

    public String compactMetrics() {
        return String.format(Locale.US,
                "Median %.2f | DR %.2f | clip S %.2f%% / H %.2f%% | sat %.2f | noise %.3f | flat chroma %.3f | detail %.3f | JPEG blocks %.2f | ring %.2f | black %.1f%% | bright %.1f%% | neutral %.1f%% | evidence %.2f | cast %.3f | cast conf %.2f",
                medianLum, (p95 - p05), shadowClip * 100.0, highlightClip * 100.0, avgSat, noise, flatChromaNoise, detail, blockiness,
                ringing, blackFraction * 100.0, brightFraction * 100.0, neutralFraction * 100.0, neutralEvidenceConfidence, neutralCastStrength, neutralCastConfidence);
    }
}
