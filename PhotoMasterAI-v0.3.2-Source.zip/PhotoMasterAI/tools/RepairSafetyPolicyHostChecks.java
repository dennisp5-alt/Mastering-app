package com.dennis.photomasterai;

public final class RepairSafetyPolicyHostChecks {
    public static void main(String[] args) {
        // Bright duck/water sample: bright median with safe highlights must not be darkened.
        double duckEv = RepairSafetyPolicy.exposureEv(0.66, 0.0000, 0.97, 0.12, false, false);
        require(Math.abs(duckEv) < 0.001, "safe bright scene must not be globally darkened");
        require(RepairSafetyPolicy.brightExposureProtected(0.66, duckEv, false),
                "bright exposure guard should report active");

        // Pool/social-like source: small highlight clipping and a bright median still should not trigger -EV.
        double poolEv = RepairSafetyPolicy.exposureEv(0.65, 0.0056, 0.99, 0.20, false, false);
        require(Math.abs(poolEv) < 0.001, "mixed high-DR pool image should use highlight roll-off before -EV");

        // Cave group sample: some lift is justified, but must be capped.
        double caveEv = RepairSafetyPolicy.exposureEv(0.17, 0.0000, 0.98, 0.12, false, false);
        require(caveEv > 0.0 && caveEv <= 0.400001, "dark scene lift must stay capped at +0.40 EV");
        require(RepairSafetyPolicy.capShadowLift(0.42, 0.17, false, false) <= 0.220001,
                "very dark scenes should cap shadow lift");

        // Moon/dark-field sample: black sky is intentional; no global lift or shadow opening.
        boolean moon = RepairSafetyPolicy.isDarkField(0.72, 0.00, 0.18, 0.94);
        require(moon, "moon-like dark field should be detected");
        require(Math.abs(RepairSafetyPolicy.exposureEv(0.00, 0.0002, 0.94, 0.18, false, moon)) < 0.001,
                "dark field must not receive global exposure lift");
        require(RepairSafetyPolicy.capShadowLift(0.42, 0.00, false, moon) == 0.0,
                "dark field must preserve intentional blacks");

        // Social/screenshot source: lower processing pressure.
        boolean social = RepairSafetyPolicy.isProcessedSource(1080L * 1920L, 0.82, 0.41, 0.02, false);
        require(social, "small high-ringing social source should be guarded");
        require(!RepairSafetyPolicy.isProcessedSource(1080L * 1920L, 0.82, 0.05, 0.00, true),
                "dark-field classification must override social-source heuristic");

        System.out.println("Repair Safety Policy host checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
