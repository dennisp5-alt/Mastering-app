package com.dennis.photomasterai;

public final class DeepPixelRepairHostChecks {
    public static void main(String[] args) {
        DeepPixelRepair.Plan clean = DeepPixelRepair.plan(
                0.008, 0.007, 0.064, 0.03, 0.02,
                4000, 3000, false, false, false);
        require(!clean.active, "clean source must remain untouched");

        DeepPixelRepair.Plan noisy = DeepPixelRepair.plan(
                0.020, 0.030, 0.045, 0.12, 0.06,
                4000, 3000, false, false, false);
        require(noisy.active && noisy.chromaDenoise > noisy.lumaDenoise,
                "noise repair should prioritise chroma speckle");

        DeepPixelRepair.Plan blocky = DeepPixelRepair.plan(
                0.011, 0.009, 0.052, 0.66, 0.12,
                1920, 1080, false, false, false);
        require(blocky.active && blocky.deblock > 0.05,
                "compression or halo artifacts should enable bounded repair");

        DeepPixelRepair.Plan ringy = DeepPixelRepair.plan(
                0.010, 0.010, 0.050, 0.03, 0.70,
                1920, 1080, false, false, false);
        require(ringy.active && ringy.deblock > 0.04,
                "ringing alone should activate halo control");

        DeepPixelRepair.Plan softAi = DeepPixelRepair.plan(
                0.012, 0.010, 0.025, 0.08, 0.05,
                1800, 1200, true, true, false);
        require(softAi.active && softAi.detailRecovery > 0.05 && softAi.lowResolutionSource,
                "soft low-res AI path should allow bounded detail recovery");

        DeepPixelRepair.Plan portrait = DeepPixelRepair.plan(
                0.012, 0.010, 0.025, 0.08, 0.05,
                4000, 3000, true, true, true);
        require(portrait.detailRecovery <= 0.078001,
                "person evidence must cap detail recovery harder in v0.3.1");

        System.out.println("Deep Pixel Repair host checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
