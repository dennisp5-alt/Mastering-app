# Photo Master AI v0.3.2 — Exposure Guard + Repair Rollback

v0.3.2 keeps the improved defect detection from v0.3.1 but tightens when repairs are allowed.

## New safety logic

- Bright-scene exposure guard: a high median alone no longer triggers global darkening.
- Highlight-first correction: safe bright scenes keep exposure; true clipping is handled with bounded highlight roll-off first.
- Dark-scene exposure cap: very dark scenes receive smaller global exposure lifts and more selective shadow recovery.
- Dark-field / isolated-bright-subject protection: moon, stage-light and similar scenes preserve intentional blacks and do not treat the subject edge as a generic halo defect.
- Full repair rollback: if reduced repair still raises noise, reduces real detail or worsens ringing, Deep Pixel Repair is removed and the image is re-rendered.
- Benefit-vs-loss gate: strong noise reduction is not accepted when it costs too much real detail.
- Halo/compression repair rejection: the halo stage is disabled when ringing fails to improve.
- Already-processed/social-source guard: small, high-ringing screenshots/social images receive lower sharpening, halo repair and colour-density pressure.

## Preserved

- v0.3.1 flat-region chroma-noise detection
- ringing/resampling/compression detection
- TRUE / PRO / NAT GEO / LIFE / AI ENHANCE / AI MAX
- ML Kit scene labels, face detection and person segmentation
- calibrated cast evidence/confidence logic
- proper adaptive Photo Master AI app icon
- JPEG quality 100 output

Deep Pixel Repair remains non-generative. It does not invent detail or upscale.
