# Auto+ AI Camera for Samsung Galaxy S23 Ultra — v0.1.0 BULK TEST

Package: `com.dennis.s23uaicamera`
Target: Samsung SM-S918B / Android 16 API 36

## Purpose
First full capture tester built from the S23U Camera Capability Probe. It intentionally uses documented Camera2 controls first and does **not** write unknown Qualcomm/Samsung vendor tags.

## What is implemented
- Logical rear camera 0, with 0.6x / 1x / 3x / 10x requested zoom and active physical camera ID telemetry.
- 640x480 continuous YUV analysis while capturing full-resolution JPEG.
- 7x7 (49-zone) internal focus/exposure scoring map.
- Face-priority AF/AE region when Camera2 reports faces.
- Histogram-aware EV control with highlight protection.
- Motion telemetry from the gyroscope.
- Auto-level telemetry and conservative post-capture straighten (only <=5 degrees).
- Three rendering personalities: TRUE, PRO, NAT GEO.
- AI mode automatically saves both the untouched Camera2 reference JPEG and the processed AI JPEG from the same capture.
- JPEG quality request = 100.
- Per-shot JSON diagnostics saved to `Download/AutoPlusAI`.
- Images saved to `Pictures/AutoPlusAI`.

## Bulk-test priorities
1. Confirm preview/capture reliability at all four zoom positions.
2. Compare `_REF.jpg` with `_AI.jpg` in daylight, indoor, backlit, sunset and night scenes.
3. Check `activePhysicalCameraId` in diagnostics to see when Samsung switches lenses.
4. Check whether automatic EV is too bright/dark in difficult scenes.
5. Check auto-level sign/direction and crop safety.
6. Check TRUE/PRO/NAT GEO colour preference.

## Intentionally deferred until evidence supports it
- Qualcomm vendor tags (`EnableMFNR`, `EnableMFHDR`, `EnableAutoHDR`, `AICameraMode`, `HorizonLevelControl`, etc.). Their names are exposed, but the probe does not reveal safe Java value types/contracts.
- 50 MP / 200 MP, because the third-party stream maps expose no maximum-resolution stream and top out at 4080x3060 on the logical/main camera.
- RAW+DNG capture and 10-bit P010 still pipeline.
- Multi-frame registration/merge. v0.1 establishes exposure, focus, lens switching, colour and level baselines first.
- OEM Auto extension A/B path. The probe confirms it is available and can be added after direct Camera2 reliability is proven.

This is a diagnostic/bulk-test build, not a finished production camera.


## v0.1.1 hotfix
- Fixed stretched portrait preview / face proportions by using 4:3 preview geometry.
- Hardened MediaStore saving with pending/publish transaction.
- Reduced 12 MP AI processing memory use with row-wise pixel processing.
- Added capture timeout diagnostics and safer still-capture request.


## v0.1.4 capture-baseline
Known-good S23U Daylight Lab capture architecture: logical 0 / physical 5 binding, preview + one full-res YUV output only, in-app JPEG encoding, MediaStore save. AI analysis output temporarily removed from Camera2 session for save validation.
