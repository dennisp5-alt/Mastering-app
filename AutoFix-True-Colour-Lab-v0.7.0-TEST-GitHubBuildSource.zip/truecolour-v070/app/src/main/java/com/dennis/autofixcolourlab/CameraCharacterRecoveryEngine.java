package com.dennis.autofixcolourlab;

import java.util.Locale;

/**
 * Camera-agnostic, evidence-gated JPEG character recovery.
 * Estimates baked rendering rather than identifying a camera model. Corrections are deliberately
 * small and reversible in spirit: neutral files should pass effectively unchanged.
 */
public final class CameraCharacterRecoveryEngine {
    private CameraCharacterRecoveryEngine() {}

    public static final class Accumulator {
        private long n;
        private double sumY, sumY2, sumSat, sumR, sumG, sumB;
        private long deepBlack, shadow, highlight, clipped, saturated;
        public void addPixel(int c) {
            double r=((c>>>16)&255)/255.0, g=((c>>>8)&255)/255.0, b=(c&255)/255.0;
            double max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b));
            double y=.2126*r+.7152*g+.0722*b;
            double sat=max<=1e-6?0:(max-min)/max;
            n++; sumY+=y; sumY2+=y*y; sumSat+=sat; sumR+=r; sumG+=g; sumB+=b;
            if(y<.025) deepBlack++; if(y<.18) shadow++; if(y>.82) highlight++;
            if(max>.995) clipped++; if(sat>.72) saturated++;
        }
        public Analysis finish() {
            if(n<64) return Analysis.neutral("insufficient evidence");
            double mean=sumY/n, sd=Math.sqrt(Math.max(0,sumY2/n-mean*mean));
            double sat=sumSat/n, clip=clipped/(double)n, satHi=saturated/(double)n;
            double black=deepBlack/(double)n, shadows=shadow/(double)n;
            double r=sumR/n,g=sumG/n,b=sumB/n;
            // Evidence scores intentionally require fairly strong global signatures.
            double overSat=clamp((sat-.34)/.18)*clamp((satHi-.08)/.18);
            double hardContrast=clamp((sd-.255)/.13) * clamp((black-.012)/.055 + clip/.035);
            double liftedShadows=clamp((.075-black)/.075) * clamp((.31-shadows)/.18) * clamp((mean-.40)/.22);
            double hdr=clamp((.245-sd)/.11) * clamp((mean-.39)/.20) * clamp((.055-clip)/.055);
            // Global cast is only a weak precondition; True Colour remains authoritative for WB.
            double warm=clamp(((r-b)-.075)/.14), cool=clamp(((b-r)-.075)/.14);
            double wbBias=Math.max(warm,cool)*.35;
            double confidence=clamp(Math.max(Math.max(overSat,hardContrast),Math.max(liftedShadows,hdr))*.82 + wbBias*.18);
            boolean active=confidence>=.40;
            if(!active) return Analysis.neutral("neutral/insufficient baked-processing evidence");
            return new Analysis(true,confidence,overSat,hardContrast,liftedShadows,hdr,wbBias,warm>=cool?1:-1,
                    "measured JPEG rendering signature");
        }
    }

    public static final class Analysis {
        public final boolean active; public final double confidence, overSaturation, hardContrast, liftedShadows, hdrCompression, wbBias;
        public final int wbDirection; public final String reason;
        Analysis(boolean a,double c,double s,double hc,double ls,double hdr,double wb,int dir,String reason){active=a;confidence=c;overSaturation=s;hardContrast=hc;liftedShadows=ls;hdrCompression=hdr;wbBias=wb;wbDirection=dir;this.reason=reason;}
        static Analysis neutral(String why){return new Analysis(false,0,0,0,0,0,0,0,why);}
        public String summary(){return String.format(Locale.US,"Camera Character Recovery: %s  • confidence %.0f%%\nOversaturation %.0f%%  hard contrast %.0f%%  lifted/HDR shadows %.0f%%/%.0f%%  WB-bias evidence %.0f%%",
                active?"ACTIVE":"BYPASS",confidence*100,overSaturation*100,hardContrast*100,liftedShadows*100,hdrCompression*100,wbBias*100);}
    }

    public static final class Processor {
        private final Analysis a; private final double amount;
        public Processor(Analysis a,double strength){this.a=a; this.amount=clamp(strength)*Math.min(.72,.30+.42*a.confidence);}
        public int apply(int c){
            if(!a.active||amount<=0) return c;
            double r=((c>>>16)&255)/255.0,g=((c>>>8)&255)/255.0,b=(c&255)/255.0;
            double y=.2126*r+.7152*g+.0722*b;
            // Undo global saturation boosting, bounded to preserve naturally vivid subjects.
            double ds=amount*a.overSaturation*.18;
            r=y+(r-y)*(1-ds); g=y+(g-y)*(1-ds); b=y+(b-y)*(1-ds);
            // Reverse harsh S-curves or lifted/HDR shadows with tiny luminance remaps.
            double target=y;
            if(a.hardContrast>0) target += amount*a.hardContrast*(.5-y)*.075;
            if(a.liftedShadows>0 && y<.45) target -= amount*a.liftedShadows*(.45-y)*.055;
            if(a.hdrCompression>0){ if(y<.42) target-=amount*a.hdrCompression*(.42-y)*.035; else if(y>.62) target+=amount*a.hdrCompression*(y-.62)*.025; }
            double scale=y>1e-5?target/y:1; r*=scale;g*=scale;b*=scale;
            // Only a very small cast pre-normalisation; True Colour decides actual WB correction.
            double wb=amount*a.wbBias*.025;
            if(a.wbDirection>0){r*=1-wb;b*=1+wb;} else if(a.wbDirection<0){r*=1+wb;b*=1-wb;}
            return (c & 0xff000000) | (to8(r)<<16) | (to8(g)<<8) | to8(b);
        }
    }
    private static int to8(double v){return (int)Math.round(clamp(v)*255);}
    private static double clamp(double v){return Math.max(0,Math.min(1,v));}
}
