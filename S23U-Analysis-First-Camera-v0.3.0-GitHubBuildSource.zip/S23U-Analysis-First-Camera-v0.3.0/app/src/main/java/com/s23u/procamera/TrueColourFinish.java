package com.s23u.procamera;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * True Colour + Natural Tone finishing stage for Analysis First v0.3.0. It only re-encodes
 * when a confidence-gated neutral correction and/or semantic sky/water blue
 * restraint is actually applied. Mixed light, weak evidence and genuine object
 * colours are preserved by default.
 */
final class TrueColourFinish {
    static final class Result {
        final boolean applied;
        final double affectedPercent;
        final String detail;

        Result(boolean applied, double affectedPercent, String detail) {
            this.applied = applied;
            this.affectedPercent = affectedPercent;
            this.detail = detail;
        }

        static Result skipped(String detail) {
            return new Result(false, 0.0, detail);
        }
    }

    private static final byte MASK_NONE = 0;
    private static final byte MASK_SKY = 1;
    private static final byte MASK_WATER = 2;

    private static final String[] EXIF_TAGS = {
            ExifInterface.TAG_APERTURE_VALUE,
            ExifInterface.TAG_COLOR_SPACE,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_FLASH,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
            ExifInterface.TAG_IMAGE_DESCRIPTION,
            ExifInterface.TAG_IMAGE_UNIQUE_ID,
            ExifInterface.TAG_ISO_SPEED_RATINGS,
            ExifInterface.TAG_LIGHT_SOURCE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MAX_APERTURE_VALUE,
            ExifInterface.TAG_METERING_MODE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.TAG_SOFTWARE,
            ExifInterface.TAG_SUBSEC_TIME,
            ExifInterface.TAG_SUBSEC_TIME_DIGITIZED,
            ExifInterface.TAG_SUBSEC_TIME_ORIGINAL,
            ExifInterface.TAG_USER_COMMENT,
            ExifInterface.TAG_WHITE_BALANCE
    };

    private TrueColourFinish() { }

    static Result apply(ContentResolver resolver, Uri uri, File cacheDir,
                        TrueColourDecision decision) throws IOException {
        ExifSnapshot exif = ExifSnapshot.read(resolver, uri);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inMutable = true;

        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) return Result.skipped("image unavailable");
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) return Result.skipped("decode failed");

        long pixels = (long) bitmap.getWidth() * bitmap.getHeight();
        if (pixels > 20_000_000L) {
            bitmap.recycle();
            return Result.skipped("above 20 MP safety limit");
        }

        SceneMask mask = buildSceneMask(bitmap);
        NeutralMeasurement neutral = measureNeutrals(bitmap, mask);
        ToneMeasurement toneMeasurement = measureTone(bitmap);
        NaturalTonality.Plan tonePlan = NaturalTonality.plan(
                toneMeasurement.p05, toneMeasurement.p50, toneMeasurement.p95,
                toneMeasurement.shadowFraction, toneMeasurement.highlightFraction);
        GainPlan gains = GainPlan.none();
        if (decision != null && decision.correctionAllowed()) {
            gains = buildGainPlan(neutral, decision);
        }

        long lensAffected = decision != null && decision.lensCalibrationActive()
                ? applyLensCalibration(bitmap, decision.lensUBias, decision.lensVBias) : 0L;
        long wbAffected = gains.active ? applyNeutralCorrection(bitmap, gains) : 0L;
        long blueAffected = mask.maskedCells > 0 ? tameMaskedPixels(bitmap, mask) : 0L;
        long toneAffected = tonePlan.active ? applyNaturalTonality(bitmap, tonePlan) : 0L;
        long affected = Math.max(toneAffected,
                Math.max(lensAffected, Math.max(wbAffected, blueAffected)));
        if (affected == 0L) {
            bitmap.recycle();
            String reason = decision == null ? "colour decision unavailable"
                    : decision.shortLabel();
            return Result.skipped("no pixel correction required · " + reason
                    + " · Natural Tone already contained · object colours protected");
        }

        File temporary = File.createTempFile("s23u-true-colour-", ".jpg", cacheDir);
        try {
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)) {
                    throw new IOException("Q100 JPEG encode failed");
                }
            } finally {
                bitmap.recycle();
            }

            try (InputStream input = new FileInputStream(temporary);
                 OutputStream output = resolver.openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("output stream unavailable");
                byte[] buffer = new byte[128 * 1024];
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    output.write(buffer, 0, read);
                }
                output.flush();
            }
            exif.restore(resolver, uri);
        } finally {
            if (!temporary.delete()) temporary.deleteOnExit();
        }

        double affectedPercent = affected * 100.0 / Math.max(1L, pixels);
        String wb = gains.active
                ? String.format(java.util.Locale.US,
                "neutral WB %.1f%% evidence · gains %.4f/%.4f/%.4f",
                neutral.evidenceFraction * 100.0, gains.rGain, gains.gGain, gains.bGain)
                : "global WB preserved";
        String lensCal = lensAffected > 0 && decision != null
                ? String.format(java.util.Locale.US,
                "lens chroma cal U%+.2f/V%+.2f (%d samples)",
                decision.lensUBias, decision.lensVBias, decision.calibrationSamples)
                : "lens chroma cal safe-zero";
        String semantic = blueAffected > 0
                ? String.format(java.util.Locale.US,
                "sky %.1f%% / water %.1f%% restrained",
                mask.skyPercent(), mask.waterPercent())
                : "semantic blues preserved";
        return new Result(true, affectedPercent, lensCal + " · " + wb + " · " + semantic
                + " · " + tonePlan.diagnostic()
                + " · skin/foliage/object protection active");
    }

    private static SceneMask buildSceneMask(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int cell = Math.max(12, Math.min(32, Math.min(width, height) / 120));
        int cols = (width + cell - 1) / cell;
        int rows = (height + cell - 1) / cell;
        int count = cols * rows;

        boolean[] candidate = new boolean[count];
        double[] blueFraction = new double[count];
        double[] texture = new double[count];

        for (int gy = 0; gy < rows; gy++) {
            int y0 = gy * cell;
            int y1 = Math.min(height, y0 + cell);
            int[] ys = sampleAxis(y0, y1);
            for (int gx = 0; gx < cols; gx++) {
                int x0 = gx * cell;
                int x1 = Math.min(width, x0 + cell);
                int[] xs = sampleAxis(x0, x1);
                int blue = 0;
                int samples = 0;
                int lumaMin = 255;
                int lumaMax = 0;
                long lumaSum = 0L;
                for (int y : ys) {
                    for (int x : xs) {
                        int colour = bitmap.getPixel(x, y);
                        if (isStrongBlue(colour)) blue++;
                        int r = (colour >>> 16) & 0xff;
                        int g = (colour >>> 8) & 0xff;
                        int b = colour & 0xff;
                        int luma = (54 * r + 183 * g + 19 * b) >> 8;
                        lumaMin = Math.min(lumaMin, luma);
                        lumaMax = Math.max(lumaMax, luma);
                        lumaSum += luma;
                        samples++;
                    }
                }
                int index = gy * cols + gx;
                double fraction = blue / (double) Math.max(1, samples);
                double meanLuma = lumaSum / (double) Math.max(1, samples);
                double localTexture = lumaMax - lumaMin;
                blueFraction[index] = fraction;
                texture[index] = localTexture;
                candidate[index] = fraction >= 0.55 && meanLuma >= 55.0
                        && localTexture <= 85.0;
            }
        }

        byte[] types = new byte[count];
        boolean[] visited = new boolean[count];
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        List<Integer> component = new ArrayList<>();
        int skyCells = 0;
        int waterCells = 0;

        for (int start = 0; start < count; start++) {
            if (!candidate[start] || visited[start]) continue;
            queue.clear();
            component.clear();
            queue.add(start);
            visited[start] = true;

            int minX = cols;
            int maxX = -1;
            int minY = rows;
            int maxY = -1;
            long sumX = 0L;
            long sumY = 0L;
            double sumTexture = 0.0;
            double sumBlue = 0.0;

            while (!queue.isEmpty()) {
                int index = queue.removeFirst();
                component.add(index);
                int y = index / cols;
                int x = index - y * cols;
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
                sumX += x;
                sumY += y;
                sumTexture += texture[index];
                sumBlue += blueFraction[index];

                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        int nx = x + dx;
                        int ny = y + dy;
                        if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;
                        int next = ny * cols + nx;
                        if (!candidate[next] || visited[next]) continue;
                        visited[next] = true;
                        queue.addLast(next);
                    }
                }
            }

            int size = component.size();
            double centroidY = (sumY / (double) Math.max(1, size)) / Math.max(1, rows);
            double spanWidth = (maxX - minX + 1) / (double) Math.max(1, cols);
            double spanHeight = (maxY - minY + 1) / (double) Math.max(1, rows);
            double meanTexture = sumTexture / Math.max(1, size);
            double meanBlue = sumBlue / Math.max(1, size);
            boolean touchesTop = minY == 0;
            boolean touchesLeft = minX == 0;
            boolean touchesRight = maxX == cols - 1;

            int minSkySize = Math.max(4, (int) Math.ceil(count * 0.006));
            boolean sky = size >= minSkySize
                    && centroidY < 0.42
                    && (touchesTop || ((touchesLeft || touchesRight)
                    && minY / (double) Math.max(1, rows) < 0.30
                    && spanWidth > 0.08));

            int minWaterSize = Math.max(6, (int) Math.ceil(count * 0.012));
            boolean water = !sky
                    && size >= minWaterSize
                    && centroidY > 0.38
                    && spanWidth >= 0.35
                    && spanHeight <= 0.42
                    && meanTexture < 28.0
                    && meanBlue >= 0.62
                    && !touchesTop;

            byte type = sky ? MASK_SKY : (water ? MASK_WATER : MASK_NONE);
            if (type == MASK_NONE) continue;
            for (int index : component) types[index] = type;
            if (type == MASK_SKY) skyCells += size;
            else waterCells += size;
        }

        return new SceneMask(cell, cols, rows, types, skyCells, waterCells);
    }


    private static NeutralMeasurement measureNeutrals(Bitmap bitmap, SceneMask mask) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int step = Math.max(4, Math.min(width, height) / 420);
        long rSum = 0L, gSum = 0L, bSum = 0L;
        int neutral = 0;
        int sampled = 0;
        for (int y = step / 2; y < height; y += step) {
            int gy = Math.min(mask.rows - 1, y / mask.cellSize);
            for (int x = step / 2; x < width; x += step) {
                int gx = Math.min(mask.cols - 1, x / mask.cellSize);
                int colour = bitmap.getPixel(x, y);
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                sampled++;
                int max = Math.max(r, Math.max(g, b));
                int min = Math.min(r, Math.min(g, b));
                int luma = (54 * r + 183 * g + 19 * b) >> 8;
                if (luma < 45 || luma > 225 || max - min > 46) continue;
                byte type = mask.types[gy * mask.cols + gx];
                if (type != MASK_NONE || isLikelyFoliage(r, g, b) || isLikelySkin(r, g, b)) continue;
                rSum += r;
                gSum += g;
                bSum += b;
                neutral++;
            }
        }
        if (neutral == 0) return new NeutralMeasurement(0.0, 0.0, 0.0, 0.0);
        return new NeutralMeasurement(neutral / (double) Math.max(1, sampled),
                rSum / (double) neutral, gSum / (double) neutral, bSum / (double) neutral);
    }

    private static GainPlan buildGainPlan(NeutralMeasurement neutral, TrueColourDecision decision) {
        if (neutral.evidenceFraction < 0.006 || neutral.r <= 1.0 || neutral.g <= 1.0
                || neutral.b <= 1.0) return GainPlan.none();
        if (!directionAgrees(neutral, decision.castName)) return GainPlan.none();
        double mean = (neutral.r + neutral.g + neutral.b) / 3.0;
        double rawR = mean / neutral.r;
        double rawG = mean / neutral.g;
        double rawB = mean / neutral.b;
        double maxDelta = Math.max(Math.abs(rawR - 1.0),
                Math.max(Math.abs(rawG - 1.0), Math.abs(rawB - 1.0)));
        if (maxDelta < 0.010) return GainPlan.none();
        double cap = Math.max(0.0, decision.maxGainDelta);
        double r = 1.0 + clampDouble(rawR - 1.0, -cap, cap);
        double g = 1.0 + clampDouble(rawG - 1.0, -cap, cap);
        double b = 1.0 + clampDouble(rawB - 1.0, -cap, cap);
        return new GainPlan(true, r, g, b);
    }

    private static boolean directionAgrees(NeutralMeasurement neutral, String castName) {
        if (castName == null) return false;
        if ("cool/blue".equals(castName)) return neutral.b >= neutral.r + 2.0;
        if ("warm/yellow".equals(castName)) return neutral.r >= neutral.b + 2.0;
        if ("red/magenta".equals(castName)) return neutral.r >= neutral.g + 2.0;
        if ("green/cyan".equals(castName)) return neutral.g >= neutral.r + 1.5
                || neutral.b >= neutral.r + 2.0;
        return false;
    }

    private static long applyLensCalibration(Bitmap bitmap, double uBias, double vBias) {
        if (Math.abs(uBias) < 0.05 && Math.abs(vBias) < 0.05) return 0L;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;
        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int count = width * rows;
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int i = 0; i < count; i++) {
                int colour = pixels[i];
                int a = (colour >>> 24) & 0xff;
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                int max = Math.max(r, Math.max(g, b));
                int min = Math.min(r, Math.min(g, b));
                double protection = isLikelySkin(r, g, b) ? 0.65
                        : (max - min > 120 ? 0.78 : 1.0);
                double y = 0.299 * r + 0.587 * g + 0.114 * b;
                double u = -0.169 * r - 0.331 * g + 0.500 * b;
                double v = 0.500 * r - 0.419 * g - 0.081 * b;
                u -= uBias * protection;
                v -= vBias * protection;
                int nr = clamp((int) Math.round(y + 1.402 * v));
                int ng = clamp((int) Math.round(y - 0.344136 * u - 0.714136 * v));
                int nb = clamp((int) Math.round(y + 1.772 * u));
                if (nr != r || ng != g || nb != b) affected++;
                pixels[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static long applyNeutralCorrection(Bitmap bitmap, GainPlan gains) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;
        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int i = 0; i < width * rows; i++) {
                int colour = pixels[i];
                int a = (colour >>> 24) & 0xff;
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                int max = Math.max(r, Math.max(g, b));
                int min = Math.min(r, Math.min(g, b));
                double protect = isLikelySkin(r, g, b) ? 0.35
                        : (max - min > 100 ? 0.72 : 1.0);
                int nr = clamp((int) Math.round(r * (1.0 + (gains.rGain - 1.0) * protect)));
                int ng = clamp((int) Math.round(g * (1.0 + (gains.gGain - 1.0) * protect)));
                int nb = clamp((int) Math.round(b * (1.0 + (gains.bGain - 1.0) * protect)));
                if (nr != r || ng != g || nb != b) affected++;
                pixels[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static ToneMeasurement measureTone(Bitmap bitmap) {
        int[] histogram = new int[256];
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int step = Math.max(3, Math.min(width, height) / 520);
        int total = 0;
        int shadow = 0;
        int highlight = 0;
        for (int y = step / 2; y < height; y += step) {
            for (int x = step / 2; x < width; x += step) {
                int colour = bitmap.getPixel(x, y);
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                int luma = (54 * r + 183 * g + 19 * b) >> 8;
                histogram[luma]++;
                total++;
                if (luma <= 32) shadow++;
                if (luma >= 235) highlight++;
            }
        }
        return new ToneMeasurement(percentile(histogram, total, 0.05),
                percentile(histogram, total, 0.50), percentile(histogram, total, 0.95),
                shadow / (double) Math.max(1, total),
                highlight / (double) Math.max(1, total));
    }

    private static int percentile(int[] histogram, int total, double fraction) {
        int target = Math.max(1, (int) Math.ceil(total * fraction));
        int running = 0;
        for (int i = 0; i < histogram.length; i++) {
            running += histogram[i];
            if (running >= target) return i;
        }
        return 255;
    }

    private static long applyNaturalTonality(Bitmap bitmap, NaturalTonality.Plan plan) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;
        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int count = width * rows;
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int i = 0; i < count; i++) {
                int colour = pixels[i];
                int a = (colour >>> 24) & 0xff;
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                int luma = (54 * r + 183 * g + 19 * b) >> 8;
                int mapped = NaturalTonality.mapLuma(luma, plan);
                int delta = mapped - luma;
                if (delta == 0) continue;
                double protection = isLikelySkin(r, g, b) ? 0.72 : 1.0;
                int adjustedDelta = (int) Math.round(delta * protection);
                if (adjustedDelta == 0) continue;
                int nr = clamp(r + adjustedDelta);
                int ng = clamp(g + adjustedDelta);
                int nb = clamp(b + adjustedDelta);
                pixels[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
                affected++;
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static final class ToneMeasurement {
        final int p05;
        final int p50;
        final int p95;
        final double shadowFraction;
        final double highlightFraction;

        ToneMeasurement(int p05, int p50, int p95,
                        double shadowFraction, double highlightFraction) {
            this.p05 = p05;
            this.p50 = p50;
            this.p95 = p95;
            this.shadowFraction = shadowFraction;
            this.highlightFraction = highlightFraction;
        }
    }

    private static boolean isLikelyFoliage(int r, int g, int b) {
        return g >= r + 10 && g >= b + 7 && g >= 48;
    }

    private static boolean isLikelySkin(int r, int g, int b) {
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        return r > 70 && g > 40 && b > 25 && r > g && g >= b - 5
                && max - min >= 15 && r - g <= 90;
    }

    private static double clampDouble(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }

    private static final class NeutralMeasurement {
        final double evidenceFraction;
        final double r;
        final double g;
        final double b;
        NeutralMeasurement(double evidenceFraction, double r, double g, double b) {
            this.evidenceFraction = evidenceFraction;
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }

    private static final class GainPlan {
        final boolean active;
        final double rGain;
        final double gGain;
        final double bGain;
        GainPlan(boolean active, double rGain, double gGain, double bGain) {
            this.active = active;
            this.rGain = rGain;
            this.gGain = gGain;
            this.bGain = bGain;
        }
        static GainPlan none() { return new GainPlan(false, 1.0, 1.0, 1.0); }
    }

    private static int[] sampleAxis(int start, int endExclusive) {
        int last = Math.max(start, endExclusive - 1);
        int mid = start + Math.max(0, (last - start) / 2);
        return new int[]{start, mid, last};
    }

    private static long tameMaskedPixels(Bitmap bitmap, SceneMask mask) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;

        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int count = width * rows;
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int localY = 0; localY < rows; localY++) {
                int y = top + localY;
                int gy = Math.min(mask.rows - 1, y / mask.cellSize);
                for (int x = 0; x < width; x++) {
                    int gx = Math.min(mask.cols - 1, x / mask.cellSize);
                    byte type = mask.types[gy * mask.cols + gx];
                    if (type == MASK_NONE) continue;
                    int i = localY * width + x;
                    int colour = pixels[i];
                    if (!isStrongBlue(colour)) continue;

                    int a = (colour >>> 24) & 0xff;
                    int r = (colour >>> 16) & 0xff;
                    int g = (colour >>> 8) & 0xff;
                    int b = colour & 0xff;
                    int max = Math.max(r, Math.max(g, b));
                    int min = Math.min(r, Math.min(g, b));
                    int chroma = max - min;

                    double base = type == MASK_SKY ? 0.065 : 0.045;
                    double range = type == MASK_SKY ? 0.065 : 0.050;
                    double strength = base + Math.min(range,
                            Math.max(0, chroma - 45) / (type == MASK_SKY ? 720.0 : 900.0));
                    strength *= mask.edgeWeight(gx, gy, type);

                    int luma = (54 * r + 183 * g + 19 * b) >> 8;
                    r = clamp((int) Math.round(r + (luma - r) * strength));
                    g = clamp((int) Math.round(g + (luma - g) * strength));
                    b = clamp((int) Math.round(b + (luma - b) * strength));
                    pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
                    affected++;
                }
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static boolean isStrongBlue(int colour) {
        int r = (colour >>> 16) & 0xff;
        int g = (colour >>> 8) & 0xff;
        int b = colour & 0xff;
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        if (max - min < 45 || max < 72) return false;
        boolean blue = b >= r + 22 && b >= g + 4;
        boolean cyan = g >= r + 22 && b >= r + 22 && Math.abs(b - g) <= 62;
        return blue || cyan;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static final class SceneMask {
        final int cellSize;
        final int cols;
        final int rows;
        final byte[] types;
        final int skyCells;
        final int waterCells;
        final int maskedCells;

        SceneMask(int cellSize, int cols, int rows, byte[] types,
                  int skyCells, int waterCells) {
            this.cellSize = cellSize;
            this.cols = cols;
            this.rows = rows;
            this.types = types;
            this.skyCells = skyCells;
            this.waterCells = waterCells;
            this.maskedCells = skyCells + waterCells;
        }

        double skyPercent() {
            return skyCells * 100.0 / Math.max(1, cols * rows);
        }

        double waterPercent() {
            return waterCells * 100.0 / Math.max(1, cols * rows);
        }

        double edgeWeight(int gx, int gy, byte type) {
            int same = 0;
            int total = 0;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    int nx = gx + dx;
                    int ny = gy + dy;
                    if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;
                    total++;
                    if (types[ny * cols + nx] == type) same++;
                }
            }
            double neighbourhood = same / (double) Math.max(1, total);
            return 0.45 + 0.55 * neighbourhood;
        }
    }

    private static final class ExifSnapshot {
        private final Map<String, String> values;

        private ExifSnapshot(Map<String, String> values) {
            this.values = values;
        }

        static ExifSnapshot read(ContentResolver resolver, Uri uri) throws IOException {
            Map<String, String> values = new LinkedHashMap<>();
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "r")) {
                if (descriptor == null) throw new IOException("EXIF input unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (String tag : EXIF_TAGS) {
                    String value = exif.getAttribute(tag);
                    if (value != null) values.put(tag, value);
                }
            }
            return new ExifSnapshot(values);
        }

        void restore(ContentResolver resolver, Uri uri) throws IOException {
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "rw")) {
                if (descriptor == null) throw new IOException("EXIF output unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (Map.Entry<String, String> entry : values.entrySet()) {
                    exif.setAttribute(entry.getKey(), entry.getValue());
                }
                exif.saveAttributes();
            }
        }
    }
}
