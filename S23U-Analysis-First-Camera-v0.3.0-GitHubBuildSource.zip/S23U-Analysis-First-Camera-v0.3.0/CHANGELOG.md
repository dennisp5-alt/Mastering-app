# Changelog

## 0.3.0 — Calibrated Colour + Natural Tonality

- Keeps the v0.2.1 True Colour and Stability Guard baseline.
- Adds conservative persistent per-lens colour self-calibration for 0.6x, 1x, 3x and 10x.
- Calibration learns only from repeated stable, near-neutral, single-illuminant scenes classified as NO_CAST.
- Adds a restrained Natural Tone curve with smooth highlight shoulder and black-preserving shadow separation.
- Natural Tone strength is derived from measured image percentiles rather than a fixed filter.
- Skin receives reduced tonal strength and existing semantic colour protection remains active.
- Refines the interface into a cleaner graphite camera layout with rounded control cards and a stronger shutter hierarchy.
- Standard control remains untouched.

