# v0.3.0 test guide

Use matched Standard and Analysis First frames where possible. Prioritise: neutral/grey objects on each lens, blue sky plus real blue objects, faces in daylight/shade, bright white roofs/clouds, deep shadows, 3x portraits, and handheld 10x.

Watch the live Colour line for `lens cal uncalibrated-safe` changing gradually toward `learned N/10`. This should happen slowly; it is not a failure if calibration stays at zero when neutral evidence is weak.

Natural Tone should soften near-highlights and open deep shadow separation without grey blacks, flat HDR, colour shifts, waxy skin or halos. Standard must remain pixel-untouched.
