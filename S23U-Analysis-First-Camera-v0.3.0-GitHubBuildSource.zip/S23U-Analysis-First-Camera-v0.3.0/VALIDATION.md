# Validation notes — 0.3.0

This source keeps the proven v0.2.1 True Colour + Stability Guard capture baseline.

v0.3.0 adds two deliberately restrained imaging stages:

1. **Per-lens calibrated colour memory** for 0.6x, 1x, 3x and 10x. It learns only
   from repeated stable, near-neutral, single-illuminant scenes already classified
   as NO_CAST. Corrections are confidence-weighted, capped and remain exactly zero
   when evidence is weak.
2. **Natural Tonality** using measured full-resolution luminance percentiles to set
   a gentle black-preserving shadow separation and white-preserving highlight shoulder.

The interface is also reorganised into a cleaner graphite camera UI with rounded
control surfaces and a stronger shutter hierarchy. Standard mode remains untouched.

Host checks cover lens/stability guards, True Colour confidence gates, learned lens
profile weighting, Natural Tone endpoints/highlight behaviour, Smart routing and face
coordinate mapping. Physical S23 Ultra testing remains authoritative for colour match,
Samsung OIS behaviour and final image-quality decisions.
