# Analysis First Camera 0.3.0

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture, True Colour, per-lens calibration, Natural Tonality and handheld stability.

The calibrated colour engine does not assume that dominant scene colour is a cast. Lens calibration is learned slowly from trustworthy neutral evidence and remains zero when evidence is weak. Natural Tone uses a restrained measured highlight shoulder and shadow toe rather than aggressive HDR.

Standard mode remains an untouched comparison control.
