package com.s23u.procamera;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

final class CameraHardwareMap {
    static final class LensInfo {
        final String cameraId;
        final float focalLengthMm;
        final String lensClass;
        final float minimumFocusDiopters;

        LensInfo(String cameraId, float focalLengthMm, String lensClass,
                 float minimumFocusDiopters) {
            this.cameraId = cameraId;
            this.focalLengthMm = focalLengthMm;
            this.lensClass = lensClass;
            this.minimumFocusDiopters = minimumFocusDiopters;
        }
    }

    final String logicalCameraId;
    final Rect activeArray;
    final int sensorOrientation;
    final int faceDetectionMode;
    final int previewDistortionMode;
    final int captureDistortionMode;
    private final Map<String, LensInfo> physicalLenses;

    private CameraHardwareMap(String logicalCameraId, Rect activeArray,
                              int sensorOrientation, int faceDetectionMode,
                              int previewDistortionMode, int captureDistortionMode,
                              Map<String, LensInfo> physicalLenses) {
        this.logicalCameraId = logicalCameraId;
        this.activeArray = activeArray == null ? null : new Rect(activeArray);
        this.sensorOrientation = sensorOrientation;
        this.faceDetectionMode = faceDetectionMode;
        this.previewDistortionMode = previewDistortionMode;
        this.captureDistortionMode = captureDistortionMode;
        this.physicalLenses = physicalLenses;
    }

    static CameraHardwareMap discover(Context context) throws CameraAccessException {
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        if (manager == null) throw new CameraAccessException(CameraAccessException.CAMERA_ERROR);

        String selectedId = null;
        CameraCharacteristics selected = null;
        int selectedScore = Integer.MIN_VALUE;
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(id);
            Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
            if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
            Set<String> physicalIds = characteristics.getPhysicalCameraIds();
            int score = physicalIds.size() * 10;
            int[] capabilities = characteristics.get(
                    CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            if (contains(capabilities,
                    CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)) {
                score += 100;
            }
            if (score > selectedScore) {
                selectedScore = score;
                selectedId = id;
                selected = characteristics;
            }
        }
        if (selectedId == null || selected == null) {
            throw new CameraAccessException(CameraAccessException.CAMERA_DISCONNECTED);
        }

        Map<String, LensInfo> lenses = new LinkedHashMap<>();
        Set<String> physicalIds = selected.getPhysicalCameraIds();
        for (String physicalId : physicalIds) {
            try {
                CameraCharacteristics physical = manager.getCameraCharacteristics(physicalId);
                float focal = firstFocalLength(physical);
                Float minFocus = physical.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
                lenses.put(physicalId, new LensInfo(physicalId, focal,
                        LensClassifier.fromFocalLength(focal),
                        minFocus == null ? Float.NaN : minFocus));
            } catch (CameraAccessException | IllegalArgumentException ignored) {
                // Some Samsung firmware advertises a physical ID but restricts direct queries.
            }
        }

        int faceMode = 0;
        int[] faceModes = selected.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES);
        if (contains(faceModes, CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_FULL)) {
            faceMode = CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_FULL;
        } else if (contains(faceModes, CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_SIMPLE)) {
            faceMode = CameraCharacteristics.STATISTICS_FACE_DETECT_MODE_SIMPLE;
        }
        Rect active = selected.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        Integer orientation = selected.get(CameraCharacteristics.SENSOR_ORIENTATION);
        int[] distortionModes = selected.get(
                CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES);
        int captureDistortion = contains(distortionModes,
                CaptureRequest.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)
                ? CaptureRequest.DISTORTION_CORRECTION_MODE_HIGH_QUALITY
                : contains(distortionModes, CaptureRequest.DISTORTION_CORRECTION_MODE_FAST)
                ? CaptureRequest.DISTORTION_CORRECTION_MODE_FAST : -1;
        int previewDistortion = contains(distortionModes,
                CaptureRequest.DISTORTION_CORRECTION_MODE_FAST)
                ? CaptureRequest.DISTORTION_CORRECTION_MODE_FAST : captureDistortion;
        return new CameraHardwareMap(selectedId, active,
                orientation == null ? 90 : orientation, faceMode,
                previewDistortion, captureDistortion, lenses);
    }

    String physicalIdForZoom(float zoom) {
        String expected = LensClassifier.expectedForZoom(zoom);
        for (LensInfo lens : physicalLenses.values()) {
            if (expected.equals(lens.lensClass)) return lens.cameraId;
        }
        return null;
    }

    LensInfo lensForId(String cameraId) {
        return cameraId == null ? null : physicalLenses.get(cameraId);
    }

    int physicalLensCount() {
        return physicalLenses.size();
    }

    String lensInventory() {
        if (physicalLenses.isEmpty()) return "no public physical IDs";
        StringBuilder result = new StringBuilder();
        for (LensInfo lens : physicalLenses.values()) {
            if (result.length() > 0) result.append(" · ");
            result.append(lens.lensClass).append(' ')
                    .append(String.format(java.util.Locale.US, "%.2fmm", lens.focalLengthMm));
        }
        return result.toString();
    }

    String captureDistortionLabel() {
        if (captureDistortionMode == CaptureRequest.DISTORTION_CORRECTION_MODE_HIGH_QUALITY) {
            return "HIGH_QUALITY_REQUEST";
        }
        if (captureDistortionMode == CaptureRequest.DISTORTION_CORRECTION_MODE_FAST) {
            return "FAST_REQUEST";
        }
        return "FIRMWARE_DEFAULT";
    }

    private static float firstFocalLength(CameraCharacteristics characteristics) {
        float[] focalLengths = characteristics.get(
                CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        if (focalLengths == null || focalLengths.length == 0) return Float.NaN;
        return focalLengths[0];
    }

    private static boolean contains(int[] values, int wanted) {
        if (values == null) return false;
        for (int value : values) if (value == wanted) return true;
        return false;
    }
}
