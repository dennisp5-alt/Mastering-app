package com.s23u.procamera;

import java.util.Locale;

/** Confidence-gated colour decision; never infers a cast from scene colour alone. */
final class TrueColourDecision {
    enum Action { NO_EVIDENCE, NO_CAST, PRESERVE_MIXED_LIGHT, WITHHOLD, CORRECT }

    final Action action;
    final String castName;
    final double evidenceConfidence;
    final double castConfidence;
    final double maxGainDelta;
    final String lensProfile;

    private TrueColourDecision(Action action, String castName, double evidenceConfidence,
                               double castConfidence, double maxGainDelta, String lensProfile) {
        this.action = action;
        this.castName = castName;
        this.evidenceConfidence = evidenceConfidence;
        this.castConfidence = castConfidence;
        this.maxGainDelta = maxGainDelta;
        this.lensProfile = lensProfile;
    }

    static TrueColourDecision decide(ColourStats stats, String expectedLens, boolean faceDetected) {
        LensColourProfile profile = LensColourProfile.forLens(expectedLens);
        if (stats == null || !stats.isFresh() || stats.evidenceConfidence < 0.30) {
            return new TrueColourDecision(Action.NO_EVIDENCE, "undecided",
                    stats == null ? 0.0 : stats.evidenceConfidence,
                    stats == null ? 0.0 : stats.castConfidence, 0.0, profile.lens);
        }
        double u = stats.neutralU - 128.0 - profile.uBias;
        double v = stats.neutralV - 128.0 - profile.vBias;
        double strength = Math.hypot(u, v);
        String cast = castName(u, v);
        if (stats.mixedLightScore >= 0.58) {
            return new TrueColourDecision(Action.PRESERVE_MIXED_LIGHT, cast,
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile.lens);
        }
        if (strength < 3.6) {
            return new TrueColourDecision(Action.NO_CAST, "none",
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile.lens);
        }
        if (stats.castConfidence < 0.42 || stats.stabilityScore < 0.45) {
            return new TrueColourDecision(Action.WITHHOLD, cast,
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile.lens);
        }
        double cap = profile.maxCorrection;
        if (faceDetected || stats.skinFraction > 0.05) cap = Math.min(cap, 0.014);
        double confidenceScale = Math.min(1.0, Math.max(0.0,
                (stats.castConfidence - 0.42) / 0.40));
        cap *= 0.55 + 0.45 * confidenceScale;
        return new TrueColourDecision(Action.CORRECT, cast,
                stats.evidenceConfidence, stats.castConfidence, cap, profile.lens);
    }

    boolean correctionAllowed() {
        return action == Action.CORRECT && maxGainDelta > 0.0;
    }

    String shortLabel() {
        switch (action) {
            case NO_CAST: return "no cast";
            case PRESERVE_MIXED_LIGHT: return "mixed light preserved";
            case WITHHOLD: return "cast withheld";
            case CORRECT: return "correct " + castName;
            default: return "colour undecided";
        }
    }

    String diagnostic() {
        return String.format(Locale.US, "%s · evidence %.0f%% · cast %.0f%% · lens %s",
                shortLabel(), evidenceConfidence * 100.0, castConfidence * 100.0, lensProfile);
    }

    private static String castName(double u, double v) {
        if (Math.abs(u) >= Math.abs(v)) return u > 0 ? "cool/blue" : "warm/yellow";
        return v > 0 ? "red/magenta" : "green/cyan";
    }
}
