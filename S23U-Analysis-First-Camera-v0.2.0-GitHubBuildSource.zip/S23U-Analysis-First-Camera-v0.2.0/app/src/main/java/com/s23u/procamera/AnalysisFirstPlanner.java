package com.s23u.procamera;

import java.util.Locale;

/**
 * Converts live preview measurements into a capture plan before the shutter fires.
 * The planner never changes pixels. It only chooses capture route, exposure bias,
 * and whether the metering system deserves a short settling delay.
 */
final class AnalysisFirstPlanner {
    static final class Plan {
        final SmartAutoEngine.Decision decision;
        final float exposureEv;
        final boolean waitForSettling;
        final String protection;
        final String reason;
        final TrueColourDecision colourDecision;

        Plan(SmartAutoEngine.Decision decision, float exposureEv,
             boolean waitForSettling, String protection, String reason,
             TrueColourDecision colourDecision) {
            this.decision = decision;
            this.exposureEv = exposureEv;
            this.waitForSettling = waitForSettling;
            this.protection = protection;
            this.reason = reason;
            this.colourDecision = colourDecision;
        }

        String liveLabel() {
            String ev = Math.abs(exposureEv) < 0.05f ? "EV 0.0"
                    : String.format(Locale.US, "EV %+.1f", exposureEv);
            return decision.route.name() + " · " + ev + " · " + protection
                    + " · " + reason + " · colour " + colourDecision.shortLabel();
        }
    }

    private AnalysisFirstPlanner() { }

    static Plan plan(SceneStats scene, ColourStats colour, LiveCameraState live,
                     boolean hdrAvailable, boolean nightAvailable,
                     float requestedZoom, boolean flashForced) {
        boolean faceDetected = live != null && live.isFresh() && live.faceCount > 0;
        int iso = live != null && live.isFresh() ? live.iso : -1;
        long exposureNs = live != null && live.isFresh() ? live.exposureNs : -1L;

        SmartAutoEngine.Decision decision = SmartAutoEngine.decide(scene, iso, exposureNs,
                faceDetected, hdrAvailable, nightAvailable, requestedZoom, flashForced);
        String expectedLens = LensClassifier.expectedForZoom(requestedZoom);
        TrueColourDecision colourDecision = TrueColourDecision.decide(
                colour, expectedLens, faceDetected);

        boolean analysisFresh = scene != null && scene.valid;
        boolean liveFresh = live != null && live.isFresh();
        boolean colourNeedsSettle = colour != null && colour.isFresh()
                && colour.enoughNeutralEvidence()
                && colour.stabilityScore < 0.48;
        boolean settling = !analysisFresh || !liveFresh
                || !scene.meteringStable() || colourNeedsSettle
                || (live != null && (live.aeBusy() || live.focusBusy()));

        float ev = 0.0f;
        String protection = "natural exposure";
        String reason = decision.reason;

        if (analysisFresh && decision.route == SmartAutoEngine.Route.STANDARD
                && !flashForced) {
            boolean moonLike = scene.shadowFraction >= 0.55
                    && scene.tonalRange() >= 150
                    && scene.p95 >= 185
                    && scene.highlightFraction < 0.08;
            boolean severeHighlights = scene.highlightFraction >= 0.065 || scene.p95 >= 250;
            boolean brightHighlights = scene.highlightFraction >= 0.022 || scene.p95 >= 244;
            boolean openShadows = scene.meanLuma < 58.0 && scene.p95 < 205
                    && scene.highlightFraction < 0.006;

            if (moonLike) {
                ev = -0.7f;
                protection = "isolated bright subject";
                reason = "dark-field highlight protection";
            } else if (severeHighlights && !faceDetected) {
                ev = -0.7f;
                protection = "strong highlight guard";
                reason = "protect bright detail before capture";
            } else if (brightHighlights && !faceDetected) {
                ev = -0.3f;
                protection = "highlight guard";
                reason = "retain highlight headroom";
            } else if (openShadows && iso > 0 && iso < 640 && exposureNs > 0
                    && exposureNs < 30_000_000L) {
                ev = 0.3f;
                protection = "gentle shadow lift";
                reason = "clean sensor headroom available";
            }
        }

        if (decision.route != SmartAutoEngine.Route.STANDARD) {
            ev = 0.0f;
            protection = decision.route == SmartAutoEngine.Route.HDR
                    ? "Samsung HDR capture" : "Samsung Night capture";
        }

        if (faceDetected && decision.route == SmartAutoEngine.Route.STANDARD) {
            protection = "face AE priority";
            if (ev < 0.0f) ev = Math.max(ev, -0.3f);
        }

        return new Plan(decision, ev, settling, protection, reason, colourDecision);
    }
}
