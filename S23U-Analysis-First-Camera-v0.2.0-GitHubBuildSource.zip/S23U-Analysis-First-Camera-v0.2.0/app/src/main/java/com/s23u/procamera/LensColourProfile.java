package com.s23u.procamera;

/**
 * Per-lens colour calibration hook. Biases are deliberately zero until matched
 * real-world S23U samples justify a correction. The hook lets 0.6x/1x/3x/10x
 * be calibrated independently without changing the decision engine later.
 */
final class LensColourProfile {
    final String lens;
    final double uBias;
    final double vBias;
    final double maxCorrection;

    private LensColourProfile(String lens, double uBias, double vBias, double maxCorrection) {
        this.lens = lens;
        this.uBias = uBias;
        this.vBias = vBias;
        this.maxCorrection = maxCorrection;
    }

    static LensColourProfile forLens(String lens) {
        if ("ULTRA_WIDE".equals(lens)) return new LensColourProfile(lens, 0.0, 0.0, 0.020);
        if ("TELE_3X".equals(lens)) return new LensColourProfile(lens, 0.0, 0.0, 0.018);
        if ("TELE_10X".equals(lens)) return new LensColourProfile(lens, 0.0, 0.0, 0.015);
        return new LensColourProfile("MAIN_1X", 0.0, 0.0, 0.022);
    }
}
