# Analysis First Camera 0.2.0 — True Colour Intelligence

Offline Samsung Galaxy S23 Ultra camera experiment. Standard remains an untouched
comparison path. Analysis First now measures exposure and colour evidence before
the shutter fires, then applies only confidence-supported finishing.

## New in 0.2.0

- Live YUV colour analysis from the preview: neutral evidence, cast strength,
  mixed-light score, sky, foliage and skin-like coverage.
- Separate outcomes for no cast, insufficient evidence, mixed light preserved,
  suspected cast withheld and real cast correction.
- Confidence-gated neutral correction. Whole-frame scene colour is never used as
  proof of a white-balance error.
- Semantic sky/water blue restraint from 0.1.1 remains, while cartons, tarps,
  clothing, signs and other object blues stay protected.
- Skin protection reduces correction strength over skin-like pixels.
- Per-lens colour calibration hooks for 0.6x, 1x, 3x and 10x. Biases remain zero
  until real matched test shots justify calibration.
- True Colour is ON by default in Analysis First and can be switched back to the
  original JPEG path. Standard never enters this pixel-processing path.
- Existing optical guard, orientation, 3x/10x validation, HDR/Night routing,
  face AE and exposure planning are retained.

This does not reproduce OPPO's dedicated multispectral hardware sensor. It uses
S23 Ultra preview YUV data and conservative software inference.
