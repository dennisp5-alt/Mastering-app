# Recovery baseline

Analysis First Camera 0.1.0 is intentionally forked from the known-working S23U
Pro Camera Test v1.0.5 capture baseline. If the new planner causes a regression,
compare against Standard control first. The inherited optical guard, lens routing,
orientation handling and maximum-quality CameraX JPEG path should remain unchanged.
