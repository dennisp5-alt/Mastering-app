# Changelog

## 0.2.0 — True Colour Intelligence
- Added pre-capture neutral-reference colour analysis from YUV preview frames.
- Added mixed-light detection and preserve-mixed-light guard.
- Added sky, foliage and skin-like semantic colour evidence.
- Added separate evidence confidence, cast strength and cast confidence.
- Added bounded neutral WB correction only when stable evidence supports it.
- Retained the 0.1.1 sky/water-only blue restraint and genuine-blue protection.
- Added skin/saturated-object protection during bounded colour correction.
- Added zero-bias per-lens calibration hooks for later matched 0.6x/1x/3x/10x tuning.
- True Colour defaults ON in Analysis First; Standard remains unchanged.
- versionCode 3 / versionName 0.2.0.
