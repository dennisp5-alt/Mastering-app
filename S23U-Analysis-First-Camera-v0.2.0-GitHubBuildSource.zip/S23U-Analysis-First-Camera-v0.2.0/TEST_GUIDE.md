# Analysis First Camera 0.2.0 — True Colour test

Use matched pairs from the same position: Standard first, then Analysis First
with True Colour ON. Let the live colour readout settle before pressing ANALYSE + SNAP.

Priority scenes:
1. Blue carton with no sky — object blue should remain essentially unchanged.
2. Blue sky + blue tarp — sky may be restrained; tarp should stay close to Standard.
3. White/grey object in open shade — neutral evidence should rise; only a real stable cast may correct.
4. Warm indoor light — warm ambience should not automatically be neutralised.
5. Mixed window daylight + warm room light — report mixed light preserved; no global WB correction.
6. Face in shade / face against sky — skin protection should prevent obvious colour shifts.
7. Same subject at 1x, 3x and 10x — note colour readout; calibration hooks are present but zero-bias in this build.

Useful live fields: neutral %, evidence %, mixed %, sky %, foliage %, skin %, colour settle %.
After capture, the result panel reports the colour decision and whether a Q100
True Colour finish was actually needed. A bypass on a healthy image is a pass.
