# Analysis First Camera 0.1.1 — blue-mask test

The priority for this build is to confirm that the optional Scene Blue finish can
change excessive sky/cyan without changing legitimate blue objects.

## Matched tests

For each scene, hold framing as closely as possible and capture:

1. Standard control.
2. Analysis First with Original JPEG.
3. Analysis First with Scene blue ON.

Recommended scenes:

- Blue sky plus a blue tarp, carton, clothing or sign in the same frame.
- Blue sky with foliage and fine branches.
- Plain blue object with no sky: Scene blue should normally bypass.
- Water with a blue object nearby.
- Neutral indoor scene with no strong blue.

A good result keeps the object blue almost unchanged while applying only a mild
restraint to an excessive cyan/electric sky or a broad water field. The saved
report should mention `scene-mask blue restraint` when applied, or
`no sky/water blue field detected · object blues protected` when bypassed.

The existing 1x/3x/10x optical, orientation, exposure-planning and HDR/Night tests
remain valid from v0.1.0.
