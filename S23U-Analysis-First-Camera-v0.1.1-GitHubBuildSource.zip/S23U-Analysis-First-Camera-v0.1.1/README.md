# Analysis First Camera 0.1.1 — S23 Ultra experiment

Standalone offline camera experiment for Galaxy S23 Ultra (`SM-S918*`).

The main mode analyses the live preview before each capture, builds a capture plan,
then snaps. It is intentionally capture-first rather than filter-first.

## Analysis First pipeline

1. Live 4:3 preview analysis measures luminance distribution, shadows, highlights,
   tonal range and short-term metering stability.
2. Camera2 metadata supplies ISO, shutter, active physical lens, AF/AE state and
   firmware face detection when available.
3. The planner chooses Standard, Samsung HDR or Samsung Night at 1x when justified.
4. On Standard captures it can apply a bounded exposure bias before capture:
   highlight protection, dark-field/bright-subject protection, or a small clean
   shadow lift when sensor headroom is available.
5. The app waits briefly for preview/AE/AF settling when needed, then captures a
   JPEG quality 100 image.
6. Planned EV and protection decisions are written into EXIF diagnostics.

## v0.1.1 scene-aware blue finish

The optional blue finish no longer edits blue/cyan pixels globally. It first builds
a coarse spatial mask and only allows restraint inside large, smooth, plausible
sky or water blue fields. Small or object-like blue regions are protected by
default, including tarps, cartons, clothing, signs and vehicles. Edge cells are
softened and the maximum chroma reduction remains deliberately mild.

If the app cannot establish a plausible sky/water region, the JPEG is left alone
and the capture report states that object blues were protected. The Standard
control path remains completely untouched.

## Controls retained from the working v1.0.5 camera baseline

- 0.6x / 1x / 3x / 10x requests.
- Full-size optical guard on non-1x lenses when Samsung exposes the physical lens.
- Lens/focal length/ISO/shutter diagnostics.
- Tap focus and AE-only face metering.
- Samsung HDR/Night extension routing with Standard fallback.
- Distortion-correction request where supported.
- Landscape/portrait session rebuild handling.
- Standard control mode for matched A/B comparisons.

## Important limits

The sky/water mask is a conservative local scene classifier, not a neural semantic
segmentation network. It is deliberately biased toward false negatives rather than
changing legitimate blue objects. Samsung's full proprietary computational camera
pipeline is also not accessible to third-party apps.

No Internet, location or microphone permission is requested. New JPEGs are saved
to `DCIM/Analysis First Camera`.
