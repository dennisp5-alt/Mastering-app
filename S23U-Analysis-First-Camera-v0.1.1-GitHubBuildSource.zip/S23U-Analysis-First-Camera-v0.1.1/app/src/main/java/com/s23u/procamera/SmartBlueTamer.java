package com.s23u.procamera;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Optional Analysis-First blue/cyan restraint.
 *
 * v0.1.1 no longer edits every blue pixel in the image. It first finds large,
 * smooth, spatially plausible sky/water blue fields on a coarse scene grid and
 * limits chroma restraint to those fields. Genuine object blues (cartons,
 * tarps, clothing, signs, cars, etc.) are therefore protected by default.
 */
final class SmartBlueTamer {
    static final class Result {
        final boolean applied;
        final double affectedPercent;
        final String detail;

        Result(boolean applied, double affectedPercent, String detail) {
            this.applied = applied;
            this.affectedPercent = affectedPercent;
            this.detail = detail;
        }

        static Result skipped(String detail) {
            return new Result(false, 0.0, detail);
        }
    }

    private static final byte MASK_NONE = 0;
    private static final byte MASK_SKY = 1;
    private static final byte MASK_WATER = 2;

    private static final String[] EXIF_TAGS = {
            ExifInterface.TAG_APERTURE_VALUE,
            ExifInterface.TAG_COLOR_SPACE,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_FLASH,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
            ExifInterface.TAG_IMAGE_DESCRIPTION,
            ExifInterface.TAG_IMAGE_UNIQUE_ID,
            ExifInterface.TAG_ISO_SPEED_RATINGS,
            ExifInterface.TAG_LIGHT_SOURCE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MAX_APERTURE_VALUE,
            ExifInterface.TAG_METERING_MODE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.TAG_SOFTWARE,
            ExifInterface.TAG_SUBSEC_TIME,
            ExifInterface.TAG_SUBSEC_TIME_DIGITIZED,
            ExifInterface.TAG_SUBSEC_TIME_ORIGINAL,
            ExifInterface.TAG_USER_COMMENT,
            ExifInterface.TAG_WHITE_BALANCE
    };

    private SmartBlueTamer() { }

    static Result apply(ContentResolver resolver, Uri uri, File cacheDir) throws IOException {
        ExifSnapshot exif = ExifSnapshot.read(resolver, uri);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inMutable = true;

        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) return Result.skipped("image unavailable");
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) return Result.skipped("decode failed");

        long pixels = (long) bitmap.getWidth() * bitmap.getHeight();
        if (pixels > 20_000_000L) {
            bitmap.recycle();
            return Result.skipped("above 20 MP safety limit");
        }

        SceneMask mask = buildSceneMask(bitmap);
        if (mask.maskedCells == 0) {
            bitmap.recycle();
            return Result.skipped("no sky/water blue field detected · object blues protected");
        }

        long affected = tameMaskedPixels(bitmap, mask);
        if (affected == 0L) {
            bitmap.recycle();
            return Result.skipped("scene blue mask found but no excessive blue pixels required restraint");
        }

        File temporary = File.createTempFile("s23u-scene-blue-", ".jpg", cacheDir);
        try {
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)) {
                    throw new IOException("Q100 JPEG encode failed");
                }
            } finally {
                bitmap.recycle();
            }

            try (InputStream input = new FileInputStream(temporary);
                 OutputStream output = resolver.openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("output stream unavailable");
                byte[] buffer = new byte[128 * 1024];
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    output.write(buffer, 0, read);
                }
                output.flush();
            }
            exif.restore(resolver, uri);
        } finally {
            if (!temporary.delete()) temporary.deleteOnExit();
        }

        double affectedPercent = affected * 100.0 / Math.max(1L, pixels);
        return new Result(true, affectedPercent,
                String.format(java.util.Locale.US,
                        "scene-mask blue restraint · sky %.1f%% / water %.1f%% grid · corrected %.2f%% pixels · object blues protected",
                        mask.skyPercent(), mask.waterPercent(), affectedPercent));
    }

    private static SceneMask buildSceneMask(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int cell = Math.max(12, Math.min(32, Math.min(width, height) / 120));
        int cols = (width + cell - 1) / cell;
        int rows = (height + cell - 1) / cell;
        int count = cols * rows;

        boolean[] candidate = new boolean[count];
        double[] blueFraction = new double[count];
        double[] texture = new double[count];

        for (int gy = 0; gy < rows; gy++) {
            int y0 = gy * cell;
            int y1 = Math.min(height, y0 + cell);
            int[] ys = sampleAxis(y0, y1);
            for (int gx = 0; gx < cols; gx++) {
                int x0 = gx * cell;
                int x1 = Math.min(width, x0 + cell);
                int[] xs = sampleAxis(x0, x1);
                int blue = 0;
                int samples = 0;
                int lumaMin = 255;
                int lumaMax = 0;
                long lumaSum = 0L;
                for (int y : ys) {
                    for (int x : xs) {
                        int colour = bitmap.getPixel(x, y);
                        if (isStrongBlue(colour)) blue++;
                        int r = (colour >>> 16) & 0xff;
                        int g = (colour >>> 8) & 0xff;
                        int b = colour & 0xff;
                        int luma = (54 * r + 183 * g + 19 * b) >> 8;
                        lumaMin = Math.min(lumaMin, luma);
                        lumaMax = Math.max(lumaMax, luma);
                        lumaSum += luma;
                        samples++;
                    }
                }
                int index = gy * cols + gx;
                double fraction = blue / (double) Math.max(1, samples);
                double meanLuma = lumaSum / (double) Math.max(1, samples);
                double localTexture = lumaMax - lumaMin;
                blueFraction[index] = fraction;
                texture[index] = localTexture;
                candidate[index] = fraction >= 0.55 && meanLuma >= 55.0
                        && localTexture <= 85.0;
            }
        }

        byte[] types = new byte[count];
        boolean[] visited = new boolean[count];
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        List<Integer> component = new ArrayList<>();
        int skyCells = 0;
        int waterCells = 0;

        for (int start = 0; start < count; start++) {
            if (!candidate[start] || visited[start]) continue;
            queue.clear();
            component.clear();
            queue.add(start);
            visited[start] = true;

            int minX = cols;
            int maxX = -1;
            int minY = rows;
            int maxY = -1;
            long sumX = 0L;
            long sumY = 0L;
            double sumTexture = 0.0;
            double sumBlue = 0.0;

            while (!queue.isEmpty()) {
                int index = queue.removeFirst();
                component.add(index);
                int y = index / cols;
                int x = index - y * cols;
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
                sumX += x;
                sumY += y;
                sumTexture += texture[index];
                sumBlue += blueFraction[index];

                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        int nx = x + dx;
                        int ny = y + dy;
                        if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;
                        int next = ny * cols + nx;
                        if (!candidate[next] || visited[next]) continue;
                        visited[next] = true;
                        queue.addLast(next);
                    }
                }
            }

            int size = component.size();
            double centroidY = (sumY / (double) Math.max(1, size)) / Math.max(1, rows);
            double spanWidth = (maxX - minX + 1) / (double) Math.max(1, cols);
            double spanHeight = (maxY - minY + 1) / (double) Math.max(1, rows);
            double meanTexture = sumTexture / Math.max(1, size);
            double meanBlue = sumBlue / Math.max(1, size);
            boolean touchesTop = minY == 0;
            boolean touchesLeft = minX == 0;
            boolean touchesRight = maxX == cols - 1;

            int minSkySize = Math.max(4, (int) Math.ceil(count * 0.006));
            boolean sky = size >= minSkySize
                    && centroidY < 0.42
                    && (touchesTop || ((touchesLeft || touchesRight)
                    && minY / (double) Math.max(1, rows) < 0.30
                    && spanWidth > 0.08));

            int minWaterSize = Math.max(6, (int) Math.ceil(count * 0.012));
            boolean water = !sky
                    && size >= minWaterSize
                    && centroidY > 0.38
                    && spanWidth >= 0.35
                    && spanHeight <= 0.42
                    && meanTexture < 28.0
                    && meanBlue >= 0.62
                    && !touchesTop;

            byte type = sky ? MASK_SKY : (water ? MASK_WATER : MASK_NONE);
            if (type == MASK_NONE) continue;
            for (int index : component) types[index] = type;
            if (type == MASK_SKY) skyCells += size;
            else waterCells += size;
        }

        return new SceneMask(cell, cols, rows, types, skyCells, waterCells);
    }

    private static int[] sampleAxis(int start, int endExclusive) {
        int last = Math.max(start, endExclusive - 1);
        int mid = start + Math.max(0, (last - start) / 2);
        return new int[]{start, mid, last};
    }

    private static long tameMaskedPixels(Bitmap bitmap, SceneMask mask) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;

        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int count = width * rows;
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int localY = 0; localY < rows; localY++) {
                int y = top + localY;
                int gy = Math.min(mask.rows - 1, y / mask.cellSize);
                for (int x = 0; x < width; x++) {
                    int gx = Math.min(mask.cols - 1, x / mask.cellSize);
                    byte type = mask.types[gy * mask.cols + gx];
                    if (type == MASK_NONE) continue;
                    int i = localY * width + x;
                    int colour = pixels[i];
                    if (!isStrongBlue(colour)) continue;

                    int a = (colour >>> 24) & 0xff;
                    int r = (colour >>> 16) & 0xff;
                    int g = (colour >>> 8) & 0xff;
                    int b = colour & 0xff;
                    int max = Math.max(r, Math.max(g, b));
                    int min = Math.min(r, Math.min(g, b));
                    int chroma = max - min;

                    double base = type == MASK_SKY ? 0.065 : 0.045;
                    double range = type == MASK_SKY ? 0.065 : 0.050;
                    double strength = base + Math.min(range,
                            Math.max(0, chroma - 45) / (type == MASK_SKY ? 720.0 : 900.0));
                    strength *= mask.edgeWeight(gx, gy, type);

                    int luma = (54 * r + 183 * g + 19 * b) >> 8;
                    r = clamp((int) Math.round(r + (luma - r) * strength));
                    g = clamp((int) Math.round(g + (luma - g) * strength));
                    b = clamp((int) Math.round(b + (luma - b) * strength));
                    pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
                    affected++;
                }
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static boolean isStrongBlue(int colour) {
        int r = (colour >>> 16) & 0xff;
        int g = (colour >>> 8) & 0xff;
        int b = colour & 0xff;
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        if (max - min < 45 || max < 72) return false;
        boolean blue = b >= r + 22 && b >= g + 4;
        boolean cyan = g >= r + 22 && b >= r + 22 && Math.abs(b - g) <= 62;
        return blue || cyan;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static final class SceneMask {
        final int cellSize;
        final int cols;
        final int rows;
        final byte[] types;
        final int skyCells;
        final int waterCells;
        final int maskedCells;

        SceneMask(int cellSize, int cols, int rows, byte[] types,
                  int skyCells, int waterCells) {
            this.cellSize = cellSize;
            this.cols = cols;
            this.rows = rows;
            this.types = types;
            this.skyCells = skyCells;
            this.waterCells = waterCells;
            this.maskedCells = skyCells + waterCells;
        }

        double skyPercent() {
            return skyCells * 100.0 / Math.max(1, cols * rows);
        }

        double waterPercent() {
            return waterCells * 100.0 / Math.max(1, cols * rows);
        }

        double edgeWeight(int gx, int gy, byte type) {
            int same = 0;
            int total = 0;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    int nx = gx + dx;
                    int ny = gy + dy;
                    if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;
                    total++;
                    if (types[ny * cols + nx] == type) same++;
                }
            }
            double neighbourhood = same / (double) Math.max(1, total);
            return 0.45 + 0.55 * neighbourhood;
        }
    }

    private static final class ExifSnapshot {
        private final Map<String, String> values;

        private ExifSnapshot(Map<String, String> values) {
            this.values = values;
        }

        static ExifSnapshot read(ContentResolver resolver, Uri uri) throws IOException {
            Map<String, String> values = new LinkedHashMap<>();
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "r")) {
                if (descriptor == null) throw new IOException("EXIF input unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (String tag : EXIF_TAGS) {
                    String value = exif.getAttribute(tag);
                    if (value != null) values.put(tag, value);
                }
            }
            return new ExifSnapshot(values);
        }

        void restore(ContentResolver resolver, Uri uri) throws IOException {
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "rw")) {
                if (descriptor == null) throw new IOException("EXIF output unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (Map.Entry<String, String> entry : values.entrySet()) {
                    exif.setAttribute(entry.getKey(), entry.getValue());
                }
                exif.saveAttributes();
            }
        }
    }
}
