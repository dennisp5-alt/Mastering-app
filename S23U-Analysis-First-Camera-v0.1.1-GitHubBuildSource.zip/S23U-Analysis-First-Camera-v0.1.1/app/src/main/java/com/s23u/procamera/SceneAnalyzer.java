package com.s23u.procamera;

import android.os.SystemClock;

import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import java.nio.ByteBuffer;

final class SceneAnalyzer implements ImageAnalysis.Analyzer {
    interface Listener {
        void onSceneStats(SceneStats stats);
    }

    private final Listener listener;
    private volatile SceneStats latest = SceneStats.UNAVAILABLE;
    private double previousMean = Double.NaN;
    private int previousP50 = -1;
    private int previousP95 = -1;

    SceneAnalyzer(Listener listener) {
        this.listener = listener;
    }

    SceneStats latest() {
        SceneStats value = latest;
        if (!value.valid || SystemClock.elapsedRealtime() - value.timestampMs > 1800L) {
            return SceneStats.UNAVAILABLE;
        }
        return value;
    }

    @Override
    public void analyze(ImageProxy image) {
        try {
            ImageProxy.PlaneProxy[] planes = image.getPlanes();
            if (planes.length == 0) return;
            ImageProxy.PlaneProxy yPlane = planes[0];
            ByteBuffer buffer = yPlane.getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();
            int rowStride = yPlane.getRowStride();
            int pixelStride = yPlane.getPixelStride();
            int stepX = Math.max(4, width / 120);
            int stepY = Math.max(4, height / 90);
            int[] histogram = new int[256];
            long sum = 0L;
            int count = 0;
            int shadows = 0;
            int highlights = 0;

            for (int y = stepY / 2; y < height; y += stepY) {
                int row = y * rowStride;
                for (int x = stepX / 2; x < width; x += stepX) {
                    int index = row + x * pixelStride;
                    if (index < 0 || index >= buffer.limit()) continue;
                    int value = buffer.get(index) & 0xff;
                    histogram[value]++;
                    sum += value;
                    count++;
                    if (value <= 32) shadows++;
                    if (value >= 235) highlights++;
                }
            }

            if (count < 100) return;
            double mean = sum / (double) count;
            int p05 = percentile(histogram, count, 0.05);
            int p50 = percentile(histogram, count, 0.50);
            int p95 = percentile(histogram, count, 0.95);
            double stability = stability(mean, p50, p95);
            previousMean = mean;
            previousP50 = p50;
            previousP95 = p95;

            SceneStats stats = new SceneStats(true, mean, p05, p50, p95,
                    shadows / (double) count,
                    highlights / (double) count,
                    stability,
                    SystemClock.elapsedRealtime());
            latest = stats;
            if (listener != null) listener.onSceneStats(stats);
        } finally {
            image.close();
        }
    }

    private double stability(double mean, int p50, int p95) {
        if (!Double.isFinite(previousMean) || previousP50 < 0 || previousP95 < 0) {
            return 0.0;
        }
        double meanDelta = Math.abs(mean - previousMean) / 18.0;
        double midDelta = Math.abs(p50 - previousP50) / 18.0;
        double highDelta = Math.abs(p95 - previousP95) / 24.0;
        double instability = Math.min(1.0, 0.45 * meanDelta + 0.35 * midDelta
                + 0.20 * highDelta);
        return Math.max(0.0, 1.0 - instability);
    }

    private static int percentile(int[] histogram, int count, double fraction) {
        int target = Math.max(1, (int) Math.ceil(count * fraction));
        int running = 0;
        for (int i = 0; i < histogram.length; i++) {
            running += histogram[i];
            if (running >= target) return i;
        }
        return 255;
    }
}
