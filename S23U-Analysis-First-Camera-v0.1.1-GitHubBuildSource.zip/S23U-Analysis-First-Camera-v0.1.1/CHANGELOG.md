# Changelog

## 0.1.1 — scene-aware blue protection

- Replaced global blue/cyan pixel restraint with a spatial scene mask.
- Sky candidates must form large smooth blue fields in plausible upper-image geometry.
- Water candidates must form large, horizontally coherent, low-texture blue fields.
- Genuine object blues are protected by default.
- Added edge softening so masked corrections do not form hard block boundaries.
- Reduced maximum blue restraint slightly while keeping the useful sky correction.
- Capture report now states sky/water mask coverage and corrected-pixel percentage.
- Standard control mode and all Analysis-First capture planning remain unchanged.
- VersionCode 2 / versionName 0.1.1 for in-place update over v0.1.0.

## 0.1.0 — Analysis First Camera

- Forked from the proven S23U Pro Camera Test v1.0.5 capture baseline.
- New standalone package `com.dennis.analysisfirstcamera`.
- Added pre-capture Analysis First planner.
- Added short-term preview/metering stability score.
- Added AE-state tracking alongside AF/ISO/shutter/lens metadata.
- Added bounded pre-capture exposure compensation for highlight protection,
  dark-field bright-subject protection and limited clean shadow lift.
- Retained conservative 1x HDR/Night routing through Samsung Camera Extensions.
- Added brief settle-before-snap loop (maximum ~640 ms) when preview/AF/AE is moving.
- Added live capture-plan display and EXIF plan diagnostics.
- Retained the untouched Standard control path for A/B comparison.
