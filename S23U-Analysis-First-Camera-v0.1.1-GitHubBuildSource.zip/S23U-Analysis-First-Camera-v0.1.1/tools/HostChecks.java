package com.s23u.procamera;

public final class HostChecks {
    public static void main(String[] args) {
        require(DeviceGate.isGalaxyS23Ultra("samsung", "SM-S918B"), "S918B accepted");
        require(DeviceGate.isGalaxyS23Ultra("Samsung", "SM-S918U1"), "S918U1 accepted");
        require(!DeviceGate.isGalaxyS23Ultra("samsung", "SM-A546E"), "A54 rejected");
        require(!DeviceGate.isGalaxyS23Ultra("google", "Pixel 8 Pro"), "Pixel rejected");

        require("ULTRA_WIDE".equals(LensClassifier.fromFocalLength(2.2)), "UW lens");
        require("MAIN_1X".equals(LensClassifier.fromFocalLength(6.3)), "main lens");
        require("TELE_3X".equals(LensClassifier.fromFocalLength(7.9)), "3x lens");
        require("TELE_10X".equals(LensClassifier.fromFocalLength(27.2)), "10x lens");
        require("UNKNOWN".equals(LensClassifier.fromFocalLength(Double.NaN)), "unknown lens");

        require("ULTRA_WIDE".equals(LensClassifier.expectedForZoom(0.6f)), "0.6x request");
        require("MAIN_1X".equals(LensClassifier.expectedForZoom(1.0f)), "1x request");
        require("TELE_3X".equals(LensClassifier.expectedForZoom(3.0f)), "3x request");
        require("TELE_10X".equals(LensClassifier.expectedForZoom(10.0f)), "10x request");

        require(!ZoomRouting.shouldGuardOpticalLens(
                true, true, 1.0f, "main"), "Smart 1x needs no optical guard");
        require(ZoomRouting.shouldGuardOpticalLens(
                true, true, 3.0f, "tele3"), "Smart 3x can guard the physical tele lens");
        require(close(ZoomRouting.cameraZoomRatio(3.0f), 3.0f),
                "locked 3x retains the full-size logical 3.0 ratio");
        require(OutputResolution.isFullSize(4080, 3060), "landscape full-size output");
        require(OutputResolution.isFullSize(3060, 4080), "portrait full-size output");
        require(!OutputResolution.isFullSize(1920, 1440), "reduced output detected");
        require(OpticalVerification.matches(
                "TELE_10X", "tele10", "tele10", "TELE_3X"),
                "active physical ID verifies 10x despite ambiguous focal metadata");
        require(OpticalVerification.matches(
                "TELE_10X", "tele10", null, "TELE_10X"),
                "10x focal metadata remains a safe fallback");
        require(!OpticalVerification.matches(
                "TELE_10X", "tele10", "tele3", "TELE_3X"),
                "wrong physical and focal lens remain blocked");
        require(PortraitGeometry.hasCloseWideAngleRisk(1.0f, 650, 4000),
                "close 1x face triggers perspective guidance");
        require(!PortraitGeometry.hasCloseWideAngleRisk(1.0f, 400, 4000),
                "normal-distance 1x face remains unrestricted");
        require(!PortraitGeometry.hasCloseWideAngleRisk(3.0f, 900, 4000),
                "3x portrait does not trigger wide-angle guidance");

        SceneStats ordinary = new SceneStats(true, 108.0, 28, 105, 205,
                0.04, 0.004, 1L);
        SceneStats extreme = new SceneStats(true, 112.0, 8, 101, 244,
                0.16, 0.035, 1L);
        SmartAutoEngine.Decision standard = SmartAutoEngine.decide(ordinary,
                50, 5_000_000L, false, true, true, 1.0f, false);
        require(standard.route == SmartAutoEngine.Route.STANDARD,
                "ordinary daylight remains natural Standard");
        SmartAutoEngine.Decision hdr = SmartAutoEngine.decide(extreme,
                50, 5_000_000L, true, true, true, 1.0f, false);
        require(hdr.route == SmartAutoEngine.Route.HDR, "difficult backlight routes HDR");
        SmartAutoEngine.Decision night = SmartAutoEngine.decide(ordinary,
                1200, 55_000_000L, false, true, true, 1.0f, false);
        require(night.route == SmartAutoEngine.Route.NIGHT, "low light routes Night");
        SmartAutoEngine.Decision lensPriority = SmartAutoEngine.decide(extreme,
                1200, 55_000_000L, true, true, true, 3.0f, false);
        require(lensPriority.route == SmartAutoEngine.Route.STANDARD,
                "non-1x Smart Auto preserves optical lens priority");

        float[] portrait = CoordinateMapper.rotateSensorPoint(0.25f, 0.40f, 90, 0);
        require(close(portrait[0], 0.60f) && close(portrait[1], 0.25f),
                "portrait face-meter coordinate rotation");

        System.out.println("Host checks passed: device gate, dual-proof 10x guard, native output policy, Smart Auto routing and face coordinates");
    }

    private static void require(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    private static boolean close(float first, float second) {
        return Math.abs(first - second) < 0.0001f;
    }
}
