#!/usr/bin/env python3
"""Patch same-length versionName and integer versionCode in binary Android XML."""

from __future__ import annotations

import argparse
import struct
from pathlib import Path


RES_STRING_POOL_TYPE = 0x0001
RES_XML_RESOURCE_MAP_TYPE = 0x0180
RES_XML_START_ELEMENT_TYPE = 0x0102
UTF8_FLAG = 0x00000100
ANDROID_VERSION_CODE = 0x0101021B


def u16(data: bytearray, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def chunks(data: bytearray, start: int = 8):
    offset = start
    while offset + 8 <= len(data):
        chunk_type = u16(data, offset)
        header_size = u16(data, offset + 2)
        size = u32(data, offset + 4)
        if header_size < 8 or size < header_size or offset + size > len(data):
            raise ValueError(f"Invalid Android resource chunk at offset {offset}")
        yield offset, chunk_type, header_size, size
        offset += size


def length8(data: bytearray, offset: int) -> tuple[int, int]:
    first = data[offset]
    if first & 0x80:
        return ((first & 0x7F) << 8) | data[offset + 1], 2
    return first, 1


def length16(data: bytearray, offset: int) -> tuple[int, int]:
    first = u16(data, offset)
    if first & 0x8000:
        return ((first & 0x7FFF) << 16) | u16(data, offset + 2), 4
    return first, 2


def patch_string(data: bytearray, pool_offset: int, old: str, new: str) -> int:
    header_size = u16(data, pool_offset + 2)
    string_count = u32(data, pool_offset + 8)
    flags = u32(data, pool_offset + 16)
    strings_start = u32(data, pool_offset + 20)
    utf8 = bool(flags & UTF8_FLAG)
    encoding = "utf-8" if utf8 else "utf-16le"
    old_bytes = old.encode(encoding)
    new_bytes = new.encode(encoding)
    if len(old_bytes) != len(new_bytes) or len(old) != len(new):
        raise ValueError("Replacement must preserve encoded and character lengths")

    patched = 0
    offsets_start = pool_offset + header_size
    strings_base = pool_offset + strings_start
    for index in range(string_count):
        relative = u32(data, offsets_start + index * 4)
        position = strings_base + relative
        if utf8:
            _, utf16_prefix = length8(data, position)
            byte_length, utf8_prefix = length8(data, position + utf16_prefix)
            value_start = position + utf16_prefix + utf8_prefix
        else:
            character_length, prefix = length16(data, position)
            byte_length = character_length * 2
            value_start = position + prefix
        value = bytes(data[value_start:value_start + byte_length])
        if value == old_bytes:
            data[value_start:value_start + byte_length] = new_bytes
            patched += 1
    return patched


def resource_ids(data: bytearray, offset: int, header_size: int, size: int) -> list[int]:
    count = (size - header_size) // 4
    start = offset + header_size
    return [u32(data, start + index * 4) for index in range(count)]


def patch_version_code(data: bytearray, ids: list[int], version_code: int) -> int:
    patched = 0
    for offset, chunk_type, _, _ in chunks(data):
        if chunk_type != RES_XML_START_ELEMENT_TYPE:
            continue
        attribute_start = u16(data, offset + 24)
        attribute_size = u16(data, offset + 26)
        attribute_count = u16(data, offset + 28)
        first_attribute = offset + 16 + attribute_start
        for index in range(attribute_count):
            attribute = first_attribute + index * attribute_size
            name_index = u32(data, attribute + 4)
            resource_id = ids[name_index] if name_index < len(ids) else 0
            if resource_id != ANDROID_VERSION_CODE:
                continue
            data_type = data[attribute + 15]
            if data_type not in (0x10, 0x11):
                raise ValueError("versionCode is not stored as an integer")
            struct.pack_into("<I", data, attribute + 16, version_code)
            patched += 1
    return patched


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--old-name", required=True)
    parser.add_argument("--new-name", required=True)
    parser.add_argument("--version-code", required=True, type=int)
    args = parser.parse_args()

    data = bytearray(args.input.read_bytes())
    pool_offset = None
    ids = None
    for offset, chunk_type, header_size, size in chunks(data):
        if chunk_type == RES_STRING_POOL_TYPE and pool_offset is None:
            pool_offset = offset
        elif chunk_type == RES_XML_RESOURCE_MAP_TYPE:
            ids = resource_ids(data, offset, header_size, size)
    if pool_offset is None or ids is None:
        raise ValueError("Binary manifest string pool or resource map is missing")

    names = patch_string(data, pool_offset, args.old_name, args.new_name)
    codes = patch_version_code(data, ids, args.version_code)
    if names != 1 or codes != 1:
        raise ValueError(f"Expected one versionName and versionCode; patched {names}/{codes}")
    args.output.write_bytes(data)
    print(f"Patched versionName {args.old_name} -> {args.new_name}; versionCode={args.version_code}")


if __name__ == "__main__":
    main()
