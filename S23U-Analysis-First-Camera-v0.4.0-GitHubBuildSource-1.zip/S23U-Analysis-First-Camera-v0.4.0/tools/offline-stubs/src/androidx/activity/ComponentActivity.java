package androidx.activity;

import android.app.Activity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;

public class ComponentActivity extends Activity implements LifecycleOwner {
    public ComponentActivity() { }
    @Override public Lifecycle getLifecycle() { return null; }
}
