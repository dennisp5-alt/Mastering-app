package androidx.lifecycle;

public abstract class LiveData<T> {
    public T getValue() { return null; }
    public void observe(LifecycleOwner owner, Observer<? super T> observer) { }
    public void removeObservers(LifecycleOwner owner) { }
}
