package androidx.camera.camera2.interop;

import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import androidx.camera.core.ExtendableBuilder;

public final class Camera2Interop {
    private Camera2Interop() { }

    public static final class Extender<T> {
        public Extender(ExtendableBuilder<T> builder) { }
        public Extender<T> setPhysicalCameraId(String id) { return this; }
        public Extender<T> setSessionCaptureCallback(
                CameraCaptureSession.CaptureCallback callback) { return this; }
        public <ValueT> Extender<T> setCaptureRequestOption(
                CaptureRequest.Key<ValueT> key, ValueT value) { return this; }
    }
}
