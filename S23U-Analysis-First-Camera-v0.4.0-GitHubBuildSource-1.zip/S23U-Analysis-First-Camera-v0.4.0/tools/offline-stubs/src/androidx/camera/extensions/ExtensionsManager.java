package androidx.camera.extensions;

import android.content.Context;
import androidx.camera.core.CameraProvider;
import androidx.camera.core.CameraSelector;
import com.google.common.util.concurrent.ListenableFuture;

public final class ExtensionsManager {
    public static ListenableFuture<ExtensionsManager> getInstanceAsync(
            Context context, CameraProvider provider) { return null; }
    public boolean isExtensionAvailable(CameraSelector selector, int mode) { return false; }
    public CameraSelector getExtensionEnabledCameraSelector(
            CameraSelector selector, int mode) { return null; }
}
