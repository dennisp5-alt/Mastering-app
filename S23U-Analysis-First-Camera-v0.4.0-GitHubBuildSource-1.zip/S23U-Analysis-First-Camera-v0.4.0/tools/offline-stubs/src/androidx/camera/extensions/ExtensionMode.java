package androidx.camera.extensions;

public final class ExtensionMode {
    public static final int BOKEH = 1;
    public static final int HDR = 2;
    public static final int NIGHT = 3;
    public static final int AUTO = 5;
    private ExtensionMode() { }
}
