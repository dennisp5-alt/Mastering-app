package androidx.camera.view;

import android.content.Context;
import android.widget.FrameLayout;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.lifecycle.LiveData;

public final class PreviewView extends FrameLayout {
    public enum ImplementationMode { PERFORMANCE, COMPATIBLE }
    public enum ScaleType { FILL_START, FILL_CENTER, FILL_END, FIT_START, FIT_CENTER, FIT_END }
    public enum StreamState { IDLE, STREAMING }

    public PreviewView(Context context) { super(context); }
    public void setImplementationMode(ImplementationMode mode) { }
    public void setScaleType(ScaleType type) { }
    public Preview.SurfaceProvider getSurfaceProvider() { return null; }
    public MeteringPointFactory getMeteringPointFactory() { return null; }
    public LiveData<StreamState> getPreviewStreamState() { return null; }
}
