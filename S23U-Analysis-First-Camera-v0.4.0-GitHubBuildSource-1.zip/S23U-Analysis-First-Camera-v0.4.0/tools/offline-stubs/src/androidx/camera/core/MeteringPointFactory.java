package androidx.camera.core;

public abstract class MeteringPointFactory {
    public MeteringPoint createPoint(float x, float y) { return null; }
}
