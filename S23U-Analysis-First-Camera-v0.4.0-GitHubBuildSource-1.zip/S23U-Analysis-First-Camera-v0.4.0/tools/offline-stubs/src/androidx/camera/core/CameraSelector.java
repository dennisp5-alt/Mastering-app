package androidx.camera.core;

public final class CameraSelector {
    public static final CameraSelector DEFAULT_BACK_CAMERA = null;
}
