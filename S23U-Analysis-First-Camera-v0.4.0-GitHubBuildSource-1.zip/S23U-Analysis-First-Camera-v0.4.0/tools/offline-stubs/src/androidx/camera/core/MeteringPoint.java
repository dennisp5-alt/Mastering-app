package androidx.camera.core;

public class MeteringPoint { }
