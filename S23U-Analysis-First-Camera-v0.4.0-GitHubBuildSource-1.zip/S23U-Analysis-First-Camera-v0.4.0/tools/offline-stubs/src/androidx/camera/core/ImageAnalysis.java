package androidx.camera.core;

import java.util.concurrent.Executor;

public final class ImageAnalysis extends UseCase {
    public static final int STRATEGY_KEEP_ONLY_LATEST = 0;
    public static final int OUTPUT_IMAGE_FORMAT_YUV_420_888 = 1;

    public interface Analyzer {
        void analyze(ImageProxy image);
    }

    public void setAnalyzer(Executor executor, Analyzer analyzer) { }
    public void clearAnalyzer() { }

    public static final class Builder implements ExtendableBuilder<Builder> {
        public Builder() { }
        public Builder setTargetAspectRatio(int ratio) { return this; }
        public Builder setTargetRotation(int rotation) { return this; }
        public Builder setBackpressureStrategy(int strategy) { return this; }
        public Builder setOutputImageFormat(int format) { return this; }
        public ImageAnalysis build() { return null; }
    }
}
