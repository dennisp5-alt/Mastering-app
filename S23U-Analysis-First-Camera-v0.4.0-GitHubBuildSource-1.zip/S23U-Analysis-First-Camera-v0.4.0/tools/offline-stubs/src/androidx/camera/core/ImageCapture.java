package androidx.camera.core;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.net.Uri;
import java.util.concurrent.Executor;

public final class ImageCapture extends UseCase {
    public static final int CAPTURE_MODE_MAXIMIZE_QUALITY = 0;
    public static final int FLASH_MODE_AUTO = 0;
    public static final int FLASH_MODE_ON = 1;
    public static final int FLASH_MODE_OFF = 2;

    public void setFlashMode(int mode) { }
    public void setTargetRotation(int rotation) { }
    public void takePicture(OutputFileOptions options, Executor executor,
                            OnImageSavedCallback callback) { }

    public interface OnImageSavedCallback {
        void onImageSaved(OutputFileResults output);
        void onError(ImageCaptureException error);
        default void onCaptureProcessProgressed(int progress) { }
        default void onCaptureStarted() { }
        default void onPostviewBitmapAvailable(Bitmap bitmap) { }
    }

    public static final class OutputFileResults {
        public Uri getSavedUri() { return null; }
    }

    public static final class OutputFileOptions {
        public static final class Builder {
            public Builder(ContentResolver resolver, Uri collection,
                           ContentValues values) { }
            public OutputFileOptions build() { return null; }
        }
    }

    public static final class Builder implements ExtendableBuilder<Builder> {
        public Builder() { }
        public Builder setTargetAspectRatio(int ratio) { return this; }
        public Builder setTargetRotation(int rotation) { return this; }
        public Builder setCaptureMode(int mode) { return this; }
        public Builder setJpegQuality(int quality) { return this; }
        public Builder setFlashMode(int mode) { return this; }
        public ImageCapture build() { return null; }
    }
}
