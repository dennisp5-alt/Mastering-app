package androidx.camera.core;

import java.util.concurrent.TimeUnit;

public final class FocusMeteringAction {
    public static final int FLAG_AF = 1;
    public static final int FLAG_AE = 2;

    public static final class Builder {
        public Builder(MeteringPoint point, int mode) { }
        public Builder setAutoCancelDuration(long duration, TimeUnit unit) { return this; }
        public FocusMeteringAction build() { return null; }
    }
}
