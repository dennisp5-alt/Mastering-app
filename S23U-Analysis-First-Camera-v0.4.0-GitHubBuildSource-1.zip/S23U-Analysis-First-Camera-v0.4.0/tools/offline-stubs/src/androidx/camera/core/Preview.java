package androidx.camera.core;

public final class Preview extends UseCase {
    public interface SurfaceProvider { }

    public void setSurfaceProvider(SurfaceProvider provider) { }

    public static final class Builder implements ExtendableBuilder<Builder> {
        public Builder() { }
        public Builder setTargetAspectRatio(int ratio) { return this; }
        public Builder setTargetRotation(int rotation) { return this; }
        public Preview build() { return null; }
    }
}
