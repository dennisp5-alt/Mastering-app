package androidx.camera.core;

public interface ExtendableBuilder<T> { }
