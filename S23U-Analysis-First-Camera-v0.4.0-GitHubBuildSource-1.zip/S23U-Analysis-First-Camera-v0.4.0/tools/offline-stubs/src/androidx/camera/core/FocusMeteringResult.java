package androidx.camera.core;

public final class FocusMeteringResult {
    public boolean isFocusSuccessful() { return false; }
}
