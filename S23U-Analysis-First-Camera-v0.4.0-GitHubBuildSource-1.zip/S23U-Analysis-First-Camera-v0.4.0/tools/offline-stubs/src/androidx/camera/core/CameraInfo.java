package androidx.camera.core;

import androidx.lifecycle.LiveData;

public interface CameraInfo {
    LiveData<ZoomState> getZoomState();
}
