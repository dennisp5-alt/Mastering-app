package androidx.camera.core;

import com.google.common.util.concurrent.ListenableFuture;

public interface CameraControl {
    ListenableFuture<Void> setZoomRatio(float ratio);
    ListenableFuture<FocusMeteringResult> startFocusAndMetering(FocusMeteringAction action);
}
