package androidx.camera.core;

public final class AspectRatio {
    public static final int RATIO_4_3 = 0;
    private AspectRatio() { }
}
