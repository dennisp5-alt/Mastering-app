package androidx.camera.core;

import java.nio.ByteBuffer;

public interface ImageProxy extends AutoCloseable {
    int getWidth();
    int getHeight();
    PlaneProxy[] getPlanes();
    @Override void close();

    interface PlaneProxy {
        ByteBuffer getBuffer();
        int getPixelStride();
        int getRowStride();
    }
}
