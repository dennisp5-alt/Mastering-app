package androidx.camera.lifecycle;

import android.content.Context;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraProvider;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.UseCase;
import androidx.lifecycle.LifecycleOwner;
import com.google.common.util.concurrent.ListenableFuture;

public final class ProcessCameraProvider implements CameraProvider {
    public static ListenableFuture<ProcessCameraProvider> getInstance(Context context) {
        return null;
    }
    public Camera bindToLifecycle(LifecycleOwner owner, CameraSelector selector,
                                  UseCase... useCases) { return null; }
    public void unbindAll() { }
}
