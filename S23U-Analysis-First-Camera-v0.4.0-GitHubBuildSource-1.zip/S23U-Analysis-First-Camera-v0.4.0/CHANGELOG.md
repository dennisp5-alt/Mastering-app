# Changelog

## 0.4.0 — Lens/ISO Detail Intelligence

- Freezes the v0.3.0 True Colour, per-lens colour calibration, Natural Tonality and Stability Guard baseline.
- Adds separate detail/noise profiles for 0.6x, 1x, 3x and 10x.
- Each lens changes behaviour across clean-light, normal-light, elevated-ISO and low-light ISO bands.
- Clean 1x prioritises genuine micro-detail; 3x stays portrait-safe; 10x becomes progressively noise-first at higher ISO.
- Adds edge-aware micro-detail finishing with a strict 1–3 level luminance cap rather than global sharpening.
- Adds smooth-area noise reduction that only operates where local variation is low.
- Skin, foliage and smooth blue/sky regions receive extra protection from sharpening or over-smoothing.
- The live Analysis First readout now shows the predicted Detail IQ lens/ISO profile.
- Saved EXIF diagnostics record the Detail IQ band, source lens and ISO.
- Standard control and Original JPEG mode remain untouched.

## 0.3.0 — Calibrated Colour + Natural Tonality

- Conservative persistent per-lens colour calibration.
- Measured Natural Tonality highlight shoulder and black-preserving shadow separation.
- Professional graphite UI cleanup.
