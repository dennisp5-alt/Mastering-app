# Analysis First Camera 0.4.0

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture, True Colour, per-lens calibration, Natural Tonality, handheld stability and lens/ISO-specific Detail IQ.

The v0.3.0 colour/tone baseline is frozen. v0.4.0 adds a deliberately restrained detail/noise stage chosen from the actual lens and captured ISO. Clean 1x daylight gets the most micro-detail support; 3x is tuned for portraits and general tele work; 10x becomes increasingly noise-first as ISO rises; low-light profiles reduce sharpening instead of sharpening noise. Smooth sky, skin and foliage receive additional protection.

Standard mode remains an untouched comparison control.
