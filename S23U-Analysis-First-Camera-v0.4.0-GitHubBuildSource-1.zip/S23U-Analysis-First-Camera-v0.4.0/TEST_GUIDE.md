# v0.4.0 test guide

Use matched v0.3.0/v0.4.0 or Standard/Analysis First frames where practical. Do not judge only by overall sharpness; the goal is cleaner, more natural detail with less noisy/crunchy texture.

## Priority tests

1. **1x daylight:** grass, brick, fabric, hair and fine branches. Detail should be crisp but not haloed.
2. **3x portraits:** eyes/hair/clothing should stay sharp while skin remains natural and unsmoothed.
3. **10x daylight:** distant lettering, foliage and roof detail. Fine detail should be stable without aggressive edge halos.
4. **10x shade/dusk:** noise should be calmer and sharpening should back off automatically as ISO rises.
5. **Indoor mixed light:** smooth walls and shadows should not become blotchy or waxy.
6. **Sky + foliage:** sky should remain smooth; fine leaves should retain separation.

Watch the live `Detail IQ` line. It should change by active lens and ISO, for example `TELE_10X · elevated-ISO · NR ... · detail ...`.

The saved result report/EXIF diagnostic records the Detail IQ profile. Standard and Original JPEG paths must remain pixel-untouched.
