package com.s23u.procamera;

import android.os.SystemClock;

import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import java.nio.ByteBuffer;

final class SceneAnalyzer implements ImageAnalysis.Analyzer {
    interface Listener {
        void onSceneStats(SceneStats stats);
    }

    private final Listener listener;
    private volatile SceneStats latest = SceneStats.UNAVAILABLE;
    private volatile ColourStats latestColour = ColourStats.UNAVAILABLE;
    private double previousMean = Double.NaN;
    private int previousP50 = -1;
    private int previousP95 = -1;
    private double previousNeutralU = Double.NaN;
    private double previousNeutralV = Double.NaN;
    private double previousMixed = Double.NaN;

    SceneAnalyzer(Listener listener) {
        this.listener = listener;
    }

    SceneStats latest() {
        SceneStats value = latest;
        if (!value.valid || SystemClock.elapsedRealtime() - value.timestampMs > 1800L) {
            return SceneStats.UNAVAILABLE;
        }
        return value;
    }

    ColourStats latestColour() {
        ColourStats value = latestColour;
        return value.isFresh() ? value : ColourStats.UNAVAILABLE;
    }

    @Override
    public void analyze(ImageProxy image) {
        try {
            ImageProxy.PlaneProxy[] planes = image.getPlanes();
            if (planes.length == 0) return;
            ImageProxy.PlaneProxy yPlane = planes[0];
            ByteBuffer yBuffer = yPlane.getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();
            int yRowStride = yPlane.getRowStride();
            int yPixelStride = yPlane.getPixelStride();
            int stepX = Math.max(4, width / 120);
            int stepY = Math.max(4, height / 90);
            int[] histogram = new int[256];
            long sum = 0L;
            int count = 0;
            int shadows = 0;
            int highlights = 0;

            boolean colourAvailable = planes.length >= 3;
            ImageProxy.PlaneProxy uPlane = colourAvailable ? planes[1] : null;
            ImageProxy.PlaneProxy vPlane = colourAvailable ? planes[2] : null;
            ByteBuffer uBuffer = colourAvailable ? uPlane.getBuffer() : null;
            ByteBuffer vBuffer = colourAvailable ? vPlane.getBuffer() : null;

            long neutralUSum = 0L;
            long neutralVSum = 0L;
            int neutralCount = 0;
            int skyCount = 0;
            int foliageCount = 0;
            int skinCount = 0;
            int colourCount = 0;
            final int gridCols = 4;
            final int gridRows = 3;
            long[] cellUSum = new long[gridCols * gridRows];
            long[] cellVSum = new long[gridCols * gridRows];
            int[] cellNeutralCount = new int[gridCols * gridRows];

            for (int y = stepY / 2; y < height; y += stepY) {
                int yRow = y * yRowStride;
                for (int x = stepX / 2; x < width; x += stepX) {
                    int yIndex = yRow + x * yPixelStride;
                    if (yIndex < 0 || yIndex >= yBuffer.limit()) continue;
                    int yy = yBuffer.get(yIndex) & 0xff;
                    histogram[yy]++;
                    sum += yy;
                    count++;
                    if (yy <= 32) shadows++;
                    if (yy >= 235) highlights++;

                    if (!colourAvailable) continue;
                    int uu = sampleChroma(uBuffer, uPlane, x, y);
                    int vv = sampleChroma(vBuffer, vPlane, x, y);
                    if (uu < 0 || vv < 0) continue;
                    colourCount++;
                    int[] rgb = yuvToRgb(yy, uu, vv);
                    int r = rgb[0], g = rgb[1], b = rgb[2];
                    int max = Math.max(r, Math.max(g, b));
                    int min = Math.min(r, Math.min(g, b));
                    int chroma = max - min;
                    boolean sky = y < height * 0.62
                            && b >= r + 18 && b >= g + 3 && yy >= 55 && chroma >= 26;
                    boolean foliage = g >= r + 10 && g >= b + 6 && yy >= 28 && yy <= 220
                            && chroma >= 20;
                    boolean skin = yy >= 45 && yy <= 235 && uu >= 82 && uu <= 132
                            && vv >= 132 && vv <= 182 && r > g && g >= b - 8;
                    if (sky) skyCount++;
                    if (foliage) foliageCount++;
                    if (skin) skinCount++;

                    double uvDistance = Math.hypot(uu - 128.0, vv - 128.0);
                    boolean neutral = yy >= 45 && yy <= 225 && uvDistance <= 38.0
                            && chroma <= 48 && !sky && !foliage && !skin;
                    if (neutral) {
                        neutralUSum += uu;
                        neutralVSum += vv;
                        neutralCount++;
                        int gx = Math.min(gridCols - 1, x * gridCols / Math.max(1, width));
                        int gy = Math.min(gridRows - 1, y * gridRows / Math.max(1, height));
                        int gi = gy * gridCols + gx;
                        cellUSum[gi] += uu;
                        cellVSum[gi] += vv;
                        cellNeutralCount[gi]++;
                    }
                }
            }

            if (count < 100) return;
            double mean = sum / (double) count;
            int p05 = percentile(histogram, count, 0.05);
            int p50 = percentile(histogram, count, 0.50);
            int p95 = percentile(histogram, count, 0.95);
            double stability = stability(mean, p50, p95);
            previousMean = mean;
            previousP50 = p50;
            previousP95 = p95;
            long now = SystemClock.elapsedRealtime();

            SceneStats stats = new SceneStats(true, mean, p05, p50, p95,
                    shadows / (double) count,
                    highlights / (double) count,
                    stability,
                    now);
            latest = stats;

            if (colourAvailable && colourCount >= 80) {
                double neutralU = neutralCount > 0 ? neutralUSum / (double) neutralCount : 128.0;
                double neutralV = neutralCount > 0 ? neutralVSum / (double) neutralCount : 128.0;
                double neutralEvidence = neutralCount / (double) colourCount;
                double spread = neutralSpread(cellUSum, cellVSum, cellNeutralCount,
                        neutralU, neutralV);
                double mixed = mixedLight(cellUSum, cellVSum, cellNeutralCount);
                double evidence = clamp01(neutralEvidence / 0.030)
                        * clamp01(1.0 - spread / 22.0);
                double castStrength = Math.hypot(neutralU - 128.0, neutralV - 128.0);
                double colourStability = colourStability(neutralU, neutralV, mixed, neutralCount);
                double castConfidence = evidence
                        * clamp01((castStrength - 2.0) / 11.0)
                        * (0.55 + 0.45 * colourStability);
                ColourStats colour = new ColourStats(true, neutralEvidence, neutralU, neutralV,
                        spread, mixed,
                        skyCount / (double) colourCount,
                        foliageCount / (double) colourCount,
                        skinCount / (double) colourCount,
                        castStrength, evidence, castConfidence, colourStability, now);
                latestColour = colour;
                if (neutralCount >= 8) {
                    previousNeutralU = neutralU;
                    previousNeutralV = neutralV;
                    previousMixed = mixed;
                }
            } else {
                latestColour = ColourStats.UNAVAILABLE;
            }
            if (listener != null) listener.onSceneStats(stats);
        } finally {
            image.close();
        }
    }

    private static int sampleChroma(ByteBuffer buffer, ImageProxy.PlaneProxy plane,
                                    int x, int y) {
        int cx = x / 2;
        int cy = y / 2;
        int index = cy * plane.getRowStride() + cx * plane.getPixelStride();
        if (index < 0 || index >= buffer.limit()) return -1;
        return buffer.get(index) & 0xff;
    }

    private static int[] yuvToRgb(int yy, int uu, int vv) {
        double y = 1.164 * Math.max(0, yy - 16);
        double u = uu - 128.0;
        double v = vv - 128.0;
        int r = clamp((int) Math.round(y + 1.596 * v));
        int g = clamp((int) Math.round(y - 0.392 * u - 0.813 * v));
        int b = clamp((int) Math.round(y + 2.017 * u));
        return new int[]{r, g, b};
    }

    private double colourStability(double u, double v, double mixed, int neutralCount) {
        if (neutralCount < 8 || !Double.isFinite(previousNeutralU)
                || !Double.isFinite(previousNeutralV)) return 0.0;
        double delta = Math.hypot(u - previousNeutralU, v - previousNeutralV) / 10.0;
        double mixedDelta = Double.isFinite(previousMixed)
                ? Math.abs(mixed - previousMixed) / 0.25 : 0.0;
        return clamp01(1.0 - Math.min(1.0, 0.78 * delta + 0.22 * mixedDelta));
    }

    private static double neutralSpread(long[] uSum, long[] vSum, int[] cellCount,
                                        double meanU, double meanV) {
        double total = 0.0;
        int cells = 0;
        for (int i = 0; i < cellCount.length; i++) {
            if (cellCount[i] < 4) continue;
            double u = uSum[i] / (double) cellCount[i];
            double v = vSum[i] / (double) cellCount[i];
            total += Math.hypot(u - meanU, v - meanV);
            cells++;
        }
        return cells == 0 ? 24.0 : total / cells;
    }

    private static double mixedLight(long[] uSum, long[] vSum, int[] cellCount) {
        double[] us = new double[cellCount.length];
        double[] vs = new double[cellCount.length];
        int n = 0;
        for (int i = 0; i < cellCount.length; i++) {
            if (cellCount[i] < 4) continue;
            us[n] = uSum[i] / (double) cellCount[i];
            vs[n] = vSum[i] / (double) cellCount[i];
            n++;
        }
        if (n < 2) return 0.0;
        double maxDistance = 0.0;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                maxDistance = Math.max(maxDistance,
                        Math.hypot(us[i] - us[j], vs[i] - vs[j]));
            }
        }
        return clamp01((maxDistance - 4.0) / 22.0);
    }

    private double stability(double mean, int p50, int p95) {
        if (!Double.isFinite(previousMean) || previousP50 < 0 || previousP95 < 0) {
            return 0.0;
        }
        double meanDelta = Math.abs(mean - previousMean) / 18.0;
        double midDelta = Math.abs(p50 - previousP50) / 18.0;
        double highDelta = Math.abs(p95 - previousP95) / 24.0;
        double instability = Math.min(1.0, 0.45 * meanDelta + 0.35 * midDelta
                + 0.20 * highDelta);
        return Math.max(0.0, 1.0 - instability);
    }

    private static int percentile(int[] histogram, int count, double fraction) {
        int target = Math.max(1, (int) Math.ceil(count * fraction));
        int running = 0;
        for (int i = 0; i < histogram.length; i++) {
            running += histogram[i];
            if (running >= target) return i;
        }
        return 255;
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
