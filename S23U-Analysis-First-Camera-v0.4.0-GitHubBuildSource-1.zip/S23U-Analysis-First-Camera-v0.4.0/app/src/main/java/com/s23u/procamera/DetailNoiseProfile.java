package com.s23u.procamera;

import java.util.Locale;

/**
 * Conservative lens/ISO-specific detail and noise policy.
 *
 * The profile is deliberately small-signal: it never invents detail, never
 * globally sharpens smooth areas and becomes more noise-first as ISO rises.
 */
final class DetailNoiseProfile {
    static final class Plan {
        final String lens;
        final int iso;
        final String band;
        final double denoiseStrength;
        final double detailStrength;
        final int smoothThreshold;
        final int detailCap;

        Plan(String lens, int iso, String band, double denoiseStrength,
             double detailStrength, int smoothThreshold, int detailCap) {
            this.lens = lens;
            this.iso = iso;
            this.band = band;
            this.denoiseStrength = denoiseStrength;
            this.detailStrength = detailStrength;
            this.smoothThreshold = smoothThreshold;
            this.detailCap = detailCap;
        }

        boolean active() {
            return denoiseStrength >= 0.01 || detailStrength >= 0.01;
        }

        String diagnostic() {
            return String.format(Locale.US,
                    "Detail IQ %s · %s ISO %d · NR %.1f%% · detail %.1f%%",
                    lens, band, iso,
                    denoiseStrength * 100.0, detailStrength * 100.0);
        }
    }

    private DetailNoiseProfile() { }

    static Plan plan(String lens, int iso) {
        String safeLens = lens == null ? "MAIN_1X" : lens;
        int safeIso = iso > 0 ? iso : 200;
        String band;
        if (safeIso <= 125) band = "clean-light";
        else if (safeIso <= 400) band = "normal-light";
        else if (safeIso <= 800) band = "elevated-ISO";
        else band = "low-light";

        double nr;
        double detail;
        int smooth;
        int cap;

        switch (safeLens) {
            case "ULTRA_WIDE":
                if (safeIso <= 125) { nr = 0.025; detail = 0.060; smooth = 15; cap = 3; }
                else if (safeIso <= 400) { nr = 0.055; detail = 0.050; smooth = 18; cap = 3; }
                else if (safeIso <= 800) { nr = 0.100; detail = 0.032; smooth = 22; cap = 2; }
                else { nr = 0.155; detail = 0.018; smooth = 27; cap = 2; }
                break;
            case "TELE_3X":
                if (safeIso <= 125) { nr = 0.020; detail = 0.070; smooth = 14; cap = 3; }
                else if (safeIso <= 400) { nr = 0.060; detail = 0.055; smooth = 18; cap = 3; }
                else if (safeIso <= 800) { nr = 0.110; detail = 0.036; smooth = 22; cap = 2; }
                else { nr = 0.165; detail = 0.020; smooth = 28; cap = 2; }
                break;
            case "TELE_10X":
                if (safeIso <= 125) { nr = 0.035; detail = 0.050; smooth = 16; cap = 3; }
                else if (safeIso <= 400) { nr = 0.080; detail = 0.040; smooth = 20; cap = 3; }
                else if (safeIso <= 800) { nr = 0.135; detail = 0.026; smooth = 25; cap = 2; }
                else { nr = 0.200; detail = 0.012; smooth = 31; cap = 1; }
                break;
            case "MAIN_1X":
            default:
                if (safeIso <= 125) { nr = 0.012; detail = 0.075; smooth = 13; cap = 3; }
                else if (safeIso <= 400) { nr = 0.045; detail = 0.060; smooth = 17; cap = 3; }
                else if (safeIso <= 800) { nr = 0.090; detail = 0.038; smooth = 21; cap = 2; }
                else { nr = 0.145; detail = 0.020; smooth = 27; cap = 2; }
                break;
        }
        return new Plan(safeLens, safeIso, band, nr, detail, smooth, cap);
    }
}
