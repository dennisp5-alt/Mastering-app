package com.s23u.procamera;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Conservative self-calibration memory for the four S23U lens groups.
 * It learns only from stable, near-neutral, single-illuminant scenes that the
 * True Colour engine has already classified as NO_CAST. This avoids learning
 * sunsets, coloured walls or mixed lighting as sensor bias.
 */
final class LensCalibrationStore {
    private static final String PREFS = "lens_colour_calibration_v1";
    private static final int MAX_SAMPLES = 32;
    private final SharedPreferences preferences;

    LensCalibrationStore(Context context) {
        preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    LensColourProfile profileFor(String lens) {
        String key = safeLens(lens);
        int count = preferences.getInt(key + "_count", 0);
        double u = Double.longBitsToDouble(preferences.getLong(key + "_u", 0L));
        double v = Double.longBitsToDouble(preferences.getLong(key + "_v", 0L));
        if (!Double.isFinite(u)) u = 0.0;
        if (!Double.isFinite(v)) v = 0.0;
        return LensColourProfile.calibrated(key, u, v, count);
    }

    boolean observe(String lens, ColourStats stats, TrueColourDecision decision) {
        if (stats == null || !stats.valid || decision == null
                || decision.action != TrueColourDecision.Action.NO_CAST) return false;
        if (stats.neutralEvidence < 0.025 || stats.evidenceConfidence < 0.78
                || stats.stabilityScore < 0.72 || stats.mixedLightScore > 0.28) return false;

        double u = stats.neutralU - 128.0;
        double v = stats.neutralV - 128.0;
        double strength = Math.hypot(u, v);
        if (!Double.isFinite(strength) || strength < 0.25 || strength > 3.6) return false;

        String key = safeLens(lens);
        int count = preferences.getInt(key + "_count", 0);
        double oldU = Double.longBitsToDouble(preferences.getLong(key + "_u", 0L));
        double oldV = Double.longBitsToDouble(preferences.getLong(key + "_v", 0L));
        if (!Double.isFinite(oldU)) oldU = 0.0;
        if (!Double.isFinite(oldV)) oldV = 0.0;

        int newCount = Math.min(MAX_SAMPLES, count + 1);
        double weight = count <= 0 ? 1.0 : Math.max(0.08, 1.0 / Math.min(12.0, count + 1.0));
        double newU = clamp(oldU * (1.0 - weight) + u * weight, -3.0, 3.0);
        double newV = clamp(oldV * (1.0 - weight) + v * weight, -3.0, 3.0);
        preferences.edit()
                .putInt(key + "_count", newCount)
                .putLong(key + "_u", Double.doubleToRawLongBits(newU))
                .putLong(key + "_v", Double.doubleToRawLongBits(newV))
                .apply();
        return true;
    }

    static boolean qualifiesForLearning(ColourStats stats, TrueColourDecision decision) {
        return stats != null && stats.valid && decision != null
                && decision.action == TrueColourDecision.Action.NO_CAST
                && stats.neutralEvidence >= 0.025
                && stats.evidenceConfidence >= 0.78
                && stats.stabilityScore >= 0.72
                && stats.mixedLightScore <= 0.28
                && Math.hypot(stats.neutralU - 128.0, stats.neutralV - 128.0) >= 0.25
                && Math.hypot(stats.neutralU - 128.0, stats.neutralV - 128.0) <= 3.6;
    }

    private static String safeLens(String lens) {
        if ("ULTRA_WIDE".equals(lens) || "TELE_3X".equals(lens) || "TELE_10X".equals(lens)) {
            return lens;
        }
        return "MAIN_1X";
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }
}
