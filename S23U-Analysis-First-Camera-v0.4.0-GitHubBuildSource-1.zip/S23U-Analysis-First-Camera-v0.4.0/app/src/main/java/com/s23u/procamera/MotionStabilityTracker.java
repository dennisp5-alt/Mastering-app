package com.s23u.procamera;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

/**
 * Lightweight local gyro/accelerometer tracker. It never records or stores motion data;
 * it exposes only a short-lived motion score used to time a handheld capture.
 */
final class MotionStabilityTracker implements SensorEventListener {
    static final class Snapshot {
        final boolean available;
        final double score;
        final double gyroRadPerSec;
        final double accelMotionMs2;
        final long stableForMs;
        final long ageMs;

        Snapshot(boolean available, double score, double gyroRadPerSec,
                 double accelMotionMs2, long stableForMs, long ageMs) {
            this.available = available;
            this.score = score;
            this.gyroRadPerSec = gyroRadPerSec;
            this.accelMotionMs2 = accelMotionMs2;
            this.stableForMs = stableForMs;
            this.ageMs = ageMs;
        }

        String level(float zoom) {
            return StabilityPolicy.level(score, zoom, available, stableForMs);
        }

        int stablePercent() {
            return (int) Math.round(Math.max(0.0, Math.min(1.0, 1.0 - score)) * 100.0);
        }
    }

    private final SensorManager manager;
    private final Sensor gyro;
    private final Sensor accel;
    private final float[] gravity = new float[3];

    private boolean running;
    private boolean gravityReady;
    private volatile double gyroEwma;
    private volatile double accelMotionEwma;
    private volatile double scoreEwma = 1.0;
    private volatile long stableSinceTeleMs;
    private volatile long stableSinceModerateMs;
    private volatile long updatedMs;

    MotionStabilityTracker(Context context) {
        manager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        gyro = manager == null ? null : manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        accel = manager == null ? null : manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    void start() {
        if (running || manager == null) return;
        running = true;
        if (gyro != null) manager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        if (accel != null) manager.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
    }

    void stop() {
        if (!running || manager == null) return;
        manager.unregisterListener(this);
        running = false;
    }

    Snapshot snapshot(float zoom) {
        long now = SystemClock.elapsedRealtime();
        boolean available = gyro != null && updatedMs > 0L && now - updatedMs < 900L;
        long stableSince = StabilityPolicy.longTele(zoom)
                ? stableSinceTeleMs : stableSinceModerateMs;
        long stableFor = stableSince > 0L ? Math.max(0L, now - stableSince) : 0L;
        return new Snapshot(available, scoreEwma, gyroEwma, accelMotionEwma,
                stableFor, updatedMs == 0L ? Long.MAX_VALUE : now - updatedMs);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event == null || event.values == null || event.values.length < 3) return;
        long now = SystemClock.elapsedRealtime();
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            double x = event.values[0];
            double y = event.values[1];
            double z = event.values[2];
            double magnitude = Math.sqrt(x * x + y * y + z * z);
            gyroEwma = ewma(gyroEwma, magnitude, 0.24);
        } else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final double alpha = 0.86;
            if (!gravityReady) {
                gravity[0] = event.values[0];
                gravity[1] = event.values[1];
                gravity[2] = event.values[2];
                gravityReady = true;
            } else {
                gravity[0] = (float) (alpha * gravity[0] + (1.0 - alpha) * event.values[0]);
                gravity[1] = (float) (alpha * gravity[1] + (1.0 - alpha) * event.values[1]);
                gravity[2] = (float) (alpha * gravity[2] + (1.0 - alpha) * event.values[2]);
            }
            double ax = event.values[0] - gravity[0];
            double ay = event.values[1] - gravity[1];
            double az = event.values[2] - gravity[2];
            double motion = Math.sqrt(ax * ax + ay * ay + az * az);
            accelMotionEwma = ewma(accelMotionEwma, motion, 0.20);
        }
        double raw = StabilityPolicy.motionScore(gyroEwma, accelMotionEwma);
        scoreEwma = ewma(scoreEwma, raw, 0.30);
        if (scoreEwma <= StabilityPolicy.readyThreshold(10.0f)) {
            if (stableSinceTeleMs == 0L) stableSinceTeleMs = now;
        } else {
            stableSinceTeleMs = 0L;
        }
        if (scoreEwma <= StabilityPolicy.readyThreshold(3.0f)) {
            if (stableSinceModerateMs == 0L) stableSinceModerateMs = now;
        } else {
            stableSinceModerateMs = 0L;
        }
        updatedMs = now;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private static double ewma(double previous, double value, double alpha) {
        if (!(previous > 0.0)) return value;
        return previous + alpha * (value - previous);
    }
}
