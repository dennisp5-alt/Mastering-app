package com.s23u.procamera;

final class ModeOption {
    static final int SMART_AUTO = -2;
    static final int STANDARD = -1;

    final String label;
    final String tag;
    final int extensionMode;

    ModeOption(String label, String tag, int extensionMode) {
        this.label = label;
        this.tag = tag;
        this.extensionMode = extensionMode;
    }

    boolean usesOemExtension() {
        return extensionMode >= 0;
    }

    boolean isSmartAuto() {
        return extensionMode == SMART_AUTO;
    }

    @Override
    public String toString() {
        return label;
    }
}
