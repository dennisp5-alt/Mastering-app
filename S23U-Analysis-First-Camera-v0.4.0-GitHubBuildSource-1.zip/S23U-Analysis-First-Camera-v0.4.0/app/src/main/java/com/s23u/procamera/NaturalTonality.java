package com.s23u.procamera;

import java.util.Locale;

/** Restrained film-like highlight shoulder and shadow toe separation. */
final class NaturalTonality {
    static final class Plan {
        final boolean active;
        final double shoulder;
        final double shadowSeparation;
        final int p05;
        final int p50;
        final int p95;

        Plan(boolean active, double shoulder, double shadowSeparation,
             int p05, int p50, int p95) {
            this.active = active;
            this.shoulder = shoulder;
            this.shadowSeparation = shadowSeparation;
            this.p05 = p05;
            this.p50 = p50;
            this.p95 = p95;
        }

        String diagnostic() {
            if (!active) return "Natural Tone bypass · already contained";
            return String.format(Locale.US,
                    "Natural Tone · shoulder %.1f%% · shadow separation %.1f%% · P05/50/95 %d/%d/%d",
                    shoulder * 100.0, shadowSeparation * 100.0, p05, p50, p95);
        }
    }

    private NaturalTonality() { }

    static Plan plan(int p05, int p50, int p95,
                     double shadowFraction, double highlightFraction) {
        int range = Math.max(0, p95 - p05);
        double shoulder = clamp((p95 - 210.0) / 720.0 + highlightFraction * 0.22,
                0.0, 0.060);
        double shadow = clamp((42.0 - p05) / 900.0 + shadowFraction * 0.018,
                0.0, 0.026);
        if (range >= 150) {
            shoulder = Math.max(shoulder, 0.022);
            shadow = Math.max(shadow, 0.008);
        } else if (range >= 125) {
            shoulder = Math.max(shoulder, 0.012);
        }
        boolean active = shoulder >= 0.006 || shadow >= 0.005;
        return new Plan(active, shoulder, shadow, p05, p50, p95);
    }

    static int mapLuma(int luma, Plan plan) {
        if (plan == null || !plan.active) return clamp8(luma);
        double x = clamp(luma / 255.0, 0.0, 1.0);
        double y = x;

        // Lift only the middle of the shadow interval: black remains black and
        // the transition meets the original curve smoothly near 42% luminance.
        if (x < 0.42 && plan.shadowSeparation > 0.0) {
            double t = x / 0.42;
            y += plan.shadowSeparation * 4.0 * t * (1.0 - t);
        }

        // Compress only the middle of the highlight interval: white remains
        // white while near-highlights get a smoother shoulder.
        if (x > 0.58 && plan.shoulder > 0.0) {
            double t = (x - 0.58) / 0.42;
            y -= plan.shoulder * 4.0 * t * (1.0 - t);
        }
        return clamp8((int) Math.round(clamp(y, 0.0, 1.0) * 255.0));
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }

    private static int clamp8(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
