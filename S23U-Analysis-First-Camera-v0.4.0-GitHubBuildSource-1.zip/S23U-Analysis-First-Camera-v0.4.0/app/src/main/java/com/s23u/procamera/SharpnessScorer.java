package com.s23u.procamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;

/** Scores same-scene burst candidates using variance of a luminance Laplacian. */
final class SharpnessScorer {
    private SharpnessScorer() { }

    static double score(File file) {
        if (file == null || !file.isFile() || file.length() <= 0) return Double.NEGATIVE_INFINITY;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 8;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        if (bitmap == null || bitmap.getWidth() < 8 || bitmap.getHeight() < 8) {
            if (bitmap != null) bitmap.recycle();
            return Double.NEGATIVE_INFINITY;
        }
        try {
            int w = bitmap.getWidth();
            int h = bitmap.getHeight();
            int[] pixels = new int[w * h];
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
            double sum = 0.0;
            double sumSq = 0.0;
            double lumSum = 0.0;
            long count = 0L;
            for (int y = 2; y < h - 2; y += 2) {
                int row = y * w;
                for (int x = 2; x < w - 2; x += 2) {
                    int i = row + x;
                    double c = luma(pixels[i]);
                    double lap = 4.0 * c - luma(pixels[i - 1]) - luma(pixels[i + 1])
                            - luma(pixels[i - w]) - luma(pixels[i + w]);
                    sum += lap;
                    sumSq += lap * lap;
                    lumSum += c;
                    count++;
                }
            }
            if (count < 32) return Double.NEGATIVE_INFINITY;
            double mean = sum / count;
            double variance = Math.max(0.0, sumSq / count - mean * mean);
            double meanLuma = lumSum / count;
            return variance / Math.max(24.0, meanLuma);
        } finally {
            bitmap.recycle();
        }
    }

    private static double luma(int argb) {
        int r = (argb >> 16) & 0xff;
        int g = (argb >> 8) & 0xff;
        int b = argb & 0xff;
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
}
