package com.s23u.procamera;

final class OpticalVerification {
    private OpticalVerification() { }

    static boolean matches(String expectedLens, String expectedPhysicalId,
                           String activePhysicalId, String focalLens) {
        if (expectedPhysicalId != null && expectedPhysicalId.equals(activePhysicalId)) {
            return true;
        }
        return expectedLens != null && expectedLens.equals(focalLens);
    }
}
