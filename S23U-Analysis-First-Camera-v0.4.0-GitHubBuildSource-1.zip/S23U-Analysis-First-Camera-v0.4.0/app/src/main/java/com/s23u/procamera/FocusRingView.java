package com.s23u.procamera;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

final class FocusRingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float centreX;
    private float centreY;
    private float radius;

    FocusRingView(Context context) {
        super(context);
        paint.setColor(Color.rgb(105, 222, 196));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2.5f));
        radius = dp(34f);
        setVisibility(INVISIBLE);
    }

    void showAt(float x, float y) {
        animate().cancel();
        centreX = x;
        centreY = y;
        setAlpha(1f);
        setVisibility(VISIBLE);
        invalidate();
        animate().alpha(0f).setStartDelay(700L).setDuration(500L)
                .withEndAction(() -> setVisibility(INVISIBLE)).start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(centreX, centreY, radius, paint);
        canvas.drawLine(centreX - radius - dp(8), centreY,
                centreX - radius + dp(6), centreY, paint);
        canvas.drawLine(centreX + radius - dp(6), centreY,
                centreX + radius + dp(8), centreY, paint);
        canvas.drawLine(centreX, centreY - radius - dp(8),
                centreX, centreY - radius + dp(6), paint);
        canvas.drawLine(centreX, centreY + radius - dp(6),
                centreX, centreY + radius + dp(8), paint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
