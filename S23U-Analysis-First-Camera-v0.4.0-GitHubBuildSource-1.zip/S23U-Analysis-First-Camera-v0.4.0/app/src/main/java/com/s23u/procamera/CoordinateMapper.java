package com.s23u.procamera;

final class CoordinateMapper {
    private CoordinateMapper() { }

    static float[] rotateSensorPoint(float x, float y, int sensorOrientation,
                                     int displayRotation) {
        int rotation = (sensorOrientation - displayRotation + 360) % 360;
        if (rotation == 90) return new float[]{clamp(1f - y), clamp(x)};
        if (rotation == 180) return new float[]{clamp(1f - x), clamp(1f - y)};
        if (rotation == 270) return new float[]{clamp(y), clamp(1f - x)};
        return new float[]{clamp(x), clamp(y)};
    }

    private static float clamp(float value) {
        return Math.max(0.05f, Math.min(0.95f, value));
    }
}
