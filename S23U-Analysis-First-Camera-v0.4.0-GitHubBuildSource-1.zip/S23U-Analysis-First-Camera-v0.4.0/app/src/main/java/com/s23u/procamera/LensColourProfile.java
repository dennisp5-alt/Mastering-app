package com.s23u.procamera;

/**
 * Per-lens colour calibration profile. Learned offsets are deliberately small,
 * confidence weighted and may remain zero indefinitely when trustworthy neutral
 * evidence is unavailable.
 */
final class LensColourProfile {
    final String lens;
    final double uBias;
    final double vBias;
    final double maxCorrection;
    final int calibrationSamples;
    final double calibrationConfidence;

    LensColourProfile(String lens, double uBias, double vBias, double maxCorrection,
                      int calibrationSamples, double calibrationConfidence) {
        this.lens = lens;
        this.uBias = uBias;
        this.vBias = vBias;
        this.maxCorrection = maxCorrection;
        this.calibrationSamples = Math.max(0, calibrationSamples);
        this.calibrationConfidence = Math.max(0.0, Math.min(1.0, calibrationConfidence));
    }

    static LensColourProfile forLens(String lens) {
        return baseForLens(lens, 0.0, 0.0, 0, 0.0);
    }

    static LensColourProfile calibrated(String lens, double learnedU, double learnedV,
                                        int samples) {
        double confidence = Math.min(1.0, Math.max(0, samples) / 10.0);
        // Do not let a small evidence set steer colour strongly. Full effect is
        // reached only after repeated agreement across neutral scenes.
        double scale = confidence;
        double u = clamp(learnedU, -3.0, 3.0) * scale;
        double v = clamp(learnedV, -3.0, 3.0) * scale;
        return baseForLens(lens, u, v, samples, confidence);
    }

    private static LensColourProfile baseForLens(String lens, double uBias, double vBias,
                                                  int samples, double confidence) {
        if ("ULTRA_WIDE".equals(lens)) {
            return new LensColourProfile(lens, uBias, vBias, 0.020, samples, confidence);
        }
        if ("TELE_3X".equals(lens)) {
            return new LensColourProfile(lens, uBias, vBias, 0.018, samples, confidence);
        }
        if ("TELE_10X".equals(lens)) {
            return new LensColourProfile(lens, uBias, vBias, 0.015, samples, confidence);
        }
        return new LensColourProfile("MAIN_1X", uBias, vBias, 0.022, samples, confidence);
    }

    String calibrationLabel() {
        if (calibrationSamples <= 0) return "uncalibrated-safe";
        return "learned " + calibrationSamples + "/10";
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }
}
