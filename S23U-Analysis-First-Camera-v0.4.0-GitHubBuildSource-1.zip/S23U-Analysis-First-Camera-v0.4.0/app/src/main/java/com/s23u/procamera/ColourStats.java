package com.s23u.procamera;

import android.os.SystemClock;

/** Live YUV colour evidence measured before capture. */
final class ColourStats {
    static final ColourStats UNAVAILABLE = new ColourStats(false, 0.0, 128.0, 128.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0L);

    final boolean valid;
    final double neutralEvidence;
    final double neutralU;
    final double neutralV;
    final double neutralSpread;
    final double mixedLightScore;
    final double skyFraction;
    final double foliageFraction;
    final double skinFraction;
    final double castStrength;
    final double evidenceConfidence;
    final double castConfidence;
    final double stabilityScore;
    final long timestampMs;

    ColourStats(boolean valid, double neutralEvidence, double neutralU, double neutralV,
                double neutralSpread, double mixedLightScore, double skyFraction,
                double foliageFraction, double skinFraction, double castStrength,
                double evidenceConfidence, double castConfidence,
                double stabilityScore, long timestampMs) {
        this.valid = valid;
        this.neutralEvidence = neutralEvidence;
        this.neutralU = neutralU;
        this.neutralV = neutralV;
        this.neutralSpread = neutralSpread;
        this.mixedLightScore = mixedLightScore;
        this.skyFraction = skyFraction;
        this.foliageFraction = foliageFraction;
        this.skinFraction = skinFraction;
        this.castStrength = castStrength;
        this.evidenceConfidence = evidenceConfidence;
        this.castConfidence = castConfidence;
        this.stabilityScore = stabilityScore;
        this.timestampMs = timestampMs;
    }

    boolean isFresh() {
        return valid && SystemClock.elapsedRealtime() - timestampMs <= 1800L;
    }

    boolean enoughNeutralEvidence() {
        return valid && evidenceConfidence >= 0.30;
    }
}
