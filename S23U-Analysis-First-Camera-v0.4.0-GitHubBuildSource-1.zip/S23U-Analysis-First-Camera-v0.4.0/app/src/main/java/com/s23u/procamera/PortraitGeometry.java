package com.s23u.procamera;

final class PortraitGeometry {
    private static final float MAIN_LENS_MIN_ZOOM = 0.82f;
    private static final float MAIN_LENS_MAX_ZOOM = 1.45f;
    private static final float CLOSE_FACE_WIDTH_FRACTION = 0.16f;

    private PortraitGeometry() { }

    static boolean hasCloseWideAngleRisk(float zoom, int faceWidth, int sensorWidth) {
        if (zoom < MAIN_LENS_MIN_ZOOM || zoom > MAIN_LENS_MAX_ZOOM
                || faceWidth <= 0 || sensorWidth <= 0) return false;
        return faceWidth / (float) sensorWidth >= CLOSE_FACE_WIDTH_FRACTION;
    }
}
