package com.s23u.procamera;

final class LensClassifier {
    private LensClassifier() { }

    static String fromFocalLength(double focalLengthMm) {
        if (!Double.isFinite(focalLengthMm) || focalLengthMm <= 0.0) return "UNKNOWN";
        if (focalLengthMm < 4.2) return "ULTRA_WIDE";
        if (focalLengthMm < 7.2) return "MAIN_1X";
        if (focalLengthMm < 18.0) return "TELE_3X";
        return "TELE_10X";
    }

    static String expectedForZoom(float zoomRatio) {
        if (zoomRatio < 0.82f) return "ULTRA_WIDE";
        if (zoomRatio <= 1.45f) return "MAIN_1X";
        if (zoomRatio < 7.5f) return "TELE_3X";
        return "TELE_10X";
    }
}
