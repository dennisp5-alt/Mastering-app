package com.s23u.procamera;

final class SceneStats {
    static final SceneStats UNAVAILABLE = new SceneStats(false, 0.0, 0, 0, 0,
            0.0, 0.0, 0.0, 0L);

    final boolean valid;
    final double meanLuma;
    final int p05;
    final int p50;
    final int p95;
    final double shadowFraction;
    final double highlightFraction;
    final double stabilityScore;
    final long timestampMs;

    SceneStats(boolean valid, double meanLuma, int p05, int p50, int p95,
               double shadowFraction, double highlightFraction, long timestampMs) {
        this(valid, meanLuma, p05, p50, p95, shadowFraction, highlightFraction,
                1.0, timestampMs);
    }

    SceneStats(boolean valid, double meanLuma, int p05, int p50, int p95,
               double shadowFraction, double highlightFraction,
               double stabilityScore, long timestampMs) {
        this.valid = valid;
        this.meanLuma = meanLuma;
        this.p05 = p05;
        this.p50 = p50;
        this.p95 = p95;
        this.shadowFraction = shadowFraction;
        this.highlightFraction = highlightFraction;
        this.stabilityScore = stabilityScore;
        this.timestampMs = timestampMs;
    }

    int tonalRange() {
        return p95 - p05;
    }

    boolean meteringStable() {
        return valid && stabilityScore >= 0.62;
    }
}
