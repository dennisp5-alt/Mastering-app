package com.s23u.procamera;

import java.util.Locale;

final class SmartAutoEngine {
    enum Route {
        STANDARD,
        HDR,
        NIGHT
    }

    static final class Decision {
        final Route route;
        final String reason;

        Decision(Route route, String reason) {
            this.route = route;
            this.reason = reason;
        }

        String shortLabel() {
            return route.name() + " · " + reason;
        }
    }

    private SmartAutoEngine() { }

    static Decision decide(SceneStats scene, int iso, long exposureNs,
                           boolean faceDetected, boolean hdrAvailable,
                           boolean nightAvailable, float requestedZoom,
                           boolean flashForced) {
        if (Math.abs(requestedZoom - 1.0f) > 0.08f) {
            return new Decision(Route.STANDARD,
                    String.format(Locale.US, "lens priority %.1f×", requestedZoom));
        }
        if (flashForced) {
            return new Decision(Route.STANDARD, "flash priority");
        }

        boolean lowLight = (exposureNs >= 40_000_000L)
                || (iso >= 800)
                || (scene.valid && scene.meanLuma < 52.0 && scene.p95 < 178);
        if (lowLight && nightAvailable) {
            if (exposureNs >= 40_000_000L) {
                return new Decision(Route.NIGHT, "shutter slower than 1/25 s");
            }
            if (iso >= 800) {
                return new Decision(Route.NIGHT, "high ISO " + iso);
            }
            return new Decision(Route.NIGHT, "low preview luminance");
        }

        boolean difficultRange = scene.valid
                && scene.tonalRange() >= 168
                && scene.highlightFraction >= 0.012
                && scene.shadowFraction >= 0.085;
        boolean backlitFace = faceDetected && scene.valid
                && scene.tonalRange() >= 148
                && scene.highlightFraction >= 0.018
                && scene.shadowFraction >= 0.075;
        if ((difficultRange || backlitFace) && hdrAvailable) {
            return new Decision(Route.HDR,
                    backlitFace ? "backlit face protection" : "extreme tonal range");
        }

        if (lowLight) {
            return new Decision(Route.STANDARD, "Night extension unavailable");
        }
        if (difficultRange || backlitFace) {
            return new Decision(Route.STANDARD, "HDR extension unavailable");
        }
        return new Decision(Route.STANDARD, "natural rendering");
    }
}
