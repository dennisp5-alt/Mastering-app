package com.s23u.procamera;

import java.util.Locale;

final class DeviceGate {
    private DeviceGate() { }

    static boolean isGalaxyS23Ultra(String manufacturer, String model) {
        if (manufacturer == null || model == null) return false;
        return manufacturer.toLowerCase(Locale.US).contains("samsung")
                && model.toUpperCase(Locale.US).startsWith("SM-S918");
    }
}
