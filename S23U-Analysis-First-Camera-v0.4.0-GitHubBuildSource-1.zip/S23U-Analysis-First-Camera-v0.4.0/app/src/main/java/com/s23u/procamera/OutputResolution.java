package com.s23u.procamera;

final class OutputResolution {
    static final int TARGET_LONG_EDGE = 4080;
    static final int TARGET_SHORT_EDGE = 3060;

    private OutputResolution() { }

    static boolean isFullSize(int width, int height) {
        if (width <= 0 || height <= 0) return false;
        int longEdge = Math.max(width, height);
        int shortEdge = Math.min(width, height);
        return longEdge >= TARGET_LONG_EDGE && shortEdge >= TARGET_SHORT_EDGE;
    }

    static String dimensions(int width, int height) {
        return width > 0 && height > 0 ? width + "x" + height : "UNKNOWN";
    }
}
