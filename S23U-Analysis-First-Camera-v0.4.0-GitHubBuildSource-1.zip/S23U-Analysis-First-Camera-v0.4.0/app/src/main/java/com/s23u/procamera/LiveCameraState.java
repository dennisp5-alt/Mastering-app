package com.s23u.procamera;

import android.graphics.Rect;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.params.Face;
import android.os.SystemClock;

final class LiveCameraState {
    volatile int iso = -1;
    volatile long exposureNs = -1L;
    volatile float focalLengthMm = Float.NaN;
    volatile String physicalCameraId;
    volatile int afState = -1;
    volatile int aeState = -1;
    volatile int faceCount = 0;
    volatile Rect largestFace;
    volatile long updatedMs = 0L;

    void reset() {
        iso = -1;
        exposureNs = -1L;
        focalLengthMm = Float.NaN;
        physicalCameraId = null;
        afState = -1;
        aeState = -1;
        faceCount = 0;
        largestFace = null;
        updatedMs = 0L;
    }

    void update(CaptureResult result) {
        Integer newIso = result.get(CaptureResult.SENSOR_SENSITIVITY);
        Long newExposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
        Float newFocal = result.get(CaptureResult.LENS_FOCAL_LENGTH);
        String newPhysical = result.get(
                CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
        Integer newAf = result.get(CaptureResult.CONTROL_AF_STATE);
        Integer newAe = result.get(CaptureResult.CONTROL_AE_STATE);
        Face[] faces = result.get(CaptureResult.STATISTICS_FACES);

        if (newIso != null) iso = newIso;
        if (newExposure != null) exposureNs = newExposure;
        if (newFocal != null) focalLengthMm = newFocal;
        // Do not retain a physical ID after Samsung stops reporting it; a stale ID
        // could otherwise release Optical Lock for the wrong lens.
        physicalCameraId = newPhysical == null || newPhysical.isEmpty() ? null : newPhysical;
        if (newAf != null) afState = newAf;
        if (newAe != null) aeState = newAe;
        faceCount = faces == null ? 0 : faces.length;
        largestFace = largestFace(faces);
        updatedMs = SystemClock.elapsedRealtime();
    }

    boolean isFresh() {
        return SystemClock.elapsedRealtime() - updatedMs <= 1600L;
    }

    String actualLens(CameraHardwareMap hardwareMap) {
        CameraHardwareMap.LensInfo lens = hardwareMap == null
                ? null : hardwareMap.lensForId(physicalCameraId);
        if (lens != null) return lens.lensClass;
        return Float.isFinite(focalLengthMm)
                ? LensClassifier.fromFocalLength(focalLengthMm) : "UNKNOWN";
    }


    boolean focusBusy() {
        return afState == CaptureResult.CONTROL_AF_STATE_ACTIVE_SCAN
                || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_SCAN;
    }

    boolean aeBusy() {
        return aeState == CaptureResult.CONTROL_AE_STATE_SEARCHING
                || aeState == CaptureResult.CONTROL_AE_STATE_PRECAPTURE;
    }

    boolean focusWarning() {
        return afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED;
    }

    private static Rect largestFace(Face[] faces) {
        if (faces == null || faces.length == 0) return null;
        Rect best = null;
        long bestArea = -1L;
        for (Face face : faces) {
            Rect bounds = face.getBounds();
            long area = (long) bounds.width() * bounds.height();
            if (area > bestArea) {
                bestArea = area;
                best = new Rect(bounds);
            }
        }
        return best;
    }
}
