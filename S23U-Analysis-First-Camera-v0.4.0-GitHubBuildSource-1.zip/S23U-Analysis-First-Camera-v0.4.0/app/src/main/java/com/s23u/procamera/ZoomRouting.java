package com.s23u.procamera;

final class ZoomRouting {
    private ZoomRouting() { }

    static boolean shouldGuardOpticalLens(boolean smartAuto, boolean opticalLockEnabled,
                                          float requestedZoom, String physicalCameraId) {
        return smartAuto && opticalLockEnabled && physicalCameraId != null
                && Math.abs(requestedZoom - 1.0f) > 0.05f;
    }

    static float cameraZoomRatio(float requestedZoom) {
        // The logical multi-camera route retains Samsung's full-size JPEG stream. Optical
        // Lock now verifies the active physical lens from capture metadata instead of
        // forcing a smaller direct physical-camera stream.
        return requestedZoom;
    }
}
