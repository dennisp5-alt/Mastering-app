package com.s23u.procamera;

import java.util.Locale;

/** Confidence-gated colour decision; never infers a cast from scene colour alone. */
final class TrueColourDecision {
    enum Action { NO_EVIDENCE, NO_CAST, PRESERVE_MIXED_LIGHT, WITHHOLD, CORRECT }

    final Action action;
    final String castName;
    final double evidenceConfidence;
    final double castConfidence;
    final double maxGainDelta;
    final String lensProfile;
    final double lensUBias;
    final double lensVBias;
    final int calibrationSamples;
    final double calibrationConfidence;

    private TrueColourDecision(Action action, String castName, double evidenceConfidence,
                               double castConfidence, double maxGainDelta,
                               LensColourProfile profile) {
        this.action = action;
        this.castName = castName;
        this.evidenceConfidence = evidenceConfidence;
        this.castConfidence = castConfidence;
        this.maxGainDelta = maxGainDelta;
        LensColourProfile safe = profile == null
                ? LensColourProfile.forLens("MAIN_1X") : profile;
        this.lensProfile = safe.lens;
        this.lensUBias = safe.uBias;
        this.lensVBias = safe.vBias;
        this.calibrationSamples = safe.calibrationSamples;
        this.calibrationConfidence = safe.calibrationConfidence;
    }

    static TrueColourDecision decide(ColourStats stats, String expectedLens, boolean faceDetected) {
        return decide(stats, LensColourProfile.forLens(expectedLens), faceDetected);
    }

    static TrueColourDecision decide(ColourStats stats, LensColourProfile profile,
                                     boolean faceDetected) {
        if (profile == null) profile = LensColourProfile.forLens("MAIN_1X");
        if (stats == null || !stats.isFresh() || stats.evidenceConfidence < 0.30) {
            return new TrueColourDecision(Action.NO_EVIDENCE, "undecided",
                    stats == null ? 0.0 : stats.evidenceConfidence,
                    stats == null ? 0.0 : stats.castConfidence, 0.0, profile);
        }
        // Remove the learned sensor/lens residual before deciding whether the
        // illumination itself is biased. The learned residual is corrected later
        // as its own tiny per-lens chroma calibration in the finishing stage.
        double u = stats.neutralU - 128.0 - profile.uBias;
        double v = stats.neutralV - 128.0 - profile.vBias;
        double strength = Math.hypot(u, v);
        String cast = castName(u, v);
        if (stats.mixedLightScore >= 0.58) {
            return new TrueColourDecision(Action.PRESERVE_MIXED_LIGHT, cast,
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile);
        }
        if (strength < 3.6) {
            return new TrueColourDecision(Action.NO_CAST, "none",
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile);
        }
        if (stats.castConfidence < 0.42 || stats.stabilityScore < 0.45) {
            return new TrueColourDecision(Action.WITHHOLD, cast,
                    stats.evidenceConfidence, stats.castConfidence, 0.0, profile);
        }
        double cap = profile.maxCorrection;
        if (faceDetected || stats.skinFraction > 0.05) cap = Math.min(cap, 0.014);
        double confidenceScale = Math.min(1.0, Math.max(0.0,
                (stats.castConfidence - 0.42) / 0.40));
        cap *= 0.55 + 0.45 * confidenceScale;
        return new TrueColourDecision(Action.CORRECT, cast,
                stats.evidenceConfidence, stats.castConfidence, cap, profile);
    }

    boolean correctionAllowed() {
        return action == Action.CORRECT && maxGainDelta > 0.0;
    }

    boolean lensCalibrationActive() {
        return calibrationSamples > 0 && calibrationConfidence > 0.0
                && (Math.abs(lensUBias) >= 0.05 || Math.abs(lensVBias) >= 0.05);
    }

    String shortLabel() {
        switch (action) {
            case NO_CAST: return "no cast";
            case PRESERVE_MIXED_LIGHT: return "mixed light preserved";
            case WITHHOLD: return "cast withheld";
            case CORRECT: return "correct " + castName;
            default: return "colour undecided";
        }
    }

    String diagnostic() {
        String calibration = calibrationSamples <= 0 ? "cal safe-zero"
                : String.format(Locale.US, "cal %d/10 %.0f%%", calibrationSamples,
                calibrationConfidence * 100.0);
        return String.format(Locale.US, "%s · evidence %.0f%% · cast %.0f%% · lens %s · %s",
                shortLabel(), evidenceConfidence * 100.0, castConfidence * 100.0,
                lensProfile, calibration);
    }

    private static String castName(double u, double v) {
        if (Math.abs(u) >= Math.abs(v)) return u > 0 ? "cool/blue" : "warm/yellow";
        return v > 0 ? "red/magenta" : "green/cyan";
    }
}
