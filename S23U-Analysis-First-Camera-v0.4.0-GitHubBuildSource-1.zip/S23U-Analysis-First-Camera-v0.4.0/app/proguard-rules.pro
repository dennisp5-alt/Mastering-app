# Test build: code shrinking is intentionally disabled.
