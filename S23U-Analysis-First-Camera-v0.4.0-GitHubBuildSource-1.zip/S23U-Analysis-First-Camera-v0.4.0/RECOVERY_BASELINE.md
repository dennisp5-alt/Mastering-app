# Recovery baseline

Analysis First Camera **0.3.0** is the permanent colour/tone baseline for this branch. v0.4.0 must not retune True Colour, lens colour calibration, Natural Tonality or Stability Guard to compensate for a detail/noise problem.

If v0.4.0 weakens skin, foliage, transients/fine edges, 10x stability, colour or tonal behaviour, compare against v0.3.0 and Standard control first and adjust only the Detail IQ stage.

The inherited optical guard, lens routing, orientation handling and maximum-quality CameraX JPEG path remain protected.
