# Validation notes — 0.4.0

This source keeps the proven v0.3.0 colour/tone baseline unchanged and adds a separate conservative Detail IQ stage.

The new stage is driven by **captured ISO plus actual EXIF focal length** (falling back to requested lens only when focal metadata is unavailable). It uses four ISO bands per lens and intentionally shifts from detail-first to noise-first as ISO rises.

The pixel algorithm is local and bounded: smooth-area noise reduction uses immediate neighbours only when local luminance variation is low, while micro-detail enhancement is edge-aware and capped to 1–3 code values. Skin, foliage and smooth blue regions receive extra protection. It does not hallucinate detail, upscale, deblur or apply global sharpening.

Host checks validate profile selection and conservative high-ISO behaviour in addition to the inherited optical/stability guards, True Colour confidence gates, lens calibration and Natural Tone endpoints. A stub compile of the finishing stage also passes. Physical S23 Ultra testing remains authoritative.
