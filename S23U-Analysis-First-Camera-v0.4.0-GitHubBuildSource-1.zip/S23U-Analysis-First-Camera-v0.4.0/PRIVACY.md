# Privacy

Analysis First Camera is an offline personal test application.

- Camera permission only.
- No Internet, analytics, advertising, accounts or cloud services.
- No microphone, location, contacts or existing-photo permission.
- Live preview analysis stays in memory on the device.
- New JPEGs are written only to `DCIM/Analysis First Camera`.
