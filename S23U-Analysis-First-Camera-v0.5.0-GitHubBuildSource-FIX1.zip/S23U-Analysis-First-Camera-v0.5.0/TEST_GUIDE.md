# v0.5.0 test guide

The main goal is to prove that Computational Capture improves difficult scenes without weakening the already-good v0.4 colour/tone/detail baseline.

Recommended matched tests:

1. 1x clean daylight: should remain fast and natural; usually single-frame.
2. 1x high dynamic range: bright sky + darker foreground. Check highlight retention and shadow cleanliness.
3. 3x portrait/detail: check hair, fabric and skin. Look specifically for double edges or motion ghosts.
4. 3x foliage: moving leaves should be protected rather than smeared by fusion.
5. 10x handheld: compare fine detail, noise and stability with v0.4.0/0.4.1.
6. 0.6x architecture/fence lines: inspect edges/corners for geometry and colour-fringe behaviour.
7. Mixed indoor/outdoor light: True Colour should remain conservative as before.

A computational result reports captured frames, fused frames, alignment confidence and motion-rejected pixels in Diagnostics/EXIF. If confidence is low, the app should explicitly keep the sharpest frame instead of forcing fusion.
