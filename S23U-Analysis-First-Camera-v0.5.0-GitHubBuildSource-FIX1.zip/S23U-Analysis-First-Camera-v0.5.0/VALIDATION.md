# Validation policy

v0.5.0 must not retune True Colour, Natural Tone or Lens/ISO Detail IQ to compensate for computational-capture problems. If fusion weakens detail, creates ghosting, changes colour or adds latency without benefit, fix or bypass only the computational layer.

Acceptance rules:

- no forced fusion when alignment confidence is poor,
- moving local regions are rejected from the merge,
- sharpest-frame fallback must always remain available,
- OEM HDR/Night is not double-stacked,
- Standard remains untouched,
- high-quality optical requests are made only for modes reported by the camera HAL.
