# Recovery baseline

The permanent rendering baseline remains the proven v0.3/v0.4 True Colour + Natural Tone + Lens/ISO Detail IQ character. v0.5.0 is an additive capture-layer experiment.

If a v0.5.0 result looks worse, compare against v0.4.1 and Standard first. Do not compensate by increasing sharpening, saturation, denoise or global tone strength. Disable/fix the computational path that caused the regression.
