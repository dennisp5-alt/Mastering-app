package com.s23u.procamera;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.camera2.interop.Camera2Interop;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.FocusMeteringResult;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.core.ZoomState;
import androidx.camera.extensions.ExtensionMode;
import androidx.camera.extensions.ExtensionsManager;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class MainActivity extends ComponentActivity {
    private static final String VERSION = "0.5.0";
    private static final int CAMERA_PERMISSION_REQUEST = 701;
    private static final long SESSION_START_TIMEOUT_MS = 5000L;
    private static final String OUTPUT_FOLDER = Environment.DIRECTORY_DCIM
            + "/Analysis First Camera";
    private static final String STATE_MODE_TAG = "state_mode_tag";
    private static final String STATE_ZOOM = "state_zoom";
    private static final String STATE_FLASH = "state_flash";
    private static final String STATE_OPTICAL_LOCK = "state_optical_lock";
    private static final String STATE_TRUE_COLOUR = "state_true_colour";
    private static final String STATE_LAST_URI = "state_last_uri";

    private final List<ModeOption> modes = new ArrayList<>();
    private final ExecutorService metadataExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final LiveCameraState liveState = new LiveCameraState();
    private MotionStabilityTracker stabilityTracker;
    private LensCalibrationStore calibrationStore;

    private PreviewView previewView;
    private FocusRingView focusRing;
    private Spinner modeSpinner;
    private TextView statusText;
    private TextView metadataText;
    private TextView zoomText;
    private TextView lensText;
    private TextView smartText;
    private Button captureButton;
    private Button flashButton;
    private Button lastPhotoButton;
    private Button opticalLockButton;
    private Button trueColourButton;
    private Button nightModeButton;
    private Button portraitModeButton;
    private Button photoModeButton;
    private Button standardModeButton;
    private Button moreModeButton;
    private final List<Button> zoomButtons = new ArrayList<>();

    private ProcessCameraProvider cameraProvider;
    private ExtensionsManager extensionsManager;
    private Camera boundCamera;
    private ImageCapture imageCapture;
    private ImageAnalysis imageAnalysis;
    private SceneAnalyzer sceneAnalyzer;
    private CameraHardwareMap hardwareMap;
    private ModeOption selectedMode;
    private ModeOption activeBoundMode;
    private ModeOption standardMode;
    private ModeOption hdrMode;
    private ModeOption nightMode;
    private float requestedZoom = 1.0f;
    private int flashMode = ImageCapture.FLASH_MODE_AUTO;
    private Uri lastSavedUri;
    private boolean deviceSupported;
    private boolean opticalLockEnabled = true;
    private boolean trueColourEnabled = true;
    private boolean captureInProgress;
    private boolean cameraSessionReady;
    private boolean sessionActivationInProgress;
    private String activeOpticalGuardId;
    private String restoredModeTag = "SMART_AUTO";
    private int bindGeneration;
    private Runnable sessionTimeout;
    private long lastLiveUiPostMs;
    private long lastUserMeterMs;
    private long lastFaceMeterMs;
    private int analysisExposureIndex;

    private final CameraCaptureSession.CaptureCallback liveCaptureCallback =
            new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession session,
                                               CaptureRequest request,
                                               TotalCaptureResult result) {
                    liveState.update(result);
                    postLiveUiUpdate();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        restoreUiState(savedInstanceState);
        deviceSupported = DeviceGate.isGalaxyS23Ultra(Build.MANUFACTURER, Build.MODEL);
        buildInterface();
        stabilityTracker = new MotionStabilityTracker(this);
        calibrationStore = new LensCalibrationStore(this);

        if (!deviceSupported) {
            statusText.setText("Unsupported device: " + Build.MANUFACTURER + " " + Build.MODEL
                    + "\nThis experiment is locked to Galaxy S23 Ultra (SM-S918 variants).");
            captureButton.setEnabled(false);
            modeSpinner.setEnabled(false);
            return;
        }

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            initialiseCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (stabilityTracker != null) stabilityTracker.start();
    }

    @Override
    protected void onStop() {
        if (stabilityTracker != null) stabilityTracker.stop();
        super.onStop();
    }

    private void restoreUiState(Bundle state) {
        if (state == null) return;
        restoredModeTag = state.getString(STATE_MODE_TAG, "SMART_AUTO");
        requestedZoom = state.getFloat(STATE_ZOOM, 1.0f);
        flashMode = state.getInt(STATE_FLASH, ImageCapture.FLASH_MODE_AUTO);
        opticalLockEnabled = state.getBoolean(STATE_OPTICAL_LOCK, true);
        trueColourEnabled = state.getBoolean(STATE_TRUE_COLOUR, true);
        String lastUri = state.getString(STATE_LAST_URI);
        if (lastUri != null && !lastUri.isEmpty()) lastSavedUri = Uri.parse(lastUri);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(STATE_MODE_TAG,
                selectedMode == null ? restoredModeTag : selectedMode.tag);
        outState.putFloat(STATE_ZOOM, requestedZoom);
        outState.putInt(STATE_FLASH, flashMode);
        outState.putBoolean(STATE_OPTICAL_LOCK, opticalLockEnabled);
        outState.putBoolean(STATE_TRUE_COLOUR, trueColourEnabled);
        if (lastSavedUri != null) outState.putString(STATE_LAST_URI, lastSavedUri.toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != CAMERA_PERMISSION_REQUEST) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initialiseCamera();
        } else {
            statusText.setText("Camera permission is required. Reopen the app and grant access.");
            captureButton.setEnabled(false);
        }
    }

    private void buildInterface() {
        int background = Color.rgb(4, 5, 6);
        int surface = Color.rgb(18, 20, 22);
        int surfaceRaised = Color.rgb(31, 34, 37);
        int accent = Color.rgb(238, 196, 82);
        int accentSoft = Color.rgb(111, 224, 199);
        int text = Color.rgb(247, 248, 249);
        int muted = Color.rgb(163, 168, 173);
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        // These views remain alive for diagnostics, but the main camera screen no longer
        // exposes the developer/test panels.
        modeSpinner = new Spinner(this);
        zoomText = new TextView(this);
        lensText = new TextView(this);
        smartText = new TextView(this);
        metadataText = new TextView(this);
        lensText.setText("Live sensor: waiting for metadata");
        smartText.setText("Analysis First is reading the scene…");
        metadataText.setText("Photos save separately to DCIM/Analysis First Camera");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);

        // Minimal top controls inspired by modern flagship camera layouts, while keeping
        // Analysis First as a distinct app rather than copying another vendor's UI.
        LinearLayout topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(10), dp(3), dp(8), dp(3));
        topBar.setBackgroundColor(Color.BLACK);

        TextView brand = new TextView(this);
        brand.setText("A  Analysis First");
        brand.setTextColor(text);
        brand.setTextSize(13f);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setTypeface(brand.getTypeface(), android.graphics.Typeface.BOLD);
        topBar.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1f));

        flashButton = makeTopButton(flashCompactLabel());
        flashButton.setOnClickListener(v -> cycleFlash());
        topBar.addView(flashButton, fixedTopParams(46));

        TextView resolution = makeTopLabel("12M");
        topBar.addView(resolution, fixedTopParams(48));
        TextView exposure = makeTopLabel("±0.0");
        topBar.addView(exposure, fixedTopParams(50));

        opticalLockButton = makeTopButton("LOCK");
        opticalLockButton.setOnClickListener(v -> toggleOpticalLock());
        topBar.addView(opticalLockButton, fixedTopParams(52));

        trueColourButton = makeTopButton("TC");
        trueColourButton.setOnClickListener(v -> toggleTrueColour());
        topBar.addView(trueColourButton, fixedTopParams(42));

        Button menuButton = makeTopButton("⋮");
        menuButton.setTextSize(22f);
        menuButton.setOnClickListener(v -> showMoreMenu());
        topBar.addView(menuButton, fixedTopParams(38));
        root.addView(topBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        FrameLayout previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        previewView.setBackgroundColor(Color.BLACK);
        previewFrame.addView(previewView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        GridOverlayView grid = new GridOverlayView(this);
        previewFrame.addView(grid, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        focusRing = new FocusRingView(this);
        previewFrame.addView(focusRing, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        previewView.setOnTouchListener(this::handlePreviewTouch);

        statusText = new TextView(this);
        statusText.setText("Starting…");
        statusText.setTextColor(text);
        statusText.setTextSize(11.5f);
        statusText.setGravity(Gravity.CENTER);
        statusText.setMaxLines(2);
        statusText.setPadding(dp(10), dp(5), dp(10), dp(5));
        statusText.setBackground(roundedDrawable(
                Color.argb(185, 12, 14, 16), Color.argb(160, 86, 91, 96), 15));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(42), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        statusParams.topMargin = dp(10);
        statusParams.leftMargin = dp(18);
        statusParams.rightMargin = dp(18);
        previewFrame.addView(statusText, statusParams);

        LinearLayout zoomPill = new LinearLayout(this);
        zoomPill.setGravity(Gravity.CENTER);
        zoomPill.setPadding(dp(7), dp(4), dp(7), dp(4));
        zoomPill.setBackground(roundedDrawable(
                Color.argb(210, 16, 17, 19), Color.argb(170, 70, 74, 78), 24));
        zoomButtons.clear();
        addZoomButton(zoomPill, "0.6", 0.6f);
        addZoomButton(zoomPill, "1×", 1.0f);
        addZoomButton(zoomPill, "3×", 3.0f);
        addZoomButton(zoomPill, "10×", 10.0f);
        FrameLayout.LayoutParams zoomParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(50), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        zoomParams.leftMargin = dp(48);
        zoomParams.rightMargin = dp(48);
        zoomParams.bottomMargin = dp(12);
        previewFrame.addView(zoomPill, zoomParams);

        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(previewFrame, previewParams);

        LinearLayout bottomPanel = new LinearLayout(this);
        bottomPanel.setOrientation(LinearLayout.VERTICAL);
        bottomPanel.setBackgroundColor(Color.BLACK);
        bottomPanel.setPadding(dp(12), dp(8), dp(12), dp(4));

        LinearLayout shutterRow = new LinearLayout(this);
        shutterRow.setGravity(Gravity.CENTER);

        lastPhotoButton = makeCircleButton("▣", 60, surfaceRaised, Color.rgb(90, 94, 98));
        lastPhotoButton.setTextSize(22f);
        lastPhotoButton.setEnabled(lastSavedUri != null);
        lastPhotoButton.setOnClickListener(v -> openLastPhoto());
        LinearLayout.LayoutParams leftCircle = new LinearLayout.LayoutParams(dp(60), dp(60));
        leftCircle.rightMargin = dp(48);
        shutterRow.addView(lastPhotoButton, leftCircle);

        FrameLayout shutterHolder = new FrameLayout(this);
        captureButton = makeCircleButton("", 82, Color.rgb(249, 248, 245), Color.rgb(129, 132, 135));
        captureButton.setEnabled(false);
        captureButton.setOnClickListener(v -> capturePhoto());
        FrameLayout.LayoutParams shutterParams = new FrameLayout.LayoutParams(
                dp(82), dp(82), Gravity.CENTER);
        shutterHolder.addView(captureButton, shutterParams);
        shutterRow.addView(shutterHolder, new LinearLayout.LayoutParams(dp(92), dp(88)));

        Button diagnosticsButton = makeCircleButton("⋯", 60, surfaceRaised, Color.rgb(90, 94, 98));
        diagnosticsButton.setTextSize(22f);
        diagnosticsButton.setOnClickListener(v -> showMoreMenu());
        LinearLayout.LayoutParams rightCircle = new LinearLayout.LayoutParams(dp(60), dp(60));
        rightCircle.leftMargin = dp(48);
        shutterRow.addView(diagnosticsButton, rightCircle);
        bottomPanel.addView(shutterRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(90)));

        LinearLayout modeStrip = new LinearLayout(this);
        modeStrip.setGravity(Gravity.CENTER);
        nightModeButton = makeModeButton("NIGHT");
        nightModeButton.setOnClickListener(v -> selectModeByTag("OEM_NIGHT"));
        modeStrip.addView(nightModeButton, weightedModeParams());

        portraitModeButton = makeModeButton("PORTRAIT");
        portraitModeButton.setOnClickListener(v -> selectModeByTag("OEM_BOKEH"));
        modeStrip.addView(portraitModeButton, weightedModeParams());

        photoModeButton = makeModeButton("PHOTO");
        photoModeButton.setOnClickListener(v -> selectModeByTag("SMART_AUTO"));
        modeStrip.addView(photoModeButton, weightedModeParams());

        standardModeButton = makeModeButton("STANDARD");
        standardModeButton.setOnClickListener(v -> selectModeByTag("STANDARD"));
        modeStrip.addView(standardModeButton, weightedModeParams());

        moreModeButton = makeModeButton("MORE");
        moreModeButton.setOnClickListener(v -> showMoreMenu());
        modeStrip.addView(moreModeButton, weightedModeParams());
        bottomPanel.addView(modeStrip, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46)));

        if (landscape) {
            // Keep the same clean controls in landscape; preview still receives the majority
            // of the screen instead of falling back to the old diagnostic side panel.
            bottomPanel.setPadding(dp(24), dp(4), dp(24), dp(2));
        }

        root.addView(bottomPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(152)));
        setContentView(root);
        updateZoomButtonStyles();
        updateToggleStyles();
    }

    private LinearLayout.LayoutParams fixedTopParams(int widthDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(widthDp), dp(44));
        params.leftMargin = dp(1);
        params.rightMargin = dp(1);
        return params;
    }

    private TextView makeTopLabel(String value) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setGravity(Gravity.CENTER);
        label.setTextColor(Color.rgb(244, 245, 246));
        label.setTextSize(14f);
        label.setTypeface(label.getTypeface(), android.graphics.Typeface.BOLD);
        return label;
    }

    private Button makeTopButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextColor(Color.rgb(242, 244, 245));
        button.setTextSize(11f);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setBackground(roundedDrawable(Color.TRANSPARENT, Color.TRANSPARENT, 18));
        return button;
    }

    private Button makeCircleButton(String value, int diameterDp, int fill, int stroke) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setPadding(0, 0, 0, 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(fill);
        circle.setStroke(dp(2), stroke);
        button.setBackground(circle);
        button.setWidth(dp(diameterDp));
        button.setHeight(dp(diameterDp));
        return button;
    }

    private Button makeModeButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextColor(Color.rgb(154, 158, 163));
        button.setTextSize(10.5f);
        button.setPadding(dp(2), 0, dp(2), 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private LinearLayout.LayoutParams weightedModeParams() {
        return new LinearLayout.LayoutParams(0, dp(42), 1f);
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11f);
        button.setAllCaps(false);
        button.setTextColor(Color.rgb(235, 238, 240));
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setBackground(roundedDrawable(Color.rgb(35, 40, 44),
                Color.rgb(61, 68, 73), 14));
        return button;
    }

    private GradientDrawable roundedDrawable(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(Math.max(1, dp(1)), stroke);
        return drawable;
    }

    private void addZoomButton(LinearLayout row, String label, float zoom) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.rgb(236, 238, 240));
        button.setTextSize(12f);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setTag(zoom);
        button.setOnClickListener(v -> requestZoom(zoom));
        zoomButtons.add(button);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(40), 1f);
        params.leftMargin = dp(2);
        params.rightMargin = dp(2);
        row.addView(button, params);
    }

    private void updateZoomButtonStyles() {
        for (Button button : zoomButtons) {
            Object tag = button.getTag();
            float zoom = tag instanceof Float ? (Float) tag : -1f;
            boolean selected = Math.abs(zoom - requestedZoom) < 0.06f;
            button.setTextColor(Color.WHITE);
            button.setTypeface(button.getTypeface(), selected
                    ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            button.setBackground(roundedDrawable(
                    selected ? Color.rgb(70, 73, 77) : Color.TRANSPARENT,
                    Color.TRANSPARENT, 18));
        }
    }

    private String flashCompactLabel() {
        if (flashMode == ImageCapture.FLASH_MODE_ON) return "FLASH";
        if (flashMode == ImageCapture.FLASH_MODE_OFF) return "OFF";
        return "AUTO";
    }

    private void updateToggleStyles() {
        if (opticalLockButton != null) {
            opticalLockButton.setText("LOCK");
            opticalLockButton.setTextColor(opticalLockEnabled
                    ? Color.rgb(111, 224, 199) : Color.rgb(170, 174, 178));
        }
        if (trueColourButton != null) {
            trueColourButton.setText("TC");
            trueColourButton.setTextColor(trueColourEnabled
                    ? Color.rgb(111, 224, 199) : Color.rgb(170, 174, 178));
        }
        if (flashButton != null) flashButton.setText(flashCompactLabel());
    }

    private void updateModeStripStyles() {
        styleModeButton(nightModeButton, selectedMode != null && "OEM_NIGHT".equals(selectedMode.tag));
        styleModeButton(portraitModeButton, selectedMode != null && "OEM_BOKEH".equals(selectedMode.tag));
        styleModeButton(photoModeButton, selectedMode != null && selectedMode.isSmartAuto());
        styleModeButton(standardModeButton, selectedMode != null && "STANDARD".equals(selectedMode.tag));
        styleModeButton(moreModeButton, false);
    }

    private void styleModeButton(Button button, boolean selected) {
        if (button == null) return;
        button.setTextColor(selected ? Color.WHITE : Color.rgb(151, 155, 160));
        button.setTypeface(button.getTypeface(), selected
                ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        button.setBackground(roundedDrawable(
                selected ? Color.rgb(34, 36, 39) : Color.TRANSPARENT,
                Color.TRANSPARENT, 18));
    }

    private void selectModeByTag(String tag) {
        if (captureInProgress) return;
        for (int i = 0; i < modes.size(); i++) {
            ModeOption option = modes.get(i);
            if (tag.equals(option.tag)) {
                selectedMode = option;
                restoredModeTag = option.tag;
                if (modeSpinner != null) modeSpinner.setSelection(i, false);
                updateModeStripStyles();
                if (cameraProvider != null) bindSelectedMode();
                return;
            }
        }
        Toast.makeText(this, tag.replace("OEM_", "")
                + " mode is not available on this firmware", Toast.LENGTH_SHORT).show();
    }

    private void showMoreMenu() {
        List<String> labels = new ArrayList<>();
        for (ModeOption option : modes) labels.add(option.label);
        labels.add("Diagnostics");
        labels.add("Toggle Optical Lock");
        labels.add("Toggle True Colour / Original JPEG");
        String[] items = labels.toArray(new String[0]);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Analysis First")
                .setItems(items, (dialog, which) -> {
                    if (which < modes.size()) {
                        selectModeByTag(modes.get(which).tag);
                    } else if (which == modes.size()) {
                        showDiagnosticsDialog();
                    } else if (which == modes.size() + 1) {
                        toggleOpticalLock();
                    } else {
                        toggleTrueColour();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showDiagnosticsDialog() {
        String diagnostic = "Status\n" + safeText(statusText)
                + "\n\nLens / capture\n" + safeText(lensText)
                + "\n\nAnalysis\n" + safeText(smartText)
                + "\n\nSystem\n" + safeText(metadataText);
        TextView content = new TextView(this);
        content.setText(diagnostic);
        content.setTextColor(Color.rgb(235, 237, 239));
        content.setTextSize(12f);
        content.setPadding(dp(18), dp(12), dp(18), dp(12));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Diagnostics · v" + VERSION)
                .setView(scroll)
                .setPositiveButton("Close", null)
                .show();
    }

    private String safeText(TextView view) {
        if (view == null || view.getText() == null || view.getText().length() == 0) return "—";
        return view.getText().toString();
    }

    private void initialiseCamera() {
        statusText.setText("Checking S23U physical lenses and OEM extensions…");
        try {
            hardwareMap = CameraHardwareMap.discover(this);
            metadataText.setText("Public lens map: " + hardwareMap.lensInventory());
        } catch (Exception error) {
            hardwareMap = null;
            metadataText.setText("Physical lens map unavailable: " + readableError(error)
                    + "\nLive focal-length verification remains active.");
        }

        sceneAnalyzer = new SceneAnalyzer(stats -> postLiveUiUpdate());
        ListenableFuture<ProcessCameraProvider> providerFuture =
                ProcessCameraProvider.getInstance(this);
        providerFuture.addListener(() -> {
            try {
                cameraProvider = providerFuture.get();
                ListenableFuture<ExtensionsManager> extensionFuture =
                        ExtensionsManager.getInstanceAsync(this, cameraProvider);
                extensionFuture.addListener(() -> {
                    try {
                        extensionsManager = extensionFuture.get();
                        populateModes();
                        bindSelectedMode();
                    } catch (Exception error) {
                        showFatal("OEM extension discovery failed", error);
                    }
                }, getMainExecutor());
            } catch (Exception error) {
                showFatal("Camera provider failed", error);
            }
        }, getMainExecutor());
    }

    private void populateModes() {
        modes.clear();
        modes.add(new ModeOption("Analysis First 0.5.0 — Computational Capture", "SMART_AUTO",
                ModeOption.SMART_AUTO));
        standardMode = new ModeOption("Standard 1.0.0 control — unchanged", "STANDARD",
                ModeOption.STANDARD);
        modes.add(standardMode);
        addExtensionIfAvailable("OEM Auto — may alter faces", "OEM_AUTO", ExtensionMode.AUTO);
        hdrMode = addExtensionIfAvailable("OEM HDR — manual test", "OEM_HDR",
                ExtensionMode.HDR);
        nightMode = addExtensionIfAvailable("OEM Night — manual test", "OEM_NIGHT",
                ExtensionMode.NIGHT);
        addExtensionIfAvailable("OEM Bokeh — manual test", "OEM_BOKEH",
                ExtensionMode.BOKEH);

        ArrayAdapter<ModeOption> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, modes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(adapter);
        int restoredIndex = 0;
        for (int index = 0; index < modes.size(); index++) {
            if (modes.get(index).tag.equals(restoredModeTag)) {
                restoredIndex = index;
                break;
            }
        }
        selectedMode = modes.get(restoredIndex);
        modeSpinner.setSelection(restoredIndex, false);
        modeSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                               int position, long id) {
                        if (captureInProgress) return;
                        selectedMode = modes.get(position);
                        restoredModeTag = selectedMode.tag;
                        if (cameraProvider != null) bindSelectedMode();
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) { }
                });
        updateModeControlState();
        updateModeStripStyles();

        StringBuilder supported = new StringBuilder("Available: Analysis First · Standard");
        for (ModeOption mode : modes) {
            if (mode.usesOemExtension()) {
                supported.append(" · ").append(mode.tag.replace("OEM_", ""));
            }
        }
        String optics = hardwareMap == null ? "firmware default"
                : hardwareMap.opticalCorrectionLabel("MAIN_1X");
        metadataText.setText(supported + "\nTrue Colour: neutral evidence + per-lens calibration + mixed-light guard + semantic protection + lens/ISO Detail IQ + motion-aware computational capture"
                + " · Smart optics: " + optics
                + " · Standard remains the untouched control path.");
    }

    private ModeOption addExtensionIfAvailable(String label, String tag, int extensionMode) {
        try {
            if (extensionsManager.isExtensionAvailable(
                    CameraSelector.DEFAULT_BACK_CAMERA, extensionMode)) {
                ModeOption option = new ModeOption(label, tag, extensionMode);
                modes.add(option);
                return option;
            }
        } catch (RuntimeException ignored) {
            // Unsupported or broken Samsung modes stay out of the selectable list.
        }
        return null;
    }

    private void bindSelectedMode() {
        bindCameraForMode(selectedMode, null);
    }

    private boolean bindCameraForMode(ModeOption mode, Runnable onReady) {
        if (cameraProvider == null || extensionsManager == null || mode == null) return false;
        int generation = ++bindGeneration;
        cameraSessionReady = false;
        sessionActivationInProgress = false;
        captureButton.setEnabled(false);
        statusText.setText("Binding " + mode.label + "…");
        cancelSessionTimeout();
        previewView.getPreviewStreamState().removeObservers(this);
        liveState.reset();

        boolean smartPreview = mode.isSmartAuto();
        String availablePhysicalId = smartPreview && hardwareMap != null
                ? hardwareMap.physicalIdForZoom(requestedZoom) : null;
        boolean guardEligible = ZoomRouting.shouldGuardOpticalLens(
                smartPreview, opticalLockEnabled, requestedZoom, availablePhysicalId);
        activeOpticalGuardId = guardEligible ? availablePhysicalId : null;

        try {
            cameraProvider.unbindAll();
            imageAnalysis = null;
            CameraSelector selector = CameraSelector.DEFAULT_BACK_CAMERA;
            if (mode.usesOemExtension()) {
                if (!extensionsManager.isExtensionAvailable(selector, mode.extensionMode)) {
                    throw new IllegalStateException("The selected OEM mode is no longer available");
                }
                selector = extensionsManager.getExtensionEnabledCameraSelector(
                        selector, mode.extensionMode);
            }

            int targetRotation = currentTargetRotation();

            Preview.Builder previewBuilder = new Preview.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setTargetRotation(targetRotation);
            Camera2Interop.Extender<Preview> previewInterop =
                    new Camera2Interop.Extender<>(previewBuilder);
            previewInterop.setSessionCaptureCallback(liveCaptureCallback);
            if (smartPreview && hardwareMap != null
                    && hardwareMap.previewDistortionMode >= 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.DISTORTION_CORRECTION_MODE,
                        hardwareMap.previewDistortionMode);
            }
            if (smartPreview && hardwareMap != null && hardwareMap.aberrationMode >= 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                        hardwareMap.aberrationMode);
            }
            if (smartPreview && hardwareMap != null && hardwareMap.shadingMode >= 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.SHADING_MODE, hardwareMap.shadingMode);
            }
            if (smartPreview && hardwareMap != null && hardwareMap.faceDetectionMode != 0) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.STATISTICS_FACE_DETECT_MODE,
                        hardwareMap.faceDetectionMode);
            }
            boolean requestOis = smartPreview && hardwareMap != null
                    && hardwareMap.oisSupportedForZoom(requestedZoom);
            if (requestOis) {
                previewInterop.setCaptureRequestOption(
                        CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                        CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);
            }
            Preview preview = previewBuilder.build();
            preview.setSurfaceProvider(previewView.getSurfaceProvider());

            // Keep CameraX on its proven maximum 4:3 JPEG selection. An explicit
            // 4080x3060 target negotiated only 2992x2244 after rotation on the S23U.
            int captureMode = ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY;
            ImageCapture.Builder captureBuilder = new ImageCapture.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setTargetRotation(targetRotation)
                    .setCaptureMode(captureMode)
                    .setJpegQuality(100)
                    .setFlashMode(flashMode);
            if (smartPreview) {
                Camera2Interop.Extender<ImageCapture> captureInterop =
                        new Camera2Interop.Extender<>(captureBuilder);
                if (hardwareMap != null && hardwareMap.captureDistortionMode >= 0) {
                    captureInterop.setCaptureRequestOption(
                            CaptureRequest.DISTORTION_CORRECTION_MODE,
                            hardwareMap.captureDistortionMode);
                }
                if (hardwareMap != null && hardwareMap.aberrationMode >= 0) {
                    captureInterop.setCaptureRequestOption(
                            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                            hardwareMap.aberrationMode);
                }
                if (hardwareMap != null && hardwareMap.shadingMode >= 0) {
                    captureInterop.setCaptureRequestOption(
                            CaptureRequest.SHADING_MODE, hardwareMap.shadingMode);
                }
                if (requestOis) {
                    captureInterop.setCaptureRequestOption(
                            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);
                }
            }
            imageCapture = captureBuilder.build();
            if (previewView.getDisplay() != null) {
                imageCapture.setTargetRotation(previewView.getDisplay().getRotation());
            }

            if (smartPreview) {
                ImageAnalysis.Builder analysisBuilder = new ImageAnalysis.Builder()
                        .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                        .setTargetRotation(targetRotation)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888);
                imageAnalysis = analysisBuilder.build();
                imageAnalysis.setAnalyzer(analysisExecutor, sceneAnalyzer);
                boundCamera = cameraProvider.bindToLifecycle(
                        this, selector, preview, imageCapture, imageAnalysis);
            } else {
                boundCamera = cameraProvider.bindToLifecycle(
                        this, selector, preview, imageCapture);
            }

            activeBoundMode = mode;
            boundCamera.getCameraInfo().getZoomState().removeObservers(this);
            boundCamera.getCameraInfo().getZoomState().observe(this,
                    this::showZoomState);
            previewView.getPreviewStreamState().observe(this, state -> {
                if (state == PreviewView.StreamState.STREAMING) {
                    completeBindingAfterStreaming(generation, mode, onReady);
                }
            });
            statusText.setText("Starting " + mode.label + " preview…");
            updateModeControlState();
            postLiveUiUpdate();
            sessionTimeout = () -> handleSessionStartTimeout(generation);
            mainHandler.postDelayed(sessionTimeout, SESSION_START_TIMEOUT_MS);
            return true;
        } catch (Exception error) {
            imageCapture = null;
            imageAnalysis = null;
            boundCamera = null;
            activeBoundMode = null;
            activeOpticalGuardId = null;
            cameraSessionReady = false;
            sessionActivationInProgress = false;
            captureInProgress = false;
            statusText.setText("Mode failed: " + mode.label + "\n"
                    + readableError(error) + "\nChoose Standard to continue.");
            return false;
        }
    }

    private void completeBindingAfterStreaming(int generation, ModeOption mode,
                                               Runnable onReady) {
        if (generation != bindGeneration || cameraSessionReady
                || sessionActivationInProgress || boundCamera == null) return;
        sessionActivationInProgress = true;
        requestZoomOnBoundCamera(requestedZoom, generation, () -> {
            if (generation != bindGeneration) return;
            sessionActivationInProgress = false;
            cameraSessionReady = true;
            cancelSessionTimeout();
            updateCaptureAvailability();
            if (mode.isSmartAuto()) {
                statusText.setText(activeOpticalGuardId == null
                        ? "Analysis First ready · analysing preview before every snap"
                        : String.format(Locale.US,
                        "Optical Lock checking the %.1f× lens · shutter opens when verified",
                        requestedZoom));
            } else {
                statusText.setText(mode.label + " ready · tap preview to focus");
            }
            updateModeControlState();
            postLiveUiUpdate();
            if (onReady != null) onReady.run();
        });
    }

    private void handleSessionStartTimeout(int generation) {
        if (generation != bindGeneration || cameraSessionReady) return;
        sessionActivationInProgress = false;
        captureInProgress = false;
        captureButton.setEnabled(false);
        statusText.setText("Camera preview did not become active · rotate back or select Standard");
        updateModeControlState();
    }

    private void cancelSessionTimeout() {
        if (sessionTimeout == null) return;
        mainHandler.removeCallbacks(sessionTimeout);
        sessionTimeout = null;
    }

    private boolean handlePreviewTouch(View view, MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP || boundCamera == null) return true;
        lastUserMeterMs = SystemClock.elapsedRealtime();
        focusRing.showAt(event.getX(), event.getY());
        MeteringPoint point = previewView.getMeteringPointFactory()
                .createPoint(event.getX(), event.getY());
        FocusMeteringAction action = new FocusMeteringAction.Builder(point,
                FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(4, TimeUnit.SECONDS)
                .build();
        ListenableFuture<FocusMeteringResult> focusFuture =
                boundCamera.getCameraControl().startFocusAndMetering(action);
        statusText.setText("Focusing and metering…");
        focusFuture.addListener(() -> {
            try {
                FocusMeteringResult result = focusFuture.get();
                statusText.setText(result.isFocusSuccessful()
                        ? "Focus confirmed" : "Focus completed without AF confirmation");
            } catch (Exception error) {
                statusText.setText("Focus request failed: " + readableError(error));
            }
        }, getMainExecutor());
        return true;
    }

    private void requestZoom(float wantedZoom) {
        if (captureInProgress) return;
        requestedZoom = wantedZoom;
        zoomText.setText(String.format(Locale.US, "Requested %.1f×", requestedZoom));
        updateZoomButtonStyles();
        String wantedGuardId = selectedMode != null && selectedMode.isSmartAuto()
                && hardwareMap != null ? hardwareMap.physicalIdForZoom(wantedZoom) : null;
        boolean wantsGuard = ZoomRouting.shouldGuardOpticalLens(
                selectedMode != null && selectedMode.isSmartAuto(), opticalLockEnabled,
                wantedZoom, wantedGuardId);
        String nextGuardId = wantsGuard ? wantedGuardId : null;
        boolean needsGuardRebind = !same(nextGuardId, activeOpticalGuardId);
        if (needsGuardRebind || !cameraSessionReady) {
            bindSelectedMode();
        } else {
            requestZoomOnBoundCamera(wantedZoom, bindGeneration, this::postLiveUiUpdate);
        }
    }

    private void requestZoomOnBoundCamera(float wantedZoom, int generation, Runnable onFinished) {
        if (boundCamera == null) {
            if (onFinished != null) onFinished.run();
            return;
        }
        ZoomState zoomState = boundCamera.getCameraInfo().getZoomState().getValue();
        float cameraRequest = ZoomRouting.cameraZoomRatio(wantedZoom);
        float applied = cameraRequest;
        if (zoomState != null) {
            applied = Math.max(zoomState.getMinZoomRatio(),
                    Math.min(zoomState.getMaxZoomRatio(), cameraRequest));
        }
        float finalApplied = applied;
        ListenableFuture<Void> zoomFuture =
                boundCamera.getCameraControl().setZoomRatio(applied);
        zoomFuture.addListener(() -> {
            if (generation != bindGeneration) return;
            try {
                zoomFuture.get();
                if (Math.abs(finalApplied - cameraRequest) > 0.01f) {
                    statusText.setText(String.format(Locale.US,
                            "Camera ratio %.1f× unavailable; applied %.1f×",
                            cameraRequest, finalApplied));
                }
            } catch (Exception error) {
                statusText.setText("Zoom rejected by this mode: " + readableError(error));
            } finally {
                if (onFinished != null) onFinished.run();
            }
        }, getMainExecutor());
    }

    private void showZoomState(ZoomState state) {
        if (state == null) return;
        zoomText.setText(activeOpticalGuardId == null
                ? String.format(Locale.US, "Requested %.1f× · active %.1f×",
                requestedZoom, state.getZoomRatio())
                : String.format(Locale.US,
                "Requested %.1f× · full-size optical guard · active %.1f×",
                requestedZoom, state.getZoomRatio()));
    }

    private void toggleOpticalLock() {
        if (captureInProgress) return;
        opticalLockEnabled = !opticalLockEnabled;
        updateToggleStyles();
        if (selectedMode != null && selectedMode.isSmartAuto()) bindSelectedMode();
        else statusText.setText("Optical lock applies to Analysis First; Standard remains unchanged");
    }

    private void updateModeControlState() {
        boolean smart = selectedMode != null && selectedMode.isSmartAuto();
        opticalLockButton.setEnabled(smart && !captureInProgress);
        opticalLockButton.setAlpha(smart ? 1.0f : 0.45f);
        trueColourButton.setEnabled(smart && !captureInProgress);
        trueColourButton.setAlpha(smart ? 1.0f : 0.45f);
        updateToggleStyles();
        updateModeStripStyles();
    }

    private void toggleTrueColour() {
        if (captureInProgress || selectedMode == null || !selectedMode.isSmartAuto()) return;
        trueColourEnabled = !trueColourEnabled;
        updateToggleStyles();
        statusText.setText(trueColourEnabled
                ? "True Colour + Natural Tone + Detail IQ ON · per-lens/ISO noise and detail tuning active"
                : "Original JPEG path restored · colour and tone engines remain diagnostic only");
    }

    private boolean opticalGuardRequired() {
        return selectedMode != null && selectedMode.isSmartAuto()
                && opticalLockEnabled && activeOpticalGuardId != null;
    }

    private boolean opticalGuardSatisfied() {
        if (!opticalGuardRequired()) return true;
        if (!liveState.isFresh()) return false;
        return OpticalVerification.matches(
                LensClassifier.expectedForZoom(requestedZoom),
                activeOpticalGuardId,
                liveState.physicalCameraId,
                LensClassifier.fromFocalLength(liveState.focalLengthMm));
    }

    private void updateCaptureAvailability() {
        captureButton.setEnabled(imageCapture != null && cameraSessionReady
                && !captureInProgress && opticalGuardSatisfied());
    }

    private boolean closeWideAnglePortraitRisk() {
        if (selectedMode == null || !selectedMode.isSmartAuto()
                || !liveState.isFresh() || liveState.largestFace == null
                || hardwareMap == null || hardwareMap.activeArray == null) return false;
        return PortraitGeometry.hasCloseWideAngleRisk(requestedZoom,
                liveState.largestFace.width(), hardwareMap.activeArray.width());
    }

    private void cycleFlash() {
        if (captureInProgress) return;
        if (flashMode == ImageCapture.FLASH_MODE_AUTO) {
            flashMode = ImageCapture.FLASH_MODE_OFF;
            flashButton.setText(flashCompactLabel());
        } else if (flashMode == ImageCapture.FLASH_MODE_OFF) {
            flashMode = ImageCapture.FLASH_MODE_ON;
            flashButton.setText(flashCompactLabel());
        } else {
            flashMode = ImageCapture.FLASH_MODE_AUTO;
            flashButton.setText(flashCompactLabel());
        }
        if (imageCapture != null) imageCapture.setFlashMode(flashMode);
        postLiveUiUpdate();
    }

    private void capturePhoto() {
        if (imageCapture == null || selectedMode == null || captureInProgress) return;
        if (!cameraSessionReady) {
            captureButton.setEnabled(false);
            statusText.setText("Camera is still starting · capture will unlock when preview is live");
            return;
        }
        if (!opticalGuardSatisfied()) {
            updateCaptureAvailability();
            statusText.setText("Optical Lock is waiting for "
                    + LensClassifier.expectedForZoom(requestedZoom)
                    + " · step back, add light, or turn Optical Lock OFF");
            return;
        }
        captureInProgress = true;
        captureButton.setEnabled(false);
        updateModeControlState();

        if (selectedMode.isSmartAuto()) {
            runAnalysisThenCapture(0);
        } else {
            performCapture(CaptureRecord.manual(selectedMode, requestedZoom));
        }
    }

    private void runAnalysisThenCapture(int attempt) {
        if (!captureInProgress || selectedMode == null || !selectedMode.isSmartAuto()) return;
        AnalysisFirstPlanner.Plan plan = currentAnalysisPlan();
        if (plan.waitForSettling && attempt < 4) {
            statusText.setText("Analysing scene · waiting for metering/focus to settle…");
            mainHandler.postDelayed(() -> runAnalysisThenCapture(attempt + 1), 160L);
            return;
        }

        ModeOption routeMode = routeMode(plan.decision.route);
        boolean perspectiveWarning = closeWideAnglePortraitRisk();
        String expectedLens = LensClassifier.expectedForZoom(requestedZoom);
        String distortionCorrection = routeMode != null && routeMode.usesOemExtension()
                ? "OEM_CONTROLLED"
                : hardwareMap == null ? "FIRMWARE_DEFAULT"
                : hardwareMap.opticalCorrectionLabel(expectedLens);
        CaptureRecord record = CaptureRecord.smart(plan, requestedZoom,
                routeMode == null ? standardMode : routeMode,
                activeOpticalGuardId, opticalLockEnabled,
                perspectiveWarning, distortionCorrection, trueColourEnabled,
                plan.colourDecision, sceneAnalyzer == null ? ColourStats.UNAVAILABLE : sceneAnalyzer.latestColour());

        statusText.setText("Plan: " + plan.liveLabel());
        if (routeMode != null && routeMode.usesOemExtension()) {
            restoreAnalysisExposure();
            statusText.setText("Analysis selected " + plan.decision.route
                    + " · preparing Samsung extension…");
            boolean ready = bindCameraForMode(routeMode, () -> mainHandler.postDelayed(
                    () -> performCapture(record), 700L));
            if (!ready) recoverSmartCaptureAfterOemFailure(record);
            return;
        }
        applyAnalysisExposure(plan.exposureEv, () -> beginStabilityProtectedCapture(record));
    }

    private void beginStabilityProtectedCapture(CaptureRecord record) {
        if (!record.smartAuto || !StabilityPolicy.needsMotionGuard(record.zoom)
                || stabilityTracker == null) {
            dispatchCaptureStrategy(record);
            return;
        }
        awaitStableMoment(record, SystemClock.elapsedRealtime());
    }

    private void awaitStableMoment(CaptureRecord record, long startedMs) {
        if (!captureInProgress) return;
        MotionStabilityTracker.Snapshot snapshot = stabilityTracker.snapshot(record.zoom);
        long elapsed = SystemClock.elapsedRealtime() - startedMs;
        boolean ready = "READY".equals(snapshot.level(record.zoom));
        long maxWait = StabilityPolicy.maxWaitMs(record.zoom);
        if (ready || !snapshot.available || elapsed >= maxWait) {
            CaptureRecord protectedRecord = record.withStability(
                    snapshot.level(record.zoom), snapshot.stablePercent(), elapsed,
                    snapshot.available && !ready && elapsed >= maxWait,
                    hardwareMap == null ? "OIS_UNKNOWN" : hardwareMap.oisLabelForZoom(record.zoom));
            dispatchCaptureStrategy(protectedRecord);
            return;
        }
        statusText.setText(String.format(Locale.US,
                "Hold steady · %s · stability %d%% · waiting for clean %.1f× moment",
                snapshot.level(record.zoom), snapshot.stablePercent(), record.zoom));
        mainHandler.postDelayed(() -> awaitStableMoment(record, startedMs), 70L);
    }

    private void dispatchCaptureStrategy(CaptureRecord record) {
        SceneStats scene = sceneAnalyzer == null ? SceneStats.UNAVAILABLE : sceneAnalyzer.latest();
        int iso = liveState.isFresh() ? liveState.iso : -1;
        long exposureNs = liveState.isFresh() ? liveState.exposureNs : -1L;
        ComputationalCapturePolicy.Plan computational = ComputationalCapturePolicy.plan(
                scene, iso, exposureNs, record.zoom,
                flashMode == ImageCapture.FLASH_MODE_ON, record.temporaryOemRoute);
        if (record.smartAuto && computational.usesBurst()) {
            performComputationalBurst(record, computational);
        } else {
            performCapture(record);
        }
    }

    private ModeOption routeMode(SmartAutoEngine.Route route) {
        if (route == SmartAutoEngine.Route.HDR) return hdrMode;
        if (route == SmartAutoEngine.Route.NIGHT) return nightMode;
        return standardMode;
    }

    private void recoverSmartCaptureAfterOemFailure(CaptureRecord attemptedRecord) {
        CaptureRecord fallback = attemptedRecord.asStandardFallback();
        captureInProgress = true;
        statusText.setText("Samsung " + attemptedRecord.routeTag
                + " handoff failed · recovering with Standard");
        boolean recovered = bindCameraForMode(selectedMode, () -> mainHandler.postDelayed(
                () -> performCapture(fallback), 350L));
        if (!recovered) {
            captureInProgress = false;
            captureButton.setEnabled(false);
            statusText.setText("Analysis First recovery failed · select Standard and try again");
        }
    }

    private SmartAutoEngine.Decision currentSmartDecision() {
        return currentAnalysisPlan().decision;
    }

    private AnalysisFirstPlanner.Plan currentAnalysisPlan() {
        SceneStats scene = sceneAnalyzer == null ? SceneStats.UNAVAILABLE : sceneAnalyzer.latest();
        ColourStats colour = sceneAnalyzer == null ? ColourStats.UNAVAILABLE : sceneAnalyzer.latestColour();
        String expectedLens = LensClassifier.expectedForZoom(requestedZoom);
        LensColourProfile profile = calibrationStore == null
                ? LensColourProfile.forLens(expectedLens)
                : calibrationStore.profileFor(expectedLens);
        return AnalysisFirstPlanner.plan(scene, colour, liveState,
                hdrMode != null, nightMode != null, requestedZoom,
                flashMode == ImageCapture.FLASH_MODE_ON, profile);
    }

    private void applyAnalysisExposure(float wantedEv, Runnable onReady) {
        if (boundCamera == null || Math.abs(wantedEv) < 0.05f) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        androidx.camera.core.ExposureState state = boundCamera.getCameraInfo().getExposureState();
        if (state == null || !state.isExposureCompensationSupported()) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        float step = state.getExposureCompensationStep().floatValue();
        if (!(step > 0.0f)) {
            analysisExposureIndex = 0;
            if (onReady != null) onReady.run();
            return;
        }
        android.util.Range<Integer> range = state.getExposureCompensationRange();
        int wantedIndex = Math.round(wantedEv / step);
        int targetIndex = Math.max(range.getLower(), Math.min(range.getUpper(), wantedIndex));
        analysisExposureIndex = targetIndex;
        ListenableFuture<Integer> future = boundCamera.getCameraControl()
                .setExposureCompensationIndex(targetIndex);
        future.addListener(() -> {
            try {
                future.get();
                mainHandler.postDelayed(() -> {
                    if (onReady != null) onReady.run();
                }, 240L);
            } catch (Exception ignored) {
                analysisExposureIndex = 0;
                if (onReady != null) onReady.run();
            }
        }, getMainExecutor());
    }

    private void restoreAnalysisExposure() {
        if (analysisExposureIndex == 0 || boundCamera == null) return;
        analysisExposureIndex = 0;
        try {
            androidx.camera.core.ExposureState state = boundCamera.getCameraInfo().getExposureState();
            if (state != null && state.isExposureCompensationSupported()) {
                boundCamera.getCameraControl().setExposureCompensationIndex(0);
            }
        } catch (RuntimeException ignored) { }
    }

    private void performCapture(CaptureRecord record) {
        if (imageCapture == null || !cameraSessionReady) {
            finishCaptureFailure("Capture mode was not ready", record);
            return;
        }
        statusText.setText("Capturing " + record.fileTag + "…");
        imageCapture.setTargetRotation(currentTargetRotation());

        String time = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String zoomTag = String.format(Locale.US, "%.1fX", record.zoom).replace('.', 'p');
        String filename = "ANALYSIS_FIRST_" + record.fileTag + "_" + zoomTag
                + "_Q100_" + time + ".jpg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, OUTPUT_FOLDER);
        ImageCapture.OutputFileOptions outputOptions =
                new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values).build();

        imageCapture.takePicture(outputOptions, getMainExecutor(),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults output) {
                        restoreAnalysisExposure();
                        Uri uri = output.getSavedUri();
                        if (uri == null) {
                            finishCaptureFailure("Saved, but Android returned no media URI", record);
                            return;
                        }
                        lastSavedUri = uri;
                        lastPhotoButton.setEnabled(true);
                        if (record.temporaryOemRoute) {
                            statusText.setText("Saved · restoring Analysis First preview…");
                            bindCameraForMode(selectedMode, null);
                        } else {
                            statusText.setText(record.smartAuto && record.trueColourEnabled
                                    ? "Saved · applying True Colour + Tone + Detail IQ…"
                                    : "Saved · preserving original JPEG and reading EXIF…");
                        }
                        metadataExecutor.execute(() -> processAndAnnotate(uri, filename, record));
                    }

                    @Override
                    public void onError(ImageCaptureException error) {
                        restoreAnalysisExposure();
                        finishCaptureFailure("Capture failed: " + readableError(error), record);
                    }
                });
    }

    private void performComputationalBurst(CaptureRecord record,
                                           ComputationalCapturePolicy.Plan plan) {
        if (imageCapture == null || !cameraSessionReady) {
            finishCaptureFailure("Computational capture could not start", record);
            return;
        }
        statusText.setText("Computational Capture · " + plan.frames
                + " frames · hold steady…");
        File dir = new File(getCacheDir(), "computational-burst");
        if (!dir.exists() && !dir.mkdirs()) {
            finishCaptureFailure("Could not create computational burst cache", record);
            return;
        }
        ArrayList<File> candidates = new ArrayList<>();
        captureComputationalCandidate(record, plan, 0, dir, candidates);
    }

    private void captureComputationalCandidate(CaptureRecord record,
                                               ComputationalCapturePolicy.Plan plan,
                                               int index, File dir,
                                               ArrayList<File> candidates) {
        if (!captureInProgress || imageCapture == null) return;
        File file = new File(dir, "candidate_" + System.nanoTime() + "_" + index + ".jpg");
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(file).build();
        imageCapture.setTargetRotation(currentTargetRotation());
        imageCapture.takePicture(options, getMainExecutor(),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults output) {
                        candidates.add(file);
                        int next = index + 1;
                        if (next < plan.frames) {
                            statusText.setText("Computational Capture · frame " + (next + 1) + "/"
                                    + plan.frames + " · hold steady…");
                            mainHandler.postDelayed(() -> captureComputationalCandidate(
                                    record, plan, next, dir, candidates), 38L);
                        } else {
                            statusText.setText("Computational Capture · aligning frames…");
                            metadataExecutor.execute(() -> finishComputationalBurst(
                                    record, plan, candidates));
                        }
                    }

                    @Override
                    public void onError(ImageCaptureException error) {
                        if (file.exists()) file.delete();
                        int next = index + 1;
                        if (next < plan.frames) {
                            mainHandler.postDelayed(() -> captureComputationalCandidate(
                                    record, plan, next, dir, candidates), 35L);
                        } else if (!candidates.isEmpty()) {
                            metadataExecutor.execute(() -> finishComputationalBurst(
                                    record, plan, candidates));
                        } else {
                            finishCaptureFailure("Computational burst failed: "
                                    + readableError(error), record);
                        }
                    }
                });
    }

    private void finishComputationalBurst(CaptureRecord record,
                                          ComputationalCapturePolicy.Plan plan,
                                          ArrayList<File> candidates) {
        runOnUiThread(this::restoreAnalysisExposure);
        if (candidates.isEmpty()) {
            runOnUiThread(() -> finishCaptureFailure(
                    "Computational burst produced no usable frames", record));
            return;
        }
        ArrayList<BurstCandidate> scored = new ArrayList<>();
        for (File candidate : candidates) {
            scored.add(new BurstCandidate(candidate, SharpnessScorer.score(candidate)));
        }
        Collections.sort(scored, Comparator.comparingDouble((BurstCandidate c) -> c.score).reversed());
        BurstCandidate best = scored.get(0);
        ArrayList<File> orderedFiles = new ArrayList<>();
        for (BurstCandidate candidate : scored) orderedFiles.add(candidate.file);

        ComputationalFusion.Result fusionCandidate;
        try {
            int iso = liveState.isFresh() && liveState.iso > 0 ? liveState.iso : 200;
            fusionCandidate = ComputationalFusion.fuse(orderedFiles, getCacheDir(), iso);
        } catch (OutOfMemoryError error) {
            fusionCandidate = new ComputationalFusion.Result(best.file, false, scored.size(), 1,
                    0.0, 0.0, "fusion memory guard: sharpest frame retained");
        } catch (Exception error) {
            fusionCandidate = new ComputationalFusion.Result(best.file, false, scored.size(), 1,
                    0.0, 0.0, "fusion safely bypassed: " + readableError(error));
        }
        final ComputationalFusion.Result fusion = fusionCandidate;

        String time = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String zoomTag = String.format(Locale.US, "%.1fX", record.zoom).replace('.', 'p');
        String resultTag = fusion.fused ? "FUSED" : "STABLE";
        String filename = "ANALYSIS_FIRST_" + record.fileTag + "_" + zoomTag
                + "_" + resultTag + "_Q100_" + time + ".jpg";
        Uri uri = null;
        try {
            uri = copyCandidateToMediaStore(fusion.outputFile, filename);
            if (uri == null) throw new IOException("MediaStore insert returned null");
            CaptureRecord selectedRecord = record.withComputationalResult(
                    scored.size(), best.score, plan, fusion);
            Uri finalUri = uri;
            runOnUiThread(() -> {
                lastSavedUri = finalUri;
                lastPhotoButton.setEnabled(true);
                statusText.setText(fusion.fused
                        ? "Computational Capture · fused safely · applying Colour + Tone + Detail…"
                        : "Computational Capture · sharpest-frame fallback · applying Colour + Tone + Detail…");
            });
            processAndAnnotate(uri, filename, selectedRecord);
        } catch (Exception error) {
            if (uri != null) {
                try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
            }
            runOnUiThread(() -> finishCaptureFailure(
                    "Computational save failed: " + readableError(error), record));
        } finally {
            for (BurstCandidate candidate : scored) {
                if (candidate.file.exists()) candidate.file.delete();
            }
            boolean outputWasCandidate = false;
            for (BurstCandidate candidate : scored) {
                if (candidate.file.equals(fusion.outputFile)) {
                    outputWasCandidate = true;
                    break;
                }
            }
            if (!outputWasCandidate && fusion.outputFile != null && fusion.outputFile.exists()) {
                fusion.outputFile.delete();
            }
        }
    }

    private Uri copyCandidateToMediaStore(File source, String filename) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, OUTPUT_FOLDER);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) return null;
        boolean success = false;
        try (FileInputStream input = new FileInputStream(source);
             OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("Could not open media output stream");
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) >= 0) {
                if (read > 0) output.write(buffer, 0, read);
            }
            output.flush();
            success = true;
        } finally {
            if (!success) {
                try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
            }
        }
        ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        getContentResolver().update(uri, ready, null, null);
        return uri;
    }

    private static final class BurstCandidate {
        final File file;
        final double score;

        BurstCandidate(File file, double score) {
            this.file = file;
            this.score = score;
        }
    }

    private void processAndAnnotate(Uri uri, String filename, CaptureRecord record) {
        if (record.smartAuto && calibrationStore != null) {
            calibrationStore.observe(LensClassifier.expectedForZoom(record.zoom),
                    record.colourStats, record.colourDecision);
        }
        TrueColourFinish.Result colour = TrueColourFinish.Result.skipped(record.smartAuto
                ? "OFF · original JPEG preserved" : "Standard untouched");
        if (record.smartAuto && record.trueColourEnabled) {
            try {
                colour = TrueColourFinish.apply(getContentResolver(), uri, getCacheDir(),
                        record.colourDecision, LensClassifier.expectedForZoom(record.zoom));
            } catch (Exception error) {
                colour = TrueColourFinish.Result.skipped(
                        "True Colour safely bypassed: " + readableError(error));
            }
        }
        inspectAndAnnotate(uri, filename, record, colour);
    }

    private void inspectAndAnnotate(Uri uri, String filename, CaptureRecord record,
                                    TrueColourFinish.Result colour) {
        String result;
        try (ParcelFileDescriptor descriptor =
                     getContentResolver().openFileDescriptor(uri, "rw")) {
            if (descriptor == null) throw new IOException("No file descriptor");
            ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
            double focal = exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, Double.NaN);
            String actualLens = LensClassifier.fromFocalLength(focal);
            String expectedLens = LensClassifier.expectedForZoom(record.zoom);
            String iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
            String exposure = exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME);
            String aperture = exif.getAttribute(ExifInterface.TAG_F_NUMBER);
            int width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, -1);
            int height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, -1);
            if (width <= 0) {
                width = exif.getAttributeInt(ExifInterface.TAG_PIXEL_X_DIMENSION, -1);
            }
            if (height <= 0) {
                height = exif.getAttributeInt(ExifInterface.TAG_PIXEL_Y_DIMENSION, -1);
            }
            String outputSize = OutputResolution.dimensions(width, height);
            boolean outputKnown = width > 0 && height > 0;
            boolean fullSize = OutputResolution.isFullSize(width, height);
            String fullSizeState = outputKnown ? (fullSize ? "YES" : "NO") : "UNKNOWN";
            String guardState = record.opticalGuardId == null ? "NONE"
                    : "EXPECTED:" + record.opticalGuardId;
            String colourState = colour.applied
                    ? String.format(Locale.US, "APPLIED:%.2f%%", colour.affectedPercent)
                    : "BYPASS";
            String diagnostic = "Analysis First Camera " + VERSION
                    + " | MODE=" + record.fileTag
                    + " | ROUTE=" + record.routeTag
                    + " | REASON=" + record.reason
                    + String.format(Locale.US, " | PLAN_EV=%+.1f", record.plannedExposureEv)
                    + " | PROTECTION=" + record.analysisProtection
                    + String.format(Locale.US, " | REQUEST=%.1fX/%s", record.zoom, expectedLens)
                    + " | OPTICAL_GUARD=" + guardState
                    + String.format(Locale.US, " | CAMERA_RATIO=LOGICAL_%.1fX", record.zoom)
                    + String.format(Locale.US, " | ACTUAL=%s/%.2fmm", actualLens, focal)
                    + " | GEOMETRY=" + record.distortionCorrection
                    + (record.perspectiveWarning ? "+CLOSE_1X_WARNING" : "")
                    + " | OUTPUT=" + outputSize + " | FULL_SIZE=" + fullSizeState
                    + " | TRUE_COLOUR=" + colourState
                    + " | DETAIL_IQ=" + colour.detailProfile
                    + " | DETAIL_LENS=" + colour.detailLens
                    + " | DETAIL_ISO=" + colour.detailIso
                    + " | COLOUR_DECISION=" + record.colourDecision.shortLabel()
                    + " | STABILITY=" + record.stabilityLevel
                    + " | STABILITY_PCT=" + record.stabilityPercent
                    + " | STABILITY_WAIT_MS=" + record.stabilityWaitMs
                    + " | STABILITY_FORCED=" + (record.stabilityForced ? "YES" : "NO")
                    + " | OIS=" + record.oisState
                    + " | BURST_FRAMES=" + record.burstFrames
                    + String.format(Locale.US, " | SHARPNESS_SCORE=%.3f", record.sharpnessScore)
                    + " | COMPUTATIONAL=" + record.computationalMode
                    + " | COMPUTATIONAL_REASON=" + record.computationalReason
                    + " | FUSED_FRAMES=" + record.fusedFrames
                    + String.format(Locale.US, " | ALIGN_CONF=%.3f", record.alignmentConfidence)
                    + String.format(Locale.US, " | MOTION_REJECT=%.2f%%", record.motionRejectedPercent)
                    + String.format(Locale.US, " | NEUTRAL_EVID=%.1f%% | MIXED=%.0f%% | SKY=%.0f%% | FOLIAGE=%.0f%% | SKIN=%.0f%%",
                    record.colourStats.neutralEvidence * 100.0,
                    record.colourStats.mixedLightScore * 100.0,
                    record.colourStats.skyFraction * 100.0,
                    record.colourStats.foliageFraction * 100.0,
                    record.colourStats.skinFraction * 100.0)
                    + (record.smartAuto && record.trueColourEnabled
                    ? " | PIXEL_PATH=OPTIONAL_Q100_REENCODE"
                    : " | PIXEL_PATH=ORIGINAL_JPEG")
                    + " | JPEG_Q=100_REQUEST";
            exif.setAttribute(ExifInterface.TAG_SOFTWARE, "Analysis First Camera " + VERSION);
            exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, diagnostic);
            exif.setAttribute(ExifInterface.TAG_USER_COMMENT, diagnostic);
            exif.saveAttributes();

            boolean fallback = !"UNKNOWN".equals(actualLens) && !actualLens.equals(expectedLens);
            result = "Saved " + filename + "\n"
                    + record.routeTag + " · " + record.reason
                    + String.format(Locale.US, " · plan EV %+.1f", record.plannedExposureEv)
                    + " · " + record.analysisProtection + "\n"
                    + (record.smartAuto && StabilityPolicy.needsMotionGuard(record.zoom)
                    ? "stability " + record.stabilityLevel + " " + record.stabilityPercent + "% · "
                    + record.oisState.replace('_', ' ') + "\n"
                    : "")
                    + (record.smartAuto && record.burstFrames > 1
                    ? String.format(Locale.US,
                    "computational %s · captured %d · fused %d · align %.0f%% · motion reject %.1f%% · sharpness %.2f\n",
                    record.computationalMode.replace('_', ' '), record.burstFrames,
                    record.fusedFrames, record.alignmentConfidence * 100.0,
                    record.motionRejectedPercent, record.sharpnessScore)
                    : "")
                    + "requested " + String.format(Locale.US, "%.1f×", record.zoom)
                    + " · actual " + actualLens + " "
                    + (Double.isFinite(focal) ? String.format(Locale.US, "%.2f mm", focal) : "")
                    + " · ISO " + safe(iso) + " · " + exposureLabel(exposure)
                    + " · f/" + safe(aperture)
                    + "\noutput " + outputSize + " · full-size target " + fullSizeState
                    + (record.smartAuto ? "\nTrue Colour: " + record.colourDecision.diagnostic()
                    + "\nFinish: " + colour.detail : "")
                    + (record.perspectiveWarning
                    ? "\nCLOSE 1X PERSPECTIVE WARNING WAS ACTIVE" : "")
                    + (fallback ? "\nLENS FALLBACK DETECTED" : "")
                    + (outputKnown && !fullSize ? "\nOUTPUT BELOW 4080x3060 TARGET" : "");
        } catch (Exception error) {
            result = "Saved " + filename + "\nEXIF inspection failed: "
                    + readableError(error);
        }

        String finalResult = result;
        runOnUiThread(() -> {
            captureInProgress = false;
            statusText.setText("Capture complete");
            metadataText.setText(finalResult);
            updateCaptureAvailability();
            updateModeControlState();
            Toast.makeText(this, "Photo saved separately", Toast.LENGTH_SHORT).show();
        });
    }

    private void finishCaptureFailure(String message, CaptureRecord record) {
        restoreAnalysisExposure();
        captureInProgress = false;
        if (record != null && record.temporaryOemRoute && selectedMode != null) {
            bindCameraForMode(selectedMode, null);
        }
        statusText.setText(message);
        updateCaptureAvailability();
        updateModeControlState();
    }

    private void postLiveUiUpdate() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastLiveUiPostMs < 350L) return;
        lastLiveUiPostMs = now;
        runOnUiThread(this::updateLiveUi);
    }

    private void updateLiveUi() {
        if (!liveState.isFresh()) {
            updateCaptureAvailability();
            return;
        }
        String expected = LensClassifier.expectedForZoom(requestedZoom);
        String actual = liveState.actualLens(hardwareMap);
        boolean mismatch = !"UNKNOWN".equals(actual) && !expected.equals(actual);
        String focal = Float.isFinite(liveState.focalLengthMm)
                ? String.format(Locale.US, "%.2f mm", liveState.focalLengthMm) : "focal ?";
        String exposure = exposureLabelNs(liveState.exposureNs);
        StringBuilder lens = new StringBuilder("Live sensor: ")
                .append(actual).append(" · ").append(focal)
                .append(" · ISO ").append(liveState.iso > 0 ? liveState.iso : "?")
                .append(" · ").append(exposure);
        if (activeOpticalGuardId != null) {
            lens.append(" · guard ID ").append(activeOpticalGuardId);
        }
        if (liveState.physicalCameraId != null) {
            lens.append(" · active ID ").append(liveState.physicalCameraId);
        }
        if (opticalGuardRequired() && !opticalGuardSatisfied()) {
            lens.append("\nOptical Lock waiting for ").append(expected)
                    .append(" — step back, add light, or switch lock OFF");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (mismatch) {
            lens.append("\nLens fallback detected before capture");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (liveState.focusWarning() && "TELE_3X".equals(expected)) {
            lens.append("\n3× focus uncertain — step back or tap focus");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else if (closeWideAnglePortraitRisk()) {
            lens.append("\nClose 1× portrait can distort proportions — step back and use 3×");
            lensText.setTextColor(Color.rgb(255, 190, 92));
        } else {
            lensText.setTextColor(Color.rgb(183, 200, 194));
        }
        lensText.setText(lens.toString());
        if (opticalGuardRequired() && !opticalGuardSatisfied()) {
            statusText.setText(String.format(Locale.US,
                    "%.0f× OPTICAL WAIT · step back / add light / unlock", requestedZoom));
            statusText.setTextColor(Color.rgb(255, 196, 96));
        } else if (mismatch) {
            statusText.setText(String.format(Locale.US,
                    "%.0f× FALLBACK · %s active", requestedZoom, actual.replace('_', ' ')));
            statusText.setTextColor(Color.rgb(255, 196, 96));
        } else if (liveState.focusWarning() && "TELE_3X".equals(expected)) {
            statusText.setText("3× FOCUS · tap subject or step back");
            statusText.setTextColor(Color.rgb(255, 196, 96));
        } else if (StabilityPolicy.needsMotionGuard(requestedZoom) && stabilityTracker != null) {
            MotionStabilityTracker.Snapshot motion = stabilityTracker.snapshot(requestedZoom);
            statusText.setText(motion.level(requestedZoom) + " · " + motion.stablePercent() + "%");
            statusText.setTextColor("READY".equals(motion.level(requestedZoom))
                    ? Color.rgb(111, 224, 199) : Color.rgb(255, 196, 96));
        } else {
            statusText.setText("READY");
            statusText.setTextColor(Color.rgb(111, 224, 199));
        }
        updateCaptureAvailability();

        if (selectedMode != null && selectedMode.isSmartAuto()) {
            AnalysisFirstPlanner.Plan plan = currentAnalysisPlan();
            SceneStats scene = sceneAnalyzer == null ? SceneStats.UNAVAILABLE : sceneAnalyzer.latest();
            ColourStats colour = sceneAnalyzer == null ? ColourStats.UNAVAILABLE
                    : sceneAnalyzer.latestColour();
            String sceneText = scene.valid
                    ? String.format(Locale.US,
                    " · Y %.0f · range %d · shadows %.0f%% · highlights %.1f%% · settle %.0f%%",
                    scene.meanLuma, scene.tonalRange(), scene.shadowFraction * 100.0,
                    scene.highlightFraction * 100.0, scene.stabilityScore * 100.0)
                    : " · scene analysis settling";
            LensColourProfile liveProfile = calibrationStore == null
                    ? LensColourProfile.forLens(LensClassifier.expectedForZoom(requestedZoom))
                    : calibrationStore.profileFor(LensClassifier.expectedForZoom(requestedZoom));
            String colourText = colour.valid
                    ? String.format(Locale.US,
                    "\nColour: neutral %.1f%% · evidence %.0f%% · mixed %.0f%% · sky %.0f%% · foliage %.0f%% · skin %.0f%% · settle %.0f%% · lens cal %s",
                    colour.neutralEvidence * 100.0, colour.evidenceConfidence * 100.0,
                    colour.mixedLightScore * 100.0, colour.skyFraction * 100.0,
                    colour.foliageFraction * 100.0, colour.skinFraction * 100.0,
                    colour.stabilityScore * 100.0, liveProfile.calibrationLabel())
                    : "\nColour: gathering neutral evidence · lens cal " + liveProfile.calibrationLabel();
            String detailText;
            if (trueColourEnabled) {
                String detailLens = "UNKNOWN".equals(actual) ? expected : actual;
                DetailNoiseProfile.Plan detailPlan = DetailNoiseProfile.plan(
                        detailLens, liveState.iso > 0 ? liveState.iso : 200);
                detailText = String.format(Locale.US,
                        "\nDetail IQ: %s · %s · NR %.1f%% · detail %.1f%%",
                        detailPlan.lens, detailPlan.band,
                        detailPlan.denoiseStrength * 100.0,
                        detailPlan.detailStrength * 100.0);
            } else {
                detailText = "\nDetail IQ: bypass · Original JPEG";
            }
            String stabilityText = "";
            if (StabilityPolicy.needsMotionGuard(requestedZoom) && stabilityTracker != null) {
                MotionStabilityTracker.Snapshot motion = stabilityTracker.snapshot(requestedZoom);
                String ois = hardwareMap == null ? "OIS ?"
                        : hardwareMap.oisLabelForZoom(requestedZoom).replace('_', ' ');
                stabilityText = String.format(Locale.US,
                        "\nStability: %s · %d%% · %s",
                        motion.level(requestedZoom), motion.stablePercent(), ois);
            }
            ComputationalCapturePolicy.Plan computational = ComputationalCapturePolicy.plan(
                    scene, liveState.iso, liveState.exposureNs, requestedZoom,
                    flashMode == ImageCapture.FLASH_MODE_ON,
                    plan.decision.route != SmartAutoEngine.Route.STANDARD);
            String computationalText = computational.usesBurst()
                    ? "\nComputational: " + computational.frames + " frames · align + local motion reject · "
                    + computational.reason
                    : "\nComputational: single frame · " + computational.reason;
            String opticsText = hardwareMap == null ? "\nOptics: firmware default"
                    : "\nOptics: " + hardwareMap.opticalCorrectionLabel(expected);
            smartText.setText("Capture plan: " + plan.liveLabel() + sceneText + colourText
                    + detailText + stabilityText + computationalText + opticsText
                    + (liveState.faceCount > 0 ? " · face AE active" : ""));
            maybeAutoMeterFace();
        }
    }

    private void maybeAutoMeterFace() {
        if (captureInProgress || !cameraSessionReady || boundCamera == null || selectedMode == null
                || !selectedMode.isSmartAuto() || liveState.largestFace == null
                || hardwareMap == null || hardwareMap.activeArray == null
                || previewView.getWidth() <= 0 || previewView.getHeight() <= 0) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastFaceMeterMs < 3500L || now - lastUserMeterMs < 6000L) return;

        Rect face = liveState.largestFace;
        Rect sensor = hardwareMap.activeArray;
        float nx = (face.exactCenterX() - sensor.left) / sensor.width();
        float ny = (face.exactCenterY() - sensor.top) / sensor.height();
        float[] viewPoint = CoordinateMapper.rotateSensorPoint(nx, ny,
                hardwareMap.sensorOrientation, displayRotationDegrees());
        MeteringPoint point = previewView.getMeteringPointFactory().createPoint(
                viewPoint[0] * previewView.getWidth(), viewPoint[1] * previewView.getHeight());
        FocusMeteringAction action = new FocusMeteringAction.Builder(
                point, FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build();
        lastFaceMeterMs = now;
        boundCamera.getCameraControl().startFocusAndMetering(action);
    }

    private int displayRotationDegrees() {
        int rotation = currentTargetRotation();
        if (rotation == Surface.ROTATION_90) return 90;
        if (rotation == Surface.ROTATION_180) return 180;
        if (rotation == Surface.ROTATION_270) return 270;
        return 0;
    }

    @SuppressWarnings("deprecation")
    private int currentTargetRotation() {
        if (previewView != null && previewView.getDisplay() != null) {
            return previewView.getDisplay().getRotation();
        }
        return getWindowManager().getDefaultDisplay().getRotation();
    }

    private void openLastPhoto() {
        if (lastSavedUri == null) return;
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(lastSavedUri, "image/jpeg");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(view);
        } catch (Exception error) {
            Toast.makeText(this, "No gallery app could open the photo", Toast.LENGTH_LONG).show();
        }
    }

    private void showFatal(String prefix, Exception error) {
        statusText.setText(prefix + ": " + readableError(error));
        captureButton.setEnabled(false);
    }

    private static String exposureLabel(String value) {
        if (value == null || value.isEmpty()) return "shutter unknown";
        try {
            return exposureLabelSeconds(Double.parseDouble(value));
        } catch (NumberFormatException ignored) {
            return value + " s";
        }
    }

    private static String exposureLabelNs(long nanoseconds) {
        if (nanoseconds <= 0L) return "shutter ?";
        return exposureLabelSeconds(nanoseconds / 1_000_000_000.0);
    }

    private static String exposureLabelSeconds(double seconds) {
        if (seconds > 0.0 && seconds < 1.0) {
            return "1/" + Math.max(1, Math.round(1.0 / seconds)) + " s";
        }
        return String.format(Locale.US, "%.2f s", seconds);
    }

    private static String safe(String value) {
        return value == null || value.isEmpty() ? "?" : value;
    }

    private static boolean same(String first, String second) {
        return first == null ? second == null : first.equals(second);
    }

    private static String readableError(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        String message = current.getMessage();
        return message == null || message.trim().isEmpty()
                ? current.getClass().getSimpleName() : message;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bindGeneration++;
        cancelSessionTimeout();
        mainHandler.removeCallbacksAndMessages(null);
        if (imageAnalysis != null) imageAnalysis.clearAnalyzer();
        if (stabilityTracker != null) stabilityTracker.stop();
        analysisExecutor.shutdownNow();
        metadataExecutor.shutdownNow();
    }

    private static final class CaptureRecord {
        final String fileTag;
        final String routeTag;
        final String reason;
        final float zoom;
        final boolean smartAuto;
        final boolean temporaryOemRoute;
        final String opticalGuardId;
        final boolean perspectiveWarning;
        final String distortionCorrection;
        final boolean trueColourEnabled;
        final TrueColourDecision colourDecision;
        final ColourStats colourStats;
        final float plannedExposureEv;
        final String analysisProtection;
        final String stabilityLevel;
        final int stabilityPercent;
        final long stabilityWaitMs;
        final boolean stabilityForced;
        final String oisState;
        final int burstFrames;
        final double sharpnessScore;
        final String computationalMode;
        final String computationalReason;
        final int fusedFrames;
        final double alignmentConfidence;
        final double motionRejectedPercent;

        private CaptureRecord(String fileTag, String routeTag, String reason, float zoom,
                              boolean smartAuto, boolean temporaryOemRoute,
                              String opticalGuardId, boolean perspectiveWarning,
                              String distortionCorrection, boolean trueColourEnabled,
                              float plannedExposureEv, String analysisProtection,
                              TrueColourDecision colourDecision, ColourStats colourStats,
                              String stabilityLevel, int stabilityPercent, long stabilityWaitMs,
                              boolean stabilityForced, String oisState, int burstFrames,
                              double sharpnessScore) {
            this(fileTag, routeTag, reason, zoom, smartAuto, temporaryOemRoute,
                    opticalGuardId, perspectiveWarning, distortionCorrection, trueColourEnabled,
                    plannedExposureEv, analysisProtection, colourDecision, colourStats,
                    stabilityLevel, stabilityPercent, stabilityWaitMs, stabilityForced,
                    oisState, burstFrames, sharpnessScore, "SINGLE",
                    "single-frame path", 1, 0.0, 0.0);
        }

        private CaptureRecord(String fileTag, String routeTag, String reason, float zoom,
                              boolean smartAuto, boolean temporaryOemRoute,
                              String opticalGuardId, boolean perspectiveWarning,
                              String distortionCorrection, boolean trueColourEnabled,
                              float plannedExposureEv, String analysisProtection,
                              TrueColourDecision colourDecision, ColourStats colourStats,
                              String stabilityLevel, int stabilityPercent, long stabilityWaitMs,
                              boolean stabilityForced, String oisState, int burstFrames,
                              double sharpnessScore, String computationalMode,
                              String computationalReason, int fusedFrames,
                              double alignmentConfidence, double motionRejectedPercent) {
            this.fileTag = fileTag;
            this.routeTag = routeTag;
            this.reason = reason;
            this.zoom = zoom;
            this.smartAuto = smartAuto;
            this.temporaryOemRoute = temporaryOemRoute;
            this.opticalGuardId = opticalGuardId;
            this.perspectiveWarning = perspectiveWarning;
            this.distortionCorrection = distortionCorrection;
            this.trueColourEnabled = trueColourEnabled;
            this.colourDecision = colourDecision;
            this.colourStats = colourStats == null ? ColourStats.UNAVAILABLE : colourStats;
            this.plannedExposureEv = plannedExposureEv;
            this.analysisProtection = analysisProtection;
            this.stabilityLevel = stabilityLevel == null ? "NOT_USED" : stabilityLevel;
            this.stabilityPercent = stabilityPercent;
            this.stabilityWaitMs = stabilityWaitMs;
            this.stabilityForced = stabilityForced;
            this.oisState = oisState == null ? "OIS_NOT_REQUESTED" : oisState;
            this.burstFrames = Math.max(1, burstFrames);
            this.sharpnessScore = sharpnessScore;
            this.computationalMode = computationalMode == null ? "SINGLE" : computationalMode;
            this.computationalReason = computationalReason == null
                    ? "single-frame path" : computationalReason;
            this.fusedFrames = Math.max(1, fusedFrames);
            this.alignmentConfidence = Math.max(0.0, Math.min(1.0, alignmentConfidence));
            this.motionRejectedPercent = Math.max(0.0, motionRejectedPercent);
        }

        static CaptureRecord smart(AnalysisFirstPlanner.Plan plan, float zoom,
                                   ModeOption routeMode, String opticalGuardId,
                                   boolean opticalLockEnabled, boolean perspectiveWarning,
                                   String distortionCorrection, boolean trueColourEnabled,
                                   TrueColourDecision colourDecision, ColourStats colourStats) {
            String route = plan.decision.route.name();
            return new CaptureRecord("ANALYSIS_" + route, route, plan.reason,
                    zoom, true, routeMode != null && routeMode.usesOemExtension(),
                    opticalLockEnabled ? opticalGuardId : null,
                    perspectiveWarning, distortionCorrection, trueColourEnabled,
                    plan.exposureEv, plan.protection, colourDecision, colourStats,
                    "NOT_USED", 0, 0L, false, "OIS_NOT_REQUESTED", 1, 0.0);
        }

        static CaptureRecord manual(ModeOption mode, float zoom) {
            return new CaptureRecord(mode.tag, mode.tag, "manual control", zoom,
                    false, false, null, false, "STANDARD_UNCHANGED", false,
                    0.0f, "manual",
                    TrueColourDecision.decide(ColourStats.UNAVAILABLE,
                            LensClassifier.expectedForZoom(zoom), false),
                    ColourStats.UNAVAILABLE,
                    "NOT_USED", 0, 0L, false, "STANDARD_UNCHANGED", 1, 0.0);
        }

        CaptureRecord withStability(String level, int percent, long waitMs,
                                    boolean forced, String ois) {
            return new CaptureRecord(fileTag, routeTag, reason, zoom, smartAuto,
                    temporaryOemRoute, opticalGuardId, perspectiveWarning,
                    distortionCorrection, trueColourEnabled, plannedExposureEv,
                    analysisProtection, colourDecision, colourStats,
                    level, percent, waitMs, forced, ois, 1, 0.0);
        }

        CaptureRecord withBurstResult(int frames, double score) {
            return new CaptureRecord(fileTag, routeTag, reason, zoom, smartAuto,
                    temporaryOemRoute, opticalGuardId, perspectiveWarning,
                    distortionCorrection, trueColourEnabled, plannedExposureEv,
                    analysisProtection, colourDecision, colourStats,
                    stabilityLevel, stabilityPercent, stabilityWaitMs, stabilityForced,
                    oisState, frames, score);
        }

        CaptureRecord withComputationalResult(int frames, double score,
                                              ComputationalCapturePolicy.Plan plan,
                                              ComputationalFusion.Result fusion) {
            String mode = fusion != null && fusion.fused ? "ALIGNED_FUSION"
                    : "SHARPEST_FALLBACK";
            return new CaptureRecord(fileTag, routeTag, reason, zoom, smartAuto,
                    temporaryOemRoute, opticalGuardId, perspectiveWarning,
                    distortionCorrection, trueColourEnabled, plannedExposureEv,
                    analysisProtection, colourDecision, colourStats,
                    stabilityLevel, stabilityPercent, stabilityWaitMs, stabilityForced,
                    oisState, frames, score, mode,
                    plan == null ? "computational capture" : plan.reason,
                    fusion == null ? 1 : fusion.fusedFrames,
                    fusion == null ? 0.0 : fusion.alignmentConfidence,
                    fusion == null ? 0.0 : fusion.motionRejectedPercent);
        }

        CaptureRecord asStandardFallback() {
            return new CaptureRecord("ANALYSIS_STANDARD_FALLBACK", "STANDARD_FALLBACK",
                    "Samsung " + routeTag + " handoff unavailable; safe Standard fallback",
                    zoom, true, false, opticalGuardId,
                    perspectiveWarning, distortionCorrection, trueColourEnabled,
                    plannedExposureEv, analysisProtection, colourDecision, colourStats,
                    stabilityLevel, stabilityPercent, stabilityWaitMs, stabilityForced,
                    oisState, burstFrames, sharpnessScore);
        }
    }
}
