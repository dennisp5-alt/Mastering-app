package com.s23u.procamera;

/**
 * Decides when sequential full-resolution frames are worth the latency and
 * memory cost. Fusion is never used with forced flash or an OEM extension
 * route. The fusion implementation always has a sharpest-frame fallback.
 */
final class ComputationalCapturePolicy {
    enum Mode {
        SINGLE,
        ALIGN_AND_FUSE
    }

    static final class Plan {
        final Mode mode;
        final int frames;
        final String reason;

        Plan(Mode mode, int frames, String reason) {
            this.mode = mode;
            this.frames = Math.max(1, frames);
            this.reason = reason;
        }

        boolean usesBurst() {
            return mode == Mode.ALIGN_AND_FUSE && frames > 1;
        }
    }

    private ComputationalCapturePolicy() { }

    static Plan plan(SceneStats scene, int iso, long exposureNs, float zoom,
                     boolean flashForced, boolean temporaryOemRoute) {
        if (flashForced) return new Plan(Mode.SINGLE, 1, "forced flash");
        if (temporaryOemRoute) return new Plan(Mode.SINGLE, 1, "OEM extension owns capture stack");

        boolean sceneValid = scene != null && scene.valid;
        boolean difficultRange = sceneValid && scene.tonalRange() >= 150
                && scene.highlightFraction >= 0.010 && scene.shadowFraction >= 0.080;
        boolean shadowHeavy = sceneValid && scene.shadowFraction >= 0.20;
        boolean lowishLight = iso >= 320 || exposureNs >= 12_000_000L || shadowHeavy;

        if (zoom >= 8.0f) {
            return new Plan(Mode.ALIGN_AND_FUSE, 4,
                    "10x detail/noise support with motion rejection");
        }
        if (zoom >= 2.5f) {
            return new Plan(Mode.ALIGN_AND_FUSE, 3,
                    difficultRange ? "3x dynamic-range support" : "3x detail/noise support");
        }
        if (difficultRange || lowishLight) {
            return new Plan(Mode.ALIGN_AND_FUSE, 3,
                    difficultRange ? "difficult-light shadow support" : "low-light noise support");
        }
        return new Plan(Mode.SINGLE, 1, "single clean frame is sufficient");
    }
}
