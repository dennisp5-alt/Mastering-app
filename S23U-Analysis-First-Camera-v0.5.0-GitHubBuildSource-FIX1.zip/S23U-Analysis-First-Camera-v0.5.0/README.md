# Analysis First Camera 0.5.0

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture. v0.5.0 keeps the proven v0.3/v0.4 colour, Natural Tone and Lens/ISO Detail IQ baseline, and adds a conservative computational-capture layer instead of retuning the look.

## v0.5.0 Computational Capture

- Motion-aware full-resolution multi-frame capture for scenes where extra frames can genuinely help.
- Translation alignment before fusion, with a sharpest-frame reference.
- Local motion rejection so people, leaves and other moving areas are not blindly averaged.
- Automatic sharpest-frame fallback whenever alignment/fusion confidence is insufficient.
- 3x gets three-frame detail/noise support; 10x gets four-frame support; 0.6x/1x only burst when difficult range, shadows or light levels justify the latency.
- Samsung OEM HDR/Night routes keep control of their own capture stacks and are never double-fused.
- Forced flash stays single-frame.

## High-quality optical requests

Analysis First now requests the highest quality camera-HAL modes the S23 Ultra reports for:

- geometric distortion correction,
- chromatic-aberration correction,
- lens shading correction,
- OIS where available.

These are requested only when advertised by the camera hardware. The app deliberately does not invent unmeasured distortion coefficients in software. Samsung/firmware lens calibration remains authoritative.

## Difficult-light exposure

A new capture-time exposure policy protects highlights more intelligently before the JPEG exists. It retains the previous moon/bright-subject protection, adds telephoto dynamic-range protection, and only lifts dark faces/shadows when ISO/shutter headroom says it is safe. Natural Tone still performs the restrained final tonal shaping.

## Frozen baseline

True Colour, per-lens colour learning, semantic blue protection, Natural Tonality and Lens/ISO Detail IQ remain the existing baseline. Standard remains the untouched control path.
