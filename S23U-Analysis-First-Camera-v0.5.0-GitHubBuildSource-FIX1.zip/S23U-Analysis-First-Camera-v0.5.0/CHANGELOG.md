# Changelog

## 0.5.0 — Computational Capture

- Added motion-aware multi-frame computational capture with translation alignment.
- Added local motion rejection and automatic sharpest-frame fallback.
- 3x uses three-frame support; 10x uses four-frame support; 0.6x/1x burst only when scene conditions justify it.
- OEM HDR/Night and forced-flash paths stay single-stack to avoid double processing.
- Added high-quality camera-HAL requests for distortion, chromatic-aberration and lens-shading correction where the S23 Ultra advertises support.
- Added a conservative difficult-light exposure policy, including tele dynamic-range protection and clean-headroom face/shadow support.
- Added EXIF diagnostics for computational mode, captured/fused frames, alignment confidence and motion rejection.
- Preserved v0.4.1 clean camera UI.
- Preserved the existing True Colour, Natural Tone, Stability Guard and Lens/ISO Detail IQ baseline.
- Standard remains untouched.

## 0.4.1 — Clean Camera UI

- Replaced the development/test screen with the minimal full-screen camera interface.
- Moved detailed diagnostics out of the normal shooting screen.
