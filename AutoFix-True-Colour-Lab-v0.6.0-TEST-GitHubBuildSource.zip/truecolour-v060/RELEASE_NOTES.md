# AutoFix True Colour Lab v0.6.0 TEST

Image Integrity Intelligence test build. v0.5 colour behaviour remains the baseline.

New bounded, evidence-gated stage:
- highlight shoulder protection/recovery from existing RGB signal
- conservative shadow recovery (disabled for intentional low-key/night evidence)
- low-light chroma/noise-aware correction guard
- texture/detail and skin/subject protection
- conservative profile-free edge/vignette guard; no guessed lens geometry
- small depth-aware midtone separation when scene evidence supports it
- final Quality Guard rejects excessive luminance/chroma displacement or newly clipped channels
- integrity diagnostics report highlight, shadow, noise, detail, optical, depth and subject evidence

No generative reconstruction, fake detail, sky replacement or face beautification is used.
PNG/JPEG export behaviour and existing signing identity are retained from v0.5.
