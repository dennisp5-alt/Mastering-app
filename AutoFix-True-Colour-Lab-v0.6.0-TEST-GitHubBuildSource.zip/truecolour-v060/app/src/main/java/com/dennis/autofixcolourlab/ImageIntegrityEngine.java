package com.dennis.autofixcolourlab;

import java.util.Locale;

/**
 * v0.6 evidence-gated image integrity stage. It is intentionally bounded: it may
 * protect/recover existing signal, but never synthesises detail or replaces content.
 */
public final class ImageIntegrityEngine {
    private ImageIntegrityEngine() {}

    public static final class Analysis {
        public final double highlightNeed, shadowNeed, noiseRisk, detailRisk, opticalNeed, depthConfidence, subjectProtection;
        public final boolean qualityGuardActive;
        Analysis(double hi,double sh,double no,double de,double op,double dp,double sp,boolean q) {
            highlightNeed=hi; shadowNeed=sh; noiseRisk=no; detailRisk=de; opticalNeed=op;
            depthConfidence=dp; subjectProtection=sp; qualityGuardActive=q;
        }
        public String summary() {
            return String.format(Locale.US,
                "Image Integrity v0.6: highlights %.0f%%  shadows %.0f%%  noise guard %.0f%%  detail guard %.0f%%\nOptical cleanup %.0f%%  depth evidence %.0f%%  subject protection %.0f%%  •  Quality Guard %s",
                highlightNeed*100, shadowNeed*100, noiseRisk*100, detailRisk*100,
                opticalNeed*100, depthConfidence*100, subjectProtection*100,
                qualityGuardActive?"ACTIVE":"standby");
        }
    }

    public static Analysis analyse(SceneIntelligence.Analysis s) {
        double hi=clamp01((s.highlightCoverage-.035)*4.0 + (s.clippingRisk?.20:0));
        double sh=s.preserveDarkness?0:clamp01((s.darkCoverage-.22)*1.35);
        double noise=clamp01(s.darkCoverage*.78 + (s.preserveDarkness?.16:0));
        double detail=clamp01(Math.max(s.foliageCoverage, s.skinCoverage)*1.55);
        // Profile-free optical work is deliberately limited. This is primarily a guard
        // against edge colour/vignette exaggeration rather than guessed lens geometry.
        double optical=clamp01((s.skyCoverage+s.foliageCoverage)*.30);
        double depth=clamp01((s.skyCoverage*.7+s.foliageCoverage*.45) * (1.0-s.darkCoverage*.55));
        double subject=clamp01(s.skinCoverage*3.2);
        boolean q=hi>.05 || sh>.08 || noise>.12 || detail>.10 || subject>.08;
        return new Analysis(hi,sh,noise,detail,optical,depth,subject,q);
    }

    public static final class Processor {
        private final Analysis a; private final double strength;
        public Processor(Analysis a,double strength) { this.a=a; this.strength=clamp01(strength); }

        public int apply(int argb, double nx, double ny) {
            int alpha=(argb>>>24)&255, r=(argb>>>16)&255, g=(argb>>>8)&255, b=argb&255;
            if(alpha<16 || strength<=0) return argb;
            double or=r, og=g, ob=b;
            double max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b));
            double lum=.2126*r+.7152*g+.0722*b;
            double sat=max<=0?0:(max-min)/max;
            boolean skin=r>72&&g>38&&b>24&&r>g*1.08&&g>b*1.05&&(r-b)>24&&sat<.62;
            double protect=skin ? (1.0-.70*a.subjectProtection) : 1.0;

            // Highlight roll-off: compress only the top shoulder, preserving channel ratios.
            if(lum>205 && a.highlightNeed>0) {
                double t=clamp01((lum-205)/50.0), k=.18*a.highlightNeed*strength*protect*t*t;
                r=(int)Math.round(r-(r-205)*k); g=(int)Math.round(g-(g-205)*k); b=(int)Math.round(b-(b-205)*k);
            }
            // Shadow recovery is capped at ~7 code values and disabled for intentional low-key/night scenes.
            if(lum<72 && a.shadowNeed>0) {
                double t=clamp01((72-lum)/72.0), lift=7.0*a.shadowNeed*strength*protect*t*t;
                r=(int)Math.round(r+lift); g=(int)Math.round(g+lift); b=(int)Math.round(b+lift);
            }
            // Noise/detail guard: reduce extreme low-light chroma only; no blur or invented texture.
            if(lum<82 && sat>.20 && a.noiseRisk>.15) {
                double grey=(r+g+b)/3.0, k=.10*a.noiseRisk*strength*clamp01((82-lum)/82.0);
                r=(int)Math.round(r+(grey-r)*k); g=(int)Math.round(g+(grey-g)*k); b=(int)Math.round(b+(grey-b)*k);
            }
            // Conservative profile-free edge guard. Prevents corner saturation/vignette exaggeration.
            double dx=nx-.5, dy=ny-.5, radius=Math.sqrt(dx*dx+dy*dy)/.70710678;
            if(radius>.72 && a.opticalNeed>.08) {
                double edge=clamp01((radius-.72)/.28), lift=2.5*a.opticalNeed*strength*edge;
                r=(int)Math.round(r+lift); g=(int)Math.round(g+lift); b=(int)Math.round(b+lift);
            }
            // Depth-aware finish is tiny and only separates already-present midtone colour.
            if(a.depthConfidence>.12 && lum>75 && lum<205 && sat>.10) {
                double center=clamp01(1.0-radius), k=.018*a.depthConfidence*strength*center*protect;
                double grey=(r+g+b)/3.0;
                r=(int)Math.round(r+(r-grey)*k); g=(int)Math.round(g+(g-grey)*k); b=(int)Math.round(b+(b-grey)*k);
            }

            r=clip(r); g=clip(g); b=clip(b);
            // Quality Guard: reject a per-pixel proposal if it causes excessive luminance/chroma displacement.
            double nl=.2126*r+.7152*g+.0722*b;
            double delta=Math.abs(r-or)+Math.abs(g-og)+Math.abs(b-ob);
            if(Math.abs(nl-lum)>9.0 || delta>25.0 || (max<250 && Math.max(r,Math.max(g,b))>=255)) {
                r=(int)or; g=(int)og; b=(int)ob;
            }
            return (alpha<<24)|(r<<16)|(g<<8)|b;
        }
    }
    private static int clip(int v){return Math.max(0,Math.min(255,v));}
    private static double clamp01(double v){return Math.max(0,Math.min(1,v));}
}
