#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
test_build_dir="$(mktemp -d "$project_dir/build-tests.XXXXXX")"
trap 'rm -r -- "$test_build_dir"' EXIT

java -m jdk.compiler/com.sun.tools.javac.Main \
  -source 17 \
  -target 17 \
  -encoding UTF-8 \
  -d "$test_build_dir" \
  "$project_dir/app/src/main/java/com/dennis/autofixcolourlab/HistogramEngine.java" \
  "$project_dir/app/src/main/java/com/dennis/autofixcolourlab/TrueColourEngine.java" \
  "$project_dir/app/src/main/java/com/dennis/autofixcolourlab/NatureEditorialEngine.java" \
  "$project_dir/tests/HistogramEngineTest.java" \
  "$project_dir/tests/TrueColourEngineTest.java" \
  "$project_dir/tests/NatureEditorialEngineTest.java"

java -cp "$test_build_dir" com.dennis.autofixcolourlab.HistogramEngineTest
java -cp "$test_build_dir" com.dennis.autofixcolourlab.TrueColourEngineTest
java -cp "$test_build_dir" com.dennis.autofixcolourlab.NatureEditorialEngineTest

# v0.6 image-integrity evidence/guard regression checks
javac -source 17 -target 17 -d "$test_build_dir" \
  app/src/main/java/com/dennis/autofixcolourlab/SceneIntelligence.java \
  app/src/main/java/com/dennis/autofixcolourlab/ImageIntegrityEngine.java \
  tests/ImageIntegrityEngineTest.java
java -cp "$test_build_dir" com.dennis.autofixcolourlab.ImageIntegrityEngineTest
