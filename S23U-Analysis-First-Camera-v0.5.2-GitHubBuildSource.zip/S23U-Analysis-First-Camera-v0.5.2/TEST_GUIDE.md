# v0.5.2 test guide

The goal is a shorter **hold-steady** period without reducing final saved quality.

1. 1x daylight: press the shutter normally. The **CAPTURED · you can relax** confirmation should arrive sooner than the old final-save completion.
2. 3x daylight: clean scenes should usually take one maximum-quality frame rather than forcing a two-frame burst.
3. 3x difficult light: the app may choose FUSION 2. Move naturally after the CAPTURED confirmation; the protected primary must remain usable if donors are rejected.
4. 10x daylight: normally FUSION 2. Compare sharpness and capture feel with v0.5.1.
5. 10x difficult/low light while exceptionally steady: a third donor may be used.
6. Bright sky + dark foreground: verify highlight protection, sky colour and Natural Tone match the v0.5.1 baseline.
7. Portrait/skin/fabric: verify no change to skin texture, colour or Detail IQ.
8. Open Diagnostics after representative shots and record the timing line: primary ms and extras ms. These numbers identify whether remaining delay is analysis, Samsung/CameraX exposure/processing, donor capture, or save/post-processing.

A pass means the first maximum-quality frame is secured materially sooner while final Q100 image quality remains equal to or better than v0.5.1.
