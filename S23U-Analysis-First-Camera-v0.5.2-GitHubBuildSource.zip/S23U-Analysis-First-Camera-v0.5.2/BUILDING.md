# Building Analysis First Camera 0.5.2

Requirements: JDK 17, Android SDK 34 or newer, and Internet access for initial Gradle dependency resolution. Build with `./gradlew :app:assembleRelease`.

Package: `com.dennis.analysisfirstcamera`
Version: 0.5.2 (versionCode 10)
CameraX: 1.4.2

The v0.5.2 build deliberately stays on CameraX 1.4.2 so the quality-first capture refactor can be evaluated independently from any CameraX upgrade.
