# Analysis First Camera 0.5.2

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture. v0.5.2 freezes the proven v0.5.1 rendering and replaces avoidable capture-path delay with a quality-first pipeline: secure the maximum-quality JPEG first, then save/fuse/process after the camera has the frame.

## v0.5.2 Quality-First Capture Pipeline

- CameraX remains on **CAPTURE_MODE_MAXIMIZE_QUALITY**, explicit SDR JPEG output and JPEG quality 100. No global switch to MINIMIZE_LATENCY or ZSL.
- Smart single-frame photos use CameraX's in-memory JPEG callback first. The exact Q100 captured JPEG is then written to MediaStore off the camera callback path.
- Computational bursts also capture donor JPEGs into memory first, removing the synchronous temp-file write between frames. Donors are materialised only after the short camera sequence has finished.
- The first usable full-resolution frame is treated as the protected primary. Once it arrives the UI says **CAPTURED · you can relax** and gives a small haptic confirmation.
- Clean daylight at 0.6x, 1x and 3x is normally single-frame. 3x adds donors only when dynamic range / low light justifies them. 10x normally keeps two-frame support; a third donor requires difficult light plus excellent stability.
- Rising motion after the primary frame aborts extra donors rather than extending the hold.
- Metering/focus settling is opportunistic: already-settled scenes fire immediately; unresolved scenes get short bounded retries rather than a long unconditional wait. Exposure compensation also uses a shorter state-aware settle delay.
- Fusion and final save run after capture on the background metadata executor. The sharpest-frame fallback remains mandatory.
- EXIF diagnostics now include press-to-dispatch, press-to-exposure, press-to-primary, extra-frame and save timing so remaining delay can be measured instead of guessed.
- True Colour, Natural Tone, Lens/ISO Detail IQ, optical correction, full-size target and Standard control path are not retuned.

The Standard/manual path and Samsung OEM HDR/Night extension paths remain on their existing file-output behavior.
