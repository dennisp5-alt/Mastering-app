# Recovery baseline

The permanent rendering baseline remains the proven v0.3/v0.4 True Colour + Natural Tone + Lens/ISO Detail IQ character. v0.5.x changes the capture architecture around that rendering; it must not silently retune the look.

If a v0.5.2 result looks worse, compare against v0.5.1/v0.4.1 and Standard first. Do not compensate by increasing sharpening, saturation, denoise or global tone strength. Disable or fix the capture/fusion path that caused the regression.

The next CameraX upgrade must be tested as a separate version after v0.5.2 is proven, so framework changes are not mixed with this pipeline refactor.
