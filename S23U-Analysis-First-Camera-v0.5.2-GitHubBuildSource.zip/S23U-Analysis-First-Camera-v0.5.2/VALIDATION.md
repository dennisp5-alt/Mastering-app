# v0.5.2 validation

v0.5.2 is a capture-architecture refactor, not a rendering retune. True Colour, Natural Tone, Lens/ISO Detail IQ and optical correction are frozen.

Required behavior:
- ImageCapture stays MAXIMIZE_QUALITY, JPEG Q100 and 4:3 full-size negotiation.
- Clean 0.6x/1x/3x daylight is single-frame unless scene evidence justifies donors.
- 10x normally uses two frames; a third requires difficult light and very strong stability.
- the first full-resolution frame is secured before donor/save/fusion work;
- smart single-frame and computational donor capture use in-memory JPEG callbacks;
- no temp-file IO occurs between computational donor captures;
- rising motion aborts donors after a usable primary exists;
- forced flash and Samsung OEM extension routes remain single/OEM-controlled;
- sharpest-frame fallback remains mandatory;
- EXIF records measured capture timings;
- Standard/manual capture behavior is unchanged.
