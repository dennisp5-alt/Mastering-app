# Changelog

## 0.5.2 — Quality-First Capture Pipeline

- Preserved CameraX MAXIMIZE_QUALITY and JPEG Q100 rather than trading final quality for minimum latency.
- Added in-memory JPEG primary capture for Analysis-First single-frame photos.
- Added in-memory computational donor capture; temp-file IO now happens only after the camera sequence.
- Added protected-primary behavior and CAPTURED / you-can-relax feedback.
- Made clean 3x daylight single-frame; donors are now evidence-driven.
- Kept normal 10x two-frame support, with third donor reserved for difficult light plus excellent stability.
- Added shorter state-aware AF/AE and exposure settling.
- Added detailed capture timing diagnostics.
- Preserved True Colour, Natural Tone, Detail IQ, optical correction and Standard/manual behavior.

## 0.5.1 — Fast Computational Capture

- Reduced 3x and 10x computational burst length for handheld responsiveness.
- Added motion-aware early abort after each good frame.
- Shortened 3x/10x pre-capture stability waits.
- Added FAST / FUSION N / FAST FALLBACK capture status.
- Preserved v0.5.0 image rendering, Q100 output and safe sharpest-frame fallback.


## 0.5.0 — Computational Capture

- Added motion-aware multi-frame computational capture with translation alignment.
- Added local motion rejection and automatic sharpest-frame fallback.
- 3x uses three-frame support; 10x uses four-frame support; 0.6x/1x burst only when scene conditions justify it.
- OEM HDR/Night and forced-flash paths stay single-stack to avoid double processing.
- Added high-quality camera-HAL requests for distortion, chromatic-aberration and lens-shading correction where the S23 Ultra advertises support.
- Added a conservative difficult-light exposure policy, including tele dynamic-range protection and clean-headroom face/shadow support.
- Added EXIF diagnostics for computational mode, captured/fused frames, alignment confidence and motion rejection.
- Preserved v0.4.1 clean camera UI.
- Preserved the existing True Colour, Natural Tone, Stability Guard and Lens/ISO Detail IQ baseline.
- Standard remains untouched.

## 0.4.1 — Clean Camera UI

- Replaced the development/test screen with the minimal full-screen camera interface.
- Moved detailed diagnostics out of the normal shooting screen.
