# Analysis First Camera 0.5.5

## Calibration Refinement

v0.5.5 keeps the proven v0.5.4 CameraX 1.6.2 platform, capture pipeline, portrait UI and landscape UI unchanged.

The only image-quality work in this build is calibration refinement:

- retains the existing general per-lens calibration memory
- adds conservative lighting classes: daylight, shade, warm indoor, mixed, general
- mixed light is preservation-only and is never used to train contextual calibration
- shade and warm indoor light keep some of their natural ambience instead of being neutralised completely
- contextual calibration needs repeated stable neutral evidence before it affects output
- 0.6x / 3x / 10x contextual colour is anchored conservatively to the 1x colour baseline when both lenses have enough matching evidence
- skin, foliage, sky and strong object colours retain the existing semantic protections
- no generic saturation, HDR, sharpening or denoise increase

This is not a copy of proprietary Hasselblad/OPPO colour science. The goal is the same photographic principle: natural colour, consistent lenses and preserved light character.

v0.5.4 remains the rollback baseline if any calibration regression appears.
