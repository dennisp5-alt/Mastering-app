# v0.5.5 calibration test guide

For useful calibration evidence, take repeated scenes with neutral references when practical.

Test each available lens in:
- open daylight
- outdoor shade
- warm indoor light
- mixed indoor/window light

Useful comparisons:
- grey/white objects across 1x and 3x
- skin in daylight and shade
- green foliage and blue sky
- white walls/paper indoors
- the same subject at 1x then 3x without moving far

Do not judge contextual matching from a single frame. The new profiles deliberately need repeated stable evidence before gaining influence.
