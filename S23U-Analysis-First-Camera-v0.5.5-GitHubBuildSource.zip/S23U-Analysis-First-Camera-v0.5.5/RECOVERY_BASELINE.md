# Recovery baseline

v0.5.4 is the known-good platform/capture/UI baseline.

v0.5.5 changes calibration logic only. If colour regresses, roll back calibration before changing capture, tone, sharpening, denoise or CameraX.
