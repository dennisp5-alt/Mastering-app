# v0.5.5 validation

Pass criteria:
- installs over v0.5.4
- capture speed and UI remain unchanged
- 0.6x / 1x / 3x / 10x retain normal routing
- daylight colour remains natural and close across lenses
- shade remains believable rather than over-warmed
- warm indoor light remains warm rather than sterile
- mixed light is preserved rather than globally neutralised
- skin/sky/foliage/strong object colours remain protected
- no new halos, oversaturation, HDR flattening or aggressive denoise
- Standard baseline remains unchanged

Calibration should improve gradually. Early captures should remain close to v0.5.4 because contextual profiles are confidence-gated.
