# Building Analysis First Camera 0.5.5

Package: com.dennis.analysisfirstcamera
Version: 0.5.5
versionCode: 13
CameraX: 1.6.2
compileSdk: 36
targetSdk: 34
Java: 17
