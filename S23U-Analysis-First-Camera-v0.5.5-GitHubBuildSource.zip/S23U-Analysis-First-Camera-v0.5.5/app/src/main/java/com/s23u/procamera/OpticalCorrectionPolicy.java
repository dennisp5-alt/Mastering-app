package com.s23u.procamera;

/**
 * Human-readable optical correction policy. Geometry, aberration and shading
 * are requested from the Samsung camera HAL only when the device reports the
 * corresponding high-quality mode. This deliberately avoids guessing lens
 * coefficients in software.
 */
final class OpticalCorrectionPolicy {
    private OpticalCorrectionPolicy() { }

    static String expectedStrength(String lens) {
        if ("ULTRA_WIDE".equals(lens)) return "strong geometry / edge optics";
        if ("TELE_3X".equals(lens)) return "tele chroma / shading";
        if ("TELE_10X".equals(lens)) return "long-tele chroma / shading";
        return "main-lens geometry / shading";
    }
}
