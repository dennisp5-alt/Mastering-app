package com.s23u.procamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Conservative translation-aligned multi-frame fusion. A sharp reference frame
 * is never replaced unless at least one other full-resolution frame aligns with
 * useful confidence. Local pixel disagreement is treated as motion and rejected
 * instead of being averaged, which avoids obvious ghosting on people/leaves.
 */
final class ComputationalFusion {
    static final class Result {
        final File outputFile;
        final boolean fused;
        final int capturedFrames;
        final int fusedFrames;
        final double alignmentConfidence;
        final double motionRejectedPercent;
        final String detail;

        Result(File outputFile, boolean fused, int capturedFrames, int fusedFrames,
               double alignmentConfidence, double motionRejectedPercent, String detail) {
            this.outputFile = outputFile;
            this.fused = fused;
            this.capturedFrames = capturedFrames;
            this.fusedFrames = fusedFrames;
            this.alignmentConfidence = alignmentConfidence;
            this.motionRejectedPercent = motionRejectedPercent;
            this.detail = detail;
        }
    }

    private static final String[] EXIF_TAGS = {
            ExifInterface.TAG_APERTURE_VALUE,
            ExifInterface.TAG_COLOR_SPACE,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_FLASH,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
            ExifInterface.TAG_ISO_SPEED_RATINGS,
            ExifInterface.TAG_LIGHT_SOURCE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MAX_APERTURE_VALUE,
            ExifInterface.TAG_METERING_MODE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.TAG_SUBSEC_TIME,
            ExifInterface.TAG_SUBSEC_TIME_DIGITIZED,
            ExifInterface.TAG_SUBSEC_TIME_ORIGINAL,
            ExifInterface.TAG_WHITE_BALANCE
    };

    private ComputationalFusion() { }

    static Result fuse(List<File> sharpnessOrdered, File cacheDir, int iso) throws IOException {
        if (sharpnessOrdered == null || sharpnessOrdered.isEmpty()) {
            throw new IOException("no computational frames");
        }
        File referenceFile = sharpnessOrdered.get(0);
        if (sharpnessOrdered.size() < 2) {
            return new Result(referenceFile, false, 1, 1, 0.0, 0.0,
                    "single sharp frame");
        }

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(referenceFile.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            return fallback(referenceFile, sharpnessOrdered.size(), "reference decode unavailable");
        }
        long pixels = (long) bounds.outWidth * bounds.outHeight;
        if (pixels > 20_000_000L) {
            return fallback(referenceFile, sharpnessOrdered.size(), "above 20 MP fusion safety limit");
        }

        int sample = chooseAlignmentSample(bounds.outWidth, bounds.outHeight);
        Bitmap smallReference = decodeSample(referenceFile, sample);
        if (smallReference == null) {
            return fallback(referenceFile, sharpnessOrdered.size(), "alignment reference unavailable");
        }

        ArrayList<AlignedFrame> aligned = new ArrayList<>();
        double confidenceSum = 0.0;
        try {
            for (int i = 1; i < sharpnessOrdered.size(); i++) {
                File donorFile = sharpnessOrdered.get(i);
                Bitmap donorSmall = decodeSample(donorFile, sample);
                if (donorSmall == null) continue;
                try {
                    Alignment alignment = estimateTranslation(smallReference, donorSmall, sample);
                    if (alignment.accepted) {
                        aligned.add(new AlignedFrame(donorFile,
                                alignment.dxFull, alignment.dyFull, alignment.confidence));
                        confidenceSum += alignment.confidence;
                    }
                } finally {
                    donorSmall.recycle();
                }
            }
        } finally {
            smallReference.recycle();
        }

        if (aligned.isEmpty()) {
            return fallback(referenceFile, sharpnessOrdered.size(),
                    "motion/alignment confidence too low; sharpest frame retained");
        }

        BitmapFactory.Options full = new BitmapFactory.Options();
        full.inPreferredConfig = Bitmap.Config.ARGB_8888;
        full.inMutable = true;
        Bitmap reference = BitmapFactory.decodeFile(referenceFile.getAbsolutePath(), full);
        if (reference == null) {
            return fallback(referenceFile, sharpnessOrdered.size(), "full reference decode failed");
        }

        long rejected = 0L;
        long considered = 0L;
        int donorsUsed = 0;
        try {
            for (AlignedFrame donor : aligned) {
                Bitmap donorBitmap = BitmapFactory.decodeFile(donor.file.getAbsolutePath(), full);
                if (donorBitmap == null) continue;
                try {
                    if (donorBitmap.getWidth() != reference.getWidth()
                            || donorBitmap.getHeight() != reference.getHeight()) {
                        continue;
                    }
                    BlendStats stats = blendAligned(reference, donorBitmap,
                            donor.dx, donor.dy, iso);
                    rejected += stats.rejected;
                    considered += stats.considered;
                    if (stats.accepted > 0) donorsUsed++;
                } finally {
                    donorBitmap.recycle();
                }
            }

            if (donorsUsed == 0) {
                return fallback(referenceFile, sharpnessOrdered.size(),
                        "local motion rejection retained sharpest frame");
            }

            File fused = File.createTempFile("analysis-fusion-", ".jpg", cacheDir);
            boolean ok;
            try (FileOutputStream output = new FileOutputStream(fused)) {
                ok = reference.compress(Bitmap.CompressFormat.JPEG, 100, output);
            }
            if (!ok) {
                if (!fused.delete()) fused.deleteOnExit();
                return fallback(referenceFile, sharpnessOrdered.size(), "Q100 fusion encode failed");
            }
            copyExif(referenceFile, fused);

            double confidence = confidenceSum / Math.max(1, aligned.size());
            double rejectedPct = rejected * 100.0 / Math.max(1L, considered);
            return new Result(fused, true, sharpnessOrdered.size(), donorsUsed + 1,
                    confidence, rejectedPct,
                    String.format(java.util.Locale.US,
                            "aligned %d/%d frames · confidence %.0f%% · moving pixels rejected %.1f%%",
                            donorsUsed + 1, sharpnessOrdered.size(), confidence * 100.0, rejectedPct));
        } finally {
            reference.recycle();
        }
    }

    private static Result fallback(File reference, int captured, String detail) {
        return new Result(reference, false, captured, 1, 0.0, 0.0, detail);
    }

    private static int chooseAlignmentSample(int width, int height) {
        int sample = 1;
        while (width / sample > 720 || height / sample > 720) sample *= 2;
        return Math.max(2, sample);
    }

    private static Bitmap decodeSample(File file, int sample) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    }

    private static Alignment estimateTranslation(Bitmap reference, Bitmap donor, int sample) {
        if (reference.getWidth() != donor.getWidth() || reference.getHeight() != donor.getHeight()) {
            return Alignment.rejected();
        }
        int width = reference.getWidth();
        int height = reference.getHeight();
        int[] ref = new int[width * height];
        int[] other = new int[width * height];
        reference.getPixels(ref, 0, width, 0, 0, width, height);
        donor.getPixels(other, 0, width, 0, 0, width, height);

        int maxShift = Math.max(2, Math.min(6, Math.min(width, height) / 60));
        double best = Double.POSITIVE_INFINITY;
        int bestDx = 0;
        int bestDy = 0;
        double zero = Double.POSITIVE_INFINITY;
        int step = 5;
        int margin = maxShift + 8;
        for (int dy = -maxShift; dy <= maxShift; dy++) {
            for (int dx = -maxShift; dx <= maxShift; dx++) {
                long sum = 0L;
                int count = 0;
                for (int y = margin; y < height - margin; y += step) {
                    int donorY = y + dy;
                    int row = y * width;
                    int donorRow = donorY * width;
                    for (int x = margin; x < width - margin; x += step) {
                        int donorX = x + dx;
                        int a = ref[row + x];
                        int b = other[donorRow + donorX];
                        int la = luma(a);
                        int lb = luma(b);
                        int delta = Math.abs(la - lb);
                        // Limit the leverage of moving subjects during global alignment.
                        sum += Math.min(40, delta);
                        count++;
                    }
                }
                double sad = sum / (double) Math.max(1, count);
                if (dx == 0 && dy == 0) zero = sad;
                if (sad < best) {
                    best = sad;
                    bestDx = dx;
                    bestDy = dy;
                }
            }
        }

        // JPEG noise and small exposure changes are expected. Above this level,
        // keeping the single sharp frame is safer than forcing a merge.
        if (!Double.isFinite(best) || best > 18.0) return Alignment.rejected();
        double absolute = clamp01(1.0 - best / 24.0);
        double improvement = Double.isFinite(zero) && zero > 0.1
                ? clamp01((zero - best) / Math.max(3.0, zero)) : 0.0;
        double confidence = Math.max(0.42, Math.min(0.98, absolute * 0.82 + improvement * 0.18));
        return new Alignment(true, bestDx * sample, bestDy * sample, confidence);
    }

    private static BlendStats blendAligned(Bitmap reference, Bitmap donor,
                                           int dx, int dy, int iso) {
        int width = reference.getWidth();
        int height = reference.getHeight();
        int stripeHeight = 64;
        int[] refPixels = new int[width * stripeHeight];
        int[] donorPixels = new int[width * stripeHeight];
        long accepted = 0L;
        long rejected = 0L;
        long considered = 0L;
        int lumaThreshold = iso >= 1200 ? 26 : iso >= 500 ? 22 : 18;
        int channelThreshold = iso >= 1200 ? 52 : iso >= 500 ? 44 : 36;

        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int y0 = Math.max(top, -dy);
            int y1 = Math.min(top + rows, height - dy);
            if (y1 <= y0) continue;
            int validRows = y1 - y0;
            int count = width * validRows;
            reference.getPixels(refPixels, 0, width, 0, y0, width, validRows);
            donor.getPixels(donorPixels, 0, width, 0, y0 + dy, width, validRows);

            for (int localY = 0; localY < validRows; localY++) {
                int row = localY * width;
                for (int x = 0; x < width; x++) {
                    int donorX = x + dx;
                    if (donorX < 0 || donorX >= width) continue;
                    int i = row + x;
                    int a = refPixels[i];
                    int b = donorPixels[row + donorX];
                    considered++;
                    int ar = (a >>> 16) & 0xff;
                    int ag = (a >>> 8) & 0xff;
                    int ab = a & 0xff;
                    int br = (b >>> 16) & 0xff;
                    int bg = (b >>> 8) & 0xff;
                    int bb = b & 0xff;
                    int maxChannelDelta = Math.max(Math.abs(ar - br),
                            Math.max(Math.abs(ag - bg), Math.abs(ab - bb)));
                    if (Math.abs(luma(a) - luma(b)) > lumaThreshold
                            || maxChannelDelta > channelThreshold) {
                        rejected++;
                        continue;
                    }
                    // Reference-biased blend: repeated donors reduce random noise
                    // without allowing one donor to override the sharp base frame.
                    int nr = (3 * ar + br + 2) >> 2;
                    int ng = (3 * ag + bg + 2) >> 2;
                    int nb = (3 * ab + bb + 2) >> 2;
                    int alpha = (a >>> 24) & 0xff;
                    refPixels[i] = (alpha << 24) | (nr << 16) | (ng << 8) | nb;
                    accepted++;
                }
            }
            reference.setPixels(refPixels, 0, width, 0, y0, width, validRows);
        }
        return new BlendStats(accepted, rejected, considered);
    }

    private static int luma(int colour) {
        int r = (colour >>> 16) & 0xff;
        int g = (colour >>> 8) & 0xff;
        int b = colour & 0xff;
        return (54 * r + 183 * g + 19 * b) >> 8;
    }

    private static void copyExif(File source, File target) {
        try {
            ExifInterface from = new ExifInterface(source.getAbsolutePath());
            ExifInterface to = new ExifInterface(target.getAbsolutePath());
            for (String tag : EXIF_TAGS) {
                String value = from.getAttribute(tag);
                if (value != null) to.setAttribute(tag, value);
            }
            to.saveAttributes();
        } catch (Exception ignored) {
            // Pixel result remains valid; later diagnostics can report unknown EXIF.
        }
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static final class Alignment {
        final boolean accepted;
        final int dxFull;
        final int dyFull;
        final double confidence;

        Alignment(boolean accepted, int dxFull, int dyFull, double confidence) {
            this.accepted = accepted;
            this.dxFull = dxFull;
            this.dyFull = dyFull;
            this.confidence = confidence;
        }

        static Alignment rejected() {
            return new Alignment(false, 0, 0, 0.0);
        }
    }

    private static final class AlignedFrame {
        final File file;
        final int dx;
        final int dy;
        final double confidence;

        AlignedFrame(File file, int dx, int dy, double confidence) {
            this.file = file;
            this.dx = dx;
            this.dy = dy;
            this.confidence = confidence;
        }
    }

    private static final class BlendStats {
        final long accepted;
        final long rejected;
        final long considered;

        BlendStats(long accepted, long rejected, long considered) {
            this.accepted = accepted;
            this.rejected = rejected;
            this.considered = considered;
        }
    }
}
