package com.s23u.procamera;

/**
 * Per-lens colour calibration profile. General calibration remains the safe
 * baseline. v0.5.5 can add conservative light-class context and 1x-anchored
 * cross-lens refinement after repeated evidence.
 */
final class LensColourProfile {
    final String lens;
    final double uBias;
    final double vBias;
    final double maxCorrection;
    final int calibrationSamples;
    final double calibrationConfidence;
    final String lightingClass;
    final double lightingConfidence;
    final int contextSamples;
    final double crossLensConfidence;
    final double illuminationCorrectionScale;

    LensColourProfile(String lens, double uBias, double vBias, double maxCorrection,
                      int calibrationSamples, double calibrationConfidence) {
        this(lens, uBias, vBias, maxCorrection, calibrationSamples,
                calibrationConfidence, "general", 0.0, 0, 0.0, 0.90);
    }

    LensColourProfile(String lens, double uBias, double vBias, double maxCorrection,
                      int calibrationSamples, double calibrationConfidence,
                      String lightingClass, double lightingConfidence,
                      int contextSamples, double crossLensConfidence,
                      double illuminationCorrectionScale) {
        this.lens = lens;
        this.uBias = clamp(uBias, -3.0, 3.0);
        this.vBias = clamp(vBias, -3.0, 3.0);
        this.maxCorrection = Math.max(0.0, maxCorrection);
        this.calibrationSamples = Math.max(0, calibrationSamples);
        this.calibrationConfidence = clamp01(calibrationConfidence);
        this.lightingClass = lightingClass == null ? "general" : lightingClass;
        this.lightingConfidence = clamp01(lightingConfidence);
        this.contextSamples = Math.max(0, contextSamples);
        this.crossLensConfidence = clamp01(crossLensConfidence);
        this.illuminationCorrectionScale = clamp01(illuminationCorrectionScale);
    }

    static LensColourProfile forLens(String lens) {
        return baseForLens(lens, 0.0, 0.0, 0, 0.0,
                "general", 0.0, 0, 0.0, 0.90);
    }

    static LensColourProfile calibrated(String lens, double learnedU, double learnedV,
                                        int samples) {
        double confidence = Math.min(1.0, Math.max(0, samples) / 10.0);
        double scale = confidence;
        double u = clamp(learnedU, -3.0, 3.0) * scale;
        double v = clamp(learnedV, -3.0, 3.0) * scale;
        return baseForLens(lens, u, v, samples, confidence,
                "general", 0.0, 0, 0.0, 0.90);
    }

    static LensColourProfile refined(String lens, double uBias, double vBias,
                                     int generalSamples, double generalConfidence,
                                     LightingClass.Result light, int contextSamples,
                                     double crossLensConfidence) {
        LightingClass.Result safeLight = light == null
                ? new LightingClass.Result(LightingClass.Kind.UNKNOWN, 0.0, 0.90)
                : light;
        double confidence = Math.max(generalConfidence,
                Math.min(0.92, contextSamples / 10.0 * safeLight.confidence));
        return baseForLens(lens, uBias, vBias, generalSamples, confidence,
                safeLight.label(), safeLight.confidence, contextSamples,
                crossLensConfidence, safeLight.correctionScale);
    }

    private static LensColourProfile baseForLens(String lens, double uBias, double vBias,
                                                  int samples, double confidence,
                                                  String lightingClass,
                                                  double lightingConfidence,
                                                  int contextSamples,
                                                  double crossLensConfidence,
                                                  double illuminationCorrectionScale) {
        double max;
        String safeLens;
        if ("ULTRA_WIDE".equals(lens)) {
            safeLens = lens;
            max = 0.020;
        } else if ("TELE_3X".equals(lens)) {
            safeLens = lens;
            max = 0.018;
        } else if ("TELE_10X".equals(lens)) {
            safeLens = lens;
            max = 0.015;
        } else {
            safeLens = "MAIN_1X";
            max = 0.022;
        }
        return new LensColourProfile(safeLens, uBias, vBias, max,
                samples, confidence, lightingClass, lightingConfidence,
                contextSamples, crossLensConfidence, illuminationCorrectionScale);
    }

    String calibrationLabel() {
        String general = calibrationSamples <= 0
                ? "safe-zero"
                : "general " + calibrationSamples + "/10";
        if (contextSamples <= 0 || "general".equals(lightingClass)) {
            return general;
        }
        String cross = crossLensConfidence >= 0.20
                ? " · cross " + Math.round(crossLensConfidence * 100.0) + "%"
                : "";
        return general + " · " + lightingClass + " " + contextSamples + "/10" + cross;
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
