package com.s23u.procamera;

/**
 * Conservative illumination classifier used only to refine calibration and
 * preserve the character of real light. It does not try to name every scene.
 * Unknown light falls back to the proven general lens calibration.
 */
final class LightingClass {
    enum Kind { DAYLIGHT, SHADE, WARM_INDOOR, MIXED, UNKNOWN }

    static final class Result {
        final Kind kind;
        final double confidence;
        final double correctionScale;

        Result(Kind kind, double confidence, double correctionScale) {
            this.kind = kind == null ? Kind.UNKNOWN : kind;
            this.confidence = clamp01(confidence);
            this.correctionScale = clamp01(correctionScale);
        }

        String label() {
            switch (kind) {
                case DAYLIGHT: return "daylight";
                case SHADE: return "shade";
                case WARM_INDOOR: return "warm indoor";
                case MIXED: return "mixed";
                default: return "general";
            }
        }

        boolean contextualLearningAllowed() {
            return kind != Kind.MIXED && kind != Kind.UNKNOWN && confidence >= 0.58;
        }
    }

    private LightingClass() { }

    static Result classify(ColourStats stats) {
        if (stats == null || !stats.valid || stats.evidenceConfidence < 0.34) {
            return new Result(Kind.UNKNOWN, 0.0, 0.90);
        }

        if (stats.mixedLightScore >= 0.50) {
            double confidence = clamp01((stats.mixedLightScore - 0.42) / 0.30)
                    * (0.65 + 0.35 * stats.evidenceConfidence);
            return new Result(Kind.MIXED, confidence, 0.0);
        }

        double u = stats.neutralU - 128.0;
        double v = stats.neutralV - 128.0;
        double strength = Math.hypot(u, v);
        double outdoorEvidence = clamp01(stats.skyFraction * 3.2 + stats.foliageFraction * 1.5);

        // Strong red/green residuals are more likely a local scene cast than a
        // reliable illuminant classification, so stay on the general profile.
        if (Math.abs(v) > Math.abs(u) * 1.30 && Math.abs(v) > 2.8) {
            return new Result(Kind.UNKNOWN,
                    0.35 * stats.evidenceConfidence, 0.86);
        }

        // Cool neutral residual + outdoor semantic evidence is treated as shade.
        if (u >= 2.2 && outdoorEvidence >= 0.12) {
            double direction = clamp01((u - 1.6) / 3.2);
            double confidence = (0.48 + 0.52 * outdoorEvidence)
                    * (0.55 + 0.45 * direction)
                    * stats.evidenceConfidence;
            return new Result(Kind.SHADE, confidence, 0.78);
        }

        // Warm/yellow residual with essentially no outdoor evidence is treated
        // as warm indoor light. Preserve some warmth rather than neutralising it.
        if (u <= -2.2 && stats.skyFraction < 0.035 && outdoorEvidence < 0.16) {
            double direction = clamp01((-u - 1.6) / 3.4);
            double confidence = (0.58 + 0.42 * direction)
                    * (0.70 + 0.30 * (1.0 - stats.mixedLightScore))
                    * stats.evidenceConfidence;
            return new Result(Kind.WARM_INDOOR, confidence, 0.68);
        }

        // A near-neutral scene with meaningful sky/foliage evidence is the safest
        // daylight bucket. Indoor neutral scenes remain general.
        if (strength <= 3.2 && outdoorEvidence >= 0.14) {
            double neutrality = clamp01(1.0 - strength / 4.0);
            double confidence = (0.52 + 0.48 * outdoorEvidence)
                    * (0.62 + 0.38 * neutrality)
                    * stats.evidenceConfidence;
            return new Result(Kind.DAYLIGHT, confidence, 1.0);
        }

        return new Result(Kind.UNKNOWN,
                0.35 * stats.evidenceConfidence, 0.90);
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
