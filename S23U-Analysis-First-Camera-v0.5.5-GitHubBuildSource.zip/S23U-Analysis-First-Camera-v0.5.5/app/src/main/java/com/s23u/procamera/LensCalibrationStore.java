package com.s23u.procamera;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * v0.5.5 calibration memory.
 *
 * The proven v1 general per-lens memory is retained as the baseline. A separate
 * v2 store learns only conservative light-class context. Mixed light is never
 * trained. Cross-lens refinement is anchored to the 1x profile only after both
 * lenses have repeated matching evidence.
 */
final class LensCalibrationStore {
    private static final String GLOBAL_PREFS = "lens_colour_calibration_v1";
    private static final String CONTEXT_PREFS = "lens_colour_calibration_context_v2";
    private static final int MAX_SAMPLES = 32;
    private final SharedPreferences globalPreferences;
    private final SharedPreferences contextPreferences;

    LensCalibrationStore(Context context) {
        globalPreferences = context.getSharedPreferences(GLOBAL_PREFS, Context.MODE_PRIVATE);
        contextPreferences = context.getSharedPreferences(CONTEXT_PREFS, Context.MODE_PRIVATE);
    }

    LensColourProfile profileFor(String lens) {
        String key = safeLens(lens);
        Sample general = readGlobal(key);
        return LensColourProfile.calibrated(key, general.u, general.v, general.count);
    }

    LensColourProfile profileFor(String lens, ColourStats stats) {
        String key = safeLens(lens);
        Sample general = readGlobal(key);
        LensColourProfile safeGeneral = LensColourProfile.calibrated(
                key, general.u, general.v, general.count);
        LightingClass.Result light = LightingClass.classify(stats);

        if (light.kind == LightingClass.Kind.MIXED
                || light.kind == LightingClass.Kind.UNKNOWN) {
            return LensColourProfile.refined(key, safeGeneral.uBias, safeGeneral.vBias,
                    general.count, safeGeneral.calibrationConfidence,
                    light, 0, 0.0);
        }

        Sample context = readContext(key, light.kind);
        if (context.count < 4) {
            return LensColourProfile.refined(key, safeGeneral.uBias, safeGeneral.vBias,
                    general.count, safeGeneral.calibrationConfidence,
                    light, context.count, 0.0);
        }

        double contextConfidence = Math.min(1.0, context.count / 10.0)
                * light.confidence;
        LensColourProfile contextProfile = LensColourProfile.calibrated(
                key, context.u, context.v, context.count);

        Sample mainGeneralSample = readGlobal("MAIN_1X");
        LensColourProfile mainGeneral = LensColourProfile.calibrated(
                "MAIN_1X", mainGeneralSample.u, mainGeneralSample.v,
                mainGeneralSample.count);
        Sample mainContextSample = readContext("MAIN_1X", light.kind);
        LensColourProfile mainContext = LensColourProfile.calibrated(
                "MAIN_1X", mainContextSample.u, mainContextSample.v,
                mainContextSample.count);

        boolean paired = !"MAIN_1X".equals(key)
                && mainContextSample.count >= 4
                && mainGeneralSample.count >= 2;
        if ("MAIN_1X".equals(key)) {
            paired = false;
        }

        CrossLensCalibration.Result refined = CrossLensCalibration.refine(
                safeGeneral.uBias, safeGeneral.vBias,
                mainGeneral.uBias, mainGeneral.vBias,
                contextProfile.uBias, contextProfile.vBias,
                mainContext.uBias, mainContext.vBias,
                contextConfidence, paired);

        return LensColourProfile.refined(key, refined.u, refined.v,
                general.count, safeGeneral.calibrationConfidence,
                light, context.count, refined.confidence);
    }

    boolean observe(String lens, ColourStats stats, TrueColourDecision decision) {
        if (!qualifiesForLearning(stats, decision)) return false;

        String key = safeLens(lens);
        LightingClass.Result light = LightingClass.classify(stats);
        double u = stats.neutralU - 128.0;
        double v = stats.neutralV - 128.0;

        boolean wrote = false;

        // Keep the v1 general baseline clean. Specific shade/warm scenes no longer
        // feed the generic profile; daylight and unclassified near-neutral scenes do.
        if (light.kind == LightingClass.Kind.DAYLIGHT
                || light.kind == LightingClass.Kind.UNKNOWN) {
            update(globalPreferences, key, u, v);
            wrote = true;
        }

        if (qualifiesForContextLearning(stats, decision, light)) {
            update(contextPreferences, contextKey(key, light.kind), u, v);
            wrote = true;
        }

        return wrote;
    }

    static boolean qualifiesForLearning(ColourStats stats, TrueColourDecision decision) {
        return stats != null && stats.valid && decision != null
                && decision.action == TrueColourDecision.Action.NO_CAST
                && stats.neutralEvidence >= 0.025
                && stats.evidenceConfidence >= 0.78
                && stats.stabilityScore >= 0.72
                && stats.mixedLightScore <= 0.28
                && Math.hypot(stats.neutralU - 128.0, stats.neutralV - 128.0) >= 0.25
                && Math.hypot(stats.neutralU - 128.0, stats.neutralV - 128.0) <= 3.6;
    }

    static boolean qualifiesForContextLearning(ColourStats stats,
                                               TrueColourDecision decision,
                                               LightingClass.Result light) {
        return qualifiesForLearning(stats, decision)
                && light != null
                && light.contextualLearningAllowed()
                && light.kind != LightingClass.Kind.MIXED
                && stats.mixedLightScore <= 0.24
                && stats.neutralSpread <= 5.5
                && Math.hypot(stats.neutralU - 128.0, stats.neutralV - 128.0) <= 3.3;
    }

    private Sample readGlobal(String lens) {
        int count = globalPreferences.getInt(lens + "_count", 0);
        double u = bits(globalPreferences.getLong(lens + "_u", 0L));
        double v = bits(globalPreferences.getLong(lens + "_v", 0L));
        return new Sample(count, u, v);
    }

    private Sample readContext(String lens, LightingClass.Kind kind) {
        String key = contextKey(lens, kind);
        int count = contextPreferences.getInt(key + "_count", 0);
        double u = bits(contextPreferences.getLong(key + "_u", 0L));
        double v = bits(contextPreferences.getLong(key + "_v", 0L));
        return new Sample(count, u, v);
    }

    private void update(SharedPreferences prefs, String key, double u, double v) {
        int count = prefs.getInt(key + "_count", 0);
        double oldU = bits(prefs.getLong(key + "_u", 0L));
        double oldV = bits(prefs.getLong(key + "_v", 0L));

        int newCount = Math.min(MAX_SAMPLES, count + 1);
        double weight = count <= 0 ? 1.0
                : Math.max(0.08, 1.0 / Math.min(12.0, count + 1.0));
        double newU = clamp(oldU * (1.0 - weight) + u * weight, -3.0, 3.0);
        double newV = clamp(oldV * (1.0 - weight) + v * weight, -3.0, 3.0);

        prefs.edit()
                .putInt(key + "_count", newCount)
                .putLong(key + "_u", Double.doubleToRawLongBits(newU))
                .putLong(key + "_v", Double.doubleToRawLongBits(newV))
                .apply();
    }

    private static String contextKey(String lens, LightingClass.Kind kind) {
        return safeLens(lens) + "_" + (kind == null ? "UNKNOWN" : kind.name());
    }

    private static String safeLens(String lens) {
        if ("ULTRA_WIDE".equals(lens) || "TELE_3X".equals(lens) || "TELE_10X".equals(lens)) {
            return lens;
        }
        return "MAIN_1X";
    }

    private static double bits(long bits) {
        double value = Double.longBitsToDouble(bits);
        return Double.isFinite(value) ? value : 0.0;
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }

    private static final class Sample {
        final int count;
        final double u;
        final double v;

        Sample(int count, double u, double v) {
            this.count = Math.max(0, count);
            this.u = u;
            this.v = v;
        }
    }
}
