package com.s23u.procamera;

import java.util.Locale;

/**
 * Converts live preview measurements into a capture plan before the shutter fires.
 * The planner never changes pixels. It only chooses capture route, exposure bias,
 * and whether the metering system deserves a short settling delay.
 */
final class AnalysisFirstPlanner {
    static final class Plan {
        final SmartAutoEngine.Decision decision;
        final float exposureEv;
        final boolean waitForSettling;
        final String protection;
        final String reason;
        final TrueColourDecision colourDecision;

        Plan(SmartAutoEngine.Decision decision, float exposureEv,
             boolean waitForSettling, String protection, String reason,
             TrueColourDecision colourDecision) {
            this.decision = decision;
            this.exposureEv = exposureEv;
            this.waitForSettling = waitForSettling;
            this.protection = protection;
            this.reason = reason;
            this.colourDecision = colourDecision;
        }

        String liveLabel() {
            String ev = Math.abs(exposureEv) < 0.05f ? "EV 0.0"
                    : String.format(Locale.US, "EV %+.1f", exposureEv);
            return decision.route.name() + " · " + ev + " · " + protection
                    + " · " + reason + " · colour " + colourDecision.shortLabel();
        }
    }

    private AnalysisFirstPlanner() { }

    static Plan plan(SceneStats scene, ColourStats colour, LiveCameraState live,
                     boolean hdrAvailable, boolean nightAvailable,
                     float requestedZoom, boolean flashForced,
                     LensColourProfile colourProfile) {
        boolean faceDetected = live != null && live.isFresh() && live.faceCount > 0;
        int iso = live != null && live.isFresh() ? live.iso : -1;
        long exposureNs = live != null && live.isFresh() ? live.exposureNs : -1L;

        SmartAutoEngine.Decision decision = SmartAutoEngine.decide(scene, iso, exposureNs,
                faceDetected, hdrAvailable, nightAvailable, requestedZoom, flashForced);
        String expectedLens = LensClassifier.expectedForZoom(requestedZoom);
        TrueColourDecision colourDecision = TrueColourDecision.decide(
                colour, colourProfile == null ? LensColourProfile.forLens(expectedLens) : colourProfile,
                faceDetected);

        boolean analysisFresh = scene != null && scene.valid;
        boolean liveFresh = live != null && live.isFresh();
        boolean colourNeedsSettle = colour != null && colour.isFresh()
                && colour.enoughNeutralEvidence()
                && colour.stabilityScore < 0.48;
        boolean settling = !analysisFresh || !liveFresh
                || !scene.meteringStable() || colourNeedsSettle
                || (live != null && (live.aeBusy() || live.focusBusy()));

        float ev = 0.0f;
        String protection = "natural exposure";
        String reason = decision.reason;

        if (analysisFresh && decision.route == SmartAutoEngine.Route.STANDARD
                && !flashForced) {
            DifficultLightPolicy.Plan light = DifficultLightPolicy.plan(
                    scene, faceDetected, iso, exposureNs, requestedZoom);
            ev = light.ev;
            protection = light.protection;
            reason = light.reason;
        }

        if (decision.route != SmartAutoEngine.Route.STANDARD) {
            ev = 0.0f;
            protection = decision.route == SmartAutoEngine.Route.HDR
                    ? "Samsung HDR capture" : "Samsung Night capture";
        }

        if (decision.route == SmartAutoEngine.Route.STANDARD && !flashForced
                && StabilityPolicy.longTele(requestedZoom)) {
            float guardedEv = StabilityPolicy.shutterGuardEv(
                    requestedZoom, exposureNs, iso, ev);
            if (guardedEv < ev - 0.05f) {
                ev = guardedEv;
                protection = protection + " + 10× shutter guard";
                reason = reason + "; favour faster handheld exposure";
            }
        }

        return new Plan(decision, ev, settling, protection, reason, colourDecision);
    }
}
