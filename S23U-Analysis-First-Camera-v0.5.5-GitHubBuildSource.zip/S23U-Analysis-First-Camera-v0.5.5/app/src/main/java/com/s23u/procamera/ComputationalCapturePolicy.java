package com.s23u.procamera;

/**
 * Decides when sequential full-resolution frames are worth the latency and
 * memory cost. v0.5.2 is quality-first but selective: clean daylight stays
 * single-frame at 0.6x/1x/3x, while 10x normally uses two frames because the
 * tele sensor benefits more from donor support. Extra frames are reserved for
 * genuinely difficult light with strong stability. Fusion is never
 * forced with flash or an OEM extension route, and every path has a sharpest-
 * frame fallback.
 */
final class ComputationalCapturePolicy {
    enum Mode {
        SINGLE,
        ALIGN_AND_FUSE
    }

    static final class Plan {
        final Mode mode;
        final int frames;
        final String reason;

        Plan(Mode mode, int frames, String reason) {
            this.mode = mode;
            this.frames = Math.max(1, frames);
            this.reason = reason;
        }

        boolean usesBurst() {
            return mode == Mode.ALIGN_AND_FUSE && frames > 1;
        }

        String shortLabel() {
            return usesBurst() ? "FUSION " + frames : "FAST";
        }

        Plan shortenedTo(int actualFrames, String why) {
            int actual = Math.max(1, Math.min(frames, actualFrames));
            if (actual <= 1) {
                return new Plan(Mode.SINGLE, 1, reason + " · " + why);
            }
            return new Plan(Mode.ALIGN_AND_FUSE, actual, reason + " · " + why);
        }
    }

    private ComputationalCapturePolicy() { }

    static Plan plan(SceneStats scene, int iso, long exposureNs, float zoom,
                     boolean flashForced, boolean temporaryOemRoute,
                     int stabilityPercent, boolean motionAvailable) {
        if (flashForced) return new Plan(Mode.SINGLE, 1, "forced flash");
        if (temporaryOemRoute) return new Plan(Mode.SINGLE, 1, "OEM extension owns capture stack");

        boolean sceneValid = scene != null && scene.valid;
        boolean difficultRange = sceneValid && scene.tonalRange() >= 150
                && scene.highlightFraction >= 0.010 && scene.shadowFraction >= 0.080;
        boolean shadowHeavy = sceneValid && scene.shadowFraction >= 0.20;
        boolean lowishLight = iso >= 320 || exposureNs >= 12_000_000L || shadowHeavy;
        boolean cleanBright = sceneValid && !difficultRange && !shadowHeavy
                && iso > 0 && iso <= 160
                && exposureNs > 0L && exposureNs <= 8_000_000L;

        int stable = Math.max(0, Math.min(100, stabilityPercent));

        if (zoom >= 8.0f) {
            if (motionAvailable && stable < 58) {
                return new Plan(Mode.SINGLE, 1,
                        "10x motion priority · retain one sharp maximum-quality frame");
            }
            if (motionAvailable && stable >= 92 && (lowishLight || difficultRange)) {
                return new Plan(Mode.ALIGN_AND_FUSE, 3,
                        difficultRange ? "10x very-stable difficult-light support"
                                : "10x very-stable noise support");
            }
            return new Plan(Mode.ALIGN_AND_FUSE, 2,
                    cleanBright ? "10x quality-first two-frame detail support"
                            : "10x two-frame handheld support");
        }

        if (zoom >= 2.5f) {
            if (cleanBright) {
                return new Plan(Mode.SINGLE, 1,
                        "3x clean daylight · one maximum-quality frame is sufficient");
            }
            if (motionAvailable && stable < 58) {
                return new Plan(Mode.SINGLE, 1,
                        "3x motion priority · retain one sharp maximum-quality frame");
            }
            if (motionAvailable && stable >= 93 && lowishLight && difficultRange) {
                return new Plan(Mode.ALIGN_AND_FUSE, 3,
                        "3x very-stable difficult low-light support");
            }
            if (difficultRange || lowishLight) {
                return new Plan(Mode.ALIGN_AND_FUSE, 2,
                        difficultRange ? "3x two-frame difficult-light support"
                                : "3x two-frame noise support");
            }
            return new Plan(Mode.SINGLE, 1, "3x single maximum-quality frame");
        }

        if (cleanBright) {
            return new Plan(Mode.SINGLE, 1, "clean daylight fast path");
        }
        if (difficultRange || lowishLight) {
            if (motionAvailable && stable < 45) {
                return new Plan(Mode.SINGLE, 1,
                        "motion priority · keep one sharp frame");
            }
            return new Plan(Mode.ALIGN_AND_FUSE, 2,
                    difficultRange ? "two-frame difficult-light support"
                            : "two-frame low-light noise support");
        }
        return new Plan(Mode.SINGLE, 1, "single clean frame is sufficient");
    }

    // Host-test/backward-compatible overload. Unknown motion defaults to a normal
    // handheld state rather than assuming a tripod-level hold.
    static Plan plan(SceneStats scene, int iso, long exposureNs, float zoom,
                     boolean flashForced, boolean temporaryOemRoute) {
        return plan(scene, iso, exposureNs, zoom, flashForced, temporaryOemRoute,
                72, false);
    }

    static boolean shouldContinueBurst(float zoom, int capturedFrames, int plannedFrames,
                                       int stabilityPercent, boolean motionAvailable) {
        if (capturedFrames >= plannedFrames) return false;
        if (!motionAvailable) return true;
        int stable = Math.max(0, Math.min(100, stabilityPercent));

        // Once we have one valid full-resolution frame, rising motion wins over
        // collecting donors. This is intentionally conservative: a sharp single
        // frame is always better than a longer, blur-prone burst.
        if (capturedFrames >= 1) {
            int floor = zoom >= 8.0f ? 72 : zoom >= 2.5f ? 66 : 56;
            if (stable < floor) return false;
        }
        // Extra third/fourth donors are reserved for an already very steady hold.
        if (capturedFrames >= 2) {
            int extraFloor = zoom >= 8.0f ? 92 : 90;
            if (stable < extraFloor) return false;
        }
        if (capturedFrames >= 3 && stable < 96) return false;
        return true;
    }
}
