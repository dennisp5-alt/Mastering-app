package com.s23u.procamera;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

final class GridOverlayView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    GridOverlayView(Context context) {
        super(context);
        paint.setColor(Color.argb(92, 255, 255, 255));
        paint.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density * 0.7f));
        setClickable(false);
        setFocusable(false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        canvas.drawLine(w / 3f, 0f, w / 3f, h, paint);
        canvas.drawLine(w * 2f / 3f, 0f, w * 2f / 3f, h, paint);
        canvas.drawLine(0f, h / 3f, w, h / 3f, paint);
        canvas.drawLine(0f, h * 2f / 3f, w, h * 2f / 3f, paint);
    }
}
