package com.s23u.procamera;

/**
 * Pure calibration math. The 1x lens is the colour anchor; other lenses can
 * use contextual relative differences only after both sides have enough
 * evidence. This keeps cross-lens colour closer without forcing a generic look.
 */
final class CrossLensCalibration {
    static final class Result {
        final double u;
        final double v;
        final double confidence;

        Result(double u, double v, double confidence) {
            this.u = clamp(u, -3.0, 3.0);
            this.v = clamp(v, -3.0, 3.0);
            this.confidence = clamp01(confidence);
        }
    }

    private CrossLensCalibration() { }

    static Result refine(double generalLensU, double generalLensV,
                         double generalMainU, double generalMainV,
                         double contextLensU, double contextLensV,
                         double contextMainU, double contextMainV,
                         double contextConfidence, boolean pairedWithMain) {
        double confidence = clamp01(contextConfidence);
        if (confidence <= 0.0) {
            return new Result(generalLensU, generalLensV, 0.0);
        }

        double targetU;
        double targetV;
        double maxBlend;
        if (pairedWithMain) {
            // Preserve the trusted general 1x anchor, but use the contextual
            // difference between this lens and 1x to tighten matching.
            targetU = generalMainU + (contextLensU - contextMainU);
            targetV = generalMainV + (contextLensV - contextMainV);
            maxBlend = 0.55;
        } else {
            // Without a matching 1x context, contextual calibration is allowed
            // only a small influence.
            targetU = contextLensU;
            targetV = contextLensV;
            maxBlend = 0.30;
        }

        double blend = maxBlend * confidence;
        double u = generalLensU * (1.0 - blend) + targetU * blend;
        double v = generalLensV * (1.0 - blend) + targetV * blend;
        return new Result(u, v, pairedWithMain ? confidence : confidence * 0.55);
    }

    private static double clamp(double value, double low, double high) {
        return Math.max(low, Math.min(high, value));
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
