package com.s23u.procamera;

/**
 * Conservative pre-capture exposure policy for scenes where one JPEG exposure
 * has to protect both highlights and important mid/shadow detail. Pixel tone
 * rendering remains the responsibility of Natural Tone; this class only
 * chooses a small capture-time EV bias.
 */
final class DifficultLightPolicy {
    static final class Plan {
        final float ev;
        final String protection;
        final String reason;
        final boolean difficultRange;

        Plan(float ev, String protection, String reason, boolean difficultRange) {
            this.ev = ev;
            this.protection = protection;
            this.reason = reason;
            this.difficultRange = difficultRange;
        }
    }

    private DifficultLightPolicy() { }

    static Plan plan(SceneStats scene, boolean faceDetected, int iso, long exposureNs,
                     float requestedZoom) {
        if (scene == null || !scene.valid) {
            return new Plan(0.0f, "natural exposure", "analysis unavailable", false);
        }

        boolean moonLike = scene.shadowFraction >= 0.55
                && scene.tonalRange() >= 150
                && scene.p95 >= 185
                && scene.highlightFraction < 0.08;
        boolean severeHighlights = scene.highlightFraction >= 0.065 || scene.p95 >= 250;
        boolean brightHighlights = scene.highlightFraction >= 0.022 || scene.p95 >= 244;
        boolean difficultRange = scene.tonalRange() >= 152
                && scene.highlightFraction >= 0.012
                && scene.shadowFraction >= 0.085;
        boolean shadowDominantFace = faceDetected
                && scene.shadowFraction >= 0.16
                && scene.highlightFraction < 0.024
                && scene.meanLuma < 92.0;
        boolean cleanSensorHeadroom = iso > 0 && iso < 640
                && exposureNs > 0 && exposureNs < 30_000_000L;
        boolean openShadows = scene.meanLuma < 58.0 && scene.p95 < 205
                && scene.highlightFraction < 0.006;
        boolean tele = requestedZoom >= 2.5f;

        if (moonLike) {
            return new Plan(-0.7f, "isolated bright subject",
                    "dark-field highlight protection", true);
        }
        if (severeHighlights) {
            float ev = faceDetected ? -0.3f : -0.7f;
            return new Plan(ev,
                    faceDetected ? "face + strong highlight guard" : "strong highlight guard",
                    "protect bright detail before capture", true);
        }
        if (difficultRange && tele) {
            return new Plan(-0.3f, "tele dynamic-range guard",
                    "protect highlights; computational burst supports clean shadows", true);
        }
        if (brightHighlights) {
            return new Plan(faceDetected ? 0.0f : -0.3f,
                    faceDetected ? "face AE + highlight watch" : "highlight guard",
                    faceDetected ? "preserve face while retaining highlight headroom"
                            : "retain highlight headroom", difficultRange);
        }
        if (shadowDominantFace && cleanSensorHeadroom) {
            return new Plan(0.3f, "face shadow support",
                    "clean sensor headroom for a darker face", difficultRange);
        }
        if (openShadows && cleanSensorHeadroom) {
            return new Plan(0.3f, "gentle shadow lift",
                    "clean sensor headroom available", difficultRange);
        }
        return new Plan(0.0f, faceDetected ? "face AE priority" : "natural exposure",
                "natural rendering", difficultRange);
    }
}
