package com.dennis.photomasterai;

public final class RepairSafetyPolicyHostChecks {
    public static void main(String[] args) {
        double duckEv = RepairSafetyPolicy.exposureEv(0.66, 0.0000, 0.97, 0.12, false, false);
        require(Math.abs(duckEv) < 0.001, "safe bright scene must not be globally darkened");
        require(RepairSafetyPolicy.brightExposureProtected(0.66, duckEv, false),
                "bright exposure guard should report active");

        double poolEv = RepairSafetyPolicy.exposureEv(0.65, 0.0056, 0.99, 0.20, false, false);
        require(Math.abs(poolEv) < 0.001, "mixed high-DR pool image should use highlight roll-off before -EV");

        double caveEv = RepairSafetyPolicy.exposureEv(0.17, 0.0000, 0.98, 0.12, false, false);
        require(caveEv > 0.0 && caveEv <= 0.400001, "dark scene lift must stay capped at +0.40 EV");
        require(RepairSafetyPolicy.capShadowLift(0.42, 0.17, false, false) <= 0.220001,
                "very dark scenes should cap shadow lift");

        // Exact failure mode seen in v0.3.2: absolute bright pixels can be 0%, while
        // a large moon is still clearly bright relative to the black field.
        boolean moon = RepairSafetyPolicy.isDarkField(0.78, 0.00, 0.20, 0.36, 0.62);
        require(moon, "relative-bright moon-like dark field should be detected even without near-white pixels");
        require(Math.abs(RepairSafetyPolicy.exposureEv(0.00, 0.0002, 0.62, 0.00, false, moon)) < 0.001,
                "dark field must not receive global exposure lift");
        require(RepairSafetyPolicy.capShadowLift(0.42, 0.00, false, moon) == 0.0,
                "dark field must preserve intentional blacks");

        require(!RepairSafetyPolicy.isDarkField(0.17, 0.17, 0.14, 0.70, 0.98),
                "ordinary cave/group dark scene must not be mistaken for dark-field photography");

        // Social/screenshot classification moved to SocialSourcePolicy in v0.4.1.
        // RepairSafetyPolicy now remains responsible for tone/dark-field safety.

        System.out.println("Repair Safety Policy host checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
