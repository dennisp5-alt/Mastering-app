package com.dennis.photomasterai;

public final class SocialSourcePolicyHostChecks {
    public static void main(String[] args) {
        // Natural duck: high ringing from feathers/water edges is only an edge hint.
        SocialSourcePolicy.Decision duck = SocialSourcePolicy.decide(
                0, 0, false, 0.10, 0.12, 0.90, 0.00, false);
        require(!duck.guardActive, "duck must not be classified as social/screenshot");
        require(duck.edgeProcessedHint, "high-ring duck may still carry edge-processed hint");

        // Macro flower: extreme ringing is not enough on its own.
        SocialSourcePolicy.Decision flower = SocialSourcePolicy.decide(
                0, 0, false, 0.08, 0.10, 1.00, 0.00, false);
        require(!flower.guardActive, "macro flower must not be classified as social/screenshot");

        // Actual social UI: OCR + edge interface evidence should trigger.
        SocialSourcePolicy.Decision social = SocialSourcePolicy.decide(
                4, 3, true, 0.38, 0.78, 0.52, 0.01, false);
        require(social.guardActive, "social screenshot with UI text must trigger guard");

        // Ordinary photo containing one sign should not trigger.
        SocialSourcePolicy.Decision sign = SocialSourcePolicy.decide(
                1, 0, false, 0.14, 0.16, 0.40, 0.02, false);
        require(!sign.guardActive, "single in-scene sign must not trigger social guard");

        SocialSourcePolicy.Decision moon = SocialSourcePolicy.decide(
                3, 2, true, 0.80, 0.70, 0.95, 0.02, true);
        require(!moon.guardActive, "dark-field protection must override social classification");

        System.out.println("Social Source Policy host checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
