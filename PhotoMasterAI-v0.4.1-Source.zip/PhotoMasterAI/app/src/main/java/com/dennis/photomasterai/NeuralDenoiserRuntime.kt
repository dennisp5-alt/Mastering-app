package com.dennis.photomasterai

import android.content.Context
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.TensorBuffer
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * v0.4.1 NAFNet runtime.
 *
 * Important: this now mirrors the verified NAFNet sample loading path:
 * asset -> filesDir -> CompiledModel.create(filePath, Options(accelerator), null).
 *
 * Input/output are explicit NCHW Float32 RGB [0,1]. Every output is sanity-checked
 * against its input so a collapsed/constant GPU result can never be treated as a
 * valid denoised tile.
 */
class NeuralDenoiserRuntime(
    context: Context,
    private val cpuOnly: Boolean = false
) : AutoCloseable {
    private val modelFile: File = ensureModelFile(context)
    private val accelerator: Accelerator = if (cpuOnly) Accelerator.CPU else Accelerator.GPU
    private val model: CompiledModel = CompiledModel.create(
        modelFile.absolutePath,
        CompiledModel.Options(accelerator),
        null
    )
    private val inputs: List<TensorBuffer> = model.createInputBuffers()
    private val outputs: List<TensorBuffer> = model.createOutputBuffers()

    val acceleratorLabel: String = if (cpuOnly) "LiteRT CPU fallback" else "LiteRT GPU"

    fun run(input: FloatArray): FloatArray {
        require(input.size == ELEMENTS) { "NAFNet input must contain $ELEMENTS floats" }
        inputs[0].writeFloat(input)
        model.run(inputs, outputs)
        val out = outputs[0].readFloat()
        require(out.size >= ELEMENTS) { "NAFNet output had ${out.size} floats" }
        validateOutput(input, out)
        return out
    }

    /**
     * Synthetic probe used before full-photo tiling. It catches the exact failure
     * seen in v0.4.0 (near-constant/zero output) in one inference instead of after
     * hundreds of tiles.
     */
    fun selfTest() {
        val probe = FloatArray(ELEMENTS)
        val hw = TILE * TILE
        for (y in 0 until TILE) {
            for (x in 0 until TILE) {
                val i = y * TILE + x
                val gx = x / (TILE - 1f)
                val gy = y / (TILE - 1f)
                probe[i] = (0.08f + 0.78f * gx).coerceIn(0f, 1f)
                probe[hw + i] = (0.10f + 0.72f * gy).coerceIn(0f, 1f)
                probe[2 * hw + i] = (0.12f + 0.55f * (0.5f * gx + 0.5f * gy)).coerceIn(0f, 1f)
            }
        }
        run(probe)
    }

    private fun validateOutput(input: FloatArray, out: FloatArray) {
        var inSum = 0.0
        var outSum = 0.0
        var inSum2 = 0.0
        var outSum2 = 0.0
        var inMin = Float.POSITIVE_INFINITY
        var inMax = Float.NEGATIVE_INFINITY
        var outMin = Float.POSITIVE_INFINITY
        var outMax = Float.NEGATIVE_INFINITY

        for (i in 0 until ELEMENTS) {
            val a = input[i]
            val b = out[i]
            if (!b.isFinite()) throw IllegalStateException("NAFNet produced non-finite output")
            inSum += a
            outSum += b
            inSum2 += a * a
            outSum2 += b * b
            if (a < inMin) inMin = a
            if (a > inMax) inMax = a
            if (b < outMin) outMin = b
            if (b > outMax) outMax = b
        }

        val n = ELEMENTS.toDouble()
        val inMean = inSum / n
        val outMean = outSum / n
        val inVar = (inSum2 / n - inMean * inMean).coerceAtLeast(0.0)
        val outVar = (outSum2 / n - outMean * outMean).coerceAtLeast(0.0)
        val inStd = sqrt(inVar)
        val outStd = sqrt(outVar)
        val inRange = (inMax - inMin).toDouble()
        val outRange = (outMax - outMin).toDouble()

        // A denoiser may reduce variance, but it must not erase a clearly structured tile.
        val collapsedRange = inRange > 0.08 && outRange < 0.015
        val collapsedStd = inStd > 0.015 && outStd < 0.0025 && outStd < inStd * 0.08
        val collapsedMean = inMean > 0.045 && outMean < 0.0045

        if (collapsedRange || collapsedStd || collapsedMean) {
            throw IllegalStateException(
                "NAFNet output collapsed (in mean %.4f std %.4f range %.4f; out mean %.4f std %.4f range %.4f)"
                    .format(inMean, inStd, inRange, outMean, outStd, outRange)
            )
        }
    }

    override fun close() {
        inputs.forEach { it.close() }
        outputs.forEach { it.close() }
        model.close()
    }

    companion object {
        const val MODEL_NAME = "nafnet_sidd_width32_fp16.tflite"
        const val TILE = 256
        const val ELEMENTS = TILE * TILE * 3
        private const val EXPECTED_BYTES = 62454048L

        private fun ensureModelFile(context: Context): File {
            val file = File(context.filesDir, MODEL_NAME)
            if (file.exists() && file.length() == EXPECTED_BYTES) return file

            val temp = File(context.filesDir, "$MODEL_NAME.tmp")
            context.assets.open(MODEL_NAME).use { input ->
                FileOutputStream(temp).use { output ->
                    input.copyTo(output, 1024 * 1024)
                    output.fd.sync()
                }
            }
            check(temp.length() == EXPECTED_BYTES) {
                "Copied NAFNet model had ${temp.length()} bytes; expected $EXPECTED_BYTES"
            }
            if (file.exists()) file.delete()
            check(temp.renameTo(file)) { "Could not install NAFNet model into filesDir" }
            return file
        }
    }
}
