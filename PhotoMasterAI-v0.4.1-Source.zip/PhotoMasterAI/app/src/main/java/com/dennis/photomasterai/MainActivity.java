package com.dennis.photomasterai;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_OPEN = 1001;
    private static final long MAX_PROCESS_PIXELS = 28_000_000L;
    private static final int BG = Color.rgb(16, 18, 20);
    private static final int PANEL = Color.rgb(24, 27, 31);
    private static final int PANEL2 = Color.rgb(34, 38, 43);
    private static final int TEXT = Color.rgb(245, 247, 250);
    private static final int MUTED = Color.rgb(170, 178, 189);
    private static final int ACCENT = Color.rgb(231, 180, 76);

    private ImageView preview;
    private TextView previewBadge;
    private TextView report;
    private ProgressBar progress;
    private Button masterButton;
    private Button saveButton;
    private Button openButton;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Bitmap originalBitmap;
    private Bitmap masterBitmap;
    private Uri originalUri;
    private PhotoAnalysis originalAnalysis;
    private PhotoMasterEngine.Mode currentMode = PhotoMasterEngine.Mode.TRUE;
    private int decodeSample = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildUi());
        masterButton.setEnabled(false);
        saveButton.setEnabled(false);
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("PHOTO MASTER AI", 26, TEXT, true);
        root.addView(title, lp(-1, -2, 0, 0, 0, 0));
        TextView sub = text("v0.4.1 • Neural output sanity + Social Guard v2", 14, MUTED, false);
        root.addView(sub, lp(-1, -2, 0, 4, 0, 0));

        openButton = button("OPEN PHOTO", false);
        openButton.setOnClickListener(v -> openPhoto());
        root.addView(openButton, lp(-1, -2, 0, 16, 0, 0));

        FrameLayout previewFrame = new FrameLayout(this);
        previewFrame.setBackground(roundRect(PANEL, 18, null));
        root.addView(previewFrame, lp(-1, dp(420), 0, 14, 0, 0));

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setAdjustViewBounds(true);
        preview.setPadding(dp(6), dp(6), dp(6), dp(6));
        previewFrame.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        previewBadge = text("NO PHOTO", 12, TEXT, true);
        previewBadge.setPadding(dp(10), dp(6), dp(10), dp(6));
        previewBadge.setBackground(roundRect(Color.argb(180, 0, 0, 0), 10, null));
        FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        badgeLp.setMargins(dp(12), dp(12), 0, 0);
        previewFrame.addView(previewBadge, badgeLp);

        root.addView(text("Finish", 16, TEXT, true), lp(-1, -2, 0, 16, 0, 0));

        HorizontalScrollView modeScroll = new HorizontalScrollView(this);
        modeScroll.setHorizontalScrollBarEnabled(false);
        RadioGroup modes = new RadioGroup(this);
        modes.setOrientation(RadioGroup.HORIZONTAL);
        String[] labels = {"TRUE", "PRO", "NAT GEO", "LIFE", "AI ENHANCE", "AI MAX"};
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(View.generateViewId());
            rb.setText(labels[i]);
            rb.setTextColor(TEXT);
            rb.setTextSize(12);
            rb.setGravity(Gravity.CENTER);
            rb.setTag(labels[i]);
            rb.setPadding(dp(4), dp(2), dp(10), dp(2));
            rb.setButtonTintList(ColorStateList.valueOf(ACCENT));
            if (i == 0) rb.setChecked(true);
            modes.addView(rb, new RadioGroup.LayoutParams(dp(labels[i].startsWith("AI") ? 132 : 105), -2));
        }
        modes.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = group.findViewById(checkedId);
            if (rb == null) return;
            String tag = String.valueOf(rb.getTag());
            if ("PRO".equals(tag)) currentMode = PhotoMasterEngine.Mode.PRO;
            else if ("NAT GEO".equals(tag)) currentMode = PhotoMasterEngine.Mode.NAT_GEO;
            else if ("LIFE".equals(tag)) currentMode = PhotoMasterEngine.Mode.LIFE;
            else if ("AI ENHANCE".equals(tag)) currentMode = PhotoMasterEngine.Mode.AI_ENHANCE;
            else if ("AI MAX".equals(tag)) currentMode = PhotoMasterEngine.Mode.AI_MAX;
            else currentMode = PhotoMasterEngine.Mode.TRUE;
        });
        modeScroll.addView(modes, new HorizontalScrollView.LayoutParams(-2, -2));
        root.addView(modeScroll, lp(-1, -2, 0, 8, 0, 0));

        masterButton = button("MASTER PHOTO", true);
        masterButton.setTextSize(18);
        masterButton.setOnClickListener(v -> runMaster());
        root.addView(masterButton, lp(-1, -2, 0, 14, 0, 0));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, lp(-1, dp(8), 0, 10, 0, 0));

        LinearLayout compare = new LinearLayout(this);
        compare.setOrientation(LinearLayout.HORIZONTAL);
        Button originalButton = button("ORIGINAL", false);
        Button masterViewButton = button("MASTER", false);
        originalButton.setOnClickListener(v -> showOriginal());
        masterViewButton.setOnClickListener(v -> showMaster());
        LinearLayout.LayoutParams half1 = new LinearLayout.LayoutParams(0, -2, 1f);
        half1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -2, 1f);
        half2.setMargins(dp(6), 0, 0, 0);
        compare.addView(originalButton, half1);
        compare.addView(masterViewButton, half2);
        root.addView(compare, lp(-1, -2, 0, 12, 0, 0));

        saveButton = button("SAVE JPEG 100%", false);
        saveButton.setOnClickListener(v -> saveMaster());
        root.addView(saveButton, lp(-1, -2, 0, 12, 0, 0));

        root.addView(text("Master Confidence", 17, TEXT, true), lp(-1, -2, 0, 18, 0, 0));
        report = text("Open a photo. The engine will analyse first and only apply corrections that cross its confidence thresholds.", 14, MUTED, false);
        report.setTextIsSelectable(true);
        report.setPadding(dp(14), dp(14), dp(14), dp(14));
        report.setBackground(roundRect(PANEL, 18, null));
        root.addView(report, lp(-1, -2, 0, 8, 0, 0));
        return scroll;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? Color.rgb(17, 17, 17) : TEXT);
        b.setBackground(roundRect(primary ? ACCENT : PANEL2, primary ? 16 : 14,
                primary ? null : Color.rgb(58, 64, 71)));
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private GradientDrawable roundRect(int fill, int radiusDp, Integer stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != null) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void openPhoto() {
        // Android 13+ Photo Picker: thumbnail/recents UI, no broad storage permission.
        // This fixes v0.1.0 opening the DCIM folder/document browser on Samsung devices.
        Intent intent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Intent picker = new Intent(MediaStore.ACTION_PICK_IMAGES);
            picker.setType("image/*");
            if (picker.resolveActivity(getPackageManager()) != null) intent = picker;
        }
        if (intent == null) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        startActivityForResult(intent, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_OPEN || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) { }
        loadPhoto(uri);
    }

    private void loadPhoto(Uri uri) {
        setBusy(true, "Loading + analysing…");
        executor.execute(() -> {
            try {
                Bitmap decoded = decodeForProcessing(uri);
                PhotoAnalysis a = PhotoAnalysis.analyse(decoded);
                runOnUiThread(() -> {
                    releaseBitmaps();
                    originalUri = uri;
                    originalBitmap = decoded;
                    originalAnalysis = a;
                    masterBitmap = null;
                    preview.setImageBitmap(originalBitmap);
                    previewBadge.setText("ORIGINAL");
                    String safety = decodeSample > 1
                            ? "\n\nHIGH-RES SAFETY\n• Source exceeded experimental memory limit; decoded at 1/" + decodeSample + " linear size."
                            : "";
                    report.setText("ANALYSIS\n" + a.sceneSummary() + "\n" + a.compactMetrics() + safety
                            + "\n\nReady to master. Deep Pixel Repair measures defects first. AI ENHANCE and AI MAX also run bundled scene/person ML and a gated true neural NAFNet denoise stage when measured noise justifies it.");
                    masterButton.setEnabled(true);
                    saveButton.setEnabled(false);
                    setBusy(false, null);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, null);
                    Toast.makeText(this, "Could not open photo: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private Bitmap decodeForProcessing(Uri uri) throws IOException {
        decodeSample = 1;
        ImageDecoder.Source src = ImageDecoder.createSource(getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(src, (decoder, info, source) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            decoder.setMemorySizePolicy(ImageDecoder.MEMORY_POLICY_LOW_RAM);
            long pixels = (long) info.getSize().getWidth() * (long) info.getSize().getHeight();
            if (pixels > MAX_PROCESS_PIXELS) {
                int sample = (int) Math.ceil(Math.sqrt(pixels / (double) MAX_PROCESS_PIXELS));
                decodeSample = Math.max(2, sample);
                decoder.setTargetSampleSize(decodeSample);
            }
        });
    }

    private void runMaster() {
        if (originalBitmap == null || originalAnalysis == null) return;
        PhotoMasterEngine.Mode mode = currentMode;
        boolean neural = mode == PhotoMasterEngine.Mode.AI_ENHANCE || mode == PhotoMasterEngine.Mode.AI_MAX;
        setBusy(true, neural ? "Running OCR/UI guard + neural vision + gated NAFNet denoise + safety QC…" : "Analysing Deep Pixel Repair…");
        masterButton.setEnabled(false);
        executor.execute(() -> {
            try {
                boolean darkField = RepairSafetyPolicy.isDarkField(
                        originalAnalysis.blackFraction, originalAnalysis.medianLum,
                        originalAnalysis.relativeBrightFraction, originalAnalysis.p95, originalAnalysis.p99);
                SocialSourceAnalyzer.Result social = SocialSourceAnalyzer.analyse(
                        originalBitmap, originalAnalysis, darkField);
                AiVisionAnalyzer.Result ai = neural ? AiVisionAnalyzer.analyse(originalBitmap) : AiVisionAnalyzer.Result.none();
                NeuralDenoiser.Result neuralResult = null;
                Bitmap processingBitmap = originalBitmap;
                PhotoAnalysis processingAnalysis = originalAnalysis;
                Bitmap neuralCandidate = null;
                if (neural) {
                    neuralResult = NeuralDenoiser.process(this, originalBitmap, originalAnalysis, ai, social,
                            mode == PhotoMasterEngine.Mode.AI_MAX);
                    if (neuralResult.accepted && neuralResult.bitmap != null) {
                        processingBitmap = neuralResult.bitmap;
                        processingAnalysis = neuralResult.analysis;
                        neuralCandidate = neuralResult.bitmap;
                    }
                }

                PhotoMasterEngine.Result result;
                try {
                    result = PhotoMasterEngine.master(processingBitmap, processingAnalysis, mode, ai, social);
                } finally {
                    if (neuralCandidate != null && neuralCandidate != originalBitmap && !neuralCandidate.isRecycled()) {
                        neuralCandidate.recycle();
                    }
                }
                final String neuralReport = neuralResult == null ? null : neuralResult.report;
                runOnUiThread(() -> {
                    if (masterBitmap != null && masterBitmap != result.bitmap && !masterBitmap.isRecycled()) masterBitmap.recycle();
                    masterBitmap = result.bitmap;
                    preview.setImageBitmap(masterBitmap);
                    previewBadge.setText("MASTER • " + modeLabel(mode));
                    String extra = decodeSample > 1
                            ? "\n• High-resolution safety decode: 1/" + decodeSample + " linear size"
                            : "";
                    String combined = neuralReport == null ? result.report : neuralReport + "\n\n" + result.report;
                    report.setText(combined + extra);
                    saveButton.setEnabled(true);
                    masterButton.setEnabled(true);
                    setBusy(false, null);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    masterButton.setEnabled(true);
                    setBusy(false, null);
                    Toast.makeText(this, "Master failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showOriginal() {
        if (originalBitmap != null) {
            preview.setImageBitmap(originalBitmap);
            previewBadge.setText("ORIGINAL");
        }
    }

    private void showMaster() {
        if (masterBitmap != null) {
            preview.setImageBitmap(masterBitmap);
            previewBadge.setText("MASTER • " + modeLabel(currentMode));
        }
    }

    private void saveMaster() {
        if (masterBitmap == null) {
            Toast.makeText(this, "Run MASTER PHOTO first.", Toast.LENGTH_SHORT).show();
            return;
        }
        setBusy(true, "Saving JPEG 100%…");
        executor.execute(() -> {
            Uri saved = null;
            try {
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String name = "PhotoMasterAI_" + stamp + "_" + modeLabel(currentMode).replace(" ", "-") + ".jpg";
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhotoMasterAI");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
                ContentResolver cr = getContentResolver();
                saved = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (saved == null) throw new IOException("MediaStore insert failed");
                try (OutputStream os = cr.openOutputStream(saved, "w")) {
                    if (os == null || !masterBitmap.compress(Bitmap.CompressFormat.JPEG, 100, os)) {
                        throw new IOException("JPEG encode failed");
                    }
                }
                copyUsefulExif(originalUri, saved);
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(saved, done, null, null);
                runOnUiThread(() -> {
                    setBusy(false, null);
                    Toast.makeText(this, "Saved to Pictures/PhotoMasterAI", Toast.LENGTH_LONG).show();
                    report.append("\n\nSAVED\n• JPEG quality 100\n• Camera/time/exposure EXIF copied where available\n• GPS metadata is not duplicated in this experimental build");
                });
            } catch (Exception e) {
                if (saved != null) getContentResolver().delete(saved, null, null);
                runOnUiThread(() -> {
                    setBusy(false, null);
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void copyUsefulExif(Uri from, Uri to) {
        if (from == null || to == null) return;
        String[] tags = new String[] {
                ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_DATETIME,
                ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
                ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_EXPOSURE_TIME,
                ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, ExifInterface.TAG_FOCAL_LENGTH,
                ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_LENS_MAKE,
                ExifInterface.TAG_LENS_MODEL, ExifInterface.TAG_FLASH,
                ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_EXPOSURE_BIAS_VALUE
        };
        try (InputStream in = getContentResolver().openInputStream(from);
             android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(to, "rw")) {
            if (in == null || pfd == null) return;
            ExifInterface src = new ExifInterface(in);
            ExifInterface dst = new ExifInterface(pfd.getFileDescriptor());
            for (String tag : tags) {
                String value = src.getAttribute(tag);
                if (value != null) dst.setAttribute(tag, value);
            }
            dst.setAttribute(ExifInterface.TAG_ORIENTATION, String.valueOf(ExifInterface.ORIENTATION_NORMAL));
            dst.setAttribute(ExifInterface.TAG_SOFTWARE, "Photo Master AI v0.4.1 NEURAL-TENSOR-SOCIAL-GUARD");
            dst.saveAttributes();
        } catch (Exception ignored) { }
    }

    private void setBusy(boolean busy, String message) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        openButton.setEnabled(!busy);
        saveButton.setEnabled(!busy && masterBitmap != null);
        if (message != null) previewBadge.setText(message.toUpperCase(Locale.US));
    }

    private String modeLabel(PhotoMasterEngine.Mode mode) {
        switch (mode) {
            case PRO: return "PRO";
            case NAT_GEO: return "NAT GEO";
            case LIFE: return "LIFE";
            case AI_ENHANCE: return "AI ENHANCE";
            case AI_MAX: return "AI MAX";
            default: return "TRUE";
        }
    }

    private void releaseBitmaps() {
        if (masterBitmap != null && !masterBitmap.isRecycled()) masterBitmap.recycle();
        if (originalBitmap != null && !originalBitmap.isRecycled()) originalBitmap.recycle();
        masterBitmap = null;
        originalBitmap = null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        releaseBitmaps();
    }
}
