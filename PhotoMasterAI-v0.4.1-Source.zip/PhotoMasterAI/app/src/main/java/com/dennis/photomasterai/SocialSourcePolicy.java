package com.dennis.photomasterai;

/**
 * Android-free social/screenshot decision policy.
 *
 * v0.4.1 deliberately separates:
 *  1) graphic/UI evidence strong enough to call a source social/screenshot, from
 *  2) photographic ringing/oversharpening, which is only an edge-processed hint.
 *
 * Ringing alone must never classify a normal wildlife/macro image as social.
 */
public final class SocialSourcePolicy {
    public static final class Decision {
        public final boolean guardActive;
        public final boolean edgeProcessedHint;
        public final double confidence;
        public final String reason;

        Decision(boolean guardActive, boolean edgeProcessedHint, double confidence, String reason) {
            this.guardActive = guardActive;
            this.edgeProcessedHint = edgeProcessedHint;
            this.confidence = clamp(confidence, 0.0, 1.0);
            this.reason = reason == null ? "" : reason;
        }
    }

    private SocialSourcePolicy() { }

    public static Decision decide(int textBlocks, int edgeTextBlocks, boolean knownUiToken,
                                  double topBarScore, double bottomBarScore,
                                  double ringing, double blockiness, boolean darkField) {
        if (darkField) {
            return new Decision(false, false, 1.0, "dark-field scene; social classifier bypassed");
        }

        double bar = Math.max(topBarScore, bottomBarScore);
        boolean edgeProcessed = ringing >= 0.78 || blockiness >= 0.18;

        // Strongest evidence: OCR found actual interface wording near an interface-like edge band.
        boolean uiTokenCase = knownUiToken && edgeTextBlocks >= 1 && bar >= 0.22;

        // Generic screenshot/social layout: multiple OCR blocks concentrated at top/bottom
        // together with a uniform/dark/neutral interface band.
        boolean edgeTextCase = edgeTextBlocks >= 2 && bar >= 0.42;
        boolean denseTextCase = textBlocks >= 4 && edgeTextBlocks >= 2 && bar >= 0.30;

        // Text-heavy sources with very strong edge-band geometry can also qualify even
        // without a known English UI token (useful for usernames and non-English UIs).
        boolean graphicLayoutCase = textBlocks >= 3 && edgeTextBlocks >= 1 && bar >= 0.62;

        boolean active = uiTokenCase || edgeTextCase || denseTextCase || graphicLayoutCase;
        if (!active) {
            String why = edgeProcessed
                    ? "edge-heavy / previously sharpened hint only; no UI/text layout evidence"
                    : "no convincing UI/text layout evidence";
            return new Decision(false, edgeProcessed, 0.78, why);
        }

        double confidence = 0.55
                + (knownUiToken ? 0.20 : 0.0)
                + Math.min(0.15, edgeTextBlocks * 0.045)
                + Math.min(0.10, bar * 0.12);
        String reason = knownUiToken
                ? "OCR + edge-interface evidence"
                : "text blocks + edge-interface geometry";
        return new Decision(true, edgeProcessed, confidence, reason);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
