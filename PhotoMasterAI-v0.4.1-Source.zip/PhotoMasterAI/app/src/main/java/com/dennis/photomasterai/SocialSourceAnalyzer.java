package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * v0.4.1 screenshot/social evidence analyser.
 *
 * Uses bundled on-device OCR plus simple edge-band geometry. It intentionally does
 * NOT use ringing as proof of a social source. Ringing is reported separately as an
 * edge-processed hint so sharp feathers, flower edges and macro detail are not
 * mislabeled as social-media UI.
 */
public final class SocialSourceAnalyzer {

    public static final class Result {
        public final boolean available;
        public final boolean guardActive;
        public final boolean edgeProcessedHint;
        public final int textBlocks;
        public final int edgeTextBlocks;
        public final boolean knownUiToken;
        public final double topBarScore;
        public final double bottomBarScore;
        public final double confidence;
        public final String reason;
        public final String error;

        Result(boolean available, boolean guardActive, boolean edgeProcessedHint,
               int textBlocks, int edgeTextBlocks, boolean knownUiToken,
               double topBarScore, double bottomBarScore, double confidence,
               String reason, String error) {
            this.available = available;
            this.guardActive = guardActive;
            this.edgeProcessedHint = edgeProcessedHint;
            this.textBlocks = textBlocks;
            this.edgeTextBlocks = edgeTextBlocks;
            this.knownUiToken = knownUiToken;
            this.topBarScore = topBarScore;
            this.bottomBarScore = bottomBarScore;
            this.confidence = confidence;
            this.reason = reason == null ? "" : reason;
            this.error = error;
        }

        public static Result none() {
            return new Result(false, false, false, 0, 0, false,
                    0.0, 0.0, 0.0, "not analysed", null);
        }

        public String summary() {
            return String.format(Locale.US,
                    "OCR blocks %d | edge text %d | UI token %s | top bar %.2f | bottom bar %.2f | confidence %.0f%%",
                    textBlocks, edgeTextBlocks, knownUiToken ? "yes" : "no",
                    topBarScore, bottomBarScore, confidence * 100.0);
        }
    }

    private SocialSourceAnalyzer() { }

    public static Result analyse(Bitmap source, PhotoAnalysis photo, boolean darkField) {
        TextRecognizer recognizer = null;
        Bitmap small = source;
        try {
            int maxSide = 768;
            double scale = Math.min(1.0, maxSide / (double) Math.max(source.getWidth(), source.getHeight()));
            if (scale < 1.0) {
                small = Bitmap.createScaledBitmap(source,
                        Math.max(2, (int) Math.round(source.getWidth() * scale)),
                        Math.max(2, (int) Math.round(source.getHeight() * scale)), true);
            }

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            Text text = Tasks.await(recognizer.process(InputImage.fromBitmap(small, 0)),
                    18, TimeUnit.SECONDS);

            int w = small.getWidth();
            int h = small.getHeight();
            int blocks = 0;
            int edgeBlocks = 0;
            boolean knownUi = false;
            for (Text.TextBlock b : text.getTextBlocks()) {
                String s = b.getText() == null ? "" : b.getText().trim();
                if (s.isEmpty()) continue;
                blocks++;
                Rect r = b.getBoundingBox();
                if (r != null) {
                    double cy = r.exactCenterY() / Math.max(1.0, h);
                    if (cy <= 0.28 || cy >= 0.72) edgeBlocks++;
                }
                if (containsUiToken(s)) knownUi = true;
            }

            double top = edgeBandScore(small, true);
            double bottom = edgeBandScore(small, false);
            SocialSourcePolicy.Decision d = SocialSourcePolicy.decide(
                    blocks, edgeBlocks, knownUi, top, bottom,
                    photo.ringing, photo.blockiness, darkField);

            return new Result(true, d.guardActive, d.edgeProcessedHint,
                    blocks, edgeBlocks, knownUi, top, bottom,
                    d.confidence, d.reason, null);
        } catch (Throwable t) {
            // OCR failure must never make the mastering pipeline fail.
            SocialSourcePolicy.Decision d = SocialSourcePolicy.decide(
                    0, 0, false, 0.0, 0.0,
                    photo.ringing, photo.blockiness, darkField);
            return new Result(false, false, d.edgeProcessedHint,
                    0, 0, false, 0.0, 0.0,
                    0.0, "OCR unavailable; ringing retained only as edge hint",
                    t.getClass().getSimpleName() + ": " + safeMessage(t));
        } finally {
            try { if (recognizer != null) recognizer.close(); } catch (Throwable ignored) { }
            if (small != source && small != null && !small.isRecycled()) small.recycle();
        }
    }

    /**
     * Measures whether an edge band resembles an app-interface strip rather than
     * ordinary photographic texture: broad dark/neutral coverage plus low local
     * variation and some high-contrast glyph/icon edges.
     */
    private static double edgeBandScore(Bitmap src, boolean top) {
        int w = src.getWidth();
        int h = src.getHeight();
        int bandH = Math.max(8, (int) Math.round(h * (top ? 0.18 : 0.22)));
        int y0 = top ? 0 : Math.max(0, h - bandH);
        int step = Math.max(1, Math.max(w, bandH) / 320);

        long n = 0, darkNeutral = 0, grayNeutral = 0, hardEdges = 0;
        double sum = 0.0, sum2 = 0.0;
        int prev = 0;
        boolean havePrev = false;
        float[] hsv = new float[3];

        for (int y = y0; y < y0 + bandH; y += step) {
            havePrev = false;
            for (int x = 0; x < w; x += step) {
                int c = src.getPixel(x, y);
                int r = Color.red(c), g = Color.green(c), b = Color.blue(c);
                double lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
                Color.RGBToHSV(r, g, b, hsv);
                double sat = hsv[1];
                sum += lum;
                sum2 += lum * lum;
                if (lum < 0.28 && sat < 0.32) darkNeutral++;
                if (sat < 0.14 && lum < 0.72) grayNeutral++;
                if (havePrev) {
                    double pl = (0.2126 * Color.red(prev) + 0.7152 * Color.green(prev)
                            + 0.0722 * Color.blue(prev)) / 255.0;
                    if (Math.abs(lum - pl) > 0.34) hardEdges++;
                }
                prev = c;
                havePrev = true;
                n++;
            }
        }
        if (n < 10) return 0.0;
        double mean = sum / n;
        double variance = Math.max(0.0, sum2 / n - mean * mean);
        double neutralCoverage = Math.max(darkNeutral, grayNeutral) / (double) n;
        double lowVariance = clamp((0.050 - variance) / 0.050, 0.0, 1.0);
        double edgeDensity = clamp((hardEdges / (double) Math.max(1L, n)) / 0.085, 0.0, 1.0);
        return clamp(0.58 * neutralCoverage + 0.24 * lowVariance + 0.18 * edgeDensity, 0.0, 1.0);
    }

    private static boolean containsUiToken(String text) {
        String s = text.toLowerCase(Locale.US);
        String[] tokens = new String[] {
                "message", "reply", "comment", "comments", "story", "stories",
                "ago", "friend", "friends", "following", "followers", "follow",
                "like", "likes", "share", "send", "repost", "view profile",
                "add yours", "for you", "fyp", "subscribe"
        };
        for (String token : tokens) if (s.contains(token)) return true;
        return false;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static String safeMessage(Throwable t) {
        String s = t.getMessage();
        return (s == null || s.trim().isEmpty()) ? "unknown error" : s;
    }
}
