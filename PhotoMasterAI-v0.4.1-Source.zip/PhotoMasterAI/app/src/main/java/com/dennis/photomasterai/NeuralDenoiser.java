package com.dennis.photomasterai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Locale;

/**
 * First true neural restoration stage. NAFNet-SIDD is applied in overlapping
 * context tiles, but only central tile regions are committed so there are no
 * accumulation buffers and memory remains bounded on full-resolution photos.
 */
public final class NeuralDenoiser {
    private static final int TILE = 256;
    private static final int MARGIN = 16;
    private static final int VALID = TILE - MARGIN * 2;
    private static final int PLANE = TILE * TILE;

    public static final class Result {
        public final Bitmap bitmap;
        public final PhotoAnalysis analysis;
        public final boolean attempted;
        public final boolean accepted;
        public final String report;

        Result(Bitmap bitmap, PhotoAnalysis analysis, boolean attempted,
               boolean accepted, String report) {
            this.bitmap = bitmap;
            this.analysis = analysis;
            this.attempted = attempted;
            this.accepted = accepted;
            this.report = report;
        }
    }

    private NeuralDenoiser() { }

    public static Result process(Context context, Bitmap source, PhotoAnalysis before,
                                 AiVisionAnalyzer.Result ai,
                                 SocialSourceAnalyzer.Result social,
                                 boolean aiMax) {
        long pixels = Math.max(1L, (long) before.width * Math.max(1L, (long) before.height));
        boolean darkField = RepairSafetyPolicy.isDarkField(
                before.blackFraction, before.medianLum, before.relativeBrightFraction,
                before.p95, before.p99);
        boolean processed = social != null && social.guardActive;
        boolean personLike = ai != null && ai.available && ai.personLike;

        NeuralDenoisePolicy.Decision decision = NeuralDenoisePolicy.decide(
                before.noise, before.flatChromaNoise, before.detail, pixels,
                aiMax, personLike, darkField, processed);
        if (!decision.active) {
            return new Result(null, before, false, false,
                    "REAL NEURAL DENOISE\n"
                            + "• NAFNet-SIDD width32 / LiteRT 2.2\n"
                            + "• Neural gate: withheld — " + decision.reason + "\n"
                            + "• v0.3.3 deterministic repair remains authoritative");
        }

        Bitmap candidate = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        long start = System.nanoTime();
        int tiles = 0;
        String accelerator = "LiteRT GPU";
        boolean gpuFallback = false;
        NeuralDenoiserRuntime runtime = null;
        try {
            try {
                runtime = new NeuralDenoiserRuntime(context, false);
                runtime.selfTest();
                accelerator = runtime.getAcceleratorLabel();
            } catch (Throwable gpuProblem) {
                if (runtime != null) {
                    try { runtime.close(); } catch (Throwable ignored) { }
                    runtime = null;
                }
                runtime = new NeuralDenoiserRuntime(context, true);
                runtime.selfTest();
                accelerator = runtime.getAcceleratorLabel();
                gpuFallback = true;
            }

            int[] tilePixels = new int[PLANE];
            float[] input = new float[PLANE * 3];
            int[] writePixels = new int[VALID * VALID];

            for (int writeY = 0; writeY < source.getHeight(); writeY += VALID) {
                int writeH = Math.min(VALID, source.getHeight() - writeY);
                for (int writeX = 0; writeX < source.getWidth(); writeX += VALID) {
                    int writeW = Math.min(VALID, source.getWidth() - writeX);
                    int inputX = writeX - MARGIN;
                    int inputY = writeY - MARGIN;

                    readTile(source, inputX, inputY, tilePixels);
                    toNchw(tilePixels, input);
                    float[] restored;
                    try {
                        restored = runtime.run(input);
                    } catch (Throwable tileProblem) {
                        if (!gpuFallback) {
                            try { runtime.close(); } catch (Throwable ignored) { }
                            runtime = new NeuralDenoiserRuntime(context, true);
                            runtime.selfTest();
                            accelerator = runtime.getAcceleratorLabel();
                            gpuFallback = true;
                            restored = runtime.run(input);
                        } else {
                            throw tileProblem;
                        }
                    }
                    renderCentral(restored, tilePixels, writePixels, writeW, writeH,
                            writeX, writeY, source.getWidth(), source.getHeight(),
                            decision.blend, ai);
                    candidate.setPixels(writePixels, 0, writeW,
                            writeX, writeY, writeW, writeH);
                    tiles++;
                }
            }
        } catch (Throwable t) {
            if (!candidate.isRecycled()) candidate.recycle();
            return new Result(null, before, true, false,
                    "REAL NEURAL DENOISE\n"
                            + "• NAFNet-SIDD width32 / LiteRT 2.2\n"
                            + "• NCHW path verified against reference implementation\n"
                            + "• Neural gate: requested\n"
                            + "• Runtime/output sanity failed — v0.3.3 fallback used\n"
                            + "• " + t.getClass().getSimpleName() + ": " + safeMessage(t));
        } finally {
            if (runtime != null) {
                try { runtime.close(); } catch (Throwable ignored) { }
            }
        }

        long elapsedMs = Math.max(1L, Math.round((System.nanoTime() - start) / 1_000_000.0));
        PhotoAnalysis after = PhotoAnalysis.analyse(candidate);
        double beforeDr = before.p95 - before.p05;
        double afterDr = after.p95 - after.p05;
        NeuralDenoisePolicy.Quality quality = NeuralDenoisePolicy.evaluate(
                before.noise, before.flatChromaNoise, before.detail,
                before.ringing, before.medianLum, beforeDr, before.avgSat,
                before.shadowClip, before.highlightClip,
                after.noise, after.flatChromaNoise, after.detail,
                after.ringing, after.medianLum, afterDr, after.avgSat,
                after.shadowClip, after.highlightClip, decision);

        String metrics = String.format(Locale.US,
                "• %s%s • %d tiles • %.1fs total\n"
                        + "• Neural blend %.0f%% | gate confidence %.0f%%\n"
                        + "• Noise %.3f → %.3f | flat chroma %.3f → %.3f\n"
                        + "• Detail %.3f → %.3f | ring %.2f → %.2f",
                accelerator, gpuFallback ? " (GPU output sanity fallback)" : "",
                tiles, elapsedMs / 1000.0,
                decision.blend * 100.0, decision.confidence * 100.0,
                before.noise, after.noise, before.flatChromaNoise, after.flatChromaNoise,
                before.detail, after.detail, before.ringing, after.ringing);

        if (!quality.accepted) {
            candidate.recycle();
            return new Result(null, before, true, false,
                    "REAL NEURAL DENOISE\n"
                            + "• NAFNet-SIDD width32 — true on-device neural denoise\n"
                            + metrics + "\n"
                            + "• Neural rollback: " + quality.reason + "\n"
                            + "• Original pixels restored before v0.3.3 finishing");
        }

        return new Result(candidate, after, true, true,
                "REAL NEURAL DENOISE\n"
                        + "• NAFNet-SIDD width32 — true on-device neural denoise\n"
                        + metrics + "\n"
                        + "• Neural QC: ACCEPTED — " + quality.reason + "\n"
                        + "• Edge + person-aware blend protection active");
    }

    private static void readTile(Bitmap source, int inputX, int inputY, int[] tile) {
        int w = source.getWidth();
        int h = source.getHeight();
        if (inputX >= 0 && inputY >= 0 && inputX + TILE <= w && inputY + TILE <= h) {
            source.getPixels(tile, 0, TILE, inputX, inputY, TILE, TILE);
            return;
        }
        for (int y = 0; y < TILE; y++) {
            int sy = reflect(inputY + y, h);
            int row = y * TILE;
            for (int x = 0; x < TILE; x++) {
                int sx = reflect(inputX + x, w);
                tile[row + x] = source.getPixel(sx, sy);
            }
        }
    }

    private static void toNchw(int[] pixels, float[] out) {
        for (int i = 0; i < PLANE; i++) {
            int c = pixels[i];
            out[i] = Color.red(c) / 255f;
            out[PLANE + i] = Color.green(c) / 255f;
            out[PLANE * 2 + i] = Color.blue(c) / 255f;
        }
    }

    private static void renderCentral(float[] restored, int[] sourceTile, int[] write,
                                      int writeW, int writeH, int globalX, int globalY,
                                      int imageW, int imageH, double blend,
                                      AiVisionAnalyzer.Result ai) {
        for (int y = 0; y < writeH; y++) {
            int ly = y + MARGIN;
            for (int x = 0; x < writeW; x++) {
                int lx = x + MARGIN;
                int i = ly * TILE + lx;
                int src = sourceTile[i];
                int sr = Color.red(src);
                int sg = Color.green(src);
                int sb = Color.blue(src);

                double grad = localGradient(sourceTile, lx, ly);
                double edge = clamp((grad - 0.020) / 0.140, 0.0, 1.0);
                double strength = blend * (1.0 - 0.42 * edge);

                if (ai != null && ai.available && ai.personLike) {
                    float subject = ai.subjectAt(globalX + x, globalY + y, imageW, imageH);
                    strength *= (1.0 - 0.24 * subject);
                    if (subject > 0.20f && isSkinLike(sr, sg, sb)) strength *= 0.78;
                }

                double nr = clamp(restored[i], 0.0, 1.0) * 255.0;
                double ng = clamp(restored[PLANE + i], 0.0, 1.0) * 255.0;
                double nb = clamp(restored[PLANE * 2 + i], 0.0, 1.0) * 255.0;

                int rr = clamp255(sr + (nr - sr) * strength);
                int gg = clamp255(sg + (ng - sg) * strength);
                int bb = clamp255(sb + (nb - sb) * strength);
                write[y * writeW + x] = Color.argb(Color.alpha(src), rr, gg, bb);
            }
        }
    }

    private static double localGradient(int[] p, int x, int y) {
        int i = y * TILE + x;
        double c = lum(p[i]);
        double l = lum(p[y * TILE + Math.max(0, x - 1)]);
        double r = lum(p[y * TILE + Math.min(TILE - 1, x + 1)]);
        double u = lum(p[Math.max(0, y - 1) * TILE + x]);
        double d = lum(p[Math.min(TILE - 1, y + 1) * TILE + x]);
        return Math.max(Math.max(Math.abs(c - l), Math.abs(c - r)),
                Math.max(Math.abs(c - u), Math.abs(c - d)));
    }

    private static double lum(int c) {
        return (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)) / 255.0;
    }

    private static boolean isSkinLike(int r, int g, int b) {
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        return r > 92 && g > 38 && b > 18
                && (max - min) > 15
                && Math.abs(r - g) > 12
                && r > g && r > b;
    }

    private static int reflect(int v, int max) {
        if (max <= 1) return 0;
        while (v < 0 || v >= max) {
            if (v < 0) v = -v - 1;
            if (v >= max) v = 2 * max - v - 1;
        }
        return v;
    }

    private static int clamp255(double v) { return (int) Math.round(clamp(v, 0.0, 255.0)); }
    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
    private static String safeMessage(Throwable t) {
        String s = t.getMessage();
        return (s == null || s.trim().isEmpty()) ? "unknown error" : s;
    }
}
