package com.dennis.autofixcolourlab;

import java.util.Locale;

/** Camera-agnostic scene evidence used to guard colour/tone decisions. */
public final class SceneIntelligence {
    private SceneIntelligence() {}

    public static final class Analysis {
        public final String scene;
        public final double confidence;
        public final double skinCoverage, skyCoverage, foliageCoverage;
        public final double warmCoverage, darkCoverage, highlightCoverage;
        public final boolean preserveWarmth, preserveDarkness, memoryColourGuard, clippingRisk;
        Analysis(String scene, double confidence, double skin, double sky, double foliage,
                 double warm, double dark, double highlights, boolean preserveWarmth,
                 boolean preserveDarkness, boolean memoryColourGuard, boolean clippingRisk) {
            this.scene=scene; this.confidence=confidence; this.skinCoverage=skin; this.skyCoverage=sky;
            this.foliageCoverage=foliage; this.warmCoverage=warm; this.darkCoverage=dark;
            this.highlightCoverage=highlights; this.preserveWarmth=preserveWarmth;
            this.preserveDarkness=preserveDarkness; this.memoryColourGuard=memoryColourGuard;
            this.clippingRisk=clippingRisk;
        }
        public String summary() {
            return String.format(Locale.US,
                "Scene: %s  •  confidence %.0f%%\nMemory colours: skin %.0f%%  sky %.0f%%  foliage %.0f%%\nGuards: warmth %s  darkness %s  channel clipping %s",
                scene, confidence*100, skinCoverage*100, skyCoverage*100, foliageCoverage*100,
                preserveWarmth?"protected":"normal", preserveDarkness?"protected":"normal",
                clippingRisk?"active":"clear");
        }
    }

    public static final class Accumulator {
        long n, skin, sky, foliage, warm, dark, highlight, clipped;
        double satSum, lumSum;
        public void addPixel(int argb) {
            if (((argb>>>24)&255)<16) return;
            int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;
            int max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b));
            double sat=max==0?0:(max-min)/(double)max;
            double lum=.2126*r+.7152*g+.0722*b;
            n++; satSum+=sat; lumSum+=lum;
            if (lum<58) dark++;
            if (max>244) highlight++;
            if (max>252 && min<235) clipped++;
            // Broad, conservative memory-colour evidence only; never used to force a target hue.
            if (r>72 && g>38 && b>24 && r>g*1.08 && g>b*1.05 && (r-b)>24 && sat<0.62) skin++;
            if (b>g*1.05 && b>r*1.16 && b>70 && lum>55 && sat>0.18) sky++;
            if (g>r*1.08 && g>b*1.04 && g>55 && sat>0.16) foliage++;
            if (r>g*1.10 && g>b*1.04 && lum>45 && sat>0.12) warm++;
        }
        public Analysis finish() {
            if(n==0) return new Analysis("unknown",0,0,0,0,0,0,0,false,false,false,false);
            double N=n, sk=skin/N, sy=sky/N, fo=foliage/N, wa=warm/N, da=dark/N, hi=highlight/N, cl=clipped/N;
            String scene="general"; double conf=.45;
            if (da>.62) { scene="night / low-key"; conf=Math.min(.95,.55+da*.45); }
            else if (wa>.34 && hi>.04) { scene="sunset / warm light"; conf=Math.min(.92,.50+wa*.65); }
            else if (sk>.10) { scene="people / skin dominant"; conf=Math.min(.90,.52+sk*1.6); }
            else if (fo>.24) { scene="foliage / outdoors"; conf=Math.min(.90,.50+fo); }
            else if (sy>.18) { scene="open sky / daylight"; conf=Math.min(.88,.50+sy); }
            boolean warmth=wa>.30 && (hi>.025 || sy<.08);
            boolean darkness=da>.58;
            boolean memory=sk>.035 || sy>.10 || fo>.15;
            boolean clip=cl>.0025 || hi>.16;
            return new Analysis(scene,conf,sk,sy,fo,wa,da,hi,warmth,darkness,memory,clip);
        }
    }
}
