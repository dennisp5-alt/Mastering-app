#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
android_sdk_dir="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/workspace/android-sdk}}"
build_tools_dir="$android_sdk_dir/build-tools/34.0.0"
android_jar="$android_sdk_dir/platforms/android-34/android.jar"

if [[ ! -f "$android_jar" || ! -x "$build_tools_dir/aapt2" ]]; then
  echo "Android SDK 34 was not found. Set ANDROID_SDK_ROOT to an SDK containing platform 34 and build-tools 34.0.0." >&2
  exit 2
fi

"$project_dir/run-tests.sh"

mkdir -p "$project_dir/build" "$project_dir/release" "$project_dir/signing"
run_dir="$(mktemp -d "$project_dir/build/run.XXXXXX")"
trap 'rm -r -- "$run_dir"' EXIT
compiled_resources="$run_dir/compiled-resources.zip"
unsigned_apk="$run_dir/unsigned.apk"
aligned_apk="$run_dir/aligned.apk"
generated_dir="$run_dir/generated"
classes_dir="$run_dir/classes"
dex_dir="$run_dir/dex"
final_apk="$project_dir/release/AutoFix-True-Colour-Lab-v0.5.0-TEST.apk"
keystore="$project_dir/signing/autofix-true-colour-lab-private-test.jks"

mkdir -p "$generated_dir" "$classes_dir" "$dex_dir"

"$build_tools_dir/aapt2" compile \
  --dir "$project_dir/app/src/main/res" \
  -o "$compiled_resources"

"$build_tools_dir/aapt2" link \
  -o "$unsigned_apk" \
  -I "$android_jar" \
  --manifest "$project_dir/app/src/main/AndroidManifest.xml" \
  --java "$generated_dir" \
  --min-sdk-version 29 \
  --target-sdk-version 34 \
  --version-code 5 \
  --version-name 0.5.0 \
  "$compiled_resources"

mapfile -t java_sources < <(find \
  "$project_dir/app/src/main/java" \
  "$generated_dir" \
  -type f -name '*.java' | sort)

java -m jdk.compiler/com.sun.tools.javac.Main \
  -source 17 \
  -target 17 \
  -encoding UTF-8 \
  -classpath "$android_jar" \
  -d "$classes_dir" \
  "${java_sources[@]}"

mapfile -t class_files < <(find "$classes_dir" -type f -name '*.class' | sort)
"$build_tools_dir/d8" \
  --min-api 29 \
  --lib "$android_jar" \
  --output "$dex_dir" \
  "${class_files[@]}"

zip -q -j "$unsigned_apk" "$dex_dir/classes.dex"
"$build_tools_dir/zipalign" -f -p 4 "$unsigned_apk" "$aligned_apk"

if [[ ! -f "$keystore" ]]; then
  keytool -genkeypair \
    -keystore "$keystore" \
    -storepass autofix-private-test \
    -keypass autofix-private-test \
    -alias autofixhistogram \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=Dennis AutoFix True Colour Lab, O=Private Test, C=AU" \
    -noprompt
fi

"$build_tools_dir/apksigner" sign \
  --v4-signing-enabled false \
  --ks "$keystore" \
  --ks-key-alias autofixhistogram \
  --ks-pass pass:autofix-private-test \
  --key-pass pass:autofix-private-test \
  --out "$final_apk" \
  "$aligned_apk"

"$build_tools_dir/apksigner" verify --verbose --print-certs "$final_apk"
sha256sum "$final_apk"
