# S23U Auto+ AI Camera v0.2.0

Auto Quality Brain built on the stable v0.1.9 S23 Ultra Camera2 YUV capture/save/orientation baseline.

## Stable core retained
- Logical camera 0 with physical S23U lens binding
- 0.6x physical 2, 1x physical 5, 3x physical 6, 10x physical 7
- Full-resolution YUV still capture
- App-side NV21 -> JPEG quality 100
- MediaStore save path
- Fixed portrait/landscape orientation mapping from v0.1.9
- Fast one-pass TRUE / PRO / NAT GEO finishing

## v0.2.0 Auto Quality Brain
- Zoom buttons now mean requested framing, while the engine separately records the physical optical route.
- Auto Quality uses the selected lens own live Camera2 ISO and shutter metadata plus gyro motion and face presence.
- 10x normally uses physical ID 7; in measured low light, subject motion or portrait risk it can route to the brighter 3x ID 6 and crop once to 10x framing.
- 3x normally uses physical ID 6; only extreme low-light/action conditions can route to the main ID 5.
- Hysteresis prevents easy bouncing back to a darker tele lens after a quality fallback.
- Requested 3x/10x AI output remains standardized to 12 MP.
- Preview is centre-cropped to the same requested framing when Auto Quality uses a shorter optical lens.
- REFERENCE mode forces the exact requested physical lens so the diagnostic JPEG remains untouched.
- New LENS: AUTO QUALITY / LENS: EXACT control for A/B testing.

## Intelligent AF/AE weighting
- Face regions get first priority when Camera2 face detection is available.
- Otherwise a lightweight 7x7 / 49-zone viewfinder analysis finds a detailed, sensibly exposed subject region with center weighting.
- The selected region is mapped back through requested framing and orientation into the camera active-array coordinate system.
- AE highlight protection remains conservative and can add a small motion bias when shutter speed is already slow.
- The session itself is not rebuilt for metering: only capture request metadata changes.

## Diagnostics
Each shot now records requested vs optical zoom, route reason, framing crop, ISO, shutterMs, motion, meter source/position, preview clipping estimate, AE compensation, process time and active physical camera.

VersionCode: 11
VersionName: 0.2.0
