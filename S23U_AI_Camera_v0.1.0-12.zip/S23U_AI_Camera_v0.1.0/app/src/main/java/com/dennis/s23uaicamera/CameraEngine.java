package com.dennis.s23uaicamera;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.Face;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import org.json.JSONObject;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v0.2.0 Auto Quality engine.
 *
 * The proven logical-0 + physical-output YUV capture/save architecture remains
 * unchanged. Auto Quality sits around it: the requested zoom is separated from
 * the actual optical route, preview exposure metadata and gyro motion decide
 * whether a brighter physical lens should be used, and one finishing pass keeps
 * the requested field of view.
 */
public final class CameraEngine {
    public interface Listener {
        void onTelemetry(FrameAnalysis analysis, int faceCount, String activePhysicalId,
                         float requestedZoom, float opticalZoom, int appliedEvSteps,
                         int iso, float shutterMs, String routeReason, String meterSource);
        void onPhotoSaved(String message);
        void onError(String message, Throwable error);
    }

    private static final String LOGICAL_ID = "0";

    private static final class LensSpec {
        final String label;
        final float zoom;
        final String physicalId;
        final int preferredW;
        final int preferredH;
        LensSpec(String label, float zoom, String physicalId, int preferredW, int preferredH) {
            this.label = label;
            this.zoom = zoom;
            this.physicalId = physicalId;
            this.preferredW = preferredW;
            this.preferredH = preferredH;
        }
    }

    private static final class RouteDecision {
        final LensSpec lens;
        final String reason;
        RouteDecision(LensSpec lens, String reason) {
            this.lens = lens;
            this.reason = reason;
        }
    }

    private static final class ShutterDecision {
        final int evSteps;
        final MeteringRectangle region;
        final String source;
        final float targetX;
        final float targetY;
        final float brightFraction;
        final int p95;
        ShutterDecision(int evSteps, MeteringRectangle region, String source,
                        float targetX, float targetY, float brightFraction, int p95) {
            this.evSteps = evSteps;
            this.region = region;
            this.source = source;
            this.targetX = targetX;
            this.targetY = targetY;
            this.brightFraction = brightFraction;
            this.p95 = p95;
        }
    }

    private static final LensSpec ULTRA = new LensSpec("0.6×", 0.6f, "2", 4000, 3000);
    private static final LensSpec MAIN  = new LensSpec("1×",   1.0f, "5", 4080, 3060);
    private static final LensSpec TELE3 = new LensSpec("3×",   3.0f, "6", 3648, 2736);
    private static final LensSpec TELE10= new LensSpec("10×", 10.0f, "7", 3648, 2736);

    private final Context context;
    private final TextureView textureView;
    private final Listener listener;
    private final CameraManager manager;
    private final ExecutorService processing = Executors.newSingleThreadExecutor();

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader captureReader;
    private Surface previewSurface;
    private CameraCharacteristics logicalCharacteristics;
    private CameraCharacteristics physicalCharacteristics;

    // requestedLens is the framing the user asked for. activeLens is the real
    // physical camera currently feeding the session.
    private LensSpec requestedLens = MAIN;
    private LensSpec activeLens = MAIN;
    private Size captureSize = new Size(4080, 3060);
    private Size previewSize = new Size(1440, 1080);
    private boolean physicalBinding = true;
    private volatile boolean captureBusy = false;
    private volatile boolean pendingAutoCapture = false;
    private volatile int captureGeneration = 0;
    private volatile boolean aiEnabled = true;
    private volatile boolean autoLevel = true;
    private volatile boolean autoQuality = true;
    private volatile String look = "TRUE";
    private volatile float rollDeg = 0f;
    private volatile float motion = 0f;
    private volatile float requestedZoom = 1f;
    private volatile int lastFaceCount = 0;
    private volatile String lastActivePhysicalId = "5";
    private volatile int deviceOrientationDeg = 0;
    private volatile int lastAppliedEvSteps = 0;
    private volatile int lastPreviewIso = 0;
    private volatile long lastPreviewExposureNs = 0L;
    private volatile float lastPreviewShutterMs = 0f;
    private volatile String routeReason = "EXACT OPTICAL";
    private volatile String lastMeterSource = "CENTER";
    private volatile Rect lastFaceBounds = null;
    private volatile long lastTelemetryEmitMs = 0L;

    // Snapshot of the route/decision that belongs to the in-flight still.
    private LensSpec shotRequestedLens = MAIN;
    private LensSpec shotOpticalLens = MAIN;
    private String shotRouteReason = "EXACT OPTICAL";
    private String shotMeterSource = "CENTER";
    private float shotMeterX = .5f;
    private float shotMeterY = .5f;
    private float shotBrightFraction = 0f;
    private int shotP95 = 0;
    private int shotIso = 0;
    private float shotShutterMs = 0f;

    private FrameAnalysis lastAnalysis = new FrameAnalysis(0,0,0,0,0,24,.5f,.5f,0,"READY");

    public CameraEngine(Context context, TextureView textureView, Listener listener) {
        this.context = context.getApplicationContext();
        this.textureView = textureView;
        this.listener = listener;
        this.manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public void start() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("AutoPlusCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        openCamera();
    }

    public void stop() {
        Handler h = cameraHandler;
        if (h != null) h.post(this::closeCamera);
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(1000); } catch (InterruptedException ignored) {}
        }
        cameraThread = null;
        cameraHandler = null;
    }

    public void shutdown() {
        stop();
        processing.shutdown();
    }

    public void setZoom(float value) {
        LensSpec requested = lensForZoom(value);
        Handler h = cameraHandler;
        if (h == null) {
            // Allows initial configuration before start() creates the camera thread.
            requestedZoom = requested.zoom;
            requestedLens = requested;
            activeLens = requested;
            return;
        }
        h.post(() -> {
            if (captureBusy || pendingAutoCapture) {
                listener.onPhotoSaved("Finish the current capture before changing lens");
                return;
            }
            requestedZoom = requested.zoom;
            requestedLens = requested;
            // Always give the requested physical lens a chance first. The shutter
            // decision can then judge that lens using its own ISO/shutter data.
            routeReason = autoQuality && aiEnabled ? "AUTO • EVALUATING " + requested.label : "EXACT OPTICAL";
            if (activeLens == requested && session != null) {
                applyRequestedFramingToPreview();
                emitTelemetry();
                return;
            }
            switchActiveLens(requested, routeReason);
        });
    }

    public void setAiEnabled(boolean value) {
        aiEnabled = value;
        if (!value) forceExactRequestedRoute("REFERENCE • EXACT OPTICAL");
    }

    public void setAutoLevel(boolean value) { autoLevel = value; }
    public void setLook(String value) { look = value == null ? "TRUE" : value; }
    public void setMotion(float value) { motion = value; }
    public void setRoll(float value) { rollDeg = value; }
    public void setDeviceOrientation(int value) { deviceOrientationDeg = ((value % 360) + 360) % 360; }

    public void setAutoQuality(boolean value) {
        autoQuality = value;
        if (!value) forceExactRequestedRoute("EXACT OPTICAL");
        else {
            routeReason = "AUTO • EVALUATING " + requestedLens.label;
            emitTelemetry();
        }
    }

    private void forceExactRequestedRoute(String reason) {
        Handler h = cameraHandler;
        if (h == null) return;
        h.post(() -> {
            routeReason = reason;
            if (!captureBusy && !pendingAutoCapture && activeLens != requestedLens) {
                switchActiveLens(requestedLens, reason);
            } else {
                applyRequestedFramingToPreview();
                emitTelemetry();
            }
        });
    }

    private LensSpec lensForZoom(float value) {
        if (value < 0.8f) return ULTRA;
        if (value < 2.0f) return MAIN;
        if (value < 6.0f) return TELE3;
        return TELE10;
    }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        try {
            logicalCharacteristics = manager.getCameraCharacteristics(LOGICAL_ID);
            loadPhysicalCharacteristics();
            chooseCaptureSize();
            manager.openCamera(LOGICAL_ID, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    camera = c;
                    listener.onPhotoSaved("Camera ready • requested " + requestedLens.label + " • optical " + activeLens.label);
                    createSession(true);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    c.close(); camera = null;
                    notifyError("Camera disconnected", null);
                }
                @Override public void onError(CameraDevice c, int error) {
                    c.close(); camera = null;
                    notifyError("Camera open error " + error, null);
                }
            }, cameraHandler);
        } catch (Exception e) {
            notifyError("Unable to open camera", e);
        }
    }

    private void switchActiveLens(LensSpec next, String reason) {
        activeLens = next;
        routeReason = reason;
        lastPreviewIso = 0;
        lastPreviewExposureNs = 0L;
        lastPreviewShutterMs = 0f;
        lastFaceCount = 0;
        lastFaceBounds = null;
        listener.onPhotoSaved("Routing " + requestedLens.label + " framing → " + next.label + " optical…");
        loadPhysicalCharacteristics();
        chooseCaptureSize();
        createSession(true);
    }

    private void loadPhysicalCharacteristics() {
        try {
            physicalCharacteristics = manager.getCameraCharacteristics(activeLens.physicalId);
        } catch (Exception ignored) {
            physicalCharacteristics = null;
        }
    }

    private void chooseCaptureSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] yuv = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    .getOutputSizes(ImageFormat.YUV_420_888);
            if (yuv == null || yuv.length == 0) return;
            Size best = null;
            for (Size s : yuv) {
                if (s.getWidth() == activeLens.preferredW && s.getHeight() == activeLens.preferredH) {
                    best = s;
                    break;
                }
                float aspect = s.getWidth() / (float)Math.max(1, s.getHeight());
                if (Math.abs(aspect - 4f/3f) > 0.03f) continue;
                if (best == null || (long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
            }
            if (best == null) best = yuv[0];
            captureSize = best;
        } catch (Exception ignored) {}
    }

    private void createSession(boolean bindPhysical) {
        if (camera == null || !textureView.isAvailable()) return;
        closeSessionOnly();
        physicalBinding = bindPhysical;
        try {
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            previewSize = choosePreviewSize();
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            refreshPreviewGeometry();
            previewSurface = new Surface(st);

            captureReader = ImageReader.newInstance(captureSize.getWidth(), captureSize.getHeight(), ImageFormat.YUV_420_888, 3);
            captureReader.setOnImageAvailableListener(this::onCaptureYuvAvailable, cameraHandler);

            OutputConfiguration previewOut = new OutputConfiguration(previewSurface);
            OutputConfiguration captureOut = new OutputConfiguration(captureReader.getSurface());
            if (bindPhysical) {
                previewOut.setPhysicalCameraId(activeLens.physicalId);
                captureOut.setPhysicalCameraId(activeLens.physicalId);
            }
            List<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(previewOut);
            outputs.add(captureOut);

            Executor executor = command -> {
                Handler h = cameraHandler;
                if (h != null) h.post(command);
            };
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR,
                    outputs,
                    executor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            if (camera == null) { s.close(); return; }
                            session = s;
                            try {
                                previewBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                previewBuilder.addTarget(previewSurface);
                                applySafeAuto(previewBuilder, false);
                                session.setRepeatingRequest(previewBuilder.build(), previewCaptureCallback, cameraHandler);
                                lastActivePhysicalId = physicalBinding ? activeLens.physicalId : "logical";
                                applyRequestedFramingToPreview();
                                listener.onPhotoSaved((physicalBinding ? "Optical " + activeLens.label : "Logical fallback") +
                                        " ready • " + captureSize.getWidth() + "×" + captureSize.getHeight());
                                emitTelemetry();
                                if (pendingAutoCapture) {
                                    pendingAutoCapture = false;
                                    Handler h = cameraHandler;
                                    if (h != null) h.postDelayed(() -> prepareCapture(true), 180);
                                }
                            } catch (Exception e) {
                                pendingAutoCapture = false;
                                notifyError("Unable to start preview", e);
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            if (bindPhysical) {
                                listener.onPhotoSaved("Physical " + activeLens.label + " route rejected • trying logical fallback");
                                createSession(false);
                            } else {
                                pendingAutoCapture = false;
                                notifyError("Camera session configuration failed", null);
                            }
                        }
                    });
            camera.createCaptureSession(config);
        } catch (Exception e) {
            if (bindPhysical) {
                listener.onPhotoSaved("Physical " + activeLens.label + " route error • trying logical fallback");
                createSession(false);
            } else {
                pendingAutoCapture = false;
                notifyError("Unable to create capture session", e);
            }
        }
    }

    private Size choosePreviewSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] sizes = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(SurfaceTexture.class);
            if (sizes != null && sizes.length > 0) {
                for (Size s : sizes) if (s.getWidth() == 1440 && s.getHeight() == 1080) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1440) return s;
                Size best = null;
                for (Size s : sizes) {
                    float a = s.getWidth() / (float)Math.max(1, s.getHeight());
                    if (Math.abs(a - 4f/3f) > 0.03f || s.getWidth() > 1920) continue;
                    if (best == null || (long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
                }
                if (best != null) return best;
                return sizes[0];
            }
        } catch (Exception ignored) {}
        return new Size(1440,1080);
    }

    private void applySafeAuto(CaptureRequest.Builder b, boolean still) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        try { b.set(CaptureRequest.CONTROL_ZOOM_RATIO, physicalBinding ? 1.0f : activeLens.zoom); } catch (Exception ignored) {}
        try { b.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, CaptureRequest.STATISTICS_FACE_DETECT_MODE_SIMPLE); } catch (Exception ignored) {}
        if (still) {
            try { b.set(CaptureRequest.CONTROL_ENABLE_ZSL, true); } catch (Exception ignored) {}
        }
    }

    private final CameraCaptureSession.CaptureCallback previewCaptureCallback = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
            try {
                Face[] faces = result.get(CaptureResult.STATISTICS_FACES);
                lastFaceCount = faces == null ? 0 : faces.length;
                lastFaceBounds = chooseLargestFace(faces);
                String active = result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
                if (active != null && !active.isEmpty()) lastActivePhysicalId = active;
                Integer iso = result.get(CaptureResult.SENSOR_SENSITIVITY);
                Long exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
                if (iso != null && iso > 0) lastPreviewIso = iso;
                if (exposure != null && exposure > 0) {
                    lastPreviewExposureNs = exposure;
                    lastPreviewShutterMs = exposure / 1_000_000f;
                }
                long now = SystemClock.elapsedRealtime();
                if (now - lastTelemetryEmitMs >= 500L) {
                    lastTelemetryEmitMs = now;
                    if (autoQuality && aiEnabled && !captureBusy && !pendingAutoCapture) {
                        RouteDecision hint = decideAutoQualityRoute();
                        routeReason = hint.lens == activeLens ? hint.reason : "AUTO READY • " + hint.reason;
                    }
                    emitTelemetry();
                }
            } catch (Exception ignored) {}
        }
    };

    private Rect chooseLargestFace(Face[] faces) {
        if (faces == null || faces.length == 0) return null;
        Rect best = null;
        long bestArea = -1;
        for (Face f : faces) {
            if (f == null || f.getBounds() == null) continue;
            Rect r = f.getBounds();
            long area = (long)Math.max(1, r.width()) * Math.max(1, r.height());
            if (area > bestArea) {
                bestArea = area;
                best = new Rect(r);
            }
        }
        return best;
    }

    public void capture() {
        Handler h = cameraHandler;
        if (h == null) {
            notifyError("Capture unavailable: camera thread is not running", null);
            return;
        }
        h.post(() -> prepareCapture(false));
    }

    private void prepareCapture(boolean routeLocked) {
        if (captureBusy || pendingAutoCapture) {
            listener.onPhotoSaved("Capture already in progress");
            return;
        }
        if (camera == null || session == null || captureReader == null) {
            notifyError("Capture unavailable: session/YUV output not ready", null);
            return;
        }

        if (!routeLocked && autoQuality && aiEnabled) {
            RouteDecision decision = decideAutoQualityRoute();
            routeReason = decision.reason;
            if (decision.lens != activeLens) {
                pendingAutoCapture = true;
                listener.onPhotoSaved("Auto Quality • " + requestedLens.label + " framing → " + decision.lens.label + " • " + decision.reason);
                switchActiveLens(decision.lens, decision.reason);
                return;
            }
        } else if (!autoQuality || !aiEnabled) {
            routeReason = aiEnabled ? "EXACT OPTICAL" : "REFERENCE • EXACT OPTICAL";
        }

        captureWithMetering();
    }

    private RouteDecision decideAutoQualityRoute() {
        if (!autoQuality || !aiEnabled) return new RouteDecision(requestedLens, "EXACT OPTICAL");
        if (requestedLens == ULTRA || requestedLens == MAIN) {
            return new RouteDecision(requestedLens, "AUTO • EXACT " + requestedLens.label);
        }
        if (lastPreviewIso <= 0 || lastPreviewExposureNs <= 0L) {
            return new RouteDecision(requestedLens, "AUTO • EXPOSURE NOT READY");
        }

        final int iso = lastPreviewIso;
        final float shutter = lastPreviewShutterMs;
        final double burden = iso * Math.max(0.1, shutter);
        final boolean moving = motion >= 0.90f;
        final boolean strongMotion = motion >= 1.25f;
        final boolean person = lastFaceCount > 0;

        if (requestedLens == TELE10) {
            if (activeLens == TELE10) {
                if (strongMotion && shutter >= 10f)
                    return new RouteDecision(TELE3, "MOTION → BRIGHTER 3×");
                if (person && (iso >= 1000 || shutter >= 20f))
                    return new RouteDecision(TELE3, "PERSON/LOW LIGHT → 3×");
                if (iso >= 1600 || shutter >= 25f || burden >= 30000)
                    return new RouteDecision(TELE3, "LOW LIGHT → BRIGHTER 3×");
                if (moving && shutter >= 14f)
                    return new RouteDecision(TELE3, "HAND MOTION → BRIGHTER 3×");
                return new RouteDecision(TELE10, "GOOD LIGHT → TRUE 10×");
            }

            if (activeLens == TELE3) {
                // Hysteresis: only return to the f/4.9 periscope when the 3×
                // preview is exceptionally bright and the phone is steady.
                if (iso <= 160 && shutter <= 5.0f && burden <= 800 && motion < 0.28f && !person)
                    return new RouteDecision(TELE10, "VERY GOOD LIGHT → TRUE 10×");
                return new RouteDecision(TELE3, "AUTO HOLD • 3× FOR 10× FRAMING");
            }

            return new RouteDecision(TELE10, "AUTO • TRY TRUE 10×");
        }

        // Requested 3×: preserve the physical 3× lens unless conditions are
        // genuinely difficult. The main-camera crop is an emergency quality
        // route, not the default.
        if (requestedLens == TELE3) {
            if (activeLens == TELE3) {
                if (strongMotion && shutter >= 18f)
                    return new RouteDecision(MAIN, "ACTION/LOW LIGHT → MAIN");
                if (person && (iso >= 2800 || shutter >= 30f))
                    return new RouteDecision(MAIN, "PERSON/EXTREME LIGHT → MAIN");
                if (iso >= 3600 || shutter >= 40f || burden >= 120000)
                    return new RouteDecision(MAIN, "EXTREME LOW LIGHT → MAIN");
                return new RouteDecision(TELE3, "GOOD ENOUGH → TRUE 3×");
            }
            if (activeLens == MAIN) {
                if (iso <= 400 && shutter <= 10f && burden <= 4000 && motion < 0.50f)
                    return new RouteDecision(TELE3, "LIGHT RECOVERED → TRUE 3×");
                return new RouteDecision(MAIN, "AUTO HOLD • MAIN FOR 3× FRAMING");
            }
        }
        return new RouteDecision(requestedLens, "AUTO • EXACT");
    }

    private void captureWithMetering() {
        captureBusy = true;
        final int gen = ++captureGeneration;
        final ShutterDecision decision = analyzeShutterPreview();
        lastAppliedEvSteps = decision.evSteps;
        lastMeterSource = decision.source;

        listener.onPhotoSaved("Capturing " + requestedLens.label + " • optical " + activeLens.label + " • " + routeReason);
        emitTelemetry();

        // Give AE/AF a short moment to react to the selected region before the
        // still request. This changes only request metadata, not the session.
        try {
            if (previewBuilder != null && session != null) {
                applyMetering(previewBuilder, decision);
                session.setRepeatingRequest(previewBuilder.build(), previewCaptureCallback, cameraHandler);
            }
        } catch (Exception ignored) {}

        Handler h = cameraHandler;
        if (h != null) h.postDelayed(() -> submitStill(gen, decision), 90);
    }

    private void submitStill(int gen, ShutterDecision decision) {
        if (!captureBusy || captureGeneration != gen) return;
        try {
            CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(captureReader.getSurface());
            applySafeAuto(b, true);
            applyMetering(b, decision);
            b.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);

            shotRequestedLens = requestedLens;
            shotOpticalLens = activeLens;
            shotRouteReason = routeReason;
            shotMeterSource = decision.source;
            shotMeterX = decision.targetX;
            shotMeterY = decision.targetY;
            shotBrightFraction = decision.brightFraction;
            shotP95 = decision.p95;
            shotIso = lastPreviewIso;
            shotShutterMs = lastPreviewShutterMs;

            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
                    try {
                        String active = result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
                        if (active != null && !active.isEmpty()) lastActivePhysicalId = active;
                        Face[] faces = result.get(CaptureResult.STATISTICS_FACES);
                        if (faces != null) lastFaceCount = faces.length;
                        Integer iso = result.get(CaptureResult.SENSOR_SENSITIVITY);
                        Long exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
                        if (iso != null) shotIso = iso;
                        if (exposure != null) shotShutterMs = exposure / 1_000_000f;
                        if (physicalBinding && active != null && !shotOpticalLens.physicalId.equals(active)) {
                            listener.onPhotoSaved("Lens fallback detected: requested physical " + shotOpticalLens.physicalId + " / active " + active);
                        }
                    } catch (Exception ignored) {}
                    restorePreviewAuto();
                }
                @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    if (captureGeneration == gen) captureBusy = false;
                    restorePreviewAuto();
                    notifyError("Still capture failed: reason " + failure.getReason(), null);
                }
                @Override public void onCaptureSequenceAborted(CameraCaptureSession s, int sequenceId) {
                    if (captureGeneration == gen) captureBusy = false;
                    restorePreviewAuto();
                    notifyError("Still capture sequence aborted", null);
                }
            }, cameraHandler);

            Handler h = cameraHandler;
            if (h != null) h.postDelayed(() -> {
                if (captureBusy && captureGeneration == gen) {
                    captureBusy = false;
                    restorePreviewAuto();
                    notifyError("Capture timed out before the YUV frame arrived", null);
                }
            }, 8000);
        } catch (Exception e) {
            captureBusy = false;
            restorePreviewAuto();
            notifyError("Unable to submit still capture", e);
        }
    }

    private void restorePreviewAuto() {
        try {
            if (previewBuilder == null || session == null) return;
            applySafeAuto(previewBuilder, false);
            ShutterDecision center = centerDecision(0, "CENTER", 0f, 0);
            applyMetering(previewBuilder, center);
            lastMeterSource = "CENTER";
            lastAppliedEvSteps = 0;
            session.setRepeatingRequest(previewBuilder.build(), previewCaptureCallback, cameraHandler);
        } catch (Exception ignored) {}
    }

    private void applyMetering(CaptureRequest.Builder b, ShutterDecision d) {
        if (d == null) return;
        try { b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, d.evSteps); } catch (Exception ignored) {}
        if (d.region == null) return;
        try {
            Integer maxAe = logicalCharacteristics == null ? null : logicalCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            if (maxAe != null && maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, new MeteringRectangle[]{d.region});
        } catch (Exception ignored) {}
        try {
            Integer maxAf = logicalCharacteristics == null ? null : logicalCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            if (maxAf != null && maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{d.region});
        } catch (Exception ignored) {}
    }

    private void clearMetering(CaptureRequest.Builder b) {
        try {
            Integer maxAe = logicalCharacteristics == null ? null : logicalCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            if (maxAe != null && maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, new MeteringRectangle[0]);
        } catch (Exception ignored) {}
        try {
            Integer maxAf = logicalCharacteristics == null ? null : logicalCharacteristics.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            if (maxAf != null && maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[0]);
        } catch (Exception ignored) {}
    }

    private ShutterDecision analyzeShutterPreview() {
        Bitmap thumb = null;
        try {
            final int grid = 7;
            thumb = textureView.getBitmap(84, 63);
            if (thumb == null) return centerDecision(0, "CENTER", 0f, 0);
            int w = thumb.getWidth(), h = thumb.getHeight();
            int[] pixels = new int[w * h];
            thumb.getPixels(pixels, 0, w, 0, 0, w, h);
            int[] hist = new int[256];
            long[] sum = new long[49];
            long[] sum2 = new long[49];
            int[] count = new int[49];
            int bright = 0;

            for (int y = 0; y < h; y++) {
                int zy = Math.min(6, y * grid / Math.max(1, h));
                for (int x = 0; x < w; x++) {
                    int c = pixels[y * w + x];
                    int r = (c >>> 16) & 255;
                    int g = (c >>> 8) & 255;
                    int bl = c & 255;
                    int l = Math.max(0, Math.min(255, Math.round(0.2126f * r + 0.7152f * g + 0.0722f * bl)));
                    hist[l]++;
                    if (l >= 248) bright++;
                    int zx = Math.min(6, x * grid / Math.max(1, w));
                    int z = zy * grid + zx;
                    sum[z] += l;
                    sum2[z] += (long)l * l;
                    count[z]++;
                }
            }

            int n = Math.max(1, pixels.length);
            int target = (int)Math.ceil(n * 0.95);
            int acc = 0, p95 = 255;
            for (int i = 0; i < 256; i++) {
                acc += hist[i];
                if (acc >= target) { p95 = i; break; }
            }
            float brightFrac = bright / (float)n;

            int evSteps = 0;
            if (lastFaceCount > 0) {
                if (brightFrac >= 0.18f || p95 >= 252) evSteps = -5;
                else if (brightFrac >= 0.08f || p95 >= 247) evSteps = -3;
            } else if (brightFrac >= 0.24f && p95 >= 252) {
                evSteps = -2;
            }
            if (motion >= 1.25f && lastPreviewShutterMs >= 20f) evSteps = Math.min(evSteps, -2);
            evSteps = clampAeSteps(evSteps);

            // Face detection wins. Its bounds are already in camera active-array
            // coordinates and therefore do not need preview-orientation mapping.
            if (lastFaceBounds != null && lastFaceCount > 0) {
                Rect active = activeArray();
                Rect face = new Rect(lastFaceBounds);
                if (active != null) {
                    boolean intersects = face.intersect(active);
                    if (intersects && !face.isEmpty()) {
                        MeteringRectangle mr = new MeteringRectangle(expandAndClamp(face, active, 0.22f), 1000);
                        float nx = (face.exactCenterX() - active.left) / Math.max(1f, active.width());
                        float ny = (face.exactCenterY() - active.top) / Math.max(1f, active.height());
                        return new ShutterDecision(evSteps, mr, "FACE", nx, ny, brightFrac, p95);
                    }
                }
            }

            // 49-zone subject estimate from the displayed viewfinder. High local
            // detail is preferred, with center weighting and rejection of clipped
            // or near-black zones. This is mapped back through requested framing
            // and current sensor orientation before creating an AF/AE region.
            int best = 24;
            double bestScore = -1;
            for (int z = 0; z < 49; z++) {
                if (count[z] <= 0) continue;
                double mean = sum[z] / (double)count[z];
                double variance = Math.max(0, sum2[z] / (double)count[z] - mean * mean);
                int zx = z % 7, zy = z / 7;
                double dx = zx - 3.0, dy = zy - 3.0;
                double centerWeight = 1.0 / (1.0 + 0.16 * (dx * dx + dy * dy));
                double exposureWeight = (mean < 22 || mean > 238) ? 0.28 : 1.0;
                double score = Math.sqrt(variance + 1.0) * centerWeight * exposureWeight;
                if (score > bestScore) { bestScore = score; best = z; }
            }

            float displayX = ((best % 7) + .5f) / 7f;
            float displayY = ((best / 7) + .5f) / 7f;
            float[] sensorXY = displayToSensor(displayX, displayY);
            MeteringRectangle region = makeMeteringRegion(sensorXY[0], sensorXY[1], 0.18f, 900);
            return new ShutterDecision(evSteps, region, "49-ZONE " + best, sensorXY[0], sensorXY[1], brightFrac, p95);
        } catch (Exception ignored) {
            return centerDecision(0, "CENTER", 0f, 0);
        } finally {
            if (thumb != null) thumb.recycle();
        }
    }

    private ShutterDecision centerDecision(int ev, String source, float brightFraction, int p95) {
        return new ShutterDecision(clampAeSteps(ev), makeMeteringRegion(.5f, .5f, .18f, 850),
                source, .5f, .5f, brightFraction, p95);
    }

    private int clampAeSteps(int steps) {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Range<Integer> range = cc == null ? null : cc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (range != null) steps = Math.max(range.getLower(), Math.min(range.getUpper(), steps));
        } catch (Exception ignored) {}
        return steps;
    }

    private Rect activeArray() {
        try {
            Rect r = logicalCharacteristics == null ? null : logicalCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            return r == null ? null : new Rect(r);
        } catch (Exception ignored) {
            return null;
        }
    }

    private MeteringRectangle makeMeteringRegion(float nx, float ny, float fraction, int weight) {
        Rect active = activeArray();
        if (active == null) return null;
        nx = Math.max(0f, Math.min(1f, nx));
        ny = Math.max(0f, Math.min(1f, ny));
        int rw = Math.max(64, Math.round(active.width() * fraction));
        int rh = Math.max(64, Math.round(active.height() * fraction));
        int cx = active.left + Math.round(nx * active.width());
        int cy = active.top + Math.round(ny * active.height());
        Rect r = new Rect(cx - rw/2, cy - rh/2, cx + rw/2, cy + rh/2);
        clampRect(r, active);
        return new MeteringRectangle(r, Math.max(1, Math.min(1000, weight)));
    }

    private Rect expandAndClamp(Rect src, Rect bounds, float extraFraction) {
        Rect r = new Rect(src);
        int dx = Math.round(r.width() * extraFraction * .5f);
        int dy = Math.round(r.height() * extraFraction * .5f);
        r.inset(-dx, -dy);
        clampRect(r, bounds);
        return r;
    }

    private void clampRect(Rect r, Rect bounds) {
        int w = Math.min(r.width(), bounds.width());
        int h = Math.min(r.height(), bounds.height());
        int left = Math.max(bounds.left, Math.min(r.left, bounds.right - w));
        int top = Math.max(bounds.top, Math.min(r.top, bounds.bottom - h));
        r.set(left, top, left + w, top + h);
    }

    private float[] displayToSensor(float displayX, float displayY) {
        float crop = Math.max(1f, requestedZoom / Math.max(.1f, activeLens.zoom));
        float ox = .5f + (displayX - .5f) / crop;
        float oy = .5f + (displayY - .5f) / crop;
        ox = Math.max(0f, Math.min(1f, ox));
        oy = Math.max(0f, Math.min(1f, oy));

        int orientation = normalizeQuarterTurn(jpegOrientation());
        float sx, sy;
        if (orientation == 90) {
            sx = oy;
            sy = 1f - ox;
        } else if (orientation == 180) {
            sx = 1f - ox;
            sy = 1f - oy;
        } else if (orientation == 270) {
            sx = 1f - oy;
            sy = ox;
        } else {
            sx = ox;
            sy = oy;
        }
        return new float[]{Math.max(0f, Math.min(1f, sx)), Math.max(0f, Math.min(1f, sy))};
    }

    private int normalizeQuarterTurn(int degrees) {
        int d = ((degrees % 360) + 360) % 360;
        if (d < 45 || d >= 315) return 0;
        if (d < 135) return 90;
        if (d < 225) return 180;
        return 270;
    }

    private void onCaptureYuvAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) {
                captureBusy = false;
                notifyError("YUV callback fired but no image was available", null);
                return;
            }
            final Image frame = image;
            image = null;
            captureBusy = false;

            FrameAnalysis measured = YuvAnalyzer.analyze(frame);
            String scene = classifyScene(measured, lastFaceCount, shotRequestedLens);
            lastAnalysis = new FrameAnalysis(measured.meanLuma, measured.p05, measured.p95,
                    measured.highlights, measured.shadows, measured.bestZone,
                    measured.bestXNorm, measured.bestYNorm, measured.evSteps, scene);
            emitTelemetry();

            final int orientation = jpegOrientation();
            final String mode = look;
            final boolean makeAi = aiEnabled;
            final boolean level = autoLevel;
            final float roll = rollDeg;
            final LensSpec requested = shotRequestedLens;
            final LensSpec optical = shotOpticalLens;
            final FrameAnalysis shotAnalysis = lastAnalysis;
            final int faces = lastFaceCount;
            final String activePhysical = lastActivePhysicalId;
            final String routeAtShot = shotRouteReason;
            final String meterAtShot = shotMeterSource;
            final float meterX = shotMeterX;
            final float meterY = shotMeterY;
            final float brightFraction = shotBrightFraction;
            final int previewP95 = shotP95;
            final int isoAtShot = shotIso;
            final float shutterAtShot = shotShutterMs;
            final Size captureSizeAtShot = captureSize;
            final boolean physicalBindingAtShot = physicalBinding;
            final boolean autoQualityAtShot = autoQuality;
            final int evAtShot = lastAppliedEvSteps;
            final float motionAtShot = motion;
            final int orientationAtShot = deviceOrientationDeg;
            final long started = System.nanoTime();

            if (faces > 0 && requested == ULTRA) {
                listener.onPhotoSaved("Portrait warning: 0.6× can stretch faces near frame edges");
            } else {
                listener.onPhotoSaved("Frame received • processing " + mode + "…");
            }

            processing.execute(() -> {
                try {
                    long t0 = System.nanoTime();
                    byte[] jpeg = YuvStillEncoder.encodeJpeg(frame, 100, orientation);
                    long encodeMs = (System.nanoTime() - t0) / 1_000_000L;
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
                    String lensToken = requested.label.replace("×", "x").replace(".", "p");
                    String base = "AutoPlus_" + lensToken + "_" + stamp;

                    byte[] output = jpeg;
                    String suffix = "_REF.jpg";
                    long processMs = 0L;
                    final boolean requestedTele = requested == TELE3 || requested == TELE10;
                    final boolean framingNeeded = requested.zoom / Math.max(.1f, optical.zoom) > 1.025f;
                    if (makeAi) {
                        suffix = ".jpg";
                        boolean levelNeeded = level && Math.abs(roll) >= 0.90f && Math.abs(roll) <= 5.0f;
                        boolean lookNeeded = !"TRUE".equals(mode);
                        if (levelNeeded || lookNeeded || requestedTele || framingNeeded) {
                            long p0 = System.nanoTime();
                            output = ImageProcessor.process(jpeg, mode, level, roll, orientation,
                                    requested.zoom, optical.zoom, requestedTele);
                            processMs = (System.nanoTime() - p0) / 1_000_000L;
                        }
                    }

                    Uri saved = saveImage(base + suffix, output);
                    long totalMs = (System.nanoTime() - started) / 1_000_000L;
                    String route = physicalBindingAtShot ? optical.physicalId : "logical";
                    float outputMp = requestedTele && makeAi ? 12.0f : (captureSizeAtShot.getWidth()*captureSizeAtShot.getHeight())/1_000_000f;
                    listener.onPhotoSaved(String.format(Locale.US,
                            "Saved ✓  %s framing • %s optical • %s • %.1f MP • %d ms",
                            requested.label, optical.label, mode, outputMp, totalMs));

                    try {
                        JSONObject d = new JSONObject();
                        d.put("version", "0.2.0");
                        d.put("logicalCamera", LOGICAL_ID);
                        d.put("requestedLens", requested.label);
                        d.put("requestedZoom", requested.zoom);
                        d.put("opticalLens", optical.label);
                        d.put("opticalZoom", optical.zoom);
                        d.put("expectedPhysicalId", optical.physicalId);
                        d.put("activePhysicalId", activePhysical);
                        d.put("autoQuality", autoQualityAtShot);
                        d.put("routeReason", routeAtShot);
                        d.put("framingCrop", requested.zoom / Math.max(.1f, optical.zoom));
                        d.put("physicalBinding", physicalBindingAtShot);
                        d.put("captureSize", captureSizeAtShot.toString());
                        d.put("outputStandardized12MP", requestedTele && makeAi);
                        d.put("savedUri", saved.toString());
                        d.put("aiEnabled", makeAi);
                        d.put("look", mode);
                        d.put("autoLevel", level);
                        d.put("rollDeg", roll);
                        d.put("deviceOrientationDeg", orientationAtShot);
                        d.put("appliedEvSteps", evAtShot);
                        d.put("motion", motionAtShot);
                        d.put("faces", faces);
                        d.put("meterSource", meterAtShot);
                        d.put("meterX", meterX);
                        d.put("meterY", meterY);
                        d.put("previewBrightFraction", brightFraction);
                        d.put("previewP95", previewP95);
                        d.put("iso", isoAtShot);
                        d.put("shutterMs", shutterAtShot);
                        d.put("scene", shotAnalysis.scene);
                        d.put("meanLuma", shotAnalysis.meanLuma);
                        d.put("p05", shotAnalysis.p05);
                        d.put("p95", shotAnalysis.p95);
                        d.put("encodeMs", encodeMs);
                        d.put("processMs", processMs);
                        d.put("totalMs", totalMs);
                        d.put("route", route);
                        saveJson(base + "_DIAG.json", d.toString(2));
                    } catch (Exception ignored) {}
                } catch (Exception e) {
                    notifyError("YUV encode/save failed", e);
                } finally {
                    try { frame.close(); } catch (Exception ignored) {}
                }
            });
        } catch (Exception e) {
            captureBusy = false;
            notifyError("Unable to acquire YUV frame", e);
        } finally {
            if (image != null) image.close();
        }
    }

    private String classifyScene(FrameAnalysis a, int faces, LensSpec requested) {
        if (faces > 0) {
            if (a.meanLuma < 52) return "NIGHT_PORTRAIT";
            if (requested == ULTRA) return "PORTRAIT_WIDE_RISK";
            if (a.p95 > 245 && a.p05 < 45) return "BACKLIT_PORTRAIT";
            return "PORTRAIT";
        }
        if (a.meanLuma < 48) return "NIGHT";
        if (a.p95 - a.p05 > 170) return "HIGH_DR";
        if (a.p95 > 242 && a.p05 < 32) return "BACKLIT";
        if (motion > 1.25f) return "ACTION";
        if (requested == ULTRA && a.meanLuma > 90) return "LANDSCAPE_WIDE";
        return a.scene;
    }

    private Uri saveImage(String name, byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0) throw new IllegalArgumentException("JPEG byte array is empty");
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AutoPlusAI");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) throw new IllegalStateException("MediaStore insert returned null");
        boolean ok = false;
        try {
            try (OutputStream os = cr.openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("MediaStore stream returned null");
                os.write(bytes);
                os.flush();
            }
            ContentValues publish = new ContentValues();
            publish.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(uri, publish, null, null);
            ok = true;
            return uri;
        } finally {
            if (!ok) try { cr.delete(uri, null, null); } catch (Exception ignored) {}
        }
    }

    private Uri saveJson(String name, String text) throws Exception {
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, name);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AutoPlusAI");
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) return null;
        try (OutputStream os = cr.openOutputStream(uri)) {
            if (os == null) return null;
            os.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            os.flush();
        }
        ContentValues publish = new ContentValues();
        publish.put(MediaStore.Downloads.IS_PENDING, 0);
        cr.update(uri, publish, null, null);
        return uri;
    }

    private int jpegOrientation() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Integer sensor = cc == null ? 90 : cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (sensor == null) sensor = 90;
            return (sensor + deviceOrientationDeg + 360) % 360;
        } catch (Exception ignored) {
            return 90;
        }
    }

    private void applyRequestedFramingToPreview() {
        textureView.post(() -> {
            try {
                float crop = Math.max(1f, Math.min(3.5f, requestedZoom / Math.max(.1f, activeLens.zoom)));
                Matrix m = new Matrix();
                float cx = textureView.getWidth() * .5f;
                float cy = textureView.getHeight() * .5f;
                m.setScale(crop, crop, cx, cy);
                textureView.setTransform(m);
            } catch (Exception ignored) {}
        });
    }

    public void refreshPreviewGeometry() {
        textureView.post(() -> {
            if (textureView instanceof AspectTextureView) {
                ((AspectTextureView) textureView).setAspectRatio(3, 4);
            }
            applyRequestedFramingToPreview();
        });
    }

    private void emitTelemetry() {
        listener.onTelemetry(lastAnalysis, lastFaceCount, lastActivePhysicalId,
                requestedZoom, activeLens.zoom, lastAppliedEvSteps,
                lastPreviewIso, lastPreviewShutterMs, routeReason, lastMeterSource);
    }

    private void closeSessionOnly() {
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        session = null;
        previewBuilder = null;
        try { if (captureReader != null) captureReader.close(); } catch (Exception ignored) {}
        captureReader = null;
        try { if (previewSurface != null) previewSurface.release(); } catch (Exception ignored) {}
        previewSurface = null;
    }

    private void closeCamera() {
        pendingAutoCapture = false;
        closeSessionOnly();
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        camera = null;
        captureBusy = false;
    }

    private void notifyError(String message, Throwable error) {
        listener.onError(message, error);
    }
}
