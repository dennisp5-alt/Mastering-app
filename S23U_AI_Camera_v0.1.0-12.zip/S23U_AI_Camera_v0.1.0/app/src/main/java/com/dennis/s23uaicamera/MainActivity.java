package com.dennis.s23uaicamera;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.OrientationEventListener;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener, CameraEngine.Listener, SensorEventListener {
    private static final int REQ_CAMERA = 41;
    private AspectTextureView textureView;
    private TextView telemetry;
    private TextView modeText;
    private CameraEngine engine;
    private SensorManager sensors;
    private Sensor gravitySensor;
    private Sensor gyroSensor;
    private OrientationEventListener orientationListener;
    private float rollDeg = 0f;
    private float motion = 0f;
    private int deviceOrientationDeg = 0;
    private boolean aiEnabled = true;
    private boolean autoLevel = true;
    private boolean autoQuality = true;
    private String look = "TRUE";
    private float selectedZoom = 1f;
    private Button aiButton;
    private Button levelButton;
    private Button qualityButton;
    private final List<Button> lensButtons = new ArrayList<>();
    private final List<Float> lensValues = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        gravitySensor = sensors.getDefaultSensor(Sensor.TYPE_GRAVITY);
        gyroSensor = sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        orientationListener = new OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            @Override public void onOrientationChanged(int orientation) {
                if (orientation == ORIENTATION_UNKNOWN) return;
                int snapped = ((orientation + 45) / 90 * 90) % 360;
                deviceOrientationDeg = snapped;
                if (engine != null) engine.setDeviceOrientation(snapped);
            }
        };

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        textureView = new AspectTextureView(this);
        textureView.setAspectRatio(3, 4);
        textureView.setSurfaceTextureListener(this);
        root.addView(textureView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        telemetry = new TextView(this);
        telemetry.setTextColor(Color.WHITE);
        telemetry.setBackgroundColor(0x88000000);
        telemetry.setTextSize(12f);
        telemetry.setPadding(dp(10), dp(6), dp(10), dp(6));
        telemetry.setText("AUTO+ AI CAMERA 0.2.0 • starting…");
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tp.gravity = Gravity.TOP;
        tp.topMargin = dp(24);
        root.addView(telemetry, tp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(6), dp(4), dp(6), dp(12));
        controls.setBackgroundColor(0xB0000000);

        modeText = new TextView(this);
        modeText.setTextColor(Color.WHITE);
        modeText.setGravity(Gravity.CENTER);
        modeText.setTextSize(13f);
        modeText.setText("Auto Quality • requested framing + intelligent optical routing");
        controls.addView(modeText, rowParams());

        LinearLayout lensRow = row();
        addLens(lensRow, "0.6×", .6f);
        addLens(lensRow, "1×", 1f);
        addLens(lensRow, "3×", 3f);
        addLens(lensRow, "10×", 10f);
        controls.addView(lensRow, rowParams());
        updateLensButtons();

        LinearLayout lookRow = row();
        lookRow.addView(actionButton("TRUE", v -> setLook("TRUE")), cell());
        lookRow.addView(actionButton("PRO", v -> setLook("PRO")), cell());
        lookRow.addView(actionButton("NAT GEO", v -> setLook("NAT GEO")), cell());
        controls.addView(lookRow, rowParams());

        LinearLayout toggles = row();
        aiButton = actionButton("AI: ON", v -> {
            aiEnabled = !aiEnabled;
            aiButton.setText(aiEnabled ? "AI: ON" : "REFERENCE");
            modeText.setText(aiEnabled ? "Auto Quality • requested framing + intelligent optical routing" : "REFERENCE • exact optical lens + untouched Q100 JPEG");
            if (engine != null) engine.setAiEnabled(aiEnabled);
        });
        levelButton = actionButton("LEVEL: AUTO", v -> {
            autoLevel = !autoLevel;
            levelButton.setText(autoLevel ? "LEVEL: AUTO" : "LEVEL: OFF");
            if (engine != null) engine.setAutoLevel(autoLevel);
        });
        toggles.addView(aiButton, cell());
        toggles.addView(levelButton, cell());
        controls.addView(toggles, rowParams());

        qualityButton = actionButton("LENS: AUTO QUALITY", v -> {
            autoQuality = !autoQuality;
            qualityButton.setText(autoQuality ? "LENS: AUTO QUALITY" : "LENS: EXACT");
            modeText.setText(autoQuality
                    ? "Auto Quality uses ISO + shutter + motion to choose the cleanest lens"
                    : "Exact Lens forces the requested physical camera");
            if (engine != null) engine.setAutoQuality(autoQuality);
        });
        controls.addView(qualityButton, rowParams());

        Button shutter = actionButton("●  CAPTURE", v -> {
            modeText.setText("Capturing " + formatZoom(selectedZoom) + "…");
            if (engine != null) engine.capture();
            else modeText.setText("ERROR • camera engine is null");
        });
        shutter.setTextSize(18f);
        shutter.setMinHeight(dp(58));
        controls.addView(shutter, rowParams());

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        cp.gravity = Gravity.BOTTOM;
        root.addView(controls, cp);
        setContentView(root);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private LinearLayout.LayoutParams rowParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(45), 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private Button actionButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12f);
        b.setAllCaps(false);
        b.setBackgroundColor(0xFF252525);
        b.setOnClickListener(listener);
        return b;
    }

    private void addLens(LinearLayout row, String label, float zoom) {
        Button b = actionButton(label, v -> {
            selectedZoom = zoom;
            updateLensButtons();
            modeText.setText("Switching to " + label + " optical camera…");
            if (engine != null) engine.setZoom(zoom);
        });
        lensButtons.add(b);
        lensValues.add(zoom);
        row.addView(b, cell());
    }

    private void updateLensButtons() {
        for (int i = 0; i < lensButtons.size(); i++) {
            float z = lensValues.get(i);
            lensButtons.get(i).setBackgroundColor(Math.abs(z - selectedZoom) < 0.01f ? 0xFF315A72 : 0xFF252525);
        }
    }

    private String formatZoom(float z) {
        if (Math.abs(z - Math.round(z)) < .01f) return Math.round(z) + "×";
        return String.format(Locale.US, "%.1f×", z);
    }

    private void setLook(String value) {
        look = value;
        if (engine != null) engine.setLook(value);
        modeText.setText(value + ("TRUE".equals(value) ? " • fastest natural path" : " • fast one-pass finishing"));
    }

    private void maybeStartCamera() {
        if (!textureView.isAvailable()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        if (engine == null) {
            engine = new CameraEngine(this, textureView, this);
            engine.setAiEnabled(aiEnabled);
            engine.setAutoLevel(autoLevel);
            engine.setLook(look);
            engine.setAutoQuality(autoQuality);
            engine.setZoom(selectedZoom);
            engine.setRoll(rollDeg);
            engine.setMotion(motion);
            engine.setDeviceOrientation(deviceOrientationDeg);
        }
        engine.start();
    }

    @Override protected void onResume() {
        super.onResume();
        if (gravitySensor != null) sensors.registerListener(this, gravitySensor, SensorManager.SENSOR_DELAY_GAME);
        if (gyroSensor != null) sensors.registerListener(this, gyroSensor, SensorManager.SENSOR_DELAY_GAME);
        if (orientationListener != null && orientationListener.canDetectOrientation()) orientationListener.enable();
        maybeStartCamera();
    }

    @Override protected void onPause() {
        if (orientationListener != null) orientationListener.disable();
        if (sensors != null) sensors.unregisterListener(this);
        if (engine != null) engine.stop();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (engine != null) engine.shutdown();
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) maybeStartCamera();
        else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
    }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) { maybeStartCamera(); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        if (engine != null) engine.refreshPreviewGeometry();
    }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}

    @Override public void onTelemetry(FrameAnalysis a, int faces, String physical,
                                      float requestedZoom, float opticalZoom, int evSteps,
                                      int iso, float shutterMs, String routeReason, String meterSource) {
        String shutterText = shutterMs > 0.01f
                ? (shutterMs < 1000f ? String.format(Locale.US, "1/%.0f", 1000f / shutterMs) : String.format(Locale.US, "%.1fs", shutterMs / 1000f))
                : "—";
        final String text = String.format(Locale.US,
                "AUTO+ AI 0.2.0   LOOK: %s   SCENE: %s\nRequested %.1f× → optical %.1f× • physical %s • faces %d\nISO %d • %s • %s\nMeter %s • AE %+d • level %+1.1f° • motion %.3f",
                look, a.scene, requestedZoom, opticalZoom, physical, faces,
                iso, shutterText, routeReason, meterSource, evSteps, rollDeg, motion);
        runOnUiThread(() -> telemetry.setText(text));
    }

    @Override public void onPhotoSaved(String message) {
        runOnUiThread(() -> {
            modeText.setText(message);
            if (message.startsWith("Saved ✓") || message.startsWith("ERROR")) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override public void onError(String message, Throwable error) {
        runOnUiThread(() -> {
            telemetry.setText("ERROR: " + message + (error == null ? "" : "\n" + error.getClass().getSimpleName() + ": " + error.getMessage()));
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_GRAVITY) {
            float gx = event.values[0];
            float gy = event.values[1];
            float planar = (float)Math.sqrt(gx * gx + gy * gy);
            if (planar > 2.0f) {
                // Angle around the camera's optical axis. Subtract the nearest
                // 90-degree device orientation so portrait/landscape posture is
                // not mistaken for a giant horizon correction.
                float raw = (float)Math.toDegrees(Math.atan2(gx, -gy));
                float nearest = Math.round(raw / 90f) * 90f;
                float fine = raw - nearest;
                if (fine > 45f) fine -= 90f;
                if (fine < -45f) fine += 90f;
                rollDeg = rollDeg * 0.75f + fine * 0.25f;
                if (engine != null) engine.setRoll(rollDeg);
            }
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            float mag = (float)Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]);
            motion = motion * .88f + mag * .12f;
            if (engine != null) engine.setMotion(motion);
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
