package com.dennis.s23uaicamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import java.io.ByteArrayOutputStream;

/**
 * v0.2.0 one-raster-pass finishing.
 *
 * Coarse orientation, fine auto-level, requested-framing crop, 12 MP tele
 * standardisation and PRO/NAT GEO colour rendering are combined into a single
 * Canvas draw. TRUE still returns the original Q100 JPEG when no geometry,
 * framing or standardisation work is required.
 */
public final class ImageProcessor {
    private ImageProcessor() {}

    public static byte[] process(byte[] jpeg, String look, boolean autoLevel,
                                 float rollDeg, int jpegOrientation,
                                 float requestedZoom, float opticalZoom,
                                 boolean standardize12MP) {
        final float framingCrop = Math.max(1.0f, Math.min(3.5f,
                requestedZoom / Math.max(0.1f, opticalZoom)));
        final boolean framingNeeded = framingCrop > 1.025f;
        final boolean levelNeeded = autoLevel && Math.abs(rollDeg) >= 0.90f && Math.abs(rollDeg) <= 5.0f;
        final boolean lookNeeded = !"TRUE".equals(look);

        if (!standardize12MP && !framingNeeded && !levelNeeded && !lookNeeded) return jpeg;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length, opts);
        if (src == null) return jpeg;

        final int orientation = normalizeQuarterTurn(jpegOrientation);
        final boolean quarterTurn = orientation == 90 || orientation == 270;
        final int orientedW = quarterTurn ? src.getHeight() : src.getWidth();
        final int orientedH = quarterTurn ? src.getWidth() : src.getHeight();

        int targetW = orientedW;
        int targetH = orientedH;
        if (standardize12MP) {
            if (orientedH >= orientedW) {
                targetW = 3000;
                targetH = 4000;
            } else {
                targetW = 4000;
                targetH = 3000;
            }
        }

        final float fineRoll = levelNeeded ? -rollDeg : 0f;
        final double theta = Math.toRadians(Math.abs(fineRoll));
        final double cos = Math.cos(theta);
        final double sin = Math.sin(theta);

        // Minimum scale that fills the target after orientation/level correction,
        // multiplied by the Auto Quality framing crop when a brighter lens is
        // being used to deliver a longer requested field of view.
        final float scaleX = (float)((targetW * cos + targetH * sin) / Math.max(1.0, orientedW));
        final float scaleY = (float)((targetW * sin + targetH * cos) / Math.max(1.0, orientedH));
        final float scale = Math.max(scaleX, scaleY) * framingCrop;

        Bitmap outBitmap;
        try {
            outBitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError oom) {
            src.recycle();
            return jpeg;
        }

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        if (lookNeeded) {
            boolean strongBlue = detectStrongBlue(src);
            boolean strongRed = detectStrongRed(src);
            paint.setColorFilter(buildLookFilter(look, strongBlue, strongRed));
        }

        Canvas canvas = new Canvas(outBitmap);
        canvas.drawColor(Color.BLACK);
        canvas.save();
        canvas.translate(targetW * 0.5f, targetH * 0.5f);
        canvas.scale(scale, scale);
        canvas.rotate(orientation + fineRoll);
        canvas.translate(-src.getWidth() * 0.5f, -src.getHeight() * 0.5f);
        canvas.drawBitmap(src, 0f, 0f, paint);
        canvas.restore();
        src.recycle();

        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(jpeg.length, 1024 * 1024));
        outBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
        outBitmap.recycle();
        return out.toByteArray();
    }

    private static int normalizeQuarterTurn(int degrees) {
        int d = ((degrees % 360) + 360) % 360;
        if (d < 45 || d >= 315) return 0;
        if (d < 135) return 90;
        if (d < 225) return 180;
        return 270;
    }

    private static ColorMatrixColorFilter buildLookFilter(String look, boolean strongBlue, boolean strongRed) {
        float saturation = 1.0f;
        float contrast = 1.0f;
        float brightness = 0.0f;
        float redScale = 1.0f;
        float greenScale = 1.0f;
        float blueScale = 1.0f;

        if ("PRO".equals(look)) {
            saturation = 1.010f;
            contrast = 1.020f;
            brightness = -0.8f;
            if (strongBlue) blueScale = 0.985f;
            if (strongRed) redScale = 0.990f;
        } else if ("NAT GEO".equals(look)) {
            saturation = 1.022f;
            contrast = 1.030f;
            brightness = -1.2f;
            greenScale = 0.997f;
            if (strongBlue) blueScale = 0.972f;
            if (strongRed) redScale = 0.982f;
        }

        ColorMatrix matrix = new ColorMatrix();
        matrix.setSaturation(saturation);

        float translate = 128f * (1f - contrast) + brightness;
        ColorMatrix contrastMatrix = new ColorMatrix(new float[] {
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        matrix.postConcat(contrastMatrix);

        ColorMatrix channels = new ColorMatrix(new float[] {
                redScale, 0, 0, 0, 0,
                0, greenScale, 0, 0, 0,
                0, 0, blueScale, 0, 0,
                0, 0, 0, 1, 0
        });
        matrix.postConcat(channels);
        return new ColorMatrixColorFilter(matrix);
    }

    private static boolean detectStrongBlue(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int stepX = Math.max(1, w / 64), stepY = Math.max(1, h / 64);
        long sr = 0, sg = 0, sb = 0, n = 0;
        for (int y = 0; y < h; y += stepY) {
            for (int x = 0; x < w; x += stepX) {
                int c = b.getPixel(x, y);
                sr += (c >>> 16) & 255;
                sg += (c >>> 8) & 255;
                sb += c & 255;
                n++;
            }
        }
        if (n == 0) return false;
        double r = sr / (double)n, g = sg / (double)n, bl = sb / (double)n;
        return bl > 110 && bl > r * 1.14 && bl > g * 1.10;
    }

    private static boolean detectStrongRed(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int stepX = Math.max(1, w / 64), stepY = Math.max(1, h / 64);
        int redHot = 0, n = 0;
        for (int y = 0; y < h; y += stepY) {
            for (int x = 0; x < w; x += stepX) {
                int c = b.getPixel(x, y);
                int r = (c >>> 16) & 255;
                int g = (c >>> 8) & 255;
                int bl = c & 255;
                if (r >= 235 && r > g * 1.28f && r > bl * 1.28f) redHot++;
                n++;
            }
        }
        return n > 0 && redHot / (float)n >= 0.004f;
    }
}
