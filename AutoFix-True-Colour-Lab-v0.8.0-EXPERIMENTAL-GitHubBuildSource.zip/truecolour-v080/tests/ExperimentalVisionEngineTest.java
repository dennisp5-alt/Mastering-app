package com.dennis.autofixcolourlab;
import android.graphics.Bitmap;
public final class ExperimentalVisionEngineTest { public static void main(String[] a){
 Bitmap b=Bitmap.createBitmap(64,48,Bitmap.Config.ARGB_8888); b.eraseColor(0xff777777);
 ExperimentalVisionEngine.Result r=ExperimentalVisionEngine.analyse(b);
 if(r==null||r.cropRetained<.80||r.straighten) throw new AssertionError();
 System.out.println("ExperimentalVisionEngineTest: 3 checks passed");
}}
