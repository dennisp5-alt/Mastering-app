package com.dennis.autofixcolourlab;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;

/** Conservative v0.8 experimental technical analysis. Pixel-only, offline, camera agnostic. */
public final class ExperimentalVisionEngine {
    private ExperimentalVisionEngine() {}
    public static final class Result {
        public final double horizonDegrees, horizonConfidence, perspective, haze, motion, defocus, cropRetained;
        public final boolean straighten, perspectiveCorrect, dehaze;
        Result(double h,double hc,double p,double z,double m,double d,double crop) {
            horizonDegrees=h; horizonConfidence=hc; perspective=p; haze=z; motion=m; defocus=d; cropRetained=crop;
            straighten=hc>=0.72 && Math.abs(h)>=0.35 && Math.abs(h)<=5.0 && crop>=0.90;
            perspectiveCorrect=p>=0.78; dehaze=z>=0.62;
        }
        public String summary() {
            return String.format(java.util.Locale.US,
                "Experimental v0.8: horizon %+.1f° (%d%%) %s  •  intelligent crop %.1f%% retained\n"+
                "Perspective %d%% %s  •  haze %d%% %s\n"+
                "Motion risk %d%%  •  defocus risk %d%%  •  %s",
                horizonDegrees, pct(horizonConfidence), straighten?"CORRECT":"BYPASS", cropRetained*100.0,
                pct(perspective), perspectiveCorrect?"CORRECT":"BYPASS", pct(haze), dehaze?"MILD":"BYPASS",
                pct(motion), pct(defocus), (motion<.42&&defocus<.42)?"sharpness GOOD":"review sharpness");
        }
        private static int pct(double v){ return (int)Math.round(Math.max(0,Math.min(1,v))*100); }
    }
    public static Result analyse(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight(); int sx=Math.max(1,w/320), sy=Math.max(1,h/240);
        double edge=0, horiz=0, vert=0, contrast=0, sat=0, dark=0; long n=0;
        double topEdge=0,bottomEdge=0; long tn=0,bn=0;
        for(int y=sy;y<h-sy;y+=sy) for(int x=sx;x<w-sx;x+=sx){
            int c=b.getPixel(x,y), cx=b.getPixel(x+sx,y), cy=b.getPixel(x,y+sy);
            double l=lum(c), lx=lum(cx), ly=lum(cy); double dx=Math.abs(lx-l), dy=Math.abs(ly-l);
            edge+=dx+dy; horiz+=dy; vert+=dx; contrast+=Math.abs(l-128); sat+=sat(c); if(l<45)dark++; n++;
            if(y<h/3){topEdge+=dx+dy;tn++;} if(y>2*h/3){bottomEdge+=dx+dy;bn++;}
        }
        edge/=Math.max(1,n); contrast/=Math.max(1,n); sat/=Math.max(1,n); double darkF=dark/(double)Math.max(1,n);
        double anis=(horiz-vert)/Math.max(1.0,horiz+vert);
        double angle=Math.max(-4.5,Math.min(4.5,anis*18.0));
        double hc=Math.min(1, Math.abs(anis)*4.2) * Math.min(1,edge/24.0);
        double te=topEdge/Math.max(1,tn), be=bottomEdge/Math.max(1,bn);
        double perspective=Math.min(1,Math.abs(te-be)/Math.max(8,Math.max(te,be))*1.5);
        double haze=Math.max(0,Math.min(1,(1-contrast/62.0)*0.65 + (1-sat/85.0)*0.35));
        double defocus=Math.max(0,Math.min(1,1-edge/26.0));
        double motion=Math.max(0,Math.min(1,Math.abs(anis)*1.8 + defocus*.28));
        double rad=Math.toRadians(Math.abs(angle)); double crop=Math.max(.82,1.0-(Math.sin(rad)*(w+h)/(double)Math.max(w,h))*.55);
        // Darkness never creates haze/night evidence by itself.
        if(darkF>.55) haze*=.45;
        return new Result(angle,hc,perspective,haze,motion,defocus,crop);
    }
    private static double lum(int c){return .2126*Color.red(c)+.7152*Color.green(c)+.0722*Color.blue(c);}
    private static double sat(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c);int mx=Math.max(r,Math.max(g,b)),mn=Math.min(r,Math.min(g,b));return mx-mn;}
    /** Applies only high-confidence geometry/haze corrections. Returns input unchanged on bypass. */
    public static Bitmap apply(Bitmap input, Result r) {
        Bitmap out=input;
        if (r.straighten) {
            Matrix m=new Matrix(); m.postRotate((float)-r.horizonDegrees);
            Bitmap rotated=Bitmap.createBitmap(out,0,0,out.getWidth(),out.getHeight(),m,true);
            if(rotated!=out){ if(out!=input&&!out.isRecycled())out.recycle(); out=rotated; }
            double keep=Math.max(.88,Math.min(.99,r.cropRetained));
            int cw=(int)(out.getWidth()*keep), ch=(int)(out.getHeight()*keep);
            if(cw>32&&ch>32){ Bitmap cropped=Bitmap.createBitmap(out,(out.getWidth()-cw)/2,(out.getHeight()-ch)/2,cw,ch); if(out!=input&&!out.isRecycled())out.recycle(); out=cropped; }
        }
        if (r.perspectiveCorrect && r.perspective < .94) {
            int w=out.getWidth(),h=out.getHeight(); float inset=(float)(Math.min(.055,r.perspective*.045)*w);
            float[] src={inset,0,w-inset,0,0,h,w,h}; float[] dst={0,0,w,0,0,h,w,h};
            Matrix pm=new Matrix(); if(pm.setPolyToPoly(src,0,dst,0,4)){ Bitmap warped=Bitmap.createBitmap(out,0,0,w,h,pm,true); if(warped!=out){if(out!=input&&!out.isRecycled())out.recycle();out=warped;} }
        }
        if (r.dehaze) {
            if(out==input) out=input.copy(Bitmap.Config.ARGB_8888,true);
            int w=out.getWidth(),h=out.getHeight(); int[] px=new int[w]; double amount=Math.min(.16,(r.haze-.60)*.32);
            for(int y=0;y<h;y++){out.getPixels(px,0,w,0,y,w,1);for(int x=0;x<w;x++){int c=px[x];int rr=Color.red(c),g=Color.green(c),b=Color.blue(c);rr=clamp((int)((rr-128)*(1+amount)+128));g=clamp((int)((g-128)*(1+amount)+128));b=clamp((int)((b-128)*(1+amount)+128));px[x]=Color.argb(Color.alpha(c),rr,g,b);}out.setPixels(px,0,w,0,y,w,1);}
        }
        return out;
    }
    private static int clamp(int v){return Math.max(0,Math.min(255,v));}

}
