package com.dennis.autofixcolourlab;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Android image I/O and strip-based full-resolution processing. */
public final class PhotoPipeline {
    public enum OutputFormat { JPEG_100, PNG_LOSSLESS }
    private static final long PREVIEW_MAX_PIXELS = 3_200_000L;
    private static final long ANALYSIS_MAX_SAMPLES = 650_000L;
    private static final long MIN_SAVE_PIXELS = 12_500_000L;
    private static final long MAX_SAVE_PIXELS = 60_000_000L;
    private static final long RESERVED_BYTES = 64L * 1024L * 1024L;

    private PhotoPipeline() {
    }

    public static final class DecodedBitmap {
        public final Bitmap bitmap;
        public final int sourceWidth;
        public final int sourceHeight;
        public final boolean scaledForMemory;
        public final String sourceColorSpace;
        public final boolean sourceWideGamut;

        private DecodedBitmap(
                Bitmap bitmap,
                int sourceWidth,
                int sourceHeight,
                boolean scaledForMemory, String sourceColorSpace, boolean sourceWideGamut) {
            this.bitmap = bitmap;
            this.sourceWidth = sourceWidth;
            this.sourceHeight = sourceHeight;
            this.scaledForMemory = scaledForMemory;
            this.sourceColorSpace = sourceColorSpace;
            this.sourceWideGamut = sourceWideGamut;
        }
    }

    public static final class SavedPhoto {
        public final Uri uri;
        public final int width;
        public final int height;
        public final int sourceWidth;
        public final int sourceHeight;
        public final boolean scaledForMemory;
        public final String displayName;

        private SavedPhoto(
                Uri uri,
                int width,
                int height,
                int sourceWidth,
                int sourceHeight,
                boolean scaledForMemory,
                String displayName) {
            this.uri = uri;
            this.width = width;
            this.height = height;
            this.sourceWidth = sourceWidth;
            this.sourceHeight = sourceHeight;
            this.scaledForMemory = scaledForMemory;
            this.displayName = displayName;
        }
    }

    public static final class CorrectionAnalysis {
        public final HistogramEngine.Analysis histogram;
        public final TrueColourEngine.Analysis trueColour;
        public final TrueColourEngine.Analysis labCandidate;
        public final SceneIntelligence.Analysis scene;
        public final ImageIntegrityEngine.Analysis integrity;
        public final CameraCharacterRecoveryEngine.Analysis cameraRecovery;
        public final ExperimentalVisionEngine.Result experimental;
        public int recommendedStrengthPercent;
        public final boolean alreadyBalanced;
        public final boolean multiZoneActive;
        public final boolean mixedLightGuarded;
        public final boolean channelHighlightGuarded;
        public final boolean trueColourActive;
        public final boolean labCandidateAvailable;
        public final boolean spatialColourActive;

        private CorrectionAnalysis(
                HistogramEngine.Analysis histogram,
                TrueColourEngine.Analysis trueColour,
                TrueColourEngine.Analysis labCandidate,
                SceneIntelligence.Analysis scene, CameraCharacterRecoveryEngine.Analysis cameraRecoveryHolder, ExperimentalVisionEngine.Result experimentalHolder) {
            this.histogram = histogram;
            this.trueColour = trueColour;
            this.labCandidate = labCandidate;
            this.scene = scene;
            this.integrity = ImageIntegrityEngine.analyse(scene);
            this.cameraRecovery = cameraRecoveryHolder;
            this.experimental = experimentalHolder;
            trueColourActive = trueColour.active;
            labCandidateAvailable = labCandidate.active;
            spatialColourActive = trueColour.spatialActive;
            multiZoneActive = histogram.multiZoneActive;
            mixedLightGuarded = histogram.mixedLightGuarded || trueColour.spatialActive;
            channelHighlightGuarded = histogram.channelHighlightGuarded;
            alreadyBalanced = histogram.alreadyBalanced && !trueColour.active;

            if (alreadyBalanced) {
                recommendedStrengthPercent = 0;
            } else if (histogram.recommendedStrengthPercent > 0) {
                int strength = histogram.recommendedStrengthPercent;
                if (trueColour.active && trueColour.confidence < 0.45) {
                    strength = Math.min(strength, 85);
                }
                recommendedStrengthPercent = strength;
            } else {
                recommendedStrengthPercent = trueColour.confidence >= 0.65 ? 90 : 85;
            }
            // Scene-aware guard: never neutralize intentional sunset warmth or lift low-key/night scenes aggressively.
            if (scene.preserveWarmth || scene.preserveDarkness) {
                recommendedStrengthPercent = Math.min(recommendedStrengthPercent, 72);
            }
            if (scene.clippingRisk) {
                recommendedStrengthPercent = Math.min(recommendedStrengthPercent, 82);
            }
        }


        public String confidenceSummary() {
            TrueColourEngine.Analysis c = labCandidateAvailable ? labCandidate : trueColour;
            String decision = trueColourActive ? "ACCEPTED" : (labCandidateAvailable ? "PREVIEW ONLY" : "REJECTED");
            return String.format(Locale.US,
                    "True Colour confidence %.0f%%  •  %s\nConsensus %d/%d  •  independent families %d  •  neutral evidence %.1f%%\nMixed-light score %.0f%%  •  spatial correction %s\nDecision: %s",
                    c.confidence * 100.0, decision, c.agreeingMethods, c.availableMethods,
                    c.independentFamilies, c.neutralCoverage * 100.0, c.mixedLightScore * 100.0,
                    c.spatialActive ? "accepted" : "not required/rejected",
                    c.active ? "supported by measured evidence" : c.holdReason)
                    + "\n" + cameraRecovery.summary() + "\n" + scene.summary() + "\n" + integrity.summary();
        }

        public String toneSummary() {
            return histogram.toneSummary();
        }

        public String colourSummary() {
            if (trueColour.active) {
                return trueColour.summary();
            }
            return trueColour.summary()
                    + "\nSafe fallback  •  "
                    + histogram.colourSummary();
        }

        public String colourSummary(boolean useLabLook) {
            if (!useLabLook) {
                String decision = trueColour.active
                        ? "SAFE comparison — automatic recommendation was LAB"
                        : "SAFE result — automatic recommendation retained";
                return decision + "\n" + histogram.colourSummary();
            }
            if (!labCandidate.active) {
                return "LAB preview unavailable — " + labCandidate.holdReason
                        + "\nSAFE result retained  •  " + histogram.colourSummary();
            }
            if (labCandidate.previewOnly) {
                return labCandidate.summary()
                        + "\nAutomatic decision: SAFE  •  preview was not recommended";
            }
            return labCandidate.summary()
                    + "\nAutomatic decision: LAB";
        }
    }

    public static DecodedBitmap decodePreview(Context context, Uri uri) throws IOException {
        return decode(context, uri, PREVIEW_MAX_PIXELS, false);
    }

    public static DecodedBitmap decode(
            Context context,
            Uri uri,
            final long maximumPixels,
            final boolean mutable) throws IOException {
        final int[] sourceSize = new int[2];
        final boolean[] scaled = new boolean[1];
        final String[] sourceColorSpace = new String[] {"Unknown"};
        final boolean[] sourceWideGamut = new boolean[1];
        ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
        Bitmap bitmap = ImageDecoder.decodeBitmap(source, new ImageDecoder.OnHeaderDecodedListener() {
            @Override
            public void onHeaderDecoded(
                    ImageDecoder decoder,
                    ImageDecoder.ImageInfo info,
                    ImageDecoder.Source ignored) {
                int width = info.getSize().getWidth();
                int height = info.getSize().getHeight();
                sourceSize[0] = width;
                sourceSize[1] = height;
                ColorSpace cs = info.getColorSpace();
                if (cs != null) {
                    sourceColorSpace[0] = cs.getName();
                    sourceWideGamut[0] = cs.isWideGamut();
                }

                long pixels = (long) width * (long) height;
                if (maximumPixels > 0L && pixels > maximumPixels) {
                    double scale = Math.sqrt(maximumPixels / (double) pixels);
                    int targetWidth = Math.max(1, (int) Math.floor(width * scale));
                    int targetHeight = Math.max(1, (int) Math.floor(height * scale));
                    decoder.setTargetSize(targetWidth, targetHeight);
                    scaled[0] = true;
                }
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                decoder.setMutableRequired(mutable);
                decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB));
            }
        });
        return new DecodedBitmap(
                bitmap,
                sourceSize[0],
                sourceSize[1],
                scaled[0], sourceColorSpace[0], sourceWideGamut[0]);
    }

    public static CorrectionAnalysis analyse(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        long pixels = (long) width * (long) height;
        int sampleStep = Math.max(1,
                (int) Math.ceil(Math.sqrt(pixels / (double) ANALYSIS_MAX_SAMPLES)));
        HistogramEngine.SpatialAccumulator accumulator = new HistogramEngine.SpatialAccumulator();
        TrueColourEngine.SpatialAccumulator colourAccumulator =
                new TrueColourEngine.SpatialAccumulator();
        SceneIntelligence.Accumulator sceneAccumulator = new SceneIntelligence.Accumulator();
        CameraCharacterRecoveryEngine.Accumulator recoveryAccumulator = new CameraCharacterRecoveryEngine.Accumulator();
        int[] row = new int[width];
        int start = sampleStep / 2;
        for (int y = start; y < height; y += sampleStep) {
            bitmap.getPixels(row, 0, width, 0, y, width, 1);
            for (int x = start; x < width; x += sampleStep) {
                double normalizedX = (x + 0.5) / Math.max(1.0, width);
                double normalizedY = (y + 0.5) / Math.max(1.0, height);
                accumulator.addPixelAt(row[x], normalizedX, normalizedY);
                colourAccumulator.addPixelAt(row[x], normalizedX, normalizedY);
                sceneAccumulator.addPixel(row[x]);
                recoveryAccumulator.addPixel(row[x]);
            }
        }
        CameraCharacterRecoveryEngine.Analysis recovery = recoveryAccumulator.finish();
        // Re-analyse colour/tone from a recovered sample domain so True Colour sees the more neutral starting point.
        if (recovery.active) {
            accumulator = new HistogramEngine.SpatialAccumulator();
            colourAccumulator = new TrueColourEngine.SpatialAccumulator();
            sceneAccumulator = new SceneIntelligence.Accumulator();
            CameraCharacterRecoveryEngine.Processor rp = new CameraCharacterRecoveryEngine.Processor(recovery, 1.0);
            for (int y = start; y < height; y += sampleStep) {
                bitmap.getPixels(row, 0, width, 0, y, width, 1);
                for (int x = start; x < width; x += sampleStep) {
                    int px=rp.apply(row[x]); double nx=(x+.5)/Math.max(1.0,width), ny=(y+.5)/Math.max(1.0,height);
                    accumulator.addPixelAt(px,nx,ny); colourAccumulator.addPixelAt(px,nx,ny); sceneAccumulator.addPixel(px);
                }
            }
        }
        HistogramEngine.Analysis histogram = accumulator.finish();
        TrueColourEngine.Analysis automaticColour = colourAccumulator.finish();
        TrueColourEngine.Analysis labCandidate = automaticColour.active
                ? automaticColour : colourAccumulator.finishPreview();
        return new CorrectionAnalysis(histogram, automaticColour, labCandidate, sceneAccumulator.finish(), recovery, ExperimentalVisionEngine.analyse(bitmap));
    }

    public static Bitmap renderPreview(
            Bitmap source,
            CorrectionAnalysis analysis,
            int strengthPercent) {
        return renderPreview(source, analysis, strengthPercent, analysis.trueColourActive);
    }

    public static Bitmap renderPreview(
            Bitmap source,
            CorrectionAnalysis analysis,
            int strengthPercent,
            boolean useLabLook) {
        return renderPreview(source, analysis, strengthPercent, useLabLook, false, false);
    }

    public static Bitmap renderPreview(
            Bitmap source,
            CorrectionAnalysis analysis,
            int strengthPercent,
            boolean useLabLook,
            boolean useNatureEditorial) {
        return renderPreview(source, analysis, strengthPercent, useLabLook, useNatureEditorial, false);
    }

    public static Bitmap renderPreview(
            Bitmap source, CorrectionAnalysis analysis, int strengthPercent,
            boolean useLabLook, boolean useNatureEditorial, boolean useDocumentaryEditorial) {
        Bitmap mutable = source.copy(Bitmap.Config.ARGB_8888, true);
        processInPlace(
                mutable,
                analysis,
                strengthPercent,
                useLabLook,
                useNatureEditorial,
                useDocumentaryEditorial);
        Bitmap experimental = ExperimentalVisionEngine.apply(mutable, analysis.experimental);
        return experimental;
    }

    public static void processInPlace(
            Bitmap bitmap,
            CorrectionAnalysis analysis,
            int strengthPercent) {
        processInPlace(bitmap, analysis, strengthPercent, analysis.trueColourActive);
    }

    public static void processInPlace(
            Bitmap bitmap,
            CorrectionAnalysis analysis,
            int strengthPercent,
            boolean useLabLook) {
        processInPlace(bitmap, analysis, strengthPercent, useLabLook, false, false);
    }

    public static void processInPlace(
            Bitmap bitmap, CorrectionAnalysis analysis, int strengthPercent,
            boolean useLabLook, boolean useNatureEditorial) {
        processInPlace(bitmap, analysis, strengthPercent, useLabLook, useNatureEditorial, false);
    }

    public static void processInPlace(
            Bitmap bitmap, CorrectionAnalysis analysis, int strengthPercent,
            boolean useLabLook, boolean useNatureEditorial, boolean useDocumentaryEditorial) {
        if (strengthPercent <= 0) {
            return;
        }
        TrueColourEngine.Analysis selectedColour = analysis.labCandidate;
        boolean labApplied = useLabLook && selectedColour.active;
        // SAFE always retains the proven v1.3 AutoFix colour path. LAB owns
        // colour only while that look is explicitly selected; both looks keep
        // the same histogram tone, local-light and RGB-highlight protection.
        HistogramEngine.Processor toneProcessor = new HistogramEngine.Processor(
                analysis.histogram,
                strengthPercent / 100.0,
                !labApplied);
        TrueColourEngine.Processor colourProcessor = new TrueColourEngine.Processor(
                selectedColour, labApplied ? strengthPercent / 100.0 : 0.0);
        CameraCharacterRecoveryEngine.Processor recoveryProcessor = new CameraCharacterRecoveryEngine.Processor(analysis.cameraRecovery, strengthPercent / 100.0);
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int rowsPerStrip = Math.max(1, Math.min(128, 1_000_000 / Math.max(1, width)));
        int[] pixels = new int[width * rowsPerStrip];

        int[] leftZone = null;
        int[] rightZone = null;
        double[] horizontalFraction = null;
        boolean spatialProcessing = analysis.multiZoneActive
                || (labApplied && selectedColour.spatialActive);
        if (spatialProcessing) {
            leftZone = new int[width];
            rightZone = new int[width];
            horizontalFraction = new double[width];
            for (int x = 0; x < width; x++) {
                double gridX = ((x + 0.5) * 3.0 / Math.max(1, width)) - 0.5;
                if (gridX <= 0.0) {
                    leftZone[x] = 0;
                    rightZone[x] = 0;
                    horizontalFraction[x] = 0.0;
                } else if (gridX >= 2.0) {
                    leftZone[x] = 2;
                    rightZone[x] = 2;
                    horizontalFraction[x] = 0.0;
                } else {
                    leftZone[x] = (int) Math.floor(gridX);
                    rightZone[x] = leftZone[x] + 1;
                    horizontalFraction[x] = gridX - leftZone[x];
                }
            }
        }

        for (int top = 0; top < height; top += rowsPerStrip) {
            int stripHeight = Math.min(rowsPerStrip, height - top);
            bitmap.getPixels(pixels, 0, width, 0, top, width, stripHeight);
            if (!spatialProcessing) {
                int stripSize = width * stripHeight;
                for (int index = 0; index < stripSize; index++) {
                    int recovered = recoveryProcessor.apply(pixels[index]);
                    int colourCorrected = colourProcessor.apply(recovered);
                    pixels[index] = toneProcessor.apply(colourCorrected);
                }
            } else {
                for (int stripY = 0; stripY < stripHeight; stripY++) {
                    int y = top + stripY;
                    double gridY = ((y + 0.5) * 3.0 / Math.max(1, height)) - 0.5;
                    int upper;
                    int lower;
                    double verticalFraction;
                    if (gridY <= 0.0) {
                        upper = 0;
                        lower = 0;
                        verticalFraction = 0.0;
                    } else if (gridY >= 2.0) {
                        upper = 2;
                        lower = 2;
                        verticalFraction = 0.0;
                    } else {
                        upper = (int) Math.floor(gridY);
                        lower = upper + 1;
                        verticalFraction = gridY - upper;
                    }

                    double[] columnExposure = new double[3];
                    double[] columnRedGain = new double[3];
                    double[] columnGreenGain = new double[3];
                    double[] columnBlueGain = new double[3];
                    for (int column = 0; column < 3; column++) {
                        double topExposure =
                                analysis.histogram.zoneExposureEv[upper * 3 + column];
                        double bottomExposure =
                                analysis.histogram.zoneExposureEv[lower * 3 + column];
                        columnExposure[column] = topExposure
                                + (bottomExposure - topExposure) * verticalFraction;
                        double topRed = selectedColour.zoneRedGain[upper * 3 + column];
                        double bottomRed = selectedColour.zoneRedGain[lower * 3 + column];
                        double topGreen =
                                selectedColour.zoneGreenGain[upper * 3 + column];
                        double bottomGreen =
                                selectedColour.zoneGreenGain[lower * 3 + column];
                        double topBlue = selectedColour.zoneBlueGain[upper * 3 + column];
                        double bottomBlue = selectedColour.zoneBlueGain[lower * 3 + column];
                        columnRedGain[column] = topRed
                                + (bottomRed - topRed) * verticalFraction;
                        columnGreenGain[column] = topGreen
                                + (bottomGreen - topGreen) * verticalFraction;
                        columnBlueGain[column] = topBlue
                                + (bottomBlue - topBlue) * verticalFraction;
                    }
                    int rowOffset = stripY * width;
                    for (int x = 0; x < width; x++) {
                        double leftExposure = columnExposure[leftZone[x]];
                        double localExposure = leftExposure
                                + (columnExposure[rightZone[x]] - leftExposure)
                                * horizontalFraction[x];
                        double localRedGain = columnRedGain[leftZone[x]]
                                + (columnRedGain[rightZone[x]] - columnRedGain[leftZone[x]])
                                * horizontalFraction[x];
                        double localGreenGain = columnGreenGain[leftZone[x]]
                                + (columnGreenGain[rightZone[x]] - columnGreenGain[leftZone[x]])
                                * horizontalFraction[x];
                        double localBlueGain = columnBlueGain[leftZone[x]]
                                + (columnBlueGain[rightZone[x]] - columnBlueGain[leftZone[x]])
                                * horizontalFraction[x];
                        int index = rowOffset + x;
                        int recovered = recoveryProcessor.apply(pixels[index]);
                        int colourCorrected = colourProcessor.apply(
                                recovered,
                                localRedGain,
                                localGreenGain,
                                localBlueGain);
                        pixels[index] = toneProcessor.apply(colourCorrected, localExposure);
                    }
                }
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, stripHeight);
        }
        applyImageIntegrityInPlace(bitmap, analysis.integrity, strengthPercent / 100.0);
        if (useNatureEditorial) {
            applyNatureEditorialInPlace(bitmap, strengthPercent / 100.0);
        } else if (useDocumentaryEditorial) {
            // Documentary finish is intentionally restrained and remains downstream of True Colour.
            applyNatureEditorialInPlace(bitmap, (strengthPercent / 100.0) * 0.72);
        }
    }


    private static void applyImageIntegrityInPlace(Bitmap bitmap, ImageIntegrityEngine.Analysis integrity, double strength) {
        if (strength <= 0.0 || !integrity.qualityGuardActive) return;
        int width=bitmap.getWidth(), height=bitmap.getHeight();
        int rowsPerStrip=Math.max(1, Math.min(128, 1_000_000 / Math.max(1,width)));
        int[] pixels=new int[width*rowsPerStrip];
        ImageIntegrityEngine.Processor processor=new ImageIntegrityEngine.Processor(integrity,strength);
        for(int top=0;top<height;top+=rowsPerStrip){
            int stripHeight=Math.min(rowsPerStrip,height-top);
            bitmap.getPixels(pixels,0,width,0,top,width,stripHeight);
            for(int sy=0;sy<stripHeight;sy++){
                int y=top+sy, off=sy*width;
                double ny=(y+.5)/Math.max(1.0,height);
                for(int x=0;x<width;x++){
                    pixels[off+x]=processor.apply(pixels[off+x],(x+.5)/Math.max(1.0,width),ny);
                }
            }
            bitmap.setPixels(pixels,0,width,0,top,width,stripHeight);
        }
    }

    private static void applyNatureEditorialInPlace(Bitmap bitmap, double strength) {
        if (strength <= 0.0) {
            return;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int rowsPerStrip = Math.max(1, Math.min(128, 1_000_000 / Math.max(1, width)));
        int[] pixels = new int[width * rowsPerStrip];
        NatureEditorialEngine.GuideAccumulator guideAccumulator =
                new NatureEditorialEngine.GuideAccumulator(width, height);
        for (int top = 0; top < height; top += rowsPerStrip) {
            int stripHeight = Math.min(rowsPerStrip, height - top);
            bitmap.getPixels(pixels, 0, width, 0, top, width, stripHeight);
            for (int stripY = 0; stripY < stripHeight; stripY++) {
                guideAccumulator.addRow(
                        pixels,
                        stripY * width,
                        top + stripY,
                        width);
            }
        }

        NatureEditorialEngine.Analysis editorial = guideAccumulator.finish();
        NatureEditorialEngine.Sampler sampler = editorial.createSampler(width, height);
        NatureEditorialEngine.Processor processor =
                new NatureEditorialEngine.Processor(editorial, strength);
        double[] localLuminance = new double[width];
        for (int top = 0; top < height; top += rowsPerStrip) {
            int stripHeight = Math.min(rowsPerStrip, height - top);
            bitmap.getPixels(pixels, 0, width, 0, top, width, stripHeight);
            for (int stripY = 0; stripY < stripHeight; stripY++) {
                int y = top + stripY;
                sampler.fillRow(y, localLuminance);
                int rowOffset = stripY * width;
                for (int x = 0; x < width; x++) {
                    int index = rowOffset + x;
                    pixels[index] = processor.apply(pixels[index], localLuminance[x]);
                }
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, stripHeight);
        }
    }

    public static SavedPhoto saveEditedCopy(
            Context context,
            Uri sourceUri,
            CorrectionAnalysis analysis,
            int strengthPercent) throws IOException {
        return saveEditedCopy(
                context,
                sourceUri,
                analysis,
                strengthPercent,
                analysis.trueColourActive);
    }

    public static SavedPhoto saveEditedCopy(
            Context context,
            Uri sourceUri,
            CorrectionAnalysis analysis,
            int strengthPercent,
            boolean useLabLook) throws IOException {
        return saveEditedCopy(
                context,
                sourceUri,
                analysis,
                strengthPercent,
                useLabLook,
                false);
    }

    public static SavedPhoto saveEditedCopy(
            Context context,
            Uri sourceUri,
            CorrectionAnalysis analysis,
            int strengthPercent,
            boolean useLabLook,
            boolean useNatureEditorial) throws IOException {
        return saveEditedCopy(context, sourceUri, analysis, strengthPercent, useLabLook, useNatureEditorial, false, OutputFormat.JPEG_100);
    }

    public static SavedPhoto saveEditedCopy(
            Context context, Uri sourceUri, CorrectionAnalysis analysis, int strengthPercent,
            boolean useLabLook, boolean useNatureEditorial, boolean useDocumentaryEditorial, OutputFormat outputFormat) throws IOException {
        long safeMaximumPixels = calculateSafeSavePixels();
        DecodedBitmap decoded;
        try {
            decoded = decode(context, sourceUri, safeMaximumPixels, true);
        } catch (OutOfMemoryError firstFailure) {
            System.gc();
            long retryMaximum = Math.max(8_000_000L, safeMaximumPixels / 2L);
            decoded = decode(context, sourceUri, retryMaximum, true);
        }

        Bitmap bitmap = decoded.bitmap;
        Uri outputUri = null;
        boolean labApplied = useLabLook && analysis.labCandidateAvailable;
        boolean png = outputFormat == OutputFormat.PNG_LOSSLESS;
        String displayName = "TrueColour_" + (labApplied ? "LAB_" : "SAFE_")
                + (useNatureEditorial ? "NATURE_" : (useDocumentaryEditorial ? "NATGEO_" : "NATURAL_"))
                + new SimpleDateFormat(
                "yyyyMMdd_HHmmss", Locale.US).format(new Date()) + (png ? ".png" : ".jpg");
        try {
            processInPlace(
                    bitmap,
                    analysis,
                    strengthPercent,
                    labApplied,
                    useNatureEditorial,
                    useDocumentaryEditorial);
            bitmap = ExperimentalVisionEngine.apply(bitmap, analysis.experimental);
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Images.Media.MIME_TYPE, png ? "image/png" : "image/jpeg");
            values.put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "Pictures/AutoFix True Colour Lab");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            outputUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (outputUri == null) {
                throw new IOException("Android could not create the destination image.");
            }

            try (OutputStream output = resolver.openOutputStream(outputUri, "w")) {
                Bitmap.CompressFormat format = png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG;
                if (output == null || !bitmap.compress(format, 100, output)) {
                    throw new IOException((png ? "PNG" : "JPEG") + " encoding failed.");
                }
            }

            copySafeExif(resolver, sourceUri, outputUri);

            ContentValues publish = new ContentValues();
            publish.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(outputUri, publish, null, null);
            return new SavedPhoto(
                    outputUri,
                    bitmap.getWidth(),
                    bitmap.getHeight(),
                    decoded.sourceWidth,
                    decoded.sourceHeight,
                    decoded.scaledForMemory,
                    displayName);
        } catch (IOException | RuntimeException failure) {
            if (outputUri != null) {
                context.getContentResolver().delete(outputUri, null, null);
            }
            throw failure;
        } finally {
            bitmap.recycle();
        }
    }

    public static long calculateSafeSavePixels() {
        Runtime runtime = Runtime.getRuntime();
        long used = runtime.totalMemory() - runtime.freeMemory();
        long available = Math.max(0L, runtime.maxMemory() - used - RESERVED_BYTES);
        long pixelBudget = (long) ((available * 0.55) / 4.0);
        return Math.max(MIN_SAVE_PIXELS, Math.min(MAX_SAVE_PIXELS, pixelBudget));
    }

    @SuppressWarnings("deprecation")
    private static void copySafeExif(ContentResolver resolver, Uri sourceUri, Uri outputUri) {
        // Orientation is intentionally not copied: ImageDecoder has already applied it to pixels.
        final String[] tags = new String[] {
                "Make", "Model", "Software", "Artist", "Copyright", "ImageDescription",
                "DateTime", "DateTimeOriginal", "DateTimeDigitized",
                "OffsetTime", "OffsetTimeOriginal", "OffsetTimeDigitized",
                "SubSecTime", "SubSecTimeOriginal", "SubSecTimeDigitized",
                "ExposureTime", "FNumber", "PhotographicSensitivity", "ISOSpeedRatings",
                "ExposureBiasValue", "ExposureProgram", "MeteringMode", "Flash",
                "FocalLength", "FocalLengthIn35mmFilm", "WhiteBalance", "LightSource",
                "LensMake", "LensModel",
                "GPSLatitude", "GPSLatitudeRef", "GPSLongitude", "GPSLongitudeRef",
                "GPSAltitude", "GPSAltitudeRef", "GPSTimeStamp", "GPSDateStamp",
                "GPSProcessingMethod", "GPSSpeed", "GPSSpeedRef", "GPSImgDirection",
                "GPSImgDirectionRef"
        };

        try (InputStream input = resolver.openInputStream(sourceUri);
             ParcelFileDescriptor outputDescriptor = resolver.openFileDescriptor(outputUri, "rw")) {
            if (input == null || outputDescriptor == null) {
                return;
            }
            ExifInterface sourceExif = new ExifInterface(input);
            ExifInterface outputExif = new ExifInterface(outputDescriptor.getFileDescriptor());
            for (String tag : tags) {
                String value = sourceExif.getAttribute(tag);
                if (value != null) {
                    try {
                        outputExif.setAttribute(tag, value);
                    } catch (RuntimeException ignored) {
                        // A malformed optional source tag must never prevent a successful save.
                    }
                }
            }
            outputExif.setAttribute("Orientation", "1");
            outputExif.saveAttributes();
        } catch (IOException | RuntimeException ignored) {
            // Pixel output is authoritative; unsupported metadata is a safe optional fallback.
        }
    }
}
