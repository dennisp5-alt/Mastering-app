package com.dennis.autofixcolourlab;
import android.app.*; import android.graphics.*; import android.view.*; import android.widget.*; import android.content.*;
/** Four-way comparison. One matrix-controlled ImageView is reused, so zoom/pan is exactly locked across variants. */
public final class LockedComparisonDialog {
 public static void show(Context c, Bitmap before, Bitmap tc, Bitmap lab, Bitmap nat){
  final Bitmap[] b={before,tc,lab,nat}; final String[] n={"Before","True Colour","LAB","NAT GEO"};
  LinearLayout root=new LinearLayout(c); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,12);
  ZoomImageView iv=new ZoomImageView(c); iv.setImageBitmap(before); root.addView(iv,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout tabs=new LinearLayout(c); tabs.setOrientation(LinearLayout.HORIZONTAL);
  for(int i=0;i<4;i++){ final int k=i; Button x=new Button(c); x.setText(n[i]); x.setTextSize(10); x.setOnClickListener(v->iv.setBitmapKeepMatrix(b[k])); tabs.addView(x,new LinearLayout.LayoutParams(0,-2,1)); }
  root.addView(tabs,new LinearLayout.LayoutParams(-1,-2));
  TextView hint=new TextView(c); hint.setText("Pinch and pan are locked between all four versions • double-tap not required"); hint.setGravity(Gravity.CENTER); hint.setPadding(4,4,4,4); root.addView(hint);
  AlertDialog d=new AlertDialog.Builder(c).setTitle("Locked comparison viewer").setView(root).setPositiveButton("Close",null).create();
  d.setOnDismissListener(x->{ for(int i=1;i<b.length;i++) if(b[i]!=null&&!b[i].isRecycled()) b[i].recycle(); }); d.show();
 }
 static final class ZoomImageView extends android.widget.ImageView {
  Matrix m=new Matrix(); android.view.ScaleGestureDetector scale; float lx,ly;
  ZoomImageView(Context c){super(c);setScaleType(ScaleType.MATRIX);scale=new android.view.ScaleGestureDetector(c,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){public boolean onScale(android.view.ScaleGestureDetector d){m.postScale(d.getScaleFactor(),d.getScaleFactor(),d.getFocusX(),d.getFocusY());setImageMatrix(m);return true;}});}
  void setBitmapKeepMatrix(Bitmap b){setImageBitmap(b);setImageMatrix(m);}
  public boolean onTouchEvent(android.view.MotionEvent e){scale.onTouchEvent(e); if(e.getPointerCount()==1&&!scale.isInProgress()){if(e.getAction()==0){lx=e.getX();ly=e.getY();}else if(e.getAction()==2){float dx=e.getX()-lx,dy=e.getY()-ly;m.postTranslate(dx,dy);setImageMatrix(m);lx=e.getX();ly=e.getY();}} return true;}
 }
}
