# AutoFix True Colour Lab v0.7.0 TEST

Image Integrity Intelligence test build. v0.5 colour behaviour remains the baseline.

New bounded, evidence-gated stage:
- highlight shoulder protection/recovery from existing RGB signal
- conservative shadow recovery (disabled for intentional low-key/night evidence)
- low-light chroma/noise-aware correction guard
- texture/detail and skin/subject protection
- conservative profile-free edge/vignette guard; no guessed lens geometry
- small depth-aware midtone separation when scene evidence supports it
- final Quality Guard rejects excessive luminance/chroma displacement or newly clipped channels
- integrity diagnostics report highlight, shadow, noise, detail, optical, depth and subject evidence

No generative reconstruction, fake detail, sky replacement or face beautification is used.
PNG/JPEG export behaviour and existing signing identity are retained from v0.5.

## v0.7.0 TEST — Camera Character Recovery
- New camera-agnostic preprocessing stage before True Colour.
- Detects strong evidence of baked JPEG oversaturation, harsh contrast/S-curves, lifted/HDR-compressed shadows and broad warm/cool rendering bias.
- Evidence gate defaults to bypass for neutral/uncertain files; correction magnitude is confidence-bounded.
- Recovery is applied to the analysis sample domain first, so True Colour and histogram intelligence analyse the recovered starting point.
- Existing True Colour, LAB, Nature/NAT GEO, Image Integrity and Quality Guard stages remain downstream and unchanged in purpose.
- No camera make/model profiles, generative reconstruction, fake detail or aggressive global normalisation.

## v0.8.0 EXPERIMENTAL
- High-confidence horizon straightening with conservative intelligent crop.
- Perspective evidence and guarded correction.
- Haze evidence with mild, bounded dehaze; dark scenes do not create haze evidence by themselves.
- Motion/defocus technical assessment (diagnostic; no fake-detail reconstruction).
- Multi-select duplicate/best-shot technical comparison and sequential batch processing.
- Four-way Before / True Colour / LAB / NAT GEO viewer using one shared image matrix, so pinch zoom and pan remain locked when switching versions.
- v0.7.2 True Colour/CCR/Image Integrity decision architecture retained; experimental modules bypass when evidence is weak.
