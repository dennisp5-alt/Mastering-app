package com.dennis.s23uaicamera;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.graphics.SurfaceTexture;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener, CameraEngine.Listener, SensorEventListener {
    private static final int REQ_CAMERA = 41;
    private AspectTextureView textureView;
    private TextView telemetry;
    private TextView modeText;
    private CameraEngine engine;
    private SensorManager sensors;
    private Sensor rotationSensor;
    private Sensor gyroSensor;
    private float rollDeg = 0f;
    private float motion = 0f;
    private boolean aiEnabled = true;
    private boolean autoLevel = true;
    private String look = "TRUE";
    private Button aiButton;
    private Button levelButton;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotationSensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        gyroSensor = sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        textureView = new AspectTextureView(this);
        textureView.setAspectRatio(3, 4);
        textureView.setSurfaceTextureListener(this);
        root.addView(textureView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        telemetry = new TextView(this);
        telemetry.setTextColor(Color.WHITE);
        telemetry.setBackgroundColor(0x88000000);
        telemetry.setTextSize(12f);
        telemetry.setPadding(dp(10), dp(6), dp(10), dp(6));
        telemetry.setText("AUTO+ AI • starting camera…");
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tp.gravity = Gravity.TOP;
        tp.topMargin = dp(24);
        root.addView(telemetry, tp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(6), dp(4), dp(6), dp(12));
        controls.setBackgroundColor(0xB0000000);

        modeText = new TextView(this);
        modeText.setTextColor(Color.WHITE);
        modeText.setGravity(Gravity.CENTER);
        modeText.setTextSize(13f);
        modeText.setText("AI path saves matched REF + AI images");
        controls.addView(modeText, rowParams());

        LinearLayout lensRow = row();
        addLens(lensRow, "0.6×", .6f);
        addLens(lensRow, "1×", 1f);
        addLens(lensRow, "3×", 3f);
        addLens(lensRow, "10×", 10f);
        controls.addView(lensRow, rowParams());

        LinearLayout lookRow = row();
        lookRow.addView(actionButton("TRUE", v -> setLook("TRUE")), cell());
        lookRow.addView(actionButton("PRO", v -> setLook("PRO")), cell());
        lookRow.addView(actionButton("NAT GEO", v -> setLook("NAT GEO")), cell());
        controls.addView(lookRow, rowParams());

        LinearLayout toggles = row();
        aiButton = actionButton("AI: ON", v -> {
            aiEnabled = !aiEnabled;
            aiButton.setText(aiEnabled ? "AI: ON" : "REFERENCE");
            modeText.setText(aiEnabled ? "AI path saves matched REF + AI images" : "Reference path: untouched Camera2 JPEG");
            if (engine != null) engine.setAiEnabled(aiEnabled);
        });
        levelButton = actionButton("LEVEL: AUTO", v -> {
            autoLevel = !autoLevel;
            levelButton.setText(autoLevel ? "LEVEL: AUTO" : "LEVEL: OFF");
            if (engine != null) engine.setAutoLevel(autoLevel);
        });
        toggles.addView(aiButton, cell());
        toggles.addView(levelButton, cell());
        controls.addView(toggles, rowParams());

        Button shutter = actionButton("●  CAPTURE", v -> {
            if (engine != null) engine.capture();
        });
        shutter.setTextSize(18f);
        shutter.setMinHeight(dp(58));
        controls.addView(shutter, rowParams());

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        cp.gravity = Gravity.BOTTOM;
        root.addView(controls, cp);
        setContentView(root);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private LinearLayout.LayoutParams rowParams() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(45), 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private Button actionButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12f);
        b.setAllCaps(false);
        b.setBackgroundColor(0xFF252525);
        b.setOnClickListener(listener);
        return b;
    }

    private void addLens(LinearLayout row, String label, float zoom) {
        row.addView(actionButton(label, v -> {
            if (engine != null) engine.setZoom(zoom);
            Toast.makeText(this, "Requested " + label, Toast.LENGTH_SHORT).show();
        }), cell());
    }

    private void setLook(String value) {
        look = value;
        if (engine != null) engine.setLook(value);
        Toast.makeText(this, value + " rendering", Toast.LENGTH_SHORT).show();
    }

    private void maybeStartCamera() {
        if (!textureView.isAvailable()) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        if (engine == null) {
            engine = new CameraEngine(this, textureView, this);
            engine.setAiEnabled(aiEnabled);
            engine.setAutoLevel(autoLevel);
            engine.setLook(look);
        }
        engine.start();
    }

    @Override protected void onResume() {
        super.onResume();
        if (rotationSensor != null) sensors.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
        if (gyroSensor != null) sensors.registerListener(this, gyroSensor, SensorManager.SENSOR_DELAY_GAME);
        maybeStartCamera();
    }

    @Override protected void onPause() {
        if (sensors != null) sensors.unregisterListener(this);
        if (engine != null) engine.stop();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (engine != null) engine.shutdown();
        super.onDestroy();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) maybeStartCamera();
        else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
    }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) { maybeStartCamera(); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        if (engine != null) engine.refreshPreviewGeometry();
    }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) {}

    @Override public void onTelemetry(FrameAnalysis a, int faces, String physical, float zoom, int evSteps) {
        final String scene = faces > 0 ? ("NIGHT".equals(a.scene) ? "NIGHT_PORTRAIT" : "PORTRAIT") : a.scene;
        final String text = String.format(Locale.US,
                "AI: %s   LOOK: %s   SCENE: %s\nLens request %.1f× • active physical ID %s • faces %d\nLuma %.0f  P05 %d  P95 %d  EV %+1.1f  focus zone %d/48\nLevel %+1.1f°  motion %.3f",
                aiEnabled ? "ON" : "REF", look, scene, zoom, physical, faces,
                a.meanLuma, a.p05, a.p95, evSteps / 10f, a.bestZone, rollDeg, motion);
        runOnUiThread(() -> telemetry.setText(text));
    }

    @Override public void onPhotoSaved(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    @Override public void onError(String message, Throwable error) {
        runOnUiThread(() -> {
            telemetry.setText("ERROR: " + message + (error == null ? "" : "\n" + error.getClass().getSimpleName() + ": " + error.getMessage()));
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] r = new float[9];
            float[] o = new float[3];
            SensorManager.getRotationMatrixFromVector(r, event.values);
            SensorManager.getOrientation(r, o);
            rollDeg = (float) Math.toDegrees(o[2]);
            if (engine != null) engine.setRoll(rollDeg);
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            float mag = (float) Math.sqrt(event.values[0]*event.values[0] + event.values[1]*event.values[1] + event.values[2]*event.values[2]);
            motion = motion * .88f + mag * .12f;
            if (engine != null) engine.setMotion(motion);
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
