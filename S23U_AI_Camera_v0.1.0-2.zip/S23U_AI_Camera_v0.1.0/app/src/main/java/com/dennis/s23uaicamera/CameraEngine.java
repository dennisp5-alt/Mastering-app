package com.dennis.s23uaicamera;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.Face;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CameraEngine {
    public interface Listener {
        void onTelemetry(FrameAnalysis analysis, int faceCount, String activePhysicalId, float zoom, int appliedEvSteps);
        void onPhotoSaved(String message);
        void onError(String message, Throwable error);
    }

    private final Context context;
    private final TextureView textureView;
    private final Listener listener;
    private final CameraManager manager;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private final ExecutorService processing = Executors.newSingleThreadExecutor();

    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader jpegReader;
    private ImageReader analysisReader;
    private Surface previewSurface;
    private CameraCharacteristics characteristics;
    private Rect activeArray;
    private Size jpegSize = new Size(4080, 3060);
    private Size previewSize = new Size(1440, 1080);
    private final String cameraId = "0";

    private volatile FrameAnalysis latestAnalysis = new FrameAnalysis(0,0,0,0,0,24,.5f,.5f,0,"STARTING");
    private volatile int faceCount = 0;
    private volatile Rect largestFace;
    private volatile String activePhysicalId = "?";
    private volatile float zoom = 1f;
    private volatile boolean aiEnabled = true;
    private volatile boolean autoLevel = true;
    private volatile String look = "TRUE";
    private volatile float rollDeg = 0f;
    private volatile float motion = 0f;
    private volatile boolean captureBusy = false;
    private int lastAppliedEv = 0;
    private long lastPreviewTuneMs = 0;

    public CameraEngine(Context context, TextureView textureView, Listener listener) {
        this.context = context.getApplicationContext();
        this.textureView = textureView;
        this.listener = listener;
        this.manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public void start() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("AutoPlusCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        openCamera();
    }

    public void stop() {
        if (cameraHandler != null) cameraHandler.post(this::closeCamera);
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(800); } catch (InterruptedException ignored) {}
        }
        cameraThread = null;
        cameraHandler = null;
    }

    public void shutdown() {
        stop();
        processing.shutdown();
    }

    public void setZoom(float value) {
        zoom = Math.max(0.6f, Math.min(10f, value));
        updateRepeating(true);
    }
    public void setAiEnabled(boolean value) { aiEnabled = value; updateRepeating(true); }
    public void setAutoLevel(boolean value) { autoLevel = value; }
    public void setLook(String value) { look = value; }
    public void setMotion(float value) { motion = value; }
    public void setRoll(float value) { rollDeg = value; }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        try {
            characteristics = manager.getCameraCharacteristics(cameraId);
            activeArray = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            Size[] jpg = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(ImageFormat.JPEG);
            if (jpg != null && jpg.length > 0) {
                jpegSize = Arrays.stream(jpg).max((a,b) -> Long.compare((long)a.getWidth()*a.getHeight(), (long)b.getWidth()*b.getHeight())).orElse(jpegSize);
            }
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) { camera = c; createSession(); }
                @Override public void onDisconnected(CameraDevice c) { c.close(); camera = null; }
                @Override public void onError(CameraDevice c, int error) {
                    c.close(); camera = null; notifyError("Camera open error " + error, null);
                }
            }, cameraHandler);
        } catch (Exception e) { notifyError("Unable to open camera", e); }
    }

    private void createSession() {
        if (camera == null || !textureView.isAvailable()) return;
        try {
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            previewSize = choosePreviewSize();
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            refreshPreviewGeometry();
            previewSurface = new Surface(st);

            jpegReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 3);
            analysisReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 2);
            jpegReader.setOnImageAvailableListener(this::onJpegAvailable, cameraHandler);
            analysisReader.setOnImageAvailableListener(this::onAnalysisAvailable, cameraHandler);

            previewBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewBuilder.addTarget(previewSurface);
            previewBuilder.addTarget(analysisReader.getSurface());
            applyCommon(previewBuilder, true);

            camera.createCaptureSession(Arrays.asList(previewSurface, analysisReader.getSurface(), jpegReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            if (camera == null) return;
                            session = s;
                            updateRepeating(true);
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) { notifyError("Camera session configuration failed", null); }
                    }, cameraHandler);
        } catch (Exception e) { notifyError("Unable to create camera session", e); }
    }

    private Size choosePreviewSize() {
        try {
            Size[] sizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(SurfaceTexture.class);
            if (sizes != null) {
                for (Size s : sizes) if (s.getWidth() == 1440 && s.getHeight() == 1080) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1440) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1080) return s;
                if (sizes.length > 0) return sizes[0];
            }
        } catch (Exception ignored) {}
        return new Size(1440,1080);
    }

    private void onAnalysisAvailable(ImageReader reader) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        try { latestAnalysis = YuvAnalyzer.analyze(image); }
        catch (Exception e) { notifyError("Frame analysis failed", e); }
        finally { image.close(); }

        long now = System.currentTimeMillis();
        if (now - lastPreviewTuneMs > 550) {
            lastPreviewTuneMs = now;
            updateRepeating(false);
        }
        int ev = aiEnabled ? latestAnalysis.evSteps : 0;
        listener.onTelemetry(latestAnalysis, faceCount, activePhysicalId, zoom, ev);
    }

    private void onJpegAvailable(ImageReader reader) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        byte[] bytes;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
        } finally { image.close(); }

        final CaptureMeta meta = new CaptureMeta();
        meta.analysis = latestAnalysis;
        meta.faces = faceCount;
        meta.activePhysicalId = activePhysicalId;
        meta.zoom = zoom;
        meta.ai = aiEnabled;
        meta.autoLevel = autoLevel;
        meta.look = look;
        meta.roll = rollDeg;
        meta.motion = motion;
        meta.evSteps = aiEnabled ? latestAnalysis.evSteps : 0;
        meta.jpegOrientation = jpegOrientation();

        processing.execute(() -> {
            try {
                saveCapture(bytes, meta);
            } catch (Exception e) {
                notifyError("Saving/processing image failed", e);
            } finally {
                captureBusy = false;
            }
        });
    }

    private void saveCapture(byte[] original, CaptureMeta meta) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String base = "AutoPlus_" + stamp + "_" + meta.look.replace(" ", "_");
        Uri ref = saveImage(base + "_REF.jpg", original);
        Uri ai = null;
        if (meta.ai) {
            byte[] processed = ImageProcessor.process(original, meta.look, meta.autoLevel, meta.roll, meta.jpegOrientation);
            ai = saveImage(base + "_AI.jpg", processed);
        }
        JSONObject d = new JSONObject();
        d.put("version", "0.1.1");
        d.put("mode", meta.ai ? "AI+REFERENCE" : "REFERENCE");
        d.put("look", meta.look);
        d.put("scene", sceneWithFaces(meta.analysis.scene, meta.faces));
        d.put("zoomRequested", meta.zoom);
        d.put("activePhysicalCameraId", meta.activePhysicalId);
        d.put("faceCount", meta.faces);
        d.put("meanLuma", meta.analysis.meanLuma);
        d.put("p05", meta.analysis.p05);
        d.put("p95", meta.analysis.p95);
        d.put("highlightFraction", meta.analysis.highlights);
        d.put("shadowFraction", meta.analysis.shadows);
        d.put("bestFocusZone0to48", meta.analysis.bestZone);
        d.put("recommendedEvStepsTenths", meta.evSteps);
        d.put("rollDegrees", meta.roll);
        d.put("motionGyro", meta.motion);
        d.put("autoLevelEnabled", meta.autoLevel);
        d.put("referenceUri", ref == null ? JSONObject.NULL : ref.toString());
        d.put("aiUri", ai == null ? JSONObject.NULL : ai.toString());
        Uri diag = null;
        String diagWarning = "";
        try { diag = saveJson(base + "_DIAG.json", d.toString(2)); }
        catch (Exception e) { diagWarning = "\nDiagnostics failed: " + e.getMessage(); }
        String msg = meta.ai ? "Saved REF + AI to Pictures/AutoPlusAI" : "Saved reference to Pictures/AutoPlusAI";
        if (diag != null) msg += "\nDiagnostics: Download/AutoPlusAI";
        msg += diagWarning;
        listener.onPhotoSaved(msg);
    }

    private Uri saveImage(String name, byte[] bytes) throws Exception {
        ContentResolver cr = context.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AutoPlusAI");
        v.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        v.put(MediaStore.Images.Media.WIDTH, jpegSize.getWidth());
        v.put(MediaStore.Images.Media.HEIGHT, jpegSize.getHeight());
        v.put(MediaStore.Images.Media.IS_PENDING, 1);

        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, v);
        if (uri == null) throw new IllegalStateException("MediaStore image insert failed");
        boolean published = false;
        try {
            try (OutputStream os = cr.openOutputStream(uri, "w")) {
                if (os == null) throw new IllegalStateException("Image output stream unavailable");
                os.write(bytes);
                os.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            if (cr.update(uri, done, null, null) < 1) {
                throw new IllegalStateException("MediaStore image publish failed");
            }
            published = true;
            return uri;
        } finally {
            if (!published) {
                try { cr.delete(uri, null, null); } catch (Exception ignored) {}
            }
        }
    }

    private Uri saveJson(String name, String text) throws Exception {
        ContentResolver cr = context.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AutoPlusAI");
        v.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, v);
        if (uri == null) return null;
        boolean published = false;
        try {
            try (OutputStream os = cr.openOutputStream(uri, "w")) {
                if (os == null) throw new IllegalStateException("Diagnostics output stream unavailable");
                os.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                os.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            cr.update(uri, done, null, null);
            published = true;
            return uri;
        } finally {
            if (!published) {
                try { cr.delete(uri, null, null); } catch (Exception ignored) {}
            }
        }
    }

    public void refreshPreviewGeometry() {
        textureView.post(() -> {
            // Preview stream and still capture are both 4:3. Keep a portrait 3:4 viewport.
            if (textureView instanceof AspectTextureView) {
                ((AspectTextureView) textureView).setAspectRatio(3, 4);
            }
        });
    }

    public void capture() {
        if (cameraHandler == null) return;
        cameraHandler.post(() -> {
            if (captureBusy || camera == null || session == null || jpegReader == null) return;
            captureBusy = true;
            try {
                CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(jpegReader.getSurface());
                if (previewSurface != null) b.addTarget(previewSurface);
                applyCommon(b, false);
                b.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
                b.set(CaptureRequest.CONTROL_ENABLE_ZSL, true);
                b.set(CaptureRequest.JPEG_QUALITY, (byte) 100);
                b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation());
                session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
                        updateResultMetadata(result);
                    }
                    @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                        captureBusy = false;
                        notifyError("Still capture failed: " + failure.getReason(), null);
                    }
                }, cameraHandler);
                cameraHandler.postDelayed(() -> {
                    if (captureBusy) {
                        captureBusy = false;
                        notifyError("Capture timed out before JPEG arrived", null);
                    }
                }, 7000);
            } catch (Exception e) { captureBusy = false; notifyError("Capture failed", e); }
        });
    }

    private void applyCommon(CaptureRequest.Builder b, boolean preview) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom);
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF);
        b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);
        b.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, CaptureRequest.STATISTICS_FACE_DETECT_MODE_SIMPLE);
        int ev = aiEnabled ? latestAnalysis.evSteps : 0;
        ev = Math.max(-20, Math.min(20, ev));
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev);
        if (aiEnabled) {
            b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF);
            b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY);
            MeteringRectangle meter = chooseMeteringRectangle();
            if (meter != null) {
                b.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{meter});
                b.set(CaptureRequest.CONTROL_AE_REGIONS, new MeteringRectangle[]{meter});
            }
        }
    }

    private MeteringRectangle chooseMeteringRectangle() {
        if (activeArray == null) return null;
        if (largestFace != null) {
            Rect f = new Rect(largestFace);
            f.intersect(activeArray);
            if (f.width() > 0 && f.height() > 0) return new MeteringRectangle(f, 950);
        }
        int cx = activeArray.left + Math.round(latestAnalysis.bestXNorm * activeArray.width());
        int cy = activeArray.top + Math.round(latestAnalysis.bestYNorm * activeArray.height());
        int rw = Math.max(120, activeArray.width() / 7);
        int rh = Math.max(120, activeArray.height() / 7);
        Rect r = new Rect(cx - rw/2, cy - rh/2, cx + rw/2, cy + rh/2);
        if (r.left < activeArray.left) r.offset(activeArray.left - r.left, 0);
        if (r.top < activeArray.top) r.offset(0, activeArray.top - r.top);
        if (r.right > activeArray.right) r.offset(activeArray.right - r.right, 0);
        if (r.bottom > activeArray.bottom) r.offset(0, activeArray.bottom - r.bottom);
        return new MeteringRectangle(r, 750);
    }

    private void updateRepeating(boolean force) {
        if (cameraHandler == null) return;
        cameraHandler.post(() -> {
            if (session == null || previewBuilder == null) return;
            try {
                int ev = aiEnabled ? latestAnalysis.evSteps : 0;
                if (!force && ev == lastAppliedEv) return;
                applyCommon(previewBuilder, true);
                lastAppliedEv = ev;
                session.setRepeatingRequest(previewBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
                        updateResultMetadata(result);
                    }
                }, cameraHandler);
            } catch (Exception e) { notifyError("Preview update failed", e); }
        });
    }

    private void updateResultMetadata(TotalCaptureResult result) {
        try {
            String p = result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
            if (p != null) activePhysicalId = p;
            Face[] faces = result.get(CaptureResult.STATISTICS_FACES);
            faceCount = faces == null ? 0 : faces.length;
            largestFace = null;
            if (faces != null) {
                int bestArea = 0;
                for (Face f : faces) {
                    Rect r = f.getBounds();
                    int area = r.width() * r.height();
                    if (area > bestArea) { bestArea = area; largestFace = r; }
                }
            }
        } catch (Exception ignored) {}
    }

    private int jpegOrientation() {
        int rotation = ((Activity) contextForActivity()).getWindowManager().getDefaultDisplay().getRotation();
        int degrees;
        switch (rotation) {
            case Surface.ROTATION_90: degrees = 0; break;
            case Surface.ROTATION_180: degrees = 270; break;
            case Surface.ROTATION_270: degrees = 180; break;
            case Surface.ROTATION_0:
            default: degrees = 90; break;
        }
        Integer sensor = characteristics == null ? 90 : characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        if (sensor == null) sensor = 90;
        return (degrees + sensor + 270) % 360;
    }

    // The engine is always created by MainActivity; retain a weak-free direct reference through TextureView context.
    private Context contextForActivity() { return textureView.getContext(); }

    private static String sceneWithFaces(String base, int faces) {
        if (faces <= 0) return base;
        if ("NIGHT".equals(base)) return "NIGHT_PORTRAIT";
        return "PORTRAIT";
    }

    private void closeCamera() {
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        try { if (jpegReader != null) jpegReader.close(); } catch (Exception ignored) {}
        try { if (analysisReader != null) analysisReader.close(); } catch (Exception ignored) {}
        try { if (previewSurface != null) previewSurface.release(); } catch (Exception ignored) {}
        session = null; camera = null; jpegReader = null; analysisReader = null; previewSurface = null;
    }

    private void notifyError(String msg, Throwable e) { listener.onError(msg, e); }

    private static final class CaptureMeta {
        FrameAnalysis analysis;
        int faces;
        String activePhysicalId;
        float zoom;
        boolean ai;
        boolean autoLevel;
        String look;
        float roll;
        float motion;
        int evSteps;
        int jpegOrientation;
    }
}
