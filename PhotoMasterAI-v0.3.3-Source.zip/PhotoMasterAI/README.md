# Photo Master AI v0.3.3 — Dark-Field + Social Source Guard

v0.3.3 is a narrow refinement of the v0.3.2 baseline.

## Dark-field fix

- adds relative-bright-subject evidence derived from the image histogram
- moon/stage/dark-field scenes no longer require near-white pixels to be recognised
- intentional black backgrounds receive 0 EV global lift and no shadow opening
- dark-field TRUE finishing cannot add vibrance, contrast or synthetic-looking colour
- aggressive repair/detail is withheld on these scenes

## Social / screenshot guard

- extreme ringing can identify already-processed/social sources even at higher resolution
- graphic/text/UI edges are not fed into halo-repair logic
- modest noise cleanup remains available
- detail recovery and sharpening pressure are reduced

The v0.3.2 exposure guard and full repair rollback remain intact.
