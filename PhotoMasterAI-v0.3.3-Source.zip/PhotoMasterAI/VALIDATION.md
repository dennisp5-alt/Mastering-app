# Photo Master AI v0.3.3 validation

1. Moon / dark-field
   - relative-bright dark-field guard must activate
   - exposure 0 EV
   - no shadow recovery
   - black sky stays black
   - no saturation/vibrance push

2. Cave/group dark scene
   - must NOT be classified as dark-field
   - dark-scene lift remains capped at +0.40 EV

3. Social/screenshot portrait
   - already-processed/social guard should activate with extreme ringing
   - halo repair withheld
   - restrained detail recovery/sharpening

4. Duck/water clean photo
   - should not trigger social guard
   - bright-scene exposure guard remains unchanged
