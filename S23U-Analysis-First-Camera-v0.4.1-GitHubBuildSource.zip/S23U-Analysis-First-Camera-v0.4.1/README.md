# Analysis First Camera 0.4.1

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture, True Colour, per-lens calibration, Natural Tonality, handheld stability and lens/ISO-specific Detail IQ. v0.4.1 keeps that imaging pipeline unchanged and replaces the development/test UI with a clean full-screen camera interface.

The v0.3.0 colour/tone baseline is frozen. v0.4.0 adds a deliberately restrained detail/noise stage chosen from the actual lens and captured ISO. Clean 1x daylight gets the most micro-detail support; 3x is tuned for portraits and general tele work; 10x becomes increasingly noise-first as ISO rises; low-light profiles reduce sharpening instead of sharpening noise. Smooth sky, skin and foliage receive additional protection.

Standard mode remains an untouched comparison control.


## v0.4.1 Clean Camera UI

- Full-screen preview-first layout with compact top controls.
- Samsung-style camera ergonomics without copying Samsung branding/assets.
- Zoom pill, large shutter, last-photo shortcut and bottom mode strip.
- PHOTO = Analysis First; STANDARD remains the untouched control path.
- NIGHT and PORTRAIT route to available Samsung OEM extensions.
- Optical Lock and True Colour remain available as small top controls.
- Long lens/scene/Detail IQ diagnostics move to the MORE menu.
- Only concise READY/HOLD/FALLBACK/OPTICAL WAIT messages remain on the live view.
