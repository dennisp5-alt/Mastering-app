# S23U Auto+ AI Camera v0.1.7 — Quality Refinement

Built from the proven v0.1.6 capture/save architecture. No camera-session redesign.

Changes:
- TRUE preserves the original Q100 JPEG on 0.6x/1x whenever no geometry correction is required.
- Auto-level threshold raised from 0.35° to 0.90° to avoid unnecessary resampling.
- PRO and NAT GEO processing made more conservative for better fine texture and natural colour.
- 3x/10x remain native physical-camera captures, then standardise once at final output to 4000x3000 / 3000x4000 (12 MP).
- Tele standardisation is one final filtered scale only; no repeated intermediate resizing.
- Existing physical-lens Camera2 routing, fast YUV capture, Q100 encoder, MediaStore save, and launcher icon are retained.

Version: 0.1.7 (versionCode 8)
Source suffix: -8
