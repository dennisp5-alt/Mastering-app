package com.dennis.s23uaicamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.ByteArrayOutputStream;

/**
 * v0.1.7 single-final-pass finishing.
 *
 * TRUE preserves the original Q100 JPEG byte-for-byte whenever no geometry
 * correction or telephoto 12 MP standardisation is required. PRO/NAT GEO are
 * deliberately restrained to avoid the texture loss/"processed" look seen in
 * earlier test builds. 3x/10x are standardised once at the very end to 12 MP.
 */
public final class ImageProcessor {
    private ImageProcessor() {}

    public static byte[] process(byte[] jpeg, String look, boolean autoLevel,
                                 float rollDeg, int jpegOrientation, String lensLabel) {
        final boolean tele = "3×".equals(lensLabel) || "10×".equals(lensLabel);
        final boolean levelNeeded = autoLevel && Math.abs(rollDeg) >= 0.90f && Math.abs(rollDeg) <= 5.0f;
        final boolean lookNeeded = !"TRUE".equals(look);

        // Preserve the encoder's original Q100 JPEG when there is genuinely
        // nothing to do. This is the maximum-detail path for 0.6x/1x TRUE.
        if (!tele && !levelNeeded && !lookNeeded) return jpeg;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        opts.inMutable = true;
        Bitmap work = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length, opts);
        if (work == null) return jpeg;

        // BitmapFactory does not apply the minimal EXIF orientation written by
        // YuvStillEncoder, so rotate pixels exactly once before the final encode.
        if (jpegOrientation != 0) {
            Matrix m = new Matrix();
            m.postRotate(jpegOrientation);
            Bitmap r = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (r != work) work.recycle();
            work = r;
        }

        final int nativeOrientedW = work.getWidth();
        final int nativeOrientedH = work.getHeight();
        final float targetAspect = nativeOrientedW / (float) Math.max(1, nativeOrientedH);

        if (levelNeeded) {
            Matrix m = new Matrix();
            m.postRotate(-rollDeg);
            Bitmap rotated = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (rotated != work) work.recycle();
            work = cropToAspect(rotated, targetAspect);
            if (work != rotated) rotated.recycle();
        }

        if (lookNeeded) applyLookRowWise(work, look, detectStrongBlue(work));

        // Samsung exposes ~10 MP physical 3x/10x YUV streams to third-party
        // Camera2, while its stock Camera produces a 12 MP user-facing JPEG.
        // Standardise tele output once, at the final stage, rather than through
        // repeated scaling during processing.
        int targetW = nativeOrientedW;
        int targetH = nativeOrientedH;
        if (tele) {
            if (nativeOrientedH >= nativeOrientedW) {
                targetW = 3000;
                targetH = 4000;
            } else {
                targetW = 4000;
                targetH = 3000;
            }
        }

        if (work.getWidth() != targetW || work.getHeight() != targetH) {
            Bitmap scaled = Bitmap.createScaledBitmap(work, targetW, targetH, true);
            if (scaled != work) work.recycle();
            work = scaled;
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(jpeg.length, 1024 * 1024));
        work.compress(Bitmap.CompressFormat.JPEG, 100, out);
        work.recycle();
        return out.toByteArray();
    }

    private static Bitmap cropToAspect(Bitmap b, float aspect) {
        int w = b.getWidth(), h = b.getHeight();
        float current = w / (float) h;
        if (Math.abs(current - aspect) < 0.0005f) return b;
        if (current > aspect) {
            int nw = Math.max(1, Math.round(h * aspect));
            int x = Math.max(0, (w - nw) / 2);
            return Bitmap.createBitmap(b, x, 0, Math.min(nw, w - x), h);
        } else {
            int nh = Math.max(1, Math.round(w / aspect));
            int y = Math.max(0, (h - nh) / 2);
            return Bitmap.createBitmap(b, 0, y, w, Math.min(nh, h - y));
        }
    }

    private static boolean detectStrongBlue(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int stepX = Math.max(1, w / 64), stepY = Math.max(1, h / 64);
        long sr=0, sg=0, sb=0, n=0;
        for (int y=0; y<h; y+=stepY) {
            for (int x=0; x<w; x+=stepX) {
                int c=b.getPixel(x,y);
                sr += (c>>>16)&255; sg += (c>>>8)&255; sb += c&255; n++;
            }
        }
        if (n==0) return false;
        double r=sr/(double)n, g=sg/(double)n, bl=sb/(double)n;
        return bl > 110 && bl > r*1.14 && bl > g*1.10;
    }

    private static void applyLookRowWise(Bitmap b, String look, boolean strongBlue) {
        int w = b.getWidth(), h = b.getHeight();
        int[] row = new int[w];

        // TRUE is never sent here unless geometry/tele standardisation already
        // requires a final encode. Keep it mathematically neutral.
        float contrast = 1.0f, saturation = 1.0f, shadowBias = 0.0f, highlightRoll = 0.035f;
        if ("PRO".equals(look)) {
            contrast = 1.032f; saturation = 1.015f; shadowBias = -0.7f; highlightRoll = 0.075f;
        } else if ("NAT GEO".equals(look)) {
            contrast = 1.048f; saturation = 1.032f; shadowBias = -1.0f; highlightRoll = 0.095f;
        }

        for (int yRow = 0; yRow < h; yRow++) {
            b.getPixels(row, 0, w, 0, yRow, w, 1);
            for (int i = 0; i < w; i++) {
                int c = row[i];
                int a = (c >>> 24) & 255;
                float r = (c >>> 16) & 255;
                float g = (c >>> 8) & 255;
                float bl = c & 255;
                float luma = 0.2126f * r + 0.7152f * g + 0.0722f * bl;

                float rr = luma + (r - luma) * saturation;
                float gg = luma + (g - luma) * saturation;
                float bb = luma + (bl - luma) * saturation;
                rr = (rr - 128f) * contrast + 128f;
                gg = (gg - 128f) * contrast + 128f;
                bb = (bb - 128f) * contrast + 128f;

                if (luma < 90f && shadowBias != 0f) {
                    float t = (90f - luma) / 90f;
                    rr += shadowBias * t; gg += shadowBias * t; bb += shadowBias * t;
                }
                if (luma > 205f) {
                    float t = (luma - 205f) / 50f;
                    float pull = 1f - highlightRoll * Math.min(1f, t);
                    rr = 205f + (rr - 205f) * pull;
                    gg = 205f + (gg - 205f) * pull;
                    bb = 205f + (bb - 205f) * pull;
                }

                // Keep foliage believable rather than pushing "HDR green".
                if ("NAT GEO".equals(look) && gg > rr * 1.10f && gg > bb * 1.10f) {
                    gg = luma + (gg - luma) * 0.985f;
                }
                if (strongBlue && bb > rr * 1.10f && bb > gg * 1.06f) {
                    float tame = "NAT GEO".equals(look) ? 0.965f : ("PRO".equals(look) ? 0.975f : 0.99f);
                    bb = luma + (bb - luma) * tame;
                }

                row[i] = (a << 24) | (clamp(Math.round(rr)) << 16) | (clamp(Math.round(gg)) << 8) | clamp(Math.round(bb));
            }
            b.setPixels(row, 0, w, 0, yRow, w, 1);
        }
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(v, 255); }
}
