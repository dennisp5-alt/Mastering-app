package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Locale;

public final class PhotoMasterEngine {

    public enum Mode { TRUE, PRO, NAT_GEO, LIFE, AI_ENHANCE, AI_MAX }

    public static final class Result {
        public final Bitmap bitmap;
        public final String report;
        public final PhotoAnalysis outputAnalysis;

        Result(Bitmap bitmap, String report, PhotoAnalysis outputAnalysis) {
            this.bitmap = bitmap;
            this.report = report;
            this.outputAnalysis = outputAnalysis;
        }
    }

    private static final class Params {
        double exposureEv;
        double shadowLift;
        double highlightProtect;
        double contrast;
        double saturation;
        double vibrance;
        double gamma;
        double wbR;
        double wbG;
        double wbB;
        double denoise;
        double sharpen;
        double microContrast;
        double greenControl;
        double blueControl;
        double aiSubjectLiftEv;
        double aiSubjectSharpen;
        double aiBackgroundDepthEv;
        double repairLuma;
        double repairChroma;
        double repairDeblock;
        double repairDetail;
        DeepPixelRepair.Plan repairPlan = DeepPixelRepair.Plan.none();
        boolean exposureActive;
        boolean wbActive;
        boolean toneActive;
        boolean denoiseActive;
        boolean sharpenActive;
        boolean colourActive;
        boolean healthyPreserve;
        boolean wbInsufficientEvidence;
        boolean wbNoCastDetected;
        boolean wbDetectedLowConfidence;
        boolean neuralMode;
        double castConfidence;
        double castEvidence;
        double castStrength;
        double wbCap;
        AiVisionAnalyzer.Result ai;
    }

    private PhotoMasterEngine() { }

    public static Result master(Bitmap source, PhotoAnalysis a, Mode mode, AiVisionAnalyzer.Result ai) {
        Params p = buildParams(a, mode, ai == null ? AiVisionAnalyzer.Result.none() : ai);
        Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        renderChunked(source, out, p);

        PhotoAnalysis check = PhotoAnalysis.analyse(out);
        double beforeDr = a.p95 - a.p05;
        double afterDr = check.p95 - check.p05;

        boolean highlightGuard = check.highlightClip > a.highlightClip + 0.003 && check.highlightClip > 0.008;
        boolean shadowGuard = check.shadowClip > a.shadowClip + 0.0015 && afterDr < beforeDr + 0.015;
        boolean saturationGuard = Math.abs(check.avgSat - a.avgSat) > (p.neuralMode ? 0.14 : 0.10)
                && a.avgSat >= 0.28 && a.avgSat <= 0.62;
        boolean detailGuard = !p.neuralMode && !p.repairPlan.active
                && a.noise <= 0.012 && check.detail < a.detail * 0.985;

        if (highlightGuard || shadowGuard || saturationGuard || detailGuard) {
            if (highlightGuard) {
                p.exposureEv = Math.min(0.0, p.exposureEv);
                p.highlightProtect = Math.max(p.highlightProtect, 0.12);
                p.aiSubjectLiftEv *= 0.5;
            }
            if (shadowGuard) {
                p.exposureEv = 0.0;
                p.contrast = Math.min(p.contrast, p.neuralMode ? 1.035 : 1.0);
                p.gamma = 1.0;
                p.shadowLift = Math.max(p.shadowLift, 0.02);
                p.aiBackgroundDepthEv = 0.0;
                if (a.highlightClip < 0.003) p.highlightProtect = Math.min(p.highlightProtect, 0.06);
                p.exposureActive = false;
                p.toneActive = false;
            }
            if (saturationGuard) {
                p.saturation = p.neuralMode ? 1.008 : 1.0;
                p.vibrance = p.neuralMode ? Math.min(p.vibrance, 0.030) : 0.0;
                p.greenControl = 1.0;
                p.blueControl = 1.0;
            }
            if (detailGuard) {
                p.denoise = 0.0;
                p.repairLuma = 0.0;
                p.repairChroma = 0.0;
                p.repairDeblock = 0.0;
                p.repairDetail = 0.0;
                p.denoiseActive = false;
                p.sharpen = 0.0;
                p.microContrast = 0.0;
                p.sharpenActive = false;
            }
            out.recycle();
            out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            renderChunked(source, out, p);
            check = PhotoAnalysis.analyse(out);
        }

        String report = buildReport(a, check, p, mode, highlightGuard, shadowGuard, saturationGuard, detailGuard);
        return new Result(out, report, check);
    }

    public static Result master(Bitmap source, PhotoAnalysis a, Mode mode) {
        return master(source, a, mode, AiVisionAnalyzer.Result.none());
    }

    private static Params buildParams(PhotoAnalysis a, Mode mode, AiVisionAnalyzer.Result ai) {
        Params p = new Params();
        p.ai = ai;
        p.neuralMode = mode == Mode.AI_ENHANCE || mode == Mode.AI_MAX;
        boolean aiMax = mode == Mode.AI_MAX;
        boolean personLike = ai != null && ai.available && ai.personLike;
        p.repairPlan = DeepPixelRepair.plan(
                a.noise, a.detail, a.blockiness, a.width, a.height,
                p.neuralMode, aiMax, personLike);
        p.repairLuma = p.repairPlan.lumaDenoise;
        p.repairChroma = p.repairPlan.chromaDenoise;
        p.repairDeblock = p.repairPlan.deblock;
        p.repairDetail = p.repairPlan.detailRecovery;

        double dr = a.p95 - a.p05;
        boolean healthyExposure = a.medianLum >= 0.32 && a.medianLum <= 0.62;
        boolean healthyDr = dr >= 0.45 && dr <= 0.82;
        boolean healthyClipping = a.highlightClip < 0.003 && a.shadowClip < 0.012;
        boolean healthyNoise = a.noise <= 0.012;
        boolean healthyDetail = a.detail >= 0.050;
        p.healthyPreserve = mode == Mode.TRUE && healthyExposure && healthyDr && healthyClipping && healthyNoise && healthyDetail;

        double targetMedian = 0.46;
        if (!p.healthyPreserve && (a.medianLum < 0.34 || a.medianLum > 0.64)) {
            p.exposureEv = clamp(log2(targetMedian / Math.max(0.08, a.medianLum)), -0.55, 0.70);
            if (a.highlightClip > 0.004 || a.p99 > 0.985) p.exposureEv = Math.min(p.exposureEv, 0.28);
            p.exposureActive = Math.abs(p.exposureEv) >= 0.10;
        }

        if (p.healthyPreserve) {
            p.shadowLift = 0.0;
            p.highlightProtect = 0.0;
            p.toneActive = false;
        } else {
            p.shadowLift = clamp((0.075 - a.p05) * 3.0 + (0.30 - a.medianLum) * 0.40, 0.0, 0.42);
            p.highlightProtect = (a.highlightClip > 0.003 || a.p99 > 0.985)
                    ? clamp((a.p99 - 0.965) * 5.0 + a.highlightClip * 10.0, 0.0, 0.55)
                    : 0.0;
            p.toneActive = p.shadowLift > 0.045 || p.highlightProtect > 0.045 || dr < 0.42;
        }

        double nMean = (a.neutralR + a.neutralG + a.neutralB) / 3.0;
        double rawR = nMean / Math.max(0.05, a.neutralR);
        double rawG = nMean / Math.max(0.05, a.neutralG);
        double rawB = nMean / Math.max(0.05, a.neutralB);
        p.castConfidence = a.neutralCastConfidence;
        p.castEvidence = a.neutralEvidenceConfidence;
        p.castStrength = a.neutralCastStrength;

        // v0.2.1: distinguish "no cast" from "not enough evidence".
        // This prevents balanced images with lots of neutral pixels being falsely reported as rejected.
        if (p.castEvidence < 0.10) {
            p.wbCap = 0.0;
            p.wbInsufficientEvidence = true;
        } else if (p.castStrength < 0.018) {
            p.wbCap = 0.0;
            p.wbNoCastDetected = true;
        } else if (p.castConfidence < 0.22) {
            p.wbCap = 0.0;
            p.wbDetectedLowConfidence = true;
        } else if (p.castConfidence < 0.42) {
            p.wbCap = 0.010;
        } else if (p.castConfidence < 0.70) {
            p.wbCap = 0.022;
        } else {
            p.wbCap = 0.038;
        }

        double wbStrength = p.wbCap <= 0.0 ? 0.0 : clamp(0.28 + p.castConfidence * 0.42, 0.0, 0.70);
        p.wbR = 1.0 + clamp((rawR - 1.0) * wbStrength, -p.wbCap, p.wbCap);
        p.wbG = 1.0 + clamp((rawG - 1.0) * wbStrength, -p.wbCap, p.wbCap);
        p.wbB = 1.0 + clamp((rawB - 1.0) * wbStrength, -p.wbCap, p.wbCap);
        p.wbActive = p.wbCap > 0.0 && Math.max(Math.abs(p.wbR - 1.0),
                Math.max(Math.abs(p.wbG - 1.0), Math.abs(p.wbB - 1.0))) >= 0.006;

        p.denoise = a.noise > 0.014 ? clamp((a.noise - 0.014) * 6.0, 0.0, 0.24) : 0.0;
        p.denoise = Math.max(p.denoise, p.repairLuma);
        p.denoiseActive = p.denoise > 0.035 || p.repairChroma > 0.045 || p.repairDeblock > 0.035;

        double lowDetail = clamp((0.050 - a.detail) * 4.5, 0.0, 0.16);
        p.sharpen = lowDetail > 0.025 ? clamp(lowDetail - p.denoise * 0.16, 0.0, 0.14) : 0.0;
        p.sharpen = Math.max(p.sharpen, p.repairDetail);
        p.sharpenActive = p.sharpen > 0.035;

        p.contrast = 1.0;
        p.gamma = 1.0;
        p.saturation = 1.0;
        p.vibrance = 0.0;
        p.microContrast = 0.0;
        p.greenControl = 1.0;
        p.blueControl = 1.0;

        if (!p.healthyPreserve) {
            if (dr < 0.42) p.contrast = 1.035;
            else if (dr > 0.80) p.contrast = 0.992;
            if (a.avgSat > 0.58) p.saturation = 0.985;
            else if (a.avgSat < 0.22) p.vibrance = 0.025;
        }

        switch (mode) {
            case TRUE:
                if (!p.healthyPreserve) {
                    p.contrast *= 1.006;
                    p.vibrance += 0.006;
                }
                break;
            case PRO:
                p.contrast *= 1.025;
                p.vibrance += 0.030;
                p.saturation *= 1.006;
                p.sharpen = Math.min(0.16, p.sharpen + 0.018);
                break;
            case NAT_GEO:
                p.contrast *= 1.040;
                p.vibrance += 0.040;
                p.saturation *= 1.010;
                p.greenControl = 0.990;
                p.blueControl = 0.995;
                if (a.highlightClip > 0.003 || a.p99 > 0.985) p.highlightProtect = Math.min(0.62, p.highlightProtect + 0.05);
                p.sharpen = Math.min(0.17, p.sharpen + 0.022);
                break;
            case LIFE:
                p.contrast *= 1.018;
                p.vibrance += 0.050;
                p.saturation *= 1.015;
                p.sharpen = Math.min(0.16, p.sharpen + 0.015);
                break;
            case AI_ENHANCE:
                applyAiProfile(p, a, false);
                break;
            case AI_MAX:
                applyAiProfile(p, a, true);
                break;
        }

        p.sharpenActive = p.sharpen > 0.035 || p.microContrast > 0.02 || p.aiSubjectSharpen > 0.01;
        p.colourActive = p.wbActive || Math.abs(p.saturation - 1.0) > 0.008 || p.vibrance > 0.008
                || p.greenControl < 0.995 || p.blueControl < 0.995;
        return p;
    }

    private static void applyAiProfile(Params p, PhotoAnalysis a, boolean max) {
        AiVisionAnalyzer.Result ai = p.ai;
        double confidence = (ai != null && ai.available) ? clamp(ai.topConfidence, 0.0, 1.0) : 0.0;
        double neuralScale = ai != null && ai.available ? (0.72 + 0.28 * confidence) : 0.55;

        if (max) {
            p.contrast *= 1.065;
            p.vibrance += 0.080 * neuralScale;
            p.saturation *= 1.020;
            p.sharpen = Math.min(0.22, p.sharpen + 0.090 * neuralScale);
            p.microContrast += 0.16 * neuralScale;
        } else {
            p.contrast *= 1.038;
            p.vibrance += 0.045 * neuralScale;
            p.saturation *= 1.008;
            p.sharpen = Math.min(0.18, p.sharpen + 0.050 * neuralScale);
            p.microContrast += 0.085 * neuralScale;
        }

        if (ai == null || !ai.available) return;

        if (ai.insectLike || ai.animalLike || ai.foodLike) {
            p.microContrast += max ? 0.050 : 0.030;
            p.sharpen = Math.min(max ? 0.24 : 0.19, p.sharpen + (max ? 0.035 : 0.020));
            p.vibrance += max ? 0.035 : 0.020;
        }
        if (ai.natureLike || ai.plantLike) {
            // Increase separation rather than simply saturating all greens.
            p.contrast *= max ? 1.018 : 1.010;
            p.greenControl = max ? 0.998 : 1.0;
            if (a.avgSat > 0.62) p.saturation *= 0.985;
        }
        if (ai.skyLike || ai.waterLike) {
            p.highlightProtect = Math.max(p.highlightProtect, max ? 0.10 : 0.055);
            p.blueControl = max ? 0.998 : 1.0;
        }
        if (ai.vehicleLike || ai.buildingLike) {
            p.microContrast += max ? 0.035 : 0.020;
            p.contrast *= max ? 1.012 : 1.006;
        }
        if (ai.personLike && ai.personCoverage > 0.012) {
            p.aiSubjectLiftEv = max ? 0.12 : 0.065;
            p.aiSubjectSharpen = max ? 0.055 : 0.030;
            p.aiBackgroundDepthEv = max ? 0.035 : 0.015;
            // Keep skin/person finishing from becoming too crunchy.
            p.sharpen = Math.min(p.sharpen, max ? 0.16 : 0.13);
            p.microContrast = Math.min(p.microContrast, max ? 0.14 : 0.09);
        }
    }

    private static void renderChunked(Bitmap src, Bitmap dst, Params p) {
        final int width = src.getWidth();
        final int height = src.getHeight();
        final int blockRows = 96;

        for (int rowStart = 0; rowStart < height; rowStart += blockRows) {
            int rows = Math.min(blockRows, height - rowStart);
            int readTop = Math.max(0, rowStart - 1);
            int readBottom = Math.min(height, rowStart + rows + 1);
            int readRows = readBottom - readTop;
            int[] input = new int[width * readRows];
            int[] output = new int[width * rows];
            src.getPixels(input, 0, width, 0, readTop, width, readRows);

            for (int ry = 0; ry < rows; ry++) {
                int sy = rowStart + ry;
                int localY = sy - readTop;
                for (int x = 0; x < width; x++) {
                    int idx = localY * width + x;
                    int c = input[idx];
                    double sourceR = Color.red(c) / 255.0;
                    double sourceG = Color.green(c) / 255.0;
                    double sourceB = Color.blue(c) / 255.0;
                    double r = sourceR, g = sourceG, b = sourceB;

                    double meanR = sourceR, meanG = sourceG, meanB = sourceB;
                    if (p.denoiseActive || p.sharpenActive) {
                        int x0 = Math.max(0, x - 1);
                        int x1 = Math.min(width - 1, x + 1);
                        int y0n = Math.max(0, localY - 1);
                        int y1n = Math.min(readRows - 1, localY + 1);
                        int cL = input[localY * width + x0];
                        int cR = input[localY * width + x1];
                        int cU = input[y0n * width + x];
                        int cD = input[y1n * width + x];
                        meanR = (sourceR + Color.red(cL) / 255.0 + Color.red(cR) / 255.0 + Color.red(cU) / 255.0 + Color.red(cD) / 255.0) / 5.0;
                        meanG = (sourceG + Color.green(cL) / 255.0 + Color.green(cR) / 255.0 + Color.green(cU) / 255.0 + Color.green(cD) / 255.0) / 5.0;
                        meanB = (sourceB + Color.blue(cL) / 255.0 + Color.blue(cR) / 255.0 + Color.blue(cU) / 255.0 + Color.blue(cD) / 255.0) / 5.0;
                    }

                    if (p.denoiseActive) {
                        double sourceLum0 = lum(r, g, b);
                        double meanLum0 = lum(meanR, meanG, meanB);
                        double delta = Math.abs(sourceLum0 - meanLum0);
                        double edgeProtect = 1.0 - clamp(delta / 0.075, 0.0, 1.0);

                        double lumaStrength = Math.max(p.denoise, p.repairLuma) * edgeProtect;
                        if (lumaStrength > 0.0) {
                            double targetLum = mix(sourceLum0, meanLum0, lumaStrength);
                            double scale0 = sourceLum0 > 0.006 ? targetLum / sourceLum0 : 1.0;
                            r *= scale0;
                            g *= scale0;
                            b *= scale0;
                        }

                        if (p.repairChroma > 0.0) {
                            double y0 = lum(r, g, b);
                            double cb = b - y0;
                            double cr = r - y0;
                            double ym = lum(meanR, meanG, meanB);
                            double cbm = meanB - ym;
                            double crm = meanR - ym;
                            double cs = p.repairChroma * edgeProtect;
                            cb = mix(cb, cbm, cs);
                            cr = mix(cr, crm, cs);
                            r = y0 + cr;
                            b = y0 + cb;
                            g = (y0 - 0.2126 * r - 0.0722 * b) / 0.7152;
                        }

                        if (p.repairDeblock > 0.0 && (((x & 7) == 0) || ((sy & 7) == 0))) {
                            double flat = 1.0 - clamp(delta / 0.055, 0.0, 1.0);
                            double bs = p.repairDeblock * flat;
                            r = mix(r, meanR, bs);
                            g = mix(g, meanG, bs);
                            b = mix(b, meanB, bs);
                        }
                    }

                    r *= p.wbR;
                    g *= p.wbG;
                    b *= p.wbB;

                    double sourceLum = lum(sourceR, sourceG, sourceB);
                    double neighborhoodLum = lum(meanR, meanG, meanB);
                    double y = lum(r, g, b);
                    double exp = Math.pow(2.0, p.exposureEv);
                    double tone = clamp(y * exp, 0.0, 1.25);

                    if (p.shadowLift > 0.0) {
                        double mask = Math.pow(1.0 - clamp(tone, 0.0, 1.0), 2.1);
                        tone += p.shadowLift * mask * 0.14;
                    }
                    if (p.highlightProtect > 0.0 && tone > 0.52) {
                        double t = clamp((tone - 0.52) / 0.48, 0.0, 1.3);
                        tone -= p.highlightProtect * t * t * 0.16;
                    }

                    float subject = (p.neuralMode && p.ai != null && p.ai.available)
                            ? p.ai.subjectAt(x, sy, width, height) : 0f;
                    if (subject > 0.01f && p.aiSubjectLiftEv != 0.0) {
                        double localEv = p.aiSubjectLiftEv * subject - p.aiBackgroundDepthEv * (1.0 - subject);
                        tone *= Math.pow(2.0, localEv);
                    }

                    tone = (tone - 0.5) * p.contrast + 0.5;
                    if (p.microContrast > 0.0) {
                        double local = sourceLum - neighborhoodLum;
                        double edgeMask = 1.0 - clamp(Math.abs(local) / 0.20, 0.0, 0.65);
                        tone += local * p.microContrast * edgeMask;
                    }
                    tone = Math.pow(clamp(tone, 0.0, 1.0), p.gamma);

                    double scale = y > 0.008 ? tone / y : 1.0;
                    r *= scale; g *= scale; b *= scale;

                    double gray = lum(r, g, b);
                    double max = Math.max(r, Math.max(g, b));
                    double min = Math.min(r, Math.min(g, b));
                    double chroma = clamp(max - min, 0.0, 1.0);
                    double vib = 1.0 + p.vibrance * (1.0 - chroma);
                    double sat = p.saturation * vib;
                    r = gray + (r - gray) * sat;
                    g = gray + (g - gray) * sat;
                    b = gray + (b - gray) * sat;

                    if (g > r * 1.06 && g > b * 1.03) g *= p.greenControl;
                    if (b > r * 1.08 && b > g * 1.03) b *= p.blueControl;

                    if (p.sharpenActive) {
                        double sourceDetailDelta = Math.abs(sourceLum - neighborhoodLum);
                        double noiseGuard = 1.0 - clamp(p.repairPlan.noiseScore * 0.65, 0.0, 0.65);
                        double edgeGate = clamp(sourceDetailDelta / 0.018, 0.0, 1.0);
                        double sh = (p.sharpen + p.aiSubjectSharpen * subject) * noiseGuard;
                        if (p.repairDetail > 0.0) {
                            sh = Math.max(sh, p.repairDetail * (0.55 + 0.45 * edgeGate));
                        }
                        if (subject > 0.30f) sh *= 0.78;
                        r += sh * (sourceR - meanR);
                        g += sh * (sourceG - meanG);
                        b += sh * (sourceB - meanB);
                    }

                    int alpha = Color.alpha(c);
                    output[ry * width + x] = Color.argb(alpha, to8(r), to8(g), to8(b));
                }
            }
            dst.setPixels(output, 0, width, 0, rowStart, width, rows);
        }
    }

    private static String buildReport(PhotoAnalysis before, PhotoAnalysis after, Params p, Mode mode,
                                      boolean hGuard, boolean sGuard, boolean satGuard, boolean detailGuard) {
        StringBuilder sb = new StringBuilder();
        sb.append("SCENE\n").append(before.sceneSummary()).append("\n").append(before.compactMetrics()).append("\n");
        sb.append(String.format(Locale.US, "Neutral evidence: %.2f | cast strength: %.3f | cast confidence: %.2f\n",
                p.castEvidence, p.castStrength, p.castConfidence));
        if (p.healthyPreserve) sb.append("Healthy-image preservation: ACTIVE\n");

        sb.append("\nDEEP PIXEL REPAIR\n");
        sb.append("• ").append(p.repairPlan.summary()).append("\n");
        if (p.repairPlan.active) {
            if (p.repairLuma > 0.0) sb.append(String.format(Locale.US,
                    "• Luma noise repair %.0f%% (edge-protected)\n", p.repairLuma * 100.0));
            if (p.repairChroma > 0.0) sb.append(String.format(Locale.US,
                    "• Chroma speckle repair %.0f%%\n", p.repairChroma * 100.0));
            if (p.repairDeblock > 0.0) sb.append(String.format(Locale.US,
                    "• JPEG block-boundary repair %.0f%%\n", p.repairDeblock * 100.0));
            if (p.repairDetail > 0.0) sb.append(String.format(Locale.US,
                    "• Bounded detail recovery %.0f%%\n", p.repairDetail * 100.0));
            sb.append("• Non-generative: no invented texture or AI upscaling\n");
        } else {
            sb.append("• Clean-source guard: pixel repair withheld\n");
        }

        if (p.neuralMode) {
            sb.append("\nNEURAL AI\n");
            if (p.ai != null && p.ai.available) {
                sb.append("• Bundled on-device ML models: ACTIVE (no cloud inference)\n");
                sb.append("• AI labels: ").append(p.ai.labelsSummary()).append("\n");
                sb.append("• AI scene tags: ").append(p.ai.sceneTags()).append("\n");
                sb.append(String.format(Locale.US, "• Faces %d | neural person-mask coverage %.1f%% | mask mean %.2f\n",
                        p.ai.faceCount, p.ai.personCoverage * 100.0, p.ai.personMeanConfidence));
                if (p.ai.personCoverage > 0.012) sb.append("• Neural person mask drives local subject/background finishing\n");
                else sb.append("• Neural scene labels drive the finishing profile; no person mask applied\n");
            } else {
                sb.append("• Neural vision unavailable; deterministic fallback used\n");
                if (p.ai != null && p.ai.error != null) sb.append("• AI error: ").append(p.ai.error).append("\n");
            }
        }

        sb.append("\nREPAIRED / MASTERED\n");
        boolean any = false;
        if (p.exposureActive) { sb.append(String.format(Locale.US, "• Exposure %+.2f EV\n", p.exposureEv)); any = true; }
        if (p.wbActive) {
            sb.append(String.format(Locale.US, "• Neutral-reference colour correction R %.3f / G %.3f / B %.3f (cap ±%.1f%%)\n",
                    p.wbR, p.wbG, p.wbB, p.wbCap * 100.0)); any = true;
        } else if (p.wbNoCastDetected) {
            sb.append("• No colour cast detected — neutral references already balanced\n");
        } else if (p.wbInsufficientEvidence) {
            sb.append("• Colour cast undecided — insufficient trustworthy neutral evidence\n");
        } else if (p.wbDetectedLowConfidence) {
            sb.append("• Mild colour cast detected but correction withheld — confidence too low\n");
        }
        if (p.shadowLift > 0.04) { sb.append("• Shadow recovery\n"); any = true; }
        if (p.highlightProtect > 0.04) { sb.append("• Highlight protection / roll-off\n"); any = true; }
        if (p.denoiseActive && !p.repairPlan.active) {
            sb.append(String.format(Locale.US, "• Edge-protected noise reduction %.0f%%\n", p.denoise * 100));
            any = true;
        } else if (p.repairPlan.active) {
            any = true;
        }
        if (p.sharpenActive) { sb.append(String.format(Locale.US, "• Detail finishing %.0f%% | local micro-contrast %.0f%%\n", p.sharpen * 100, p.microContrast * 100)); any = true; }
        if (p.colourActive) { sb.append("• Selective colour density / vibrance control\n"); any = true; }
        if (p.neuralMode && p.aiSubjectLiftEv > 0.0) {
            sb.append(String.format(Locale.US, "• AI person-mask relighting +%.2f EV with background depth\n", p.aiSubjectLiftEv)); any = true;
        }
        if (!any) sb.append("• No major technical repair required; finish only\n");
        sb.append("• Finish profile: ").append(modeName(mode)).append("\n");

        sb.append("\nCHANGE GUARD\n");
        if (hGuard || sGuard || satGuard || detailGuard) {
            if (hGuard) sb.append("• Highlight guard reduced unsafe brightening\n");
            if (sGuard) sb.append("• Tone change reduced — extra shadow clipping without useful DR gain\n");
            if (satGuard) sb.append("• Colour-density change reduced — shift exceeded safety envelope\n");
            if (detailGuard) sb.append("• NR/detail change rejected — source was already clean\n");
        } else {
            sb.append("• Output passed improvement and safety checks\n");
        }

        sb.append("\nOUTPUT QC\n").append(after.compactMetrics());
        sb.append("\n• Full-resolution render at working bitmap size\n");
        sb.append("• JPEG export quality: 100\n");
        return sb.toString();
    }

    private static String modeName(Mode mode) {
        switch (mode) {
            case PRO: return "PRO";
            case NAT_GEO: return "NAT GEO";
            case LIFE: return "LIFE";
            case AI_ENHANCE: return "AI ENHANCE";
            case AI_MAX: return "AI MAX";
            default: return "TRUE";
        }
    }

    private static double lum(double r, double g, double b) { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }
    private static double mix(double a, double b, double t) { return a + (b - a) * t; }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double log2(double v) { return Math.log(v) / Math.log(2.0); }
    private static int to8(double v) { return (int) Math.round(clamp(v, 0.0, 1.0) * 255.0); }
}
