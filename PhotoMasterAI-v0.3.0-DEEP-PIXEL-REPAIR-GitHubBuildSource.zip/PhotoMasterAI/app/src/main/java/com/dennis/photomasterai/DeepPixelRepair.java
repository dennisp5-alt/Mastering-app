package com.dennis.photomasterai;

import java.util.Locale;

/**
 * Measured, non-generative restoration planner.
 *
 * ML Kit remains the genuine on-device ML layer for scene/face/person
 * intelligence. Deep Pixel Repair decides whether local pixel repair is
 * justified and never invents objects or textures.
 */
public final class DeepPixelRepair {

    public static final class Plan {
        public final boolean active;
        public final double noiseScore;
        public final double softnessScore;
        public final double blockScore;
        public final double lumaDenoise;
        public final double chromaDenoise;
        public final double deblock;
        public final double detailRecovery;
        public final double confidence;
        public final boolean lowResolutionSource;

        Plan(boolean active, double noiseScore, double softnessScore, double blockScore,
             double lumaDenoise, double chromaDenoise, double deblock,
             double detailRecovery, double confidence, boolean lowResolutionSource) {
            this.active = active;
            this.noiseScore = clamp01(noiseScore);
            this.softnessScore = clamp01(softnessScore);
            this.blockScore = clamp01(blockScore);
            this.lumaDenoise = clamp(lumaDenoise, 0.0, 0.32);
            this.chromaDenoise = clamp(chromaDenoise, 0.0, 0.42);
            this.deblock = clamp(deblock, 0.0, 0.30);
            this.detailRecovery = clamp(detailRecovery, 0.0, 0.18);
            this.confidence = clamp01(confidence);
            this.lowResolutionSource = lowResolutionSource;
        }

        public static Plan none() {
            return new Plan(false, 0, 0, 0, 0, 0, 0, 0, 0, false);
        }

        public String summary() {
            if (!active) return "not required";
            return String.format(Locale.US,
                    "%.0f%% confidence | noise %.0f%% | softness %.0f%% | JPEG blocks %.0f%%",
                    confidence * 100.0, noiseScore * 100.0,
                    softnessScore * 100.0, blockScore * 100.0);
        }
    }

    private DeepPixelRepair() { }

    public static Plan plan(double noise, double detail, double blockiness,
                            int width, int height,
                            boolean aiMode, boolean aiMax, boolean personLike) {
        double noiseScore = smooth((noise - 0.010) / 0.020);
        double softnessScore = smooth((0.055 - detail) / 0.035);
        double blockScore = smooth((blockiness - 0.10) / 0.55);

        long pixels = Math.max(1L, (long) width * Math.max(1L, (long) height));
        boolean lowResolution = pixels < 3_000_000L;

        // High noise can masquerade as detail; don't sharpen noise back in.
        double recoverEvidence = softnessScore * (1.0 - 0.60 * noiseScore);
        double modeScale = aiMode ? (aiMax ? 1.28 : 1.12) : 1.0;

        double luma = 0.19 * noiseScore * modeScale;
        double chroma = 0.29 * noiseScore * modeScale;
        double deblock = 0.18 * blockScore * modeScale;
        double detailRecover = 0.115 * recoverEvidence * modeScale;

        // Protect skin/hair from brittle restoration.
        if (personLike) {
            detailRecover = Math.min(detailRecover, aiMax ? 0.090 : 0.072);
            chroma *= 0.92;
        }

        // Low-res sources may receive a little more bounded recovery, never SR.
        if (lowResolution && recoverEvidence > 0.35) {
            detailRecover = Math.min(0.14, detailRecover + 0.018);
        }

        boolean active = noiseScore >= 0.16 || softnessScore >= 0.28 || blockScore >= 0.24;
        double defectEvidence = Math.max(noiseScore, Math.max(softnessScore, blockScore));
        double confidence = active ? clamp01(0.42 + 0.58 * defectEvidence) : 0.0;

        if (luma < 0.030) luma = 0.0;
        if (chroma < 0.045) chroma = 0.0;
        if (deblock < 0.035) deblock = 0.0;
        if (detailRecover < 0.030) detailRecover = 0.0;

        active = active && (luma > 0.0 || chroma > 0.0 || deblock > 0.0 || detailRecover > 0.0);
        return new Plan(active, noiseScore, softnessScore, blockScore,
                luma, chroma, deblock, detailRecover, confidence, lowResolution);
    }

    private static double smooth(double x) {
        x = clamp01(x);
        return x * x * (3.0 - 2.0 * x);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
