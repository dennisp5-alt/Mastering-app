# Photo Master AI v0.3.0 — Deep Pixel Repair

v0.3.0 continues from the v0.2.1 CAST-FIX baseline.

New:
- measures local noise, softness and JPEG 8x8 block-boundary evidence
- separates luma repair from chroma-speckle repair
- bounded deblocking only on measured block boundaries / flat regions
- edge-gated detail recovery
- person-aware detail cap in AI modes
- clean-source guard: no meaningful repair when the source is already healthy
- proper adaptive Photo Master AI launcher icon

The existing ML Kit image labels, face detection and person segmentation are real
on-device ML and remain bundled/offline at runtime.

Deep Pixel Repair v0.3.0 itself is deliberately non-generative. It does not
perform neural denoise, neural deblur or super-resolution yet. This stage creates
the measurement/gating foundation needed to add those safely later without
running a heavy neural model on every photo or degrading already-clean images.
