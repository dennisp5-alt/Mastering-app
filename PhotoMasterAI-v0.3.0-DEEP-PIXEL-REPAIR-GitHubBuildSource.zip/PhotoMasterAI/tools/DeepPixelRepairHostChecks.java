package com.dennis.photomasterai;

public final class DeepPixelRepairHostChecks {
    public static void main(String[] args) {
        DeepPixelRepair.Plan clean = DeepPixelRepair.plan(
                0.008, 0.064, 0.03, 4000, 3000, false, false, false);
        require(!clean.active, "clean source must remain untouched");

        DeepPixelRepair.Plan noisy = DeepPixelRepair.plan(
                0.027, 0.045, 0.12, 4000, 3000, false, false, false);
        require(noisy.active && noisy.chromaDenoise > noisy.lumaDenoise,
                "noise repair should prioritise chroma speckle");

        DeepPixelRepair.Plan blocky = DeepPixelRepair.plan(
                0.011, 0.052, 0.66, 1920, 1080, false, false, false);
        require(blocky.active && blocky.deblock > 0.05,
                "JPEG blocking should enable bounded deblock");

        DeepPixelRepair.Plan softAi = DeepPixelRepair.plan(
                0.012, 0.025, 0.08, 1800, 1200, true, true, false);
        require(softAi.active && softAi.detailRecovery > 0.05 && softAi.lowResolutionSource,
                "soft low-res AI path should allow bounded detail recovery");

        DeepPixelRepair.Plan portrait = DeepPixelRepair.plan(
                0.012, 0.025, 0.08, 4000, 3000, true, true, true);
        require(portrait.detailRecovery <= 0.090001,
                "person evidence must cap detail recovery");

        System.out.println("Deep Pixel Repair host checks passed");
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
