# Photo Master AI v0.3.0 validation

Test:
- clean daylight photo: repair should normally be withheld
- noisy/high-ISO photo: chroma repair should exceed luma repair
- compressed/social-media JPEG: block repair may engage, without smearing real edges
- soft photo: bounded detail recovery, no halos
- portrait: person/face ML remains active in AI modes and detail recovery is capped
- TRUE mode on a good source: little or no meaningful change
