package com.dennis.s23uaicamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.ByteArrayOutputStream;

public final class ImageProcessor {
    private ImageProcessor() {}

    public static byte[] process(byte[] jpeg, String look, boolean autoLevel, float rollDeg, int jpegOrientation) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        opts.inMutable = true;
        Bitmap work = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length, opts);
        if (work == null) return jpeg;

        if (jpegOrientation != 0) {
            Matrix m = new Matrix();
            m.postRotate(jpegOrientation);
            Bitmap r = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (r != work) work.recycle();
            work = r;
        }

        float correction = 0f;
        if (autoLevel && Math.abs(rollDeg) >= 0.35f && Math.abs(rollDeg) <= 5.0f) correction = -rollDeg;
        if (correction != 0f) {
            int targetW = work.getWidth();
            int targetH = work.getHeight();
            float targetAspect = targetW / (float) targetH;
            Matrix m = new Matrix();
            m.postRotate(correction);
            Bitmap rotated = Bitmap.createBitmap(work, 0, 0, work.getWidth(), work.getHeight(), m, true);
            if (rotated != work) work.recycle();
            work = cropToAspect(rotated, targetAspect);
            if (work != rotated) rotated.recycle();
            if (work.getWidth() != targetW || work.getHeight() != targetH) {
                Bitmap scaled = Bitmap.createScaledBitmap(work, targetW, targetH, true);
                if (scaled != work) work.recycle();
                work = scaled;
            }
        }

        applyLookRowWise(work, look, detectStrongBlue(work));

        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(jpeg.length, 1024 * 1024));
        work.compress(Bitmap.CompressFormat.JPEG, 100, out);
        work.recycle();
        return out.toByteArray();
    }

    private static Bitmap cropToAspect(Bitmap b, float aspect) {
        int w = b.getWidth(), h = b.getHeight();
        float current = w / (float) h;
        if (Math.abs(current - aspect) < 0.0005f) return b;
        if (current > aspect) {
            int nw = Math.max(1, Math.round(h * aspect));
            int x = Math.max(0, (w - nw) / 2);
            return Bitmap.createBitmap(b, x, 0, Math.min(nw, w - x), h);
        } else {
            int nh = Math.max(1, Math.round(w / aspect));
            int y = Math.max(0, (h - nh) / 2);
            return Bitmap.createBitmap(b, 0, y, w, Math.min(nh, h - y));
        }
    }

    private static boolean detectStrongBlue(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int stepX = Math.max(1, w / 64), stepY = Math.max(1, h / 64);
        long sr=0, sg=0, sb=0, n=0;
        for (int y=0; y<h; y+=stepY) {
            for (int x=0; x<w; x+=stepX) {
                int c=b.getPixel(x,y);
                sr += (c>>>16)&255; sg += (c>>>8)&255; sb += c&255; n++;
            }
        }
        if (n==0) return false;
        double r=sr/(double)n, g=sg/(double)n, bl=sb/(double)n;
        return bl > 105 && bl > r*1.12 && bl > g*1.08;
    }

    private static void applyLookRowWise(Bitmap b, String look, boolean strongBlue) {
        int w = b.getWidth(), h = b.getHeight();
        int[] row = new int[w];
        float contrast = 1.01f, saturation = 0.99f, shadowBias = -1.5f, highlightRoll = 0.08f;
        if ("PRO".equals(look)) {
            contrast = 1.055f; saturation = 1.035f; shadowBias = -2.0f; highlightRoll = 0.11f;
        } else if ("NAT GEO".equals(look)) {
            contrast = 1.075f; saturation = 1.07f; shadowBias = -2.5f; highlightRoll = 0.14f;
        }

        for (int yRow = 0; yRow < h; yRow++) {
            b.getPixels(row, 0, w, 0, yRow, w, 1);
            for (int i = 0; i < w; i++) {
                int c = row[i];
                int a = (c >>> 24) & 255;
                float r = (c >>> 16) & 255;
                float g = (c >>> 8) & 255;
                float bl = c & 255;
                float luma = 0.2126f * r + 0.7152f * g + 0.0722f * bl;

                float rr = luma + (r - luma) * saturation;
                float gg = luma + (g - luma) * saturation;
                float bb = luma + (bl - luma) * saturation;
                rr = (rr - 128f) * contrast + 128f;
                gg = (gg - 128f) * contrast + 128f;
                bb = (bb - 128f) * contrast + 128f;

                if (luma < 96f) {
                    float t = (96f - luma) / 96f;
                    rr += shadowBias * t; gg += shadowBias * t; bb += shadowBias * t;
                }
                if (luma > 200f) {
                    float t = (luma - 200f) / 55f;
                    float pull = 1f - highlightRoll * Math.min(1f, t);
                    rr = 200f + (rr - 200f) * pull;
                    gg = 200f + (gg - 200f) * pull;
                    bb = 200f + (bb - 200f) * pull;
                }
                if ("NAT GEO".equals(look) && gg > rr * 1.08f && gg > bb * 1.08f) {
                    gg = luma + (gg - luma) * 0.96f;
                }
                if (strongBlue && bb > rr * 1.08f && bb > gg * 1.04f) {
                    float tame = "NAT GEO".equals(look) ? 0.93f : ("PRO".equals(look) ? 0.95f : 0.97f);
                    bb = luma + (bb - luma) * tame;
                }
                row[i] = (a << 24) | (clamp(Math.round(rr)) << 16) | (clamp(Math.round(gg)) << 8) | clamp(Math.round(bb));
            }
            b.setPixels(row, 0, w, 0, yRow, w, 1);
        }
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(v, 255); }
}
