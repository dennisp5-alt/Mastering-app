# Auto+ AI Camera v0.1.6

Stable feature-restoration build for Samsung Galaxy S23 Ultra.

Core capture path retained from the proven v0.1.5 baseline:
- logical camera 0
- physical outputs bound to S23U cameras 2 / 5 / 6 / 7
- full-resolution YUV_420_888 still capture
- in-app Q100 JPEG encoding
- MediaStore save to Pictures/AutoPlusAI

Restored/features:
- 0.6x / 1x / 3x / 10x optical routing
- active-physical-lens verification and fallback warning
- 4:3 proportion-safe preview
- TRUE / PRO / NAT GEO looks
- auto-level
- post-capture 49-zone luma/DR scene analysis
- face-aware portrait scene labelling
- wide-angle portrait distortion warning
- conservative smart-blue taming
- single final-photo AI save for faster completion
- REFERENCE mode to preserve the encoded Q100 frame without look/level processing
- adaptive Auto+ camera launcher icon

v0.1.6 / versionCode 7.
