package com.dennis.photomasterai;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Locale;

public final class PhotoMasterEngine {

    public enum Mode { TRUE, PRO, NAT_GEO, LIFE }

    public static final class Result {
        public final Bitmap bitmap;
        public final String report;
        public final PhotoAnalysis outputAnalysis;

        Result(Bitmap bitmap, String report, PhotoAnalysis outputAnalysis) {
            this.bitmap = bitmap;
            this.report = report;
            this.outputAnalysis = outputAnalysis;
        }
    }

    private static final class Params {
        double exposureEv;
        double shadowLift;
        double highlightProtect;
        double contrast;
        double saturation;
        double vibrance;
        double gamma;
        double wbR;
        double wbG;
        double wbB;
        double denoise;
        double sharpen;
        double greenControl;
        double blueControl;
        boolean exposureActive;
        boolean wbActive;
        boolean toneActive;
        boolean denoiseActive;
        boolean sharpenActive;
        boolean colourActive;
        boolean healthyPreserve;
        boolean wbRejectedLowConfidence;
        double castConfidence;
        double wbCap;
    }

    private PhotoMasterEngine() { }

    public static Result master(Bitmap source, PhotoAnalysis a, Mode mode) {
        Params p = buildParams(a, mode);
        Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        renderChunked(source, out, p);

        PhotoAnalysis check = PhotoAnalysis.analyse(out);
        double beforeDr = a.p95 - a.p05;
        double afterDr = check.p95 - check.p05;

        boolean highlightGuard = check.highlightClip > a.highlightClip + 0.003 && check.highlightClip > 0.008;
        boolean shadowGuard = check.shadowClip > a.shadowClip + 0.0015 && afterDr < beforeDr + 0.015;
        boolean saturationGuard = Math.abs(check.avgSat - a.avgSat) > 0.10 && a.avgSat >= 0.28 && a.avgSat <= 0.58;
        boolean detailGuard = a.noise <= 0.012 && check.detail < a.detail * 0.985;

        if (highlightGuard || shadowGuard || saturationGuard || detailGuard) {
            if (highlightGuard) {
                p.exposureEv = Math.min(0.0, p.exposureEv);
                p.highlightProtect = Math.max(p.highlightProtect, 0.12);
            }
            if (shadowGuard) {
                // Reject global tone moves that create extra black clipping without useful DR gain.
                p.exposureEv = 0.0;
                p.contrast = 1.0;
                p.gamma = 1.0;
                p.shadowLift = Math.max(p.shadowLift, 0.02);
                if (a.highlightClip < 0.003) p.highlightProtect = 0.0;
                p.exposureActive = false;
                p.toneActive = false;
            }
            if (saturationGuard) {
                p.saturation = 1.0;
                p.vibrance = 0.0;
                p.greenControl = 1.0;
                p.blueControl = 1.0;
            }
            if (detailGuard) {
                p.denoise = 0.0;
                p.denoiseActive = false;
                p.sharpen = 0.0;
                p.sharpenActive = false;
            }
            out.recycle();
            out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            renderChunked(source, out, p);
            check = PhotoAnalysis.analyse(out);
        }

        String report = buildReport(a, check, p, mode, highlightGuard, shadowGuard, saturationGuard, detailGuard);
        return new Result(out, report, check);
    }

    private static Params buildParams(PhotoAnalysis a, Mode mode) {
        Params p = new Params();

        double dr = a.p95 - a.p05;
        boolean healthyExposure = a.medianLum >= 0.32 && a.medianLum <= 0.62;
        boolean healthyDr = dr >= 0.45 && dr <= 0.82;
        boolean healthyClipping = a.highlightClip < 0.003 && a.shadowClip < 0.012;
        boolean healthyNoise = a.noise <= 0.012;
        boolean healthyDetail = a.detail >= 0.050;
        p.healthyPreserve = mode == Mode.TRUE && healthyExposure && healthyDr && healthyClipping && healthyNoise && healthyDetail;

        // Exposure: do not normalize a healthy image toward an arbitrary midpoint.
        double targetMedian = 0.46;
        if (!p.healthyPreserve && (a.medianLum < 0.34 || a.medianLum > 0.64)) {
            p.exposureEv = clamp(log2(targetMedian / Math.max(0.08, a.medianLum)), -0.55, 0.70);
            if (a.highlightClip > 0.004 || a.p99 > 0.985) p.exposureEv = Math.min(p.exposureEv, 0.28);
            p.exposureActive = Math.abs(p.exposureEv) >= 0.10;
        }

        if (p.healthyPreserve) {
            p.shadowLift = 0.0;
            p.highlightProtect = 0.0;
            p.toneActive = false;
        } else {
            p.shadowLift = clamp((0.075 - a.p05) * 3.0 + (0.30 - a.medianLum) * 0.40, 0.0, 0.42);
            p.highlightProtect = (a.highlightClip > 0.003 || a.p99 > 0.985)
                    ? clamp((a.p99 - 0.965) * 5.0 + a.highlightClip * 10.0, 0.0, 0.55)
                    : 0.0;
            p.toneActive = p.shadowLift > 0.045 || p.highlightProtect > 0.045 || dr < 0.42;
        }

        // v0.1.1: white balance comes from likely-neutral pixels, not whole-frame RGB averages.
        double nMean = (a.neutralR + a.neutralG + a.neutralB) / 3.0;
        double rawR = nMean / Math.max(0.05, a.neutralR);
        double rawG = nMean / Math.max(0.05, a.neutralG);
        double rawB = nMean / Math.max(0.05, a.neutralB);
        p.castConfidence = a.neutralCastConfidence;

        if (p.castConfidence < 0.35) {
            p.wbCap = 0.0;
            p.wbRejectedLowConfidence = true;
        } else if (p.castConfidence < 0.60) {
            p.wbCap = 0.015;
        } else if (p.castConfidence < 0.80) {
            p.wbCap = 0.030;
        } else {
            p.wbCap = 0.050;
        }

        double wbStrength = p.castConfidence < 0.35 ? 0.0 : clamp(0.38 + p.castConfidence * 0.34, 0.0, 0.72);
        double corrR = (rawR - 1.0) * wbStrength;
        double corrG = (rawG - 1.0) * wbStrength;
        double corrB = (rawB - 1.0) * wbStrength;
        p.wbR = 1.0 + clamp(corrR, -p.wbCap, p.wbCap);
        p.wbG = 1.0 + clamp(corrG, -p.wbCap, p.wbCap);
        p.wbB = 1.0 + clamp(corrB, -p.wbCap, p.wbCap);
        p.wbActive = p.wbCap > 0.0 && Math.max(Math.abs(p.wbR - 1.0),
                Math.max(Math.abs(p.wbG - 1.0), Math.abs(p.wbB - 1.0))) >= 0.006;

        // Leave low-noise files alone.
        p.denoise = a.noise > 0.014 ? clamp((a.noise - 0.014) * 6.0, 0.0, 0.24) : 0.0;
        p.denoiseActive = p.denoise > 0.035;

        double lowDetail = clamp((0.050 - a.detail) * 4.5, 0.0, 0.16);
        p.sharpen = lowDetail > 0.025 ? clamp(lowDetail - p.denoise * 0.16, 0.0, 0.14) : 0.0;
        p.sharpenActive = p.sharpen > 0.035;

        p.contrast = 1.0;
        p.gamma = 1.0;
        p.saturation = 1.0;
        p.vibrance = 0.0;
        p.greenControl = 1.0;
        p.blueControl = 1.0;

        if (!p.healthyPreserve) {
            if (dr < 0.42) p.contrast = 1.035;
            else if (dr > 0.80) p.contrast = 0.992;
            if (a.avgSat > 0.58) p.saturation = 0.985;
            else if (a.avgSat < 0.22) p.vibrance = 0.025;
        }

        switch (mode) {
            case TRUE:
                if (!p.healthyPreserve) {
                    p.contrast *= 1.006;
                    p.vibrance += 0.006;
                }
                break;
            case PRO:
                p.contrast *= 1.025;
                p.vibrance += 0.030;
                p.saturation *= 1.006;
                p.sharpen = Math.min(0.16, p.sharpen + 0.018);
                break;
            case NAT_GEO:
                p.contrast *= 1.040;
                p.vibrance += 0.040;
                p.saturation *= 1.010;
                p.greenControl = 0.990;
                p.blueControl = 0.995;
                if (a.highlightClip > 0.003 || a.p99 > 0.985) p.highlightProtect = Math.min(0.62, p.highlightProtect + 0.05);
                p.sharpen = Math.min(0.17, p.sharpen + 0.022);
                break;
            case LIFE:
                p.contrast *= 1.018;
                p.vibrance += 0.050;
                p.saturation *= 1.015;
                p.sharpen = Math.min(0.16, p.sharpen + 0.015);
                break;
        }

        p.sharpenActive = p.sharpen > 0.035;
        p.colourActive = p.wbActive || Math.abs(p.saturation - 1.0) > 0.008 || p.vibrance > 0.008
                || p.greenControl < 0.995 || p.blueControl < 0.995;
        return p;
    }

    private static void renderChunked(Bitmap src, Bitmap dst, Params p) {
        final int width = src.getWidth();
        final int height = src.getHeight();
        final int blockRows = 96;

        for (int y0 = 0; y0 < height; y0 += blockRows) {
            int rows = Math.min(blockRows, height - y0);
            int readTop = Math.max(0, y0 - 1);
            int readBottom = Math.min(height, y0 + rows + 1);
            int readRows = readBottom - readTop;
            int[] input = new int[width * readRows];
            int[] output = new int[width * rows];
            src.getPixels(input, 0, width, 0, readTop, width, readRows);

            for (int ry = 0; ry < rows; ry++) {
                int sy = y0 + ry;
                int localY = sy - readTop;
                for (int x = 0; x < width; x++) {
                    int idx = localY * width + x;
                    int c = input[idx];
                    double sourceR = Color.red(c) / 255.0;
                    double sourceG = Color.green(c) / 255.0;
                    double sourceB = Color.blue(c) / 255.0;
                    double r = sourceR;
                    double g = sourceG;
                    double b = sourceB;

                    double meanR = sourceR, meanG = sourceG, meanB = sourceB;
                    if (p.denoiseActive || p.sharpenActive) {
                        int x0 = Math.max(0, x - 1);
                        int x1 = Math.min(width - 1, x + 1);
                        int y0n = Math.max(0, localY - 1);
                        int y1n = Math.min(readRows - 1, localY + 1);
                        int cL = input[localY * width + x0];
                        int cR = input[localY * width + x1];
                        int cU = input[y0n * width + x];
                        int cD = input[y1n * width + x];
                        meanR = (sourceR + Color.red(cL) / 255.0 + Color.red(cR) / 255.0 + Color.red(cU) / 255.0 + Color.red(cD) / 255.0) / 5.0;
                        meanG = (sourceG + Color.green(cL) / 255.0 + Color.green(cR) / 255.0 + Color.green(cU) / 255.0 + Color.green(cD) / 255.0) / 5.0;
                        meanB = (sourceB + Color.blue(cL) / 255.0 + Color.blue(cR) / 255.0 + Color.blue(cU) / 255.0 + Color.blue(cD) / 255.0) / 5.0;
                    }

                    if (p.denoiseActive) {
                        double sourceLum = lum(r, g, b);
                        double meanLum = lum(meanR, meanG, meanB);
                        double delta = Math.abs(sourceLum - meanLum);
                        double edgeProtect = 1.0 - clamp(delta / 0.075, 0.0, 1.0);
                        double d = p.denoise * edgeProtect;
                        r = mix(r, meanR, d);
                        g = mix(g, meanG, d);
                        b = mix(b, meanB, d);
                    }

                    r *= p.wbR;
                    g *= p.wbG;
                    b *= p.wbB;

                    double y = lum(r, g, b);
                    double exp = Math.pow(2.0, p.exposureEv);
                    double tone = clamp(y * exp, 0.0, 1.25);

                    if (p.shadowLift > 0.0) {
                        double mask = Math.pow(1.0 - clamp(tone, 0.0, 1.0), 2.1);
                        tone += p.shadowLift * mask * 0.14;
                    }
                    if (p.highlightProtect > 0.0 && tone > 0.52) {
                        double t = clamp((tone - 0.52) / 0.48, 0.0, 1.3);
                        tone -= p.highlightProtect * t * t * 0.16;
                    }
                    tone = (tone - 0.5) * p.contrast + 0.5;
                    tone = Math.pow(clamp(tone, 0.0, 1.0), p.gamma);

                    double scale = y > 0.008 ? tone / y : 1.0;
                    r *= scale;
                    g *= scale;
                    b *= scale;

                    double gray = lum(r, g, b);
                    double max = Math.max(r, Math.max(g, b));
                    double min = Math.min(r, Math.min(g, b));
                    double chroma = clamp(max - min, 0.0, 1.0);
                    double vib = 1.0 + p.vibrance * (1.0 - chroma);
                    double sat = p.saturation * vib;
                    r = gray + (r - gray) * sat;
                    g = gray + (g - gray) * sat;
                    b = gray + (b - gray) * sat;

                    if (g > r * 1.06 && g > b * 1.03) g *= p.greenControl;
                    if (b > r * 1.08 && b > g * 1.03) b *= p.blueControl;

                    if (p.sharpenActive) {
                        r += p.sharpen * (sourceR - meanR);
                        g += p.sharpen * (sourceG - meanG);
                        b += p.sharpen * (sourceB - meanB);
                    }

                    int a = Color.alpha(c);
                    output[ry * width + x] = Color.argb(a,
                            to8(r), to8(g), to8(b));
                }
            }
            dst.setPixels(output, 0, width, 0, y0, width, rows);
        }
    }

    private static String buildReport(PhotoAnalysis before, PhotoAnalysis after, Params p, Mode mode,
                                      boolean hGuard, boolean sGuard, boolean satGuard, boolean detailGuard) {
        StringBuilder sb = new StringBuilder();
        sb.append("SCENE\n").append(before.sceneSummary()).append("\n").append(before.compactMetrics()).append("\n");
        sb.append(String.format(Locale.US, "Neutral-reference cast confidence: %.2f\n", p.castConfidence));
        if (p.healthyPreserve) sb.append("Healthy-image preservation: ACTIVE\n");
        sb.append("\nREPAIRED / MASTERED\n");
        boolean any = false;
        if (p.exposureActive) {
            sb.append(String.format(Locale.US, "• Exposure %+.2f EV\n", p.exposureEv)); any = true;
        }
        if (p.wbActive) {
            sb.append(String.format(Locale.US, "• Neutral-reference colour correction R %.3f / G %.3f / B %.3f (cap ±%.1f%%)\n",
                    p.wbR, p.wbG, p.wbB, p.wbCap * 100.0)); any = true;
        } else if (p.wbRejectedLowConfidence) {
            sb.append("• Colour cast correction rejected — insufficient neutral evidence\n");
        }
        if (p.shadowLift > 0.04) { sb.append("• Shadow recovery\n"); any = true; }
        if (p.highlightProtect > 0.04) { sb.append("• Highlight protection / roll-off\n"); any = true; }
        if (p.denoiseActive) { sb.append(String.format(Locale.US, "• Edge-protected noise reduction %.0f%%\n", p.denoise * 100)); any = true; }
        if (p.sharpenActive) { sb.append(String.format(Locale.US, "• Conservative detail finishing %.0f%%\n", p.sharpen * 100)); any = true; }
        if (p.colourActive) { sb.append("• Selective colour density / vibrance control\n"); any = true; }
        if (!any) sb.append("• No major technical repair required; finish only\n");
        sb.append("• Finish profile: ").append(modeName(mode)).append("\n");

        sb.append("\nCHANGE GUARD\n");
        if (hGuard || sGuard || satGuard || detailGuard) {
            if (hGuard) sb.append("• Highlight guard rejected unsafe brightening\n");
            if (sGuard) sb.append("• Tone change rejected — extra shadow clipping without useful DR gain\n");
            if (satGuard) sb.append("• Colour-density change rejected — shift exceeded safety envelope\n");
            if (detailGuard) sb.append("• NR/detail change rejected — source was already clean\n");
        } else {
            sb.append("• Output passed improvement and safety checks\n");
        }

        sb.append("\nOUTPUT QC\n").append(after.compactMetrics());
        sb.append("\n• Full-resolution render at working bitmap size\n");
        sb.append("• JPEG export quality: 100\n");
        return sb.toString();
    }

    private static String modeName(Mode mode) {
        switch (mode) {
            case PRO: return "PRO";
            case NAT_GEO: return "NAT GEO";
            case LIFE: return "LIFE";
            default: return "TRUE";
        }
    }

    private static double lum(double r, double g, double b) {
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    private static double mix(double a, double b, double t) { return a + (b - a) * t; }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double log2(double v) { return Math.log(v) / Math.log(2.0); }
    private static int to8(double v) { return (int) Math.round(clamp(v, 0.0, 1.0) * 255.0); }
}
