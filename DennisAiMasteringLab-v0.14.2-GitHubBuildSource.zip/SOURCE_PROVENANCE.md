# v0.14.2 source continuity

Based directly on the sanitized v0.14.1 Candidate Pipeline source used for the successful GitHub Actions test build. Package remains `com.dennis.aimasteringlab`; version is code 21/name 0.14.2. No Internet permission is added. v0.14.2 changes selection evidence and reporting only: it adds a level-matched final PCM delta gate, raises the standalone transient benefit threshold and preserves the transparent candidate through final comparison. Studio remains a two-WAV delivery path.

The public build archive contains no signing keystore or private key.

---

# v0.14.1 source continuity

Based on the exact saved `DennisAiMasteringLab-Source-v0.13.1.zip` recovered from the project Library, SHA-256 `5fbc42cf5d080fcf3fcb2462ca01a2312cc23587b8ebe7e647560fca77291309`. Preserves the v0.13.1 import/path recovery work, package `com.dennis.aimasteringlab`, private update key and offline permission model. v0.14.0 was raised to code 19/name 0.14.0; this repair branch is code 20/name 0.14.1.

Sonic Finish modifies the mastering policy rather than replacing the project architecture: release-loudness compliance no longer activates the prior-master guard; positive prior-Dennis source history does; a bounded stronger core candidate was added; conditional mastering compression no longer depends on the input limiter flag; processing-cost/minimal-change bias was reduced; specialist promotion uses measured benefit; and the final gentler challenger cannot trade away measurable quality simply to process less.

The Android SDK used by prior builds is intentionally not part of the source archive and is unavailable in the current execution container. Therefore this checkpoint records source/policy validation only until Android platform 34/build-tools 34.0.0 are supplied and the signed APK/regression gate are rerun.

---

# v0.13.1 source continuity

Based on the exact delivered DennisAiMasteringLab-Source-v0.13.0.zip, SHA256 52a87ddfbf2ef55953748ce0ba1c4b2d37d98e5e710f34ba6f13cf7875c39b42. Added StudioImports and corrected StudioProject path normalization; integrated with StudioActivity, StudioQueue and StudioPipeline. Version/product labels updated to 0.13.1, code 18. Retained package and signing key; no DSP policy or vendor codec changes.

---

# v0.13.0 source continuity

Completed all seven studio additions. See README.md, RECOVERY_v0130.md and docs/validation-v0130 for implementation, test results and current limits. The full host gate and independent real-song format verification passed. Final APK uses the retained update certificate.

---

# v0.12.0 source provenance

Recovered from the saved v0.12 checkpoint, Library revision 1, 980523 bytes, after automated workspace pruning. That checkpoint was reconstructed from authoritative DennisAiMasteringLab-Source-v0.11.0.zip (SHA256 8d809d1983a470c5031ce9a2a906d846190ed270d79ff6178fdb7ed3c68e2987). Historical v0.11 records remain under docs/history and docs/validation-v0110.

New components: MusicalEventGuard, TrackingDynamicEq, SincResampler, OversampledLimiter, PcmExportWriter, OfflineMp3 and ReleaseFormats. Existing engine preservation/benefit gates remain; the new oversampled profile participates in the same guarded competition. The activity, package builder and report writer expose verified exports and incomplete-export status.

Bundled codec: unmodified Jump3r 1.0.5 mp3/ and mpg/ packages from Maven Central source archive, SHA256 bbd353fcb01d6192b7faf00939cbb4f65e31c6911de4972007af0dd9775614e9. Desktop wrappers and Main are excluded. LGPL 2.1-or-later text is included in app/src/main/assets. The wrapper handles the upstream ID3 offset bug without editing vendor sources.

Rebuild tools: Java 17, Android platform 34 extension 12 (Google archive SHA1 ba80ccbcc29b29f25ac926a08c0b2777f0bce842), build-tools 34.0.0 (Google archive SHA1 d6d58e0c6925a9e4d9a541e84cd1f405c2f9d2a9).

Package com.dennis.aimasteringlab, versionCode 16, versionName 0.12.0. Retained signing certificate SHA256 2d6822f2d6e3785a03bfe61d73d5139822c78c9b2dedbbc64aa0424ad44eff70. Private update key is included only for the owner's future compatible builds. No Internet permission.

The source backup excludes music, SDKs and generated build trees. Current validation records are under docs/validation-v0120. Host tests do not exercise actual Android codec, UI/audio playback or screen-off behavior.

Recovered checkpoint ZIP SHA256: 640c3a1bea1e49407fad11b2585d4064518d9c9ddc1dfef1ba1bc85a58399941.
