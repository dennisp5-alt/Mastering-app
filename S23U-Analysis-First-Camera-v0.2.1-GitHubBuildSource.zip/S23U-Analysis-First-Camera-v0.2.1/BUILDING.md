# Building Analysis First Camera 0.2.1

Requirements: JDK 17, Android SDK 34 or newer, and Internet access for initial
Gradle dependency resolution. Build with `./gradlew :app:assembleRelease`.

Package: `com.dennis.analysisfirstcamera`
Version: 0.2.1 (versionCode 4)
CameraX: 1.4.2
