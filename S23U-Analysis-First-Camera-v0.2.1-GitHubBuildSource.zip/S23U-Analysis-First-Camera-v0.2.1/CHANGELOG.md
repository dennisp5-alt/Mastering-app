# Changelog

## 0.2.1 — Stability Guard
- Froze the successful 0.2.0 True Colour Intelligence tuning.
- Added local gyroscope/accelerometer handheld-motion tracking.
- Added focal-length-aware stability policy: immediate 1x, light 3x guard, strong 10x guard.
- Added live `READY / HOLD / SHAKE` status and stability percentage.
- Added bounded wait for a steadier capture moment (up to 900 ms at 10x).
- Added OIS capability discovery for logical/physical lenses and explicit OIS request when supported.
- Added conservative 10x exposure-compensation preference for slow bright exposures with ISO headroom.
- Added 3-frame 10x burst on the normal Analysis First route and automatic sharpest-frame selection.
- Added stability/OIS/burst diagnostics to saved-photo metadata/reporting.
- Standard remains untouched; HDR/Night extension routes remain single-frame.
- versionCode 4 / versionName 0.2.1.

## 0.2.0 — True Colour Intelligence
- Added pre-capture neutral-reference colour analysis from YUV preview frames.
- Added mixed-light detection and preserve-mixed-light guard.
- Added sky, foliage and skin-like semantic colour evidence.
- Added separate evidence confidence, cast strength and cast confidence.
- Added bounded neutral WB correction only when stable evidence supports it.
- Retained the 0.1.1 sky/water-only blue restraint and genuine-blue protection.
- Added skin/saturated-object protection during bounded colour correction.
- Added zero-bias per-lens calibration hooks for later matched 0.6x/1x/3x/10x tuning.
- True Colour defaults ON in Analysis First; Standard remains unchanged.
- versionCode 3 / versionName 0.2.0.
