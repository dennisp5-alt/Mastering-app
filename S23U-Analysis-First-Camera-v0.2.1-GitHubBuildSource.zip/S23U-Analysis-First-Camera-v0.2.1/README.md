# Analysis First Camera 0.2.1 — True Colour + Stability Guard

Offline Samsung Galaxy S23 Ultra camera experiment. Standard remains an untouched
comparison path. Analysis First measures exposure, colour evidence and handheld
motion before the shutter fires, then applies only confidence-supported finishing.

## New in 0.2.1 — Stability Guard

- Keeps the proven 0.2.0 True Colour Intelligence settings unchanged.
- Uses the phone gyroscope plus accelerometer to estimate short-term handheld motion.
- 1x stays immediate; 3x gets a light stability wait; 10x gets the strongest guard.
- Live long-tele status reports `READY`, `HOLD` or `SHAKE` plus a stability percentage.
- On 10x, waits up to 900 ms for a cleaner handheld moment, but never blocks forever.
- Explicitly requests optical image stabilisation when the active public camera path
  reports OIS support. Firmware default is retained when OIS control is unavailable.
- At 10x, slow bright exposures receive a small negative-EV preference to encourage
  the Samsung AE system toward a safer handheld exposure while preserving dark scenes.
- 10x Standard-route capture takes a three-frame JPEG burst and keeps the sharpest
  full-resolution frame using a local luminance-Laplacian detail score.
- Forced flash and Samsung HDR/Night extension routes stay single-frame for safety.
- No neural sharpening, fake detail generation or upscaling is used by Stability Guard.

## True Colour baseline retained from 0.2.0

- Live YUV colour analysis: neutral evidence, cast strength, mixed-light score,
  sky, foliage and skin-like coverage.
- Separate outcomes for no cast, insufficient evidence, mixed light preserved,
  suspected cast withheld and real cast correction.
- Whole-frame scene colour is never accepted as proof of white-balance error.
- Semantic sky/water blue restraint protects genuine blue objects such as tarps,
  cartons, clothing, cars and signs.
- Skin protection limits colour correction over skin-like regions.
- Per-lens colour calibration hooks remain zero-bias until matched testing justifies them.
- Standard mode never enters the Analysis First colour/stability finishing path.

This does not reproduce OPPO's dedicated multispectral hardware sensor or Samsung's
private computational camera pipeline. It uses exposed S23 Ultra camera/sensor data
and conservative local decision logic.
