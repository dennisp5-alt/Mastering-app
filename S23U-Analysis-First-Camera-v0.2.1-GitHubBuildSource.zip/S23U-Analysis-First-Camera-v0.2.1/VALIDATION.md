# Validation notes — 0.2.1

This source keeps the working S23U Pro Camera / Analysis First capture baseline and
the 0.2.0 True Colour engine. Stability Guard adds only focal-length-aware motion
measurement, bounded capture timing, exposed OIS requests, conservative long-tele
exposure preference and sharpest-frame selection.

Host policy checks cover 1x/3x/10x routing, optical/full-size guards, 10x burst
policy, high-ISO safety, Smart routing and the existing True Colour confidence gates.
Physical Galaxy S23 Ultra testing is still authoritative for Samsung OIS exposure,
actual 10x lens activation, burst timing and image-quality benefit.
