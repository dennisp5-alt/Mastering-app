# Recovery baseline

Analysis First Camera 0.2.0 True Colour is the permanent colour baseline for this
experiment. If 0.2.1 introduces a capture regression, compare against 0.2.0 and
Standard control first. Do not retune True Colour to compensate for a stability bug.

The inherited optical guard, lens routing, orientation handling and maximum-quality
CameraX JPEG path remain protected. Stability Guard must safely bypass itself when
motion sensors or OIS controls are unavailable.
