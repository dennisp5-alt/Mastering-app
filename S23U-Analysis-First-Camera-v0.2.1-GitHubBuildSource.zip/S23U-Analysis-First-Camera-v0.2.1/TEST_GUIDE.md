# Analysis First Camera 0.2.1 — Stability Guard test

The colour pipeline is intentionally unchanged from 0.2.0. The priority for this
build is handheld 3x/10x sharpness and capture reliability.

## 10x priority test

Use a detailed stationary subject outdoors and take matched shots from the same
position:

1. Standard 10x.
2. Analysis First 10x with Optical Lock ON.
3. Repeat Analysis First 10x three to five times with deliberately normal handheld movement.

Watch the live line. At 10x it should show OIS state plus `READY`, `HOLD` or `SHAKE`
and a stability percentage. Press ANALYSE + SNAP while moving slightly and confirm
that the app waits briefly for a cleaner moment rather than firing immediately.

Normal Analysis First 10x should then capture three temporary Q100 frames, select
the sharpest full-resolution JPEG, discard the other temporary files, apply the
same True Colour rules as 0.2.0, and save one final image.

## What counts as a pass

- 1x capture speed remains essentially unchanged.
- 3x has only a short stability delay when needed.
- 10x shows a useful stability readout and never hangs indefinitely.
- OIS says requested when the active public camera reports support; otherwise it
  safely reports firmware default/unknown and continues.
- The final 10x file remains full-size and from the expected optical lens when
  Optical Lock is enabled.
- Fine leaf/fence/text detail improves more often than not versus a single shaky frame.
- No extra sharpening halos, fake texture, colour shift or True Colour regression.
- Only one final photo appears in the gallery for the 10x burst.

## Important edge cases

- Forced flash disables the burst.
- Samsung HDR/Night extension routes remain single-frame.
- If gyro data is unavailable/stale, the app bypasses the wait and still captures.
- Very dark/high-ISO 10x scenes do not receive extra negative EV just to chase shutter speed.

Also recheck the existing True Colour scenes (skin, sky+tarp, blue carton, mixed
indoor/outdoor light) to confirm colour remains equivalent to 0.2.0.
