# v0.5.1 test guide

The primary test is shutter responsiveness without giving back v0.5.0 image quality.

1. 1x daylight: should feel essentially immediate and show FAST.
2. 3x daylight handheld: normally FUSION 2; compare sharpness and capture time with v0.5.0.
3. 3x while deliberately moving slightly after the first frame: the app should shorten the burst rather than forcing all donors.
4. 10x handheld: normally FUSION 2. Hold as you naturally would, not as if using a tripod.
5. 10x very steady / lower light: the app may choose 3 or 4 frames only when stability evidence supports it.
6. Bright sky + dark foreground: confirm highlight protection and Natural Tone remain unchanged.
7. Portrait/skin and close fabric: confirm colour, skin texture and Detail IQ remain at the v0.5.0 baseline.

A pass means normal handheld capture is materially quicker while colour, tone, detail and optical behavior remain unchanged.
