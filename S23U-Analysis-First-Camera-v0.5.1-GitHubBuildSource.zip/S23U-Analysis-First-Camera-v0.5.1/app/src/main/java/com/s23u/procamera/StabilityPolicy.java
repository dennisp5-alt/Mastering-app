package com.s23u.procamera;

/** Pure decision policy for focal-length-aware handheld stability protection. */
final class StabilityPolicy {
    private StabilityPolicy() { }

    static boolean needsMotionGuard(float zoom) {
        return zoom >= 2.8f;
    }

    static boolean longTele(float zoom) {
        return zoom >= 8.0f;
    }

    static int burstFrames(float zoom, boolean flashForced) {
        return longTele(zoom) && !flashForced ? 2 : 1;
    }

    static long maxWaitMs(float zoom) {
        // v0.5.1: shutter responsiveness is preferred over waiting for an ideal
        // moment that may never arrive in a normal handheld shot.
        if (longTele(zoom)) return 280L;
        if (zoom >= 2.8f) return 130L;
        return 0L;
    }

    static double readyThreshold(float zoom) {
        return longTele(zoom) ? 0.30 : 0.44;
    }

    static long requiredStableMs(float zoom) {
        return longTele(zoom) ? 105L : 65L;
    }

    static int immediateCapturePercent(float zoom) {
        return longTele(zoom) ? 72 : 64;
    }

    static boolean acceptableToCaptureNow(float zoom, int stablePercent, boolean available) {
        return !available || stablePercent >= immediateCapturePercent(zoom);
    }

    static float shutterGuardEv(float zoom, long exposureNs, int iso, float currentEv) {
        if (!longTele(zoom) || exposureNs <= 0L || iso <= 0) return currentEv;
        // Only trade a little brightness for shutter speed while the sensor still has
        // useful ISO headroom. In genuinely dark scenes we preserve the existing plan.
        if (exposureNs >= 10_000_000L && iso < 1200) { // slower than roughly 1/100 s
            return Math.min(currentEv, -0.7f);
        }
        if (exposureNs >= 5_000_000L && iso < 800) { // slower than roughly 1/200 s
            return Math.min(currentEv, -0.3f);
        }
        return currentEv;
    }

    static double motionScore(double gyroRadPerSec, double accelMotionMs2) {
        double gyro = clamp01(gyroRadPerSec / 0.18);
        double accel = clamp01(accelMotionMs2 / 0.90);
        return clamp01(gyro * 0.78 + accel * 0.22);
    }

    static String level(double score, float zoom, boolean available, long stableForMs) {
        if (!available) return "UNAVAILABLE";
        if (score <= readyThreshold(zoom) && stableForMs >= requiredStableMs(zoom)) {
            return "READY";
        }
        if (score <= Math.min(0.72, readyThreshold(zoom) + 0.25)) return "HOLD";
        return "SHAKE";
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
