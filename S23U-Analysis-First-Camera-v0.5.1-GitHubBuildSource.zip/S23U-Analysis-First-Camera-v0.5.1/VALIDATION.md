# v0.5.1 validation

v0.5.1 is a capture-latency correction, not a rendering retune. Do not change True Colour, Natural Tone, Lens/ISO Detail IQ or the optical-correction policy to hide capture problems.

Required behavior:
- clean 0.6x/1x daylight remains single-frame;
- normal 3x and 10x handheld capture defaults to two frames;
- third/fourth donors require strong stability evidence;
- rising motion aborts extra donors after a usable frame exists;
- sharpest-frame fallback remains mandatory;
- forced flash and Samsung OEM extension routes remain single/OEM-controlled;
- Q100 and full-size target checks remain unchanged.
