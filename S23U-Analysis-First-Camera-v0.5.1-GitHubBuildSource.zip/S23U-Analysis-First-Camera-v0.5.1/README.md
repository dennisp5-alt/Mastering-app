# Analysis First Camera 0.5.1

Offline Galaxy S23 Ultra camera experiment focused on analysis-first capture. v0.5.1 keeps the v0.5.0 Computational Capture image pipeline and the proven True Colour, Natural Tone and Lens/ISO Detail IQ rendering, but makes handheld capture substantially more responsive.

## v0.5.1 Fast Computational Capture

- 0.6x/1x clean daylight uses the single-frame FAST path.
- 3x normally uses two frames; a third donor is allowed only for difficult/low light when stability is already excellent.
- 10x normally uses two frames; 3-4 donors are reserved for very stable difficult/low-light scenes.
- Motion is re-checked after every captured frame. If stability drops, extra donors are aborted and the sharpest valid frame is kept.
- Stability Guard no longer waits as long for an ideal hold: up to about 130 ms at 3x and 280 ms at 10x, with immediate capture when the current hold is already acceptable.
- Inter-frame scheduling delay is reduced to 5 ms; CameraX remains in MAXIMIZE_QUALITY/Q100 mode.
- Small FAST / FUSION N / FAST FALLBACK status messages replace long hold instructions during capture.
- True Colour, Natural Tone, Detail IQ and optical-correction behavior are not retuned.

The Standard control path remains unchanged.
