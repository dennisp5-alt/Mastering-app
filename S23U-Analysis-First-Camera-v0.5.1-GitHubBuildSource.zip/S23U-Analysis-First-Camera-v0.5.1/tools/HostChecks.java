package com.s23u.procamera;

public final class HostChecks {
    public static void main(String[] args) {
        require(DeviceGate.isGalaxyS23Ultra("samsung", "SM-S918B"), "S918B accepted");
        require(DeviceGate.isGalaxyS23Ultra("Samsung", "SM-S918U1"), "S918U1 accepted");
        require(!DeviceGate.isGalaxyS23Ultra("samsung", "SM-A546E"), "A54 rejected");
        require(!DeviceGate.isGalaxyS23Ultra("google", "Pixel 8 Pro"), "Pixel rejected");

        require("ULTRA_WIDE".equals(LensClassifier.fromFocalLength(2.2)), "UW lens");
        require("MAIN_1X".equals(LensClassifier.fromFocalLength(6.3)), "main lens");
        require("TELE_3X".equals(LensClassifier.fromFocalLength(7.9)), "3x lens");
        require("TELE_10X".equals(LensClassifier.fromFocalLength(27.2)), "10x lens");
        require("UNKNOWN".equals(LensClassifier.fromFocalLength(Double.NaN)), "unknown lens");

        require("ULTRA_WIDE".equals(LensClassifier.expectedForZoom(0.6f)), "0.6x request");
        require("MAIN_1X".equals(LensClassifier.expectedForZoom(1.0f)), "1x request");
        require("TELE_3X".equals(LensClassifier.expectedForZoom(3.0f)), "3x request");
        require("TELE_10X".equals(LensClassifier.expectedForZoom(10.0f)), "10x request");

        require(!ZoomRouting.shouldGuardOpticalLens(
                true, true, 1.0f, "main"), "Smart 1x needs no optical guard");
        require(ZoomRouting.shouldGuardOpticalLens(
                true, true, 3.0f, "tele3"), "Smart 3x can guard the physical tele lens");
        require(close(ZoomRouting.cameraZoomRatio(3.0f), 3.0f),
                "locked 3x retains the full-size logical 3.0 ratio");
        require(OutputResolution.isFullSize(4080, 3060), "landscape full-size output");
        require(OutputResolution.isFullSize(3060, 4080), "portrait full-size output");
        require(!OutputResolution.isFullSize(1920, 1440), "reduced output detected");
        require(OpticalVerification.matches(
                "TELE_10X", "tele10", "tele10", "TELE_3X"),
                "active physical ID verifies 10x despite ambiguous focal metadata");
        require(OpticalVerification.matches(
                "TELE_10X", "tele10", null, "TELE_10X"),
                "10x focal metadata remains a safe fallback");
        require(!OpticalVerification.matches(
                "TELE_10X", "tele10", "tele3", "TELE_3X"),
                "wrong physical and focal lens remain blocked");
        require(PortraitGeometry.hasCloseWideAngleRisk(1.0f, 650, 4000),
                "close 1x face triggers perspective guidance");
        require(!PortraitGeometry.hasCloseWideAngleRisk(1.0f, 400, 4000),
                "normal-distance 1x face remains unrestricted");
        require(!PortraitGeometry.hasCloseWideAngleRisk(3.0f, 900, 4000),
                "3x portrait does not trigger wide-angle guidance");

        require(!StabilityPolicy.needsMotionGuard(1.0f), "1x stays immediate");
        require(StabilityPolicy.needsMotionGuard(3.0f), "3x gets light stability guard");
        require(StabilityPolicy.longTele(10.0f), "10x gets long-tele guard");
        require(StabilityPolicy.burstFrames(10.0f, false) == 2,
                "10x defaults to two-frame latency-aware support");
        require(StabilityPolicy.burstFrames(10.0f, true) == 1,
                "forced flash disables 10x burst");
        require(StabilityPolicy.shutterGuardEv(10.0f, 12_000_000L, 400, 0.0f) <= -0.69f,
                "slow bright 10x exposure gets faster-shutter bias");
        require(StabilityPolicy.shutterGuardEv(10.0f, 12_000_000L, 1800, 0.0f) == 0.0f,
                "high-ISO 10x scene is not darkened further");

        SceneStats ordinary = new SceneStats(true, 108.0, 28, 105, 205,
                0.04, 0.004, 1L);
        SceneStats extreme = new SceneStats(true, 112.0, 8, 101, 244,
                0.16, 0.035, 1L);
        SmartAutoEngine.Decision standard = SmartAutoEngine.decide(ordinary,
                50, 5_000_000L, false, true, true, 1.0f, false);
        require(standard.route == SmartAutoEngine.Route.STANDARD,
                "ordinary daylight remains natural Standard");
        SmartAutoEngine.Decision hdr = SmartAutoEngine.decide(extreme,
                50, 5_000_000L, true, true, true, 1.0f, false);
        require(hdr.route == SmartAutoEngine.Route.HDR, "difficult backlight routes HDR");
        SmartAutoEngine.Decision night = SmartAutoEngine.decide(ordinary,
                1200, 55_000_000L, false, true, true, 1.0f, false);
        require(night.route == SmartAutoEngine.Route.NIGHT, "low light routes Night");
        SmartAutoEngine.Decision lensPriority = SmartAutoEngine.decide(extreme,
                1200, 55_000_000L, true, true, true, 3.0f, false);
        require(lensPriority.route == SmartAutoEngine.Route.STANDARD,
                "non-1x Smart Auto preserves optical lens priority");


        DifficultLightPolicy.Plan difficult1x = DifficultLightPolicy.plan(
                extreme, false, 80, 5_000_000L, 1.0f);
        require(difficult1x.ev <= -0.29f,
                "difficult highlights receive capture-time protection");
        DifficultLightPolicy.Plan difficult3x = DifficultLightPolicy.plan(
                extreme, false, 160, 6_000_000L, 3.0f);
        require(difficult3x.ev <= -0.29f
                        && difficult3x.protection.contains("tele"),
                "tele difficult light protects highlights before fusion");

        ComputationalCapturePolicy.Plan clean1x = ComputationalCapturePolicy.plan(
                ordinary, 50, 5_000_000L, 1.0f, false, false);
        require(!clean1x.usesBurst() && clean1x.frames == 1,
                "clean 1x daylight remains immediate");
        ComputationalCapturePolicy.Plan comp3x = ComputationalCapturePolicy.plan(
                ordinary, 100, 5_000_000L, 3.0f, false, false);
        require(comp3x.usesBurst() && comp3x.frames == 2,
                "3x defaults to two-frame computational support");
        ComputationalCapturePolicy.Plan comp10x = ComputationalCapturePolicy.plan(
                ordinary, 250, 8_000_000L, 10.0f, false, false);
        require(comp10x.usesBurst() && comp10x.frames == 2,
                "10x defaults to two-frame handheld computational support");
        ComputationalCapturePolicy.Plan difficultComp = ComputationalCapturePolicy.plan(
                extreme, 80, 5_000_000L, 1.0f, false, false);
        require(difficultComp.usesBurst() && difficultComp.frames == 2,
                "difficult 1x light receives two-frame computational shadow support");
        require(!ComputationalCapturePolicy.plan(ordinary, 400, 15_000_000L, 3.0f,
                        true, false).usesBurst(),
                "forced flash disables computational burst");
        ComputationalCapturePolicy.Plan stable3x = ComputationalCapturePolicy.plan(
                extreme, 500, 18_000_000L, 3.0f, false, false, 94, true);
        require(stable3x.usesBurst() && stable3x.frames == 3,
                "very stable difficult 3x may earn a third donor frame");
        ComputationalCapturePolicy.Plan shaky10x = ComputationalCapturePolicy.plan(
                ordinary, 250, 8_000_000L, 10.0f, false, false, 48, true);
        require(!shaky10x.usesBurst(),
                "shaky 10x prioritises one sharp frame over a long burst");
        require(!ComputationalCapturePolicy.shouldContinueBurst(
                        3.0f, 1, 3, 42, true),
                "rising 3x motion aborts extra donors after first good frame");
        require(ComputationalCapturePolicy.shouldContinueBurst(
                        10.0f, 1, 2, 78, true),
                "steady handheld 10x may collect its second frame");
        require(OpticalCorrectionPolicy.expectedStrength("ULTRA_WIDE").contains("geometry"),
                "ultra-wide optical policy prioritises geometry");

        ColourStats balancedColour = new ColourStats(true, 0.08, 128.5, 127.5,
                2.0, 0.10, 0.28, 0.12, 0.00, 0.7, 0.92, 0.00, 0.90, 0L);
        TrueColourDecision balancedDecision = TrueColourDecision.decide(
                balancedColour, "MAIN_1X", false);
        require(balancedDecision.action == TrueColourDecision.Action.NO_CAST,
                "balanced neutral evidence reports no cast");

        ColourStats mixedColour = new ColourStats(true, 0.09, 136.0, 126.0,
                5.0, 0.72, 0.05, 0.02, 0.03, 8.2, 0.82, 0.64, 0.88, 0L);
        TrueColourDecision mixedDecision = TrueColourDecision.decide(
                mixedColour, "MAIN_1X", true);
        require(mixedDecision.action == TrueColourDecision.Action.PRESERVE_MIXED_LIGHT,
                "mixed light is preserved instead of globally neutralised");

        ColourStats realCast = new ColourStats(true, 0.10, 138.0, 128.0,
                2.5, 0.12, 0.04, 0.02, 0.00, 10.0, 0.90, 0.72, 0.90, 0L);
        TrueColourDecision castDecision = TrueColourDecision.decide(
                realCast, "MAIN_1X", false);
        require(castDecision.action == TrueColourDecision.Action.CORRECT
                        && castDecision.maxGainDelta > 0.0,
                "strong stable neutral cast permits bounded correction");


        LensColourProfile earlyProfile = LensColourProfile.calibrated("TELE_3X", 2.0, -1.0, 2);
        require(earlyProfile.calibrationConfidence > 0.0
                        && Math.abs(earlyProfile.uBias) < 1.0,
                "early lens calibration is confidence weighted");
        LensColourProfile matureProfile = LensColourProfile.calibrated("TELE_3X", 2.0, -1.0, 10);
        require(closeDouble(matureProfile.uBias, 2.0, 0.01),
                "mature lens calibration reaches measured bias");

        require(LensCalibrationStore.qualifiesForLearning(
                        balancedColour, balancedDecision),
                "stable no-cast neutral scene qualifies for conservative lens learning");
        require(!LensCalibrationStore.qualifiesForLearning(
                        mixedColour, mixedDecision),
                "mixed lighting never trains lens calibration");

        ColourStats lensResidual = new ColourStats(true, 0.08, 130.0, 128.0,
                2.0, 0.10, 0.02, 0.02, 0.0, 2.0, 0.90, 0.20, 0.90, 0L);
        TrueColourDecision calibratedResidual = TrueColourDecision.decide(
                lensResidual, matureProfile, false);
        require(calibratedResidual.action == TrueColourDecision.Action.NO_CAST
                        && calibratedResidual.lensCalibrationActive(),
                "known lens residual is separated from scene cast and retained for pixel calibration");

        NaturalTonality.Plan tone = NaturalTonality.plan(18, 118, 244, 0.18, 0.04);
        require(tone.active && tone.shoulder > 0.0 && tone.shadowSeparation > 0.0,
                "high-DR scene enables restrained Natural Tone");
        require(NaturalTonality.mapLuma(0, tone) == 0
                        && NaturalTonality.mapLuma(255, tone) == 255,
                "Natural Tone preserves black and white endpoints");
        require(NaturalTonality.mapLuma(220, tone) < 220,
                "Natural Tone rolls near-highlights without clipping white");
        require(NaturalTonality.mapLuma(35, tone) > 35,
                "Natural Tone separates deep shadows without lifting black");


        DetailNoiseProfile.Plan mainClean = DetailNoiseProfile.plan("MAIN_1X", 80);
        DetailNoiseProfile.Plan mainHigh = DetailNoiseProfile.plan("MAIN_1X", 1250);
        DetailNoiseProfile.Plan tele3 = DetailNoiseProfile.plan("TELE_3X", 320);
        DetailNoiseProfile.Plan tele10High = DetailNoiseProfile.plan("TELE_10X", 1600);
        require(mainClean.detailStrength > mainClean.denoiseStrength,
                "clean 1x prioritises genuine detail over noise reduction");
        require(mainHigh.denoiseStrength > mainHigh.detailStrength,
                "high-ISO 1x becomes noise-first");
        require(tele3.detailStrength > 0.0 && tele3.denoiseStrength > 0.0,
                "3x normal-light profile applies restrained detail and NR");
        require(tele10High.denoiseStrength >= 0.19 && tele10High.detailCap <= 1,
                "high-ISO 10x strongly suppresses noise and caps sharpening");
        require(DetailNoiseProfile.plan("TELE_10X", 80).detailStrength
                        > tele10High.detailStrength,
                "10x sharpening falls as ISO rises");

        float[] portrait = CoordinateMapper.rotateSensorPoint(0.25f, 0.40f, 90, 0);
        require(close(portrait[0], 0.60f) && close(portrait[1], 0.25f),
                "portrait face-meter coordinate rotation");

        System.out.println("Host checks passed: lens/stability guards, fast computational capture policy, difficult-light exposure, optical policy, True Colour, Natural Tone, Detail IQ and Smart routing");
    }

    private static void require(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    private static boolean close(float first, float second) {
        return Math.abs(first - second) < 0.0001f;
    }

    private static boolean closeDouble(double first, double second, double tolerance) {
        return Math.abs(first - second) <= tolerance;
    }
}
