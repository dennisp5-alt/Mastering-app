# Analysis First Camera 0.1.0 — first bulk test

For each scene, hold position and framing constant and capture:

1. Standard control.
2. Analysis First.

Watch the live `Capture plan` line before pressing the shutter, then note the plan
shown while the app analyses and snaps.

## Priority scenes

1. Normal daylight landscape — should usually stay Standard / EV 0.0.
2. Bright sky + darker ground — expect highlight guard or HDR at 1x.
3. Backlit person — expect face AE priority or HDR at 1x.
4. Moving person/animal — check shutter delay remains acceptable; do not expect
   a forced HDR stack on non-1x lenses.
5. Indoor dim room — Night may be selected at 1x when Samsung exposes it.
6. Moon / bright isolated object in dark sky — expect dark-field highlight
   protection rather than broad shadow lifting when the preview evidence matches.
7. 3x and 10x detailed distant subject with Optical Lock ON — verify correct lens,
   full-size output and no unexpected route change.

Send matched pairs plus screenshots of the live capture plan when a decision looks
wrong. The first calibration target is decision quality, not heavy post-processing.
