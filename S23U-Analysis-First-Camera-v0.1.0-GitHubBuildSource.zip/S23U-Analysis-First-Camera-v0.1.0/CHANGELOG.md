# Changelog

## 0.1.0 — Analysis First Camera

- Forked from the proven S23U Pro Camera Test v1.0.5 capture baseline.
- New standalone package `com.dennis.analysisfirstcamera`.
- Added pre-capture Analysis First planner.
- Added short-term preview/metering stability score.
- Added AE-state tracking alongside AF/ISO/shutter/lens metadata.
- Added bounded pre-capture exposure compensation for highlight protection,
  dark-field bright-subject protection and limited clean shadow lift.
- Retained conservative 1x HDR/Night routing through Samsung Camera Extensions.
- Added brief settle-before-snap loop (maximum ~640 ms) when preview/AF/AE is moving.
- Added live capture-plan display and EXIF plan diagnostics.
- Retained the untouched Standard control path for A/B comparison.
