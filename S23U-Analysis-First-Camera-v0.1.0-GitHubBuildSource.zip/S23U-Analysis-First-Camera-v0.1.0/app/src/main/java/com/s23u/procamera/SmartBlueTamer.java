package com.s23u.procamera;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

final class SmartBlueTamer {
    static final class Result {
        final boolean applied;
        final double affectedPercent;
        final String detail;

        Result(boolean applied, double affectedPercent, String detail) {
            this.applied = applied;
            this.affectedPercent = affectedPercent;
            this.detail = detail;
        }

        static Result skipped(String detail) {
            return new Result(false, 0.0, detail);
        }
    }

    private static final String[] EXIF_TAGS = {
            ExifInterface.TAG_APERTURE_VALUE,
            ExifInterface.TAG_COLOR_SPACE,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_FLASH,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
            ExifInterface.TAG_IMAGE_DESCRIPTION,
            ExifInterface.TAG_IMAGE_UNIQUE_ID,
            ExifInterface.TAG_ISO_SPEED_RATINGS,
            ExifInterface.TAG_LIGHT_SOURCE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MAX_APERTURE_VALUE,
            ExifInterface.TAG_METERING_MODE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.TAG_SOFTWARE,
            ExifInterface.TAG_SUBSEC_TIME,
            ExifInterface.TAG_SUBSEC_TIME_DIGITIZED,
            ExifInterface.TAG_SUBSEC_TIME_ORIGINAL,
            ExifInterface.TAG_USER_COMMENT,
            ExifInterface.TAG_WHITE_BALANCE
    };

    private SmartBlueTamer() { }

    static Result apply(ContentResolver resolver, Uri uri, File cacheDir) throws IOException {
        ExifSnapshot exif = ExifSnapshot.read(resolver, uri);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inMutable = true;

        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) return Result.skipped("image unavailable");
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) return Result.skipped("decode failed");

        long pixels = (long) bitmap.getWidth() * bitmap.getHeight();
        if (pixels > 20_000_000L) {
            bitmap.recycle();
            return Result.skipped("above 20 MP safety limit");
        }

        double candidatePercent = measureBluePercent(bitmap);
        if (candidatePercent < 1.25) {
            bitmap.recycle();
            return Result.skipped("blue level already natural");
        }

        long affected = tamePixels(bitmap);
        File temporary = File.createTempFile("s23u-smart-blue-", ".jpg", cacheDir);
        try {
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)) {
                    throw new IOException("Q100 JPEG encode failed");
                }
            } finally {
                bitmap.recycle();
            }

            try (InputStream input = new FileInputStream(temporary);
                 OutputStream output = resolver.openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("output stream unavailable");
                byte[] buffer = new byte[128 * 1024];
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    output.write(buffer, 0, read);
                }
                output.flush();
            }
            exif.restore(resolver, uri);
        } finally {
            if (!temporary.delete()) temporary.deleteOnExit();
        }

        double affectedPercent = affected * 100.0 / Math.max(1L, pixels);
        return new Result(true, affectedPercent, "selective blue chroma -8% to -16%");
    }

    private static double measureBluePercent(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] row = new int[width];
        long total = 0L;
        long blue = 0L;
        int stepY = Math.max(8, height / 180);
        int stepX = Math.max(8, width / 240);
        for (int y = stepY / 2; y < height; y += stepY) {
            bitmap.getPixels(row, 0, width, 0, y, width, 1);
            for (int x = stepX / 2; x < width; x += stepX) {
                total++;
                if (isStrongBlue(row[x])) blue++;
            }
        }
        return blue * 100.0 / Math.max(1L, total);
    }

    private static long tamePixels(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int stripeHeight = 96;
        int[] pixels = new int[width * stripeHeight];
        long affected = 0L;
        for (int top = 0; top < height; top += stripeHeight) {
            int rows = Math.min(stripeHeight, height - top);
            int count = width * rows;
            bitmap.getPixels(pixels, 0, width, 0, top, width, rows);
            for (int i = 0; i < count; i++) {
                int colour = pixels[i];
                if (!isStrongBlue(colour)) continue;
                int a = (colour >>> 24) & 0xff;
                int r = (colour >>> 16) & 0xff;
                int g = (colour >>> 8) & 0xff;
                int b = colour & 0xff;
                int max = Math.max(r, Math.max(g, b));
                int min = Math.min(r, Math.min(g, b));
                int chroma = max - min;
                double strength = 0.08 + Math.min(0.08,
                        Math.max(0, chroma - 45) / 625.0);
                int luma = (54 * r + 183 * g + 19 * b) >> 8;
                r = clamp((int) Math.round(r + (luma - r) * strength));
                g = clamp((int) Math.round(g + (luma - g) * strength));
                b = clamp((int) Math.round(b + (luma - b) * strength));
                pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
                affected++;
            }
            bitmap.setPixels(pixels, 0, width, 0, top, width, rows);
        }
        return affected;
    }

    private static boolean isStrongBlue(int colour) {
        int r = (colour >>> 16) & 0xff;
        int g = (colour >>> 8) & 0xff;
        int b = colour & 0xff;
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        if (max - min < 45 || max < 72) return false;
        boolean blue = b >= r + 22 && b >= g + 4;
        boolean cyan = g >= r + 22 && b >= r + 22 && Math.abs(b - g) <= 62;
        return blue || cyan;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static final class ExifSnapshot {
        private final Map<String, String> values;

        private ExifSnapshot(Map<String, String> values) {
            this.values = values;
        }

        static ExifSnapshot read(ContentResolver resolver, Uri uri) throws IOException {
            Map<String, String> values = new LinkedHashMap<>();
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "r")) {
                if (descriptor == null) throw new IOException("EXIF input unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (String tag : EXIF_TAGS) {
                    String value = exif.getAttribute(tag);
                    if (value != null) values.put(tag, value);
                }
            }
            return new ExifSnapshot(values);
        }

        void restore(ContentResolver resolver, Uri uri) throws IOException {
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(uri, "rw")) {
                if (descriptor == null) throw new IOException("EXIF output unavailable");
                ExifInterface exif = new ExifInterface(descriptor.getFileDescriptor());
                for (Map.Entry<String, String> entry : values.entrySet()) {
                    exif.setAttribute(entry.getKey(), entry.getValue());
                }
                exif.saveAttributes();
            }
        }
    }
}
