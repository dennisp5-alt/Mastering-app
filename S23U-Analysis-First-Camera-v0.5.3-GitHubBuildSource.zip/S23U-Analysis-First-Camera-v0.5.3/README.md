# Analysis First Camera 0.5.3

Offline Galaxy S23 Ultra camera experiment. v0.5.3 is a deliberately isolated **platform-stack test** built from the proven v0.5.2 Quality-First Capture baseline. True Colour, Natural Tone, Lens/ISO Detail IQ, difficult-light policy, optical correction, computational-capture policy and the clean UI are intentionally unchanged.

## What changed

- CameraX 1.4.2 -> **1.6.2 stable**.
- compileSdk 34 -> **36** for the newer CameraX toolchain.
- Android Gradle Plugin 8.5.2 -> **8.9.1**.
- Gradle 8.7 -> **8.11.1**.
- Runtime minSdk remains 31 and targetSdk remains 34 for this controlled test.
- No switch to MINIMIZE_LATENCY or ZSL. ImageCapture remains the same quality-first mode used by v0.5.2.

CameraX 1.6.x moved to the unified high-performance CameraPipe stack. This build tests whether that newer platform improves capture/session efficiency on the S23 Ultra without changing our rendering decisions.

## Pass criteria

1. Same or better final image quality than v0.5.2.
2. No regressions in 0.6x/1x/3x/10x routing, physical-lens verification, extensions or Q100 output.
3. Equal or lower primary-capture latency in diagnostics.
4. No new colour, tone, skin, sharpening, denoise, HDR or fusion behaviour.

If quality changes, v0.5.2 remains the recovery baseline.
