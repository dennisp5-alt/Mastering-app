# v0.5.3 validation

v0.5.3 is a CameraX platform-stack test, not an image-quality retune.

Host checks must remain identical to v0.5.2. The release build must report versionCode 11 / versionName 0.5.3 and use CameraX 1.6.2 with compileSdk 36.

Do not accept a speed gain if the final Q100 image shows worse fine detail, skin texture, colour, highlight roll-off, shadow depth, optical-lens routing or computational-fusion reliability than v0.5.2.
