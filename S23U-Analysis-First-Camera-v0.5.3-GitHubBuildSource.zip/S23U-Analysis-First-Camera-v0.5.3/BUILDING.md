# Building Analysis First Camera 0.5.3

Java 17 is required.

- Version: 0.5.3 (versionCode 11)
- CameraX: 1.6.2 stable
- compileSdk: 36
- targetSdk: 34
- AGP: 8.9.1
- Gradle: 8.11.1

This build intentionally changes the CameraX/toolchain layer only. The v0.5.2 capture and rendering policy is frozen for A/B testing.
