# v0.5.3 CameraX platform test guide

Use v0.5.2 as the reference. Shoot matched scenes whenever possible.

1. 1x daylight: compare shutter-to-CAPTURED feel and Diagnostics primary-ms timing.
2. 3x daylight: verify physical 3x routing, focus reliability and equal fine detail.
3. 10x daylight: verify the same two-frame policy, stability behavior and final sharpness.
4. Bright sky + dark fence/foreground: compare highlight roll-off, sky colour and shadow depth.
5. Portrait/skin/fabric: verify no change in skin rendering or Detail IQ.
6. 0.6x: check geometry/corner behavior and lens correction.
7. OEM HDR/Night/Bokeh: confirm extension discovery still works.
8. Open Diagnostics and compare primary-ms and extras-ms with v0.5.2.

A pass means v0.5.3 is equal or better in image quality and compatibility, with lower or more consistent capture/session latency. If not, revert to v0.5.2 and do not compensate with stronger processing.
