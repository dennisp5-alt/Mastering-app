# Recovery baseline

The proven recovery baseline is **v0.5.2 Quality-First Capture Pipeline**.

If v0.5.3 shows any regression in image quality, physical-lens routing, extension support, capture reliability, or latency consistency, return to v0.5.2. Do not compensate by increasing sharpening, saturation, denoise, shadow lift or fusion strength.

v0.5.3 exists only to evaluate CameraX 1.6.2 / CameraPipe separately from the image pipeline.
