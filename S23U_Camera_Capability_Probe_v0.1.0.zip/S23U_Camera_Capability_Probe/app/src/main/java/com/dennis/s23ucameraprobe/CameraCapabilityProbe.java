package com.dennis.s23ucameraprobe;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraExtensionCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.params.DynamicRangeProfiles;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.util.Range;
import android.util.Rational;
import android.util.Size;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public final class CameraCapabilityProbe {
    private CameraCapabilityProbe() {}

    public static final class Result {
        public final String json;
        public final String text;
        Result(String json, String text) { this.json = json; this.text = text; }
    }

    public static Result run(Context context) throws Exception {
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        JSONObject root = new JSONObject();
        root.put("probeVersion", "0.1.0");
        root.put("generatedUtc", utcNow());
        root.put("device", deviceJson());

        JSONArray concurrent = new JSONArray();
        if (Build.VERSION.SDK_INT >= 30) {
            for (Set<String> group : manager.getConcurrentCameraIds()) {
                concurrent.put(new JSONArray(group));
            }
        }
        root.put("concurrentCameraIdSets", concurrent);

        JSONArray cameras = new JSONArray();
        Set<String> alreadyAdded = new HashSet<>();
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            cameras.put(cameraJson(manager, id, c, false));
            alreadyAdded.add(id);

            Set<String> physicalIds = c.getPhysicalCameraIds();
            for (String pid : physicalIds) {
                if (alreadyAdded.contains(pid)) continue;
                try {
                    CameraCharacteristics pc = manager.getCameraCharacteristics(pid);
                    JSONObject physical = cameraJson(manager, pid, pc, true);
                    physical.put("parentLogicalCameraId", id);
                    cameras.put(physical);
                    alreadyAdded.add(pid);
                } catch (Exception ignored) {
                    // Some OEMs disclose the physical ID but do not permit direct characteristic lookup.
                }
            }
        }
        root.put("cameras", cameras);

        String text = buildTextSummary(root);
        return new Result(root.toString(2), text);
    }

    private static JSONObject cameraJson(CameraManager manager, String id, CameraCharacteristics c, boolean physicalOnly) throws Exception {
        JSONObject j = new JSONObject();
        j.put("cameraId", id);
        j.put("physicalOnly", physicalOnly);
        j.put("lensFacing", lensFacing(c.get(CameraCharacteristics.LENS_FACING)));
        j.put("hardwareLevel", hardwareLevel(c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)));
        j.put("sensorOrientationDegrees", value(c.get(CameraCharacteristics.SENSOR_ORIENTATION)));
        j.put("physicalCameraIds", new JSONArray(c.getPhysicalCameraIds()));

        int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        j.put("capabilities", intNames(caps, CameraCapabilityProbe::capabilityName));
        j.put("logicalMultiCamera", contains(caps, CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA));
        j.put("rawSupported", contains(caps, CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW));
        j.put("ultraHighResolutionSensor", contains(caps, CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR));
        j.put("tenBitDynamicRange", contains(caps, CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DYNAMIC_RANGE_TEN_BIT));

        j.put("focalLengthsMm", floats(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)));
        j.put("apertures", floats(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)));
        j.put("minimumFocusDistanceDiopters", value(c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)));
        j.put("hyperfocalDistanceDiopters", value(c.get(CameraCharacteristics.LENS_INFO_HYPERFOCAL_DISTANCE)));
        j.put("oisModes", intNames(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION), CameraCapabilityProbe::oisName));

        j.put("sensorPhysicalSizeMm", String.valueOf(c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)));
        j.put("pixelArraySize", String.valueOf(c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)));
        j.put("activeArraySize", String.valueOf(c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)));
        if (Build.VERSION.SDK_INT >= 31) {
            j.put("pixelArraySizeMaximumResolution", String.valueOf(c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE_MAXIMUM_RESOLUTION)));
            j.put("activeArraySizeMaximumResolution", String.valueOf(c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE_MAXIMUM_RESOLUTION)));
        }
        j.put("colorFilterArrangement", cfaName(c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)));
        j.put("sensitivityIsoRange", range(c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)));
        j.put("exposureTimeRangeNs", range(c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)));
        j.put("maxFrameDurationNs", value(c.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION)));
        j.put("maxAnalogSensitivityIso", value(c.get(CameraCharacteristics.SENSOR_MAX_ANALOG_SENSITIVITY)));

        j.put("aeCompensationRange", range(c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)));
        j.put("aeCompensationStep", rational(c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)));
        j.put("aeFpsRanges", ranges(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)));
        j.put("afModes", intNames(c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES), CameraCapabilityProbe::afName));
        j.put("awbModes", intNames(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES), CameraCapabilityProbe::awbName));
        j.put("sceneModes", ints(c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)));
        j.put("videoStabilizationModes", ints(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)));
        j.put("maxAfRegions", value(c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF)));
        j.put("maxAeRegions", value(c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE)));
        j.put("maxAwbRegions", value(c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AWB)));
        if (Build.VERSION.SDK_INT >= 30) j.put("zoomRatioRange", range(c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)));

        j.put("flashAvailable", value(c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)));
        j.put("noiseReductionModes", ints(c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)));
        j.put("edgeModes", ints(c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)));
        j.put("hotPixelModes", ints(c.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES)));
        j.put("tonemapModes", ints(c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)));
        j.put("aberrationCorrectionModes", ints(c.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)));

        StreamConfigurationMap normal = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        j.put("defaultStreams", streamMapJson(normal));
        if (Build.VERSION.SDK_INT >= 31) {
            StreamConfigurationMap max = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION);
            j.put("maximumResolutionStreams", streamMapJson(max));
        }

        JSONArray requestKeys = new JSONArray();
        for (CaptureRequest.Key<?> k : c.getAvailableCaptureRequestKeys()) requestKeys.put(k.getName());
        j.put("availableCaptureRequestKeys", requestKeys);
        JSONArray resultKeys = new JSONArray();
        for (CaptureResult.Key<?> k : c.getAvailableCaptureResultKeys()) resultKeys.put(k.getName());
        j.put("availableCaptureResultKeys", resultKeys);
        JSONArray characteristicKeys = new JSONArray();
        for (CameraCharacteristics.Key<?> k : c.getKeys()) characteristicKeys.put(k.getName());
        j.put("availableCharacteristicKeys", characteristicKeys);

        if (Build.VERSION.SDK_INT >= 33) {
            try {
                DynamicRangeProfiles d = c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES);
                if (d != null) j.put("dynamicRangeProfiles", new JSONArray(d.getSupportedProfiles()));
            } catch (Throwable t) {
                j.put("dynamicRangeProfilesError", t.toString());
            }
        }

        if (!physicalOnly && Build.VERSION.SDK_INT >= 31) {
            j.put("oemExtensions", extensionJson(manager, id));
        }
        return j;
    }

    private static JSONArray extensionJson(CameraManager manager, String id) {
        JSONArray result = new JSONArray();
        try {
            CameraExtensionCharacteristics ec = manager.getCameraExtensionCharacteristics(id);
            for (Integer ext : ec.getSupportedExtensions()) {
                JSONObject x = new JSONObject();
                x.put("type", extensionName(ext));
                x.put("value", ext);
                List<Size> jpegSizes = ec.getExtensionSupportedSizes(ext, ImageFormat.JPEG);
                x.put("jpegCaptureSizes", sizes(jpegSizes));
                List<Size> yuvSizes = ec.getExtensionSupportedSizes(ext, ImageFormat.YUV_420_888);
                x.put("yuvCaptureSizes", sizes(yuvSizes));
                try { x.put("previewSizes", sizes(ec.getExtensionSupportedSizes(ext, SurfaceTexture.class))); }
                catch (Throwable ignored) {}
                if (!jpegSizes.isEmpty()) {
                    Size largest = Collections.max(jpegSizes, Comparator.comparingLong(CameraCapabilityProbe::pixels));
                    try {
                        Range<Long> latency = ec.getEstimatedCaptureLatencyRangeMillis(ext, largest, ImageFormat.JPEG);
                        x.put("largestJpegLatencyMs", range(latency));
                    } catch (Throwable ignored) {}
                }
                if (Build.VERSION.SDK_INT >= 34) {
                    try { x.put("postviewAvailable", ec.isPostviewAvailable(ext)); } catch (Throwable ignored) {}
                    try { x.put("captureProgressAvailable", ec.isCaptureProcessProgressAvailable(ext)); } catch (Throwable ignored) {}
                }
                JSONArray req = new JSONArray();
                try { for (CaptureRequest.Key<?> k : ec.getAvailableCaptureRequestKeys(ext)) req.put(k.getName()); } catch (Throwable ignored) {}
                x.put("captureRequestKeys", req);
                JSONArray res = new JSONArray();
                try { for (CaptureResult.Key<?> k : ec.getAvailableCaptureResultKeys(ext)) res.put(k.getName()); } catch (Throwable ignored) {}
                x.put("captureResultKeys", res);
                result.put(x);
            }
        } catch (Throwable t) {
            try {
                JSONObject e = new JSONObject();
                e.put("error", t.toString());
                result.put(e);
            } catch (Exception ignored) {}
        }
        return result;
    }

    private static JSONObject streamMapJson(StreamConfigurationMap map) throws Exception {
        if (map == null) { JSONObject n = new JSONObject(); n.put("available", false); return n; }
        JSONObject j = new JSONObject();
        JSONArray formats = new JSONArray();
        int[] outputFormats = map.getOutputFormats();
        Arrays.sort(outputFormats);
        for (int format : outputFormats) {
            JSONObject f = new JSONObject();
            f.put("format", format);
            f.put("formatName", formatName(format));
            Size[] out = map.getOutputSizes(format);
            f.put("sizes", sizesWithTiming(map, format, out));
            formats.put(f);
        }
        j.put("formats", formats);
        try { j.put("surfaceTextureSizes", sizes(Arrays.asList(map.getOutputSizes(SurfaceTexture.class)))); } catch (Throwable ignored) {}
        try { j.put("highSpeedVideoSizes", sizes(Arrays.asList(map.getHighSpeedVideoSizes()))); } catch (Throwable ignored) {}
        try {
            JSONArray input = new JSONArray();
            for (int format : map.getInputFormats()) {
                JSONObject f = new JSONObject();
                f.put("format", format);
                f.put("formatName", formatName(format));
                f.put("sizes", sizes(Arrays.asList(map.getInputSizes(format))));
                input.put(f);
            }
            j.put("inputFormats", input);
        } catch (Throwable ignored) {}
        return j;
    }

    private static JSONArray sizesWithTiming(StreamConfigurationMap map, int format, Size[] input) {
        JSONArray a = new JSONArray();
        if (input == null) return a;
        List<Size> list = new ArrayList<>(Arrays.asList(input));
        list.sort((x, y) -> Long.compare(pixels(y), pixels(x)));
        for (Size s : list) {
            try {
                JSONObject x = new JSONObject();
                x.put("size", s.getWidth() + "x" + s.getHeight());
                x.put("megapixels", Math.round((pixels(s) / 1_000_000.0) * 100.0) / 100.0);
                try { x.put("minFrameDurationNs", map.getOutputMinFrameDuration(format, s)); } catch (Throwable ignored) {}
                try { x.put("stallDurationNs", map.getOutputStallDuration(format, s)); } catch (Throwable ignored) {}
                a.put(x);
            } catch (Exception ignored) {}
        }
        return a;
    }

    private static String buildTextSummary(JSONObject root) throws Exception {
        StringBuilder b = new StringBuilder();
        JSONObject d = root.getJSONObject("device");
        b.append("S23U CAMERA CAPABILITY PROBE v").append(root.getString("probeVersion")).append('\n');
        b.append("Generated: ").append(root.getString("generatedUtc")).append(" UTC\n\n");
        b.append("DEVICE\n");
        b.append("Manufacturer: ").append(d.optString("manufacturer")).append('\n');
        b.append("Model: ").append(d.optString("model")).append('\n');
        b.append("Device: ").append(d.optString("device")).append('\n');
        b.append("Android: ").append(d.optString("androidRelease")).append(" (API ").append(d.optInt("sdkInt")).append(")\n");
        b.append("Build: ").append(d.optString("buildFingerprint")).append("\n\n");

        JSONArray cameras = root.getJSONArray("cameras");
        b.append("CAMERAS DISCOVERED: ").append(cameras.length()).append("\n\n");
        for (int i = 0; i < cameras.length(); i++) {
            JSONObject c = cameras.getJSONObject(i);
            b.append("=== CAMERA ").append(c.optString("cameraId")).append(" ===\n");
            b.append("Facing: ").append(c.optString("lensFacing")).append('\n');
            b.append("Physical-only: ").append(c.optBoolean("physicalOnly")).append('\n');
            b.append("Hardware: ").append(c.optString("hardwareLevel")).append('\n');
            b.append("Focal lengths: ").append(c.optJSONArray("focalLengthsMm")).append(" mm\n");
            b.append("Apertures: ").append(c.optJSONArray("apertures")).append('\n');
            b.append("Pixel array: ").append(c.optString("pixelArraySize")).append('\n');
            b.append("Max-res pixel array: ").append(c.optString("pixelArraySizeMaximumResolution", "n/a")).append('\n');
            b.append("RAW: ").append(c.optBoolean("rawSupported")).append('\n');
            b.append("Ultra-high-res sensor: ").append(c.optBoolean("ultraHighResolutionSensor")).append('\n');
            b.append("10-bit dynamic range: ").append(c.optBoolean("tenBitDynamicRange")).append('\n');
            b.append("ISO range: ").append(c.optString("sensitivityIsoRange")).append('\n');
            b.append("Exposure range ns: ").append(c.optString("exposureTimeRangeNs")).append('\n');
            b.append("Zoom ratio: ").append(c.optString("zoomRatioRange", "n/a")).append('\n');
            b.append("OIS: ").append(c.optJSONArray("oisModes")).append('\n');
            b.append("AF modes: ").append(c.optJSONArray("afModes")).append('\n');
            b.append("Physical IDs: ").append(c.optJSONArray("physicalCameraIds")).append('\n');

            JSONObject streams = c.optJSONObject("defaultStreams");
            b.append("Largest default JPEG: ").append(largestSizeFor(streams, ImageFormat.JPEG)).append('\n');
            JSONObject maxStreams = c.optJSONObject("maximumResolutionStreams");
            b.append("Largest maximum-res JPEG: ").append(largestSizeFor(maxStreams, ImageFormat.JPEG)).append('\n');

            JSONArray ext = c.optJSONArray("oemExtensions");
            if (ext != null) {
                b.append("OEM extensions: ");
                List<String> names = new ArrayList<>();
                for (int e = 0; e < ext.length(); e++) {
                    JSONObject x = ext.optJSONObject(e);
                    if (x != null && x.has("type")) names.add(x.optString("type"));
                }
                b.append(names.isEmpty() ? "none" : String.join(", ", names)).append('\n');
            }
            b.append('\n');
        }
        b.append("NEXT STEP\nUpload BOTH the .json and .txt files. The JSON contains the complete stream maps and vendor keys; the TXT is the quick human-readable summary.\n");
        return b.toString();
    }

    private static String largestSizeFor(JSONObject streams, int wantedFormat) {
        if (streams == null) return "n/a";
        JSONArray formats = streams.optJSONArray("formats");
        if (formats == null) return "n/a";
        for (int i = 0; i < formats.length(); i++) {
            JSONObject f = formats.optJSONObject(i);
            if (f != null && f.optInt("format") == wantedFormat) {
                JSONArray sizes = f.optJSONArray("sizes");
                if (sizes != null && sizes.length() > 0) {
                    JSONObject s = sizes.optJSONObject(0);
                    return s == null ? "n/a" : s.optString("size") + " (" + s.optDouble("megapixels") + " MP)";
                }
            }
        }
        return "n/a";
    }

    private static JSONObject deviceJson() throws Exception {
        JSONObject d = new JSONObject();
        d.put("manufacturer", Build.MANUFACTURER);
        d.put("brand", Build.BRAND);
        d.put("model", Build.MODEL);
        d.put("device", Build.DEVICE);
        d.put("product", Build.PRODUCT);
        d.put("board", Build.BOARD);
        d.put("hardware", Build.HARDWARE);
        d.put("androidRelease", Build.VERSION.RELEASE);
        d.put("sdkInt", Build.VERSION.SDK_INT);
        d.put("securityPatch", Build.VERSION.SECURITY_PATCH);
        d.put("buildId", Build.ID);
        d.put("buildFingerprint", Build.FINGERPRINT);
        return d;
    }

    private interface IntNamer { String name(int x); }
    private static JSONArray intNames(int[] a, IntNamer namer) {
        JSONArray r = new JSONArray();
        if (a != null) for (int x : a) r.put(namer.name(x) + " (" + x + ")");
        return r;
    }
    private static JSONArray ints(int[] a) { JSONArray r = new JSONArray(); if (a != null) for (int x : a) r.put(x); return r; }
    private static JSONArray floats(float[] a) { JSONArray r = new JSONArray(); if (a != null) for (float x : a) r.put(x); return r; }
    private static JSONArray ranges(Range<Integer>[] a) { JSONArray r = new JSONArray(); if (a != null) for (Range<Integer> x : a) r.put(range(x)); return r; }
    private static String range(Range<?> r) { return r == null ? "n/a" : r.getLower() + " .. " + r.getUpper(); }
    private static String rational(Rational r) { return r == null ? "n/a" : r.toString() + " (" + r.floatValue() + ")"; }
    private static Object value(Object o) { return o == null ? JSONObject.NULL : o; }
    private static boolean contains(int[] a, int x) { if (a == null) return false; for (int v : a) if (v == x) return true; return false; }
    private static long pixels(Size s) { return (long) s.getWidth() * s.getHeight(); }
    private static JSONArray sizes(List<Size> input) {
        JSONArray a = new JSONArray();
        if (input == null) return a;
        List<Size> list = new ArrayList<>(input);
        list.sort((x, y) -> Long.compare(pixels(y), pixels(x)));
        for (Size s : list) a.put(s.getWidth() + "x" + s.getHeight());
        return a;
    }

    private static String lensFacing(Integer x) {
        if (x == null) return "UNKNOWN";
        if (x == CameraCharacteristics.LENS_FACING_BACK) return "BACK";
        if (x == CameraCharacteristics.LENS_FACING_FRONT) return "FRONT";
        if (x == CameraCharacteristics.LENS_FACING_EXTERNAL) return "EXTERNAL";
        return "UNKNOWN(" + x + ")";
    }
    private static String hardwareLevel(Integer x) {
        if (x == null) return "UNKNOWN";
        if (x == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY) return "LEGACY";
        if (x == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED) return "LIMITED";
        if (x == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL) return "FULL";
        if (x == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3) return "LEVEL_3";
        if (x == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL) return "EXTERNAL";
        return "UNKNOWN(" + x + ")";
    }
    private static String capabilityName(int x) {
        switch (x) {
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE: return "BACKWARD_COMPATIBLE";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR: return "MANUAL_SENSOR";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING: return "MANUAL_POST_PROCESSING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW: return "RAW";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_PRIVATE_REPROCESSING: return "PRIVATE_REPROCESSING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS: return "READ_SENSOR_SETTINGS";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE: return "BURST_CAPTURE";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_YUV_REPROCESSING: return "YUV_REPROCESSING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT: return "DEPTH_OUTPUT";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO: return "HIGH_SPEED_VIDEO";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MOTION_TRACKING: return "MOTION_TRACKING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA: return "LOGICAL_MULTI_CAMERA";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME: return "MONOCHROME";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_SECURE_IMAGE_DATA: return "SECURE_IMAGE_DATA";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_SYSTEM_CAMERA: return "SYSTEM_CAMERA";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_OFFLINE_PROCESSING: return "OFFLINE_PROCESSING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR: return "ULTRA_HIGH_RESOLUTION_SENSOR";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_REMOSAIC_REPROCESSING: return "REMOSAIC_REPROCESSING";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DYNAMIC_RANGE_TEN_BIT: return "DYNAMIC_RANGE_TEN_BIT";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_STREAM_USE_CASE: return "STREAM_USE_CASE";
            case CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_COLOR_SPACE_PROFILES: return "COLOR_SPACE_PROFILES";
            default: return "CAPABILITY";
        }
    }
    private static String oisName(int x) { return x == CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON ? "ON" : x == CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF ? "OFF" : "MODE"; }
    private static String afName(int x) {
        switch (x) {
            case CameraMetadata.CONTROL_AF_MODE_OFF: return "OFF";
            case CameraMetadata.CONTROL_AF_MODE_AUTO: return "AUTO";
            case CameraMetadata.CONTROL_AF_MODE_MACRO: return "MACRO";
            case CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO: return "CONTINUOUS_VIDEO";
            case CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE: return "CONTINUOUS_PICTURE";
            case CameraMetadata.CONTROL_AF_MODE_EDOF: return "EDOF";
            default: return "AF_MODE";
        }
    }
    private static String awbName(int x) {
        switch (x) {
            case CameraMetadata.CONTROL_AWB_MODE_OFF: return "OFF";
            case CameraMetadata.CONTROL_AWB_MODE_AUTO: return "AUTO";
            case CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT: return "INCANDESCENT";
            case CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT: return "FLUORESCENT";
            case CameraMetadata.CONTROL_AWB_MODE_WARM_FLUORESCENT: return "WARM_FLUORESCENT";
            case CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT: return "DAYLIGHT";
            case CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT: return "CLOUDY_DAYLIGHT";
            case CameraMetadata.CONTROL_AWB_MODE_TWILIGHT: return "TWILIGHT";
            case CameraMetadata.CONTROL_AWB_MODE_SHADE: return "SHADE";
            default: return "AWB_MODE";
        }
    }
    private static String cfaName(Integer x) {
        if (x == null) return "UNKNOWN";
        switch (x) {
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_RGGB: return "RGGB";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GRBG: return "GRBG";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GBRG: return "GBRG";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_BGGR: return "BGGR";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_RGB: return "RGB";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_MONO: return "MONO";
            case CameraMetadata.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_NIR: return "NIR";
            default: return "UNKNOWN(" + x + ")";
        }
    }
    private static String extensionName(int x) {
        switch (x) {
            case CameraExtensionCharacteristics.EXTENSION_AUTOMATIC: return "AUTOMATIC";
            case CameraExtensionCharacteristics.EXTENSION_BOKEH: return "BOKEH";
            case CameraExtensionCharacteristics.EXTENSION_FACE_RETOUCH: return "FACE_RETOUCH";
            case CameraExtensionCharacteristics.EXTENSION_HDR: return "HDR";
            case CameraExtensionCharacteristics.EXTENSION_NIGHT: return "NIGHT";
            default: return "EXTENSION_" + x;
        }
    }
    private static String formatName(int x) {
        if (x == ImageFormat.JPEG) return "JPEG";
        if (x == ImageFormat.YUV_420_888) return "YUV_420_888";
        if (x == ImageFormat.RAW_SENSOR) return "RAW_SENSOR";
        if (x == ImageFormat.RAW10) return "RAW10";
        if (x == ImageFormat.RAW12) return "RAW12";
        if (x == ImageFormat.PRIVATE) return "PRIVATE";
        if (Build.VERSION.SDK_INT >= 34 && x == ImageFormat.JPEG_R) return "JPEG_R_ULTRA_HDR";
        if (x == ImageFormat.YCBCR_P010) return "YCBCR_P010";
        if (x == ImageFormat.DEPTH_JPEG) return "DEPTH_JPEG";
        if (x == ImageFormat.DEPTH16) return "DEPTH16";
        return "FORMAT_" + x;
    }
    private static String utcNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }
}
