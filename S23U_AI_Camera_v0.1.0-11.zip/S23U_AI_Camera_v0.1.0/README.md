# S23U Auto+ AI Camera v0.1.9

Quality/speed refinement built on the proven v0.1.6/v0.1.7 S23 Ultra Camera2 YUV capture path.

## Core capture path retained
- Logical camera 0 with physical S23U lens binding
- 0.6x physical 2, 1x physical 5, 3x physical 6, 10x physical 7
- Full-resolution YUV still capture
- App-side NV21 -> JPEG quality 100
- MediaStore save path
- 4:3 proportion-safe preview
- 3x/10x final output standardized to 12 MP

## v0.1.9 changes
- PRO/NAT GEO moved from a 12.5-million-pixel Java loop to one Canvas/ColorMatrix raster pass.
- Coarse device orientation now comes from OrientationEventListener rather than display rotation.
- Fine auto-level roll now comes from gravity and is normalized to the nearest 90 degrees so portrait/landscape posture is not mistaken for horizon error.
- Auto-level remains conservative: correction begins at 0.90 degrees and is limited to 5 degrees.
- Shutter-time 64x48 preview metering adds conservative highlight protection, mainly for a face against bright sky/window backgrounds, without adding a camera stream.
- Gentle red protection is applied only when strongly saturated reds are detected.
- PRO/NAT GEO remain restrained; TRUE stays byte-for-byte untouched when no geometry or tele standardization is needed.
- Diagnostics now record deviceOrientationDeg, appliedEvSteps and processMs separately from encodeMs/totalMs.

VersionCode: 9
VersionName: 0.1.9


## v0.1.9 hotfix
- Fixed back-camera JPEG/pixel orientation sign. One landscape direction previously mapped to 180 degrees and could save upside down.
- Capture, save, looks, tele 12 MP standardisation and processing pipeline are otherwise unchanged from v0.1.8.
