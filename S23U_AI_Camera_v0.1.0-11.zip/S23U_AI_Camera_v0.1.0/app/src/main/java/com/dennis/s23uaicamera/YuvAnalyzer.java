package com.dennis.s23uaicamera;

import android.media.Image;
import java.nio.ByteBuffer;

public final class YuvAnalyzer {
    private YuvAnalyzer() {}

    public static FrameAnalysis analyze(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        int w = image.getWidth();
        int h = image.getHeight();
        int[] hist = new int[256];
        long[] sum = new long[49];
        long[] sum2 = new long[49];
        int[] count = new int[49];
        long total = 0;
        int n = 0;
        int step = Math.max(2, Math.min(w, h) / 160);

        for (int y = 0; y < h; y += step) {
            int row = y * rowStride;
            int zy = Math.min(6, (y * 7) / Math.max(1, h));
            for (int x = 0; x < w; x += step) {
                int pos = row + x * pixelStride;
                if (pos < 0 || pos >= buf.limit()) continue;
                int v = buf.get(pos) & 0xff;
                hist[v]++;
                total += v;
                n++;
                int zx = Math.min(6, (x * 7) / Math.max(1, w));
                int z = zy * 7 + zx;
                sum[z] += v;
                sum2[z] += (long) v * v;
                count[z]++;
            }
        }

        if (n == 0) return new FrameAnalysis(0, 0, 0, 0, 0, 24, .5f, .5f, 0, "UNKNOWN");
        double mean = (double) total / n;
        int p05 = percentile(hist, n, .05);
        int p95 = percentile(hist, n, .95);
        int hiCount = 0, loCount = 0;
        for (int i = 245; i < 256; i++) hiCount += hist[i];
        for (int i = 0; i <= 18; i++) loCount += hist[i];
        double highlights = (double) hiCount / n;
        double shadows = (double) loCount / n;

        int best = 24;
        double bestScore = -1;
        double centerMean = 0;
        int centerN = 0;
        for (int z = 0; z < 49; z++) {
            if (count[z] == 0) continue;
            double m = (double) sum[z] / count[z];
            double variance = Math.max(0, (double) sum2[z] / count[z] - m * m);
            int x = z % 7, y = z / 7;
            double dx = x - 3.0, dy = y - 3.0;
            double centerWeight = 1.0 / (1.0 + 0.13 * (dx * dx + dy * dy));
            double exposureWeight = (m < 18 || m > 240) ? 0.35 : 1.0;
            double score = Math.sqrt(variance + 1.0) * centerWeight * exposureWeight;
            if (score > bestScore) { bestScore = score; best = z; }
            if (x >= 2 && x <= 4 && y >= 2 && y <= 4) { centerMean += m; centerN++; }
        }
        if (centerN > 0) centerMean /= centerN;

        int ev = (int) Math.round((108.0 - mean) / 13.0);
        if (highlights > 0.015 || p95 > 242) ev -= 2;
        if (mean < 48 && highlights < 0.002) ev += 1;
        ev = Math.max(-10, Math.min(10, ev));

        String scene;
        if (mean < 48) scene = "NIGHT";
        else if (p95 - p05 > 165 && centerMean + 28 < mean) scene = "BACKLIT";
        else if (p95 - p05 > 170) scene = "HIGH_DR";
        else if (mean > 190) scene = "BRIGHT";
        else scene = "NORMAL";

        float bx = ((best % 7) + .5f) / 7f;
        float by = ((best / 7) + .5f) / 7f;
        return new FrameAnalysis(mean, p05, p95, highlights, shadows, best, bx, by, ev, scene);
    }

    private static int percentile(int[] hist, int n, double q) {
        int target = (int) Math.ceil(n * q);
        int acc = 0;
        for (int i = 0; i < hist.length; i++) {
            acc += hist[i];
            if (acc >= target) return i;
        }
        return 255;
    }
}
