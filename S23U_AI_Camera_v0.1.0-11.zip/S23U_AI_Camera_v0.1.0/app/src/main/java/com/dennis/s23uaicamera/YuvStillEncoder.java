package com.dennis.s23uaicamera;

import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.media.Image;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

final class YuvStillEncoder {
    private YuvStillEncoder() {}

    static byte[] encodeJpeg(Image image, int quality, int orientationDegrees) throws Exception {
        if (image == null) throw new IllegalArgumentException("image == null");
        if (image.getFormat() != ImageFormat.YUV_420_888) {
            throw new IllegalArgumentException("Expected YUV_420_888, got " + image.getFormat());
        }
        int width = image.getWidth();
        int height = image.getHeight();
        byte[] nv21 = imageToNv21(image);
        if (nv21.length != width * height * 3 / 2) {
            throw new IllegalStateException("NV21 dimensions do not match the buffer");
        }

        YuvImage yuv = new YuvImage(nv21, ImageFormat.NV21, width, height, null);
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1024 * 1024, width * height / 2));
        boolean ok = yuv.compressToJpeg(new Rect(0, 0, width, height), Math.max(1, Math.min(100, quality)), out);
        if (!ok) throw new IllegalStateException("Android JPEG encoder rejected the YUV frame");
        return addExifOrientation(out.toByteArray(), orientationDegrees);
    }

    static byte[] imageToNv21(Image image) {
        int width = image.getWidth();
        int height = image.getHeight();
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length < 3) throw new IllegalArgumentException("YUV image has fewer than 3 planes");

        byte[] out = new byte[width * height * 3 / 2];
        copyLuma(planes[0], width, height, out);
        copyChromaNv21(planes[1], planes[2], width, height, out, width * height);
        return out;
    }

    private static void copyLuma(Image.Plane yPlane, int width, int height, byte[] out) {
        ByteBuffer y = yPlane.getBuffer();
        int rowStride = yPlane.getRowStride();
        int pixelStride = yPlane.getPixelStride();
        int base = y.position();
        int dst = 0;
        for (int row = 0; row < height; row++) {
            int rowBase = base + row * rowStride;
            if (pixelStride == 1) {
                ByteBuffer dup = y.duplicate();
                dup.position(rowBase);
                dup.get(out, dst, width);
                dst += width;
            } else {
                for (int col = 0; col < width; col++) out[dst++] = y.get(rowBase + col * pixelStride);
            }
        }
    }

    private static void copyChromaNv21(Image.Plane uPlane, Image.Plane vPlane,
                                       int width, int height, byte[] out, int dstStart) {
        ByteBuffer u = uPlane.getBuffer();
        ByteBuffer v = vPlane.getBuffer();
        int uRow = uPlane.getRowStride(), vRow = vPlane.getRowStride();
        int uPix = uPlane.getPixelStride(), vPix = vPlane.getPixelStride();
        int uBase = u.position(), vBase = v.position();
        int dst = dstStart;
        int chromaW = width / 2, chromaH = height / 2;
        for (int row = 0; row < chromaH; row++) {
            int ur = uBase + row * uRow;
            int vr = vBase + row * vRow;
            for (int col = 0; col < chromaW; col++) {
                out[dst++] = v.get(vr + col * vPix);
                out[dst++] = u.get(ur + col * uPix);
            }
        }
    }

    // Minimal EXIF APP1 containing only the Orientation tag. This preserves JPEG pixels and quality.
    private static byte[] addExifOrientation(byte[] jpeg, int degrees) throws Exception {
        int orientation = orientationTag(degrees);
        if (orientation == 1 || jpeg.length < 2 || (jpeg[0] & 0xff) != 0xff || (jpeg[1] & 0xff) != 0xd8) return jpeg;

        byte[] exif = new byte[] {
                (byte)0xff, (byte)0xe1, 0x00, 0x22,
                'E','x','i','f',0x00,0x00,
                'M','M', 0x00,0x2a, 0x00,0x00,0x00,0x08,
                0x00,0x01,
                0x01,0x12, 0x00,0x03, 0x00,0x00,0x00,0x01,
                0x00,(byte)orientation,0x00,0x00,
                0x00,0x00,0x00,0x00
        };
        byte[] out = new byte[jpeg.length + exif.length];
        out[0] = jpeg[0]; out[1] = jpeg[1];
        System.arraycopy(exif, 0, out, 2, exif.length);
        System.arraycopy(jpeg, 2, out, 2 + exif.length, jpeg.length - 2);
        return out;
    }

    private static int orientationTag(int degrees) {
        int d = ((degrees % 360) + 360) % 360;
        if (d >= 45 && d < 135) return 6;   // 90 CW
        if (d >= 135 && d < 225) return 3;  // 180
        if (d >= 225 && d < 315) return 8;  // 270 CW
        return 1;
    }
}
