package com.dennis.s23uaicamera;

import android.content.Context;
import android.util.AttributeSet;
import android.view.TextureView;

/** TextureView that preserves the camera stream aspect ratio instead of stretching faces. */
public final class AspectTextureView extends TextureView {
    private int ratioWidth = 0;
    private int ratioHeight = 0;

    public AspectTextureView(Context context) { super(context); }
    public AspectTextureView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setAspectRatio(int width, int height) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("Invalid aspect ratio");
        ratioWidth = width;
        ratioHeight = height;
        requestLayout();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int maxW = MeasureSpec.getSize(widthMeasureSpec);
        int maxH = MeasureSpec.getSize(heightMeasureSpec);
        if (ratioWidth == 0 || ratioHeight == 0) {
            setMeasuredDimension(maxW, maxH);
            return;
        }
        int targetH = Math.round(maxW * (ratioHeight / (float) ratioWidth));
        if (targetH <= maxH) {
            setMeasuredDimension(maxW, targetH);
        } else {
            int targetW = Math.round(maxH * (ratioWidth / (float) ratioHeight));
            setMeasuredDimension(targetW, maxH);
        }
    }
}
