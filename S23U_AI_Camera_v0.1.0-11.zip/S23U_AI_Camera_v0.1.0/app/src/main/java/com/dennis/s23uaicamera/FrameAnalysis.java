package com.dennis.s23uaicamera;

public final class FrameAnalysis {
    public final double meanLuma;
    public final int p05;
    public final int p95;
    public final double highlights;
    public final double shadows;
    public final int bestZone;
    public final float bestXNorm;
    public final float bestYNorm;
    public final int evSteps;
    public final String scene;

    public FrameAnalysis(double meanLuma, int p05, int p95, double highlights, double shadows,
                         int bestZone, float bestXNorm, float bestYNorm, int evSteps, String scene) {
        this.meanLuma = meanLuma;
        this.p05 = p05;
        this.p95 = p95;
        this.highlights = highlights;
        this.shadows = shadows;
        this.bestZone = bestZone;
        this.bestXNorm = bestXNorm;
        this.bestYNorm = bestYNorm;
        this.evSteps = evSteps;
        this.scene = scene;
    }
}
