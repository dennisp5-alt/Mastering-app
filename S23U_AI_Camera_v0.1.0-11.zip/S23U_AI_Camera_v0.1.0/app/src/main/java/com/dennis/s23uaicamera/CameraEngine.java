package com.dennis.s23uaicamera;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.Face;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import org.json.JSONObject;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * v0.1.8 quality/speed refinement engine.
 *
 * Non-negotiable core: the proven logical-0 + physical-output YUV capture path.
 * Features are restored around it without adding a second analysis stream.
 */
public final class CameraEngine {
    public interface Listener {
        void onTelemetry(FrameAnalysis analysis, int faceCount, String activePhysicalId, float zoom, int appliedEvSteps);
        void onPhotoSaved(String message);
        void onError(String message, Throwable error);
    }

    private static final String LOGICAL_ID = "0";

    private static final class LensSpec {
        final String label;
        final float zoom;
        final String physicalId;
        final int preferredW;
        final int preferredH;
        LensSpec(String label, float zoom, String physicalId, int preferredW, int preferredH) {
            this.label = label;
            this.zoom = zoom;
            this.physicalId = physicalId;
            this.preferredW = preferredW;
            this.preferredH = preferredH;
        }
    }

    private static final LensSpec ULTRA = new LensSpec("0.6×", 0.6f, "2", 4000, 3000);
    private static final LensSpec MAIN  = new LensSpec("1×",   1.0f, "5", 4080, 3060);
    private static final LensSpec TELE3 = new LensSpec("3×",   3.0f, "6", 3648, 2736);
    private static final LensSpec TELE10= new LensSpec("10×", 10.0f, "7", 3648, 2736);

    private final Context context;
    private final TextureView textureView;
    private final Listener listener;
    private final CameraManager manager;
    private final ExecutorService processing = Executors.newSingleThreadExecutor();

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader captureReader;
    private Surface previewSurface;
    private CameraCharacteristics logicalCharacteristics;
    private CameraCharacteristics physicalCharacteristics;

    private LensSpec activeLens = MAIN;
    private Size captureSize = new Size(4080, 3060);
    private Size previewSize = new Size(1440, 1080);
    private boolean physicalBinding = true;
    private volatile boolean captureBusy = false;
    private volatile int captureGeneration = 0;
    private volatile boolean aiEnabled = true;
    private volatile boolean autoLevel = true;
    private volatile String look = "TRUE";
    private volatile float rollDeg = 0f;
    private volatile float motion = 0f;
    private volatile float requestedZoom = 1f;
    private volatile int lastFaceCount = 0;
    private volatile String lastActivePhysicalId = "5";
    private volatile int deviceOrientationDeg = 0;
    private volatile int lastAppliedEvSteps = 0;

    private FrameAnalysis lastAnalysis = new FrameAnalysis(0,0,0,0,0,24,.5f,.5f,0,"READY");

    public CameraEngine(Context context, TextureView textureView, Listener listener) {
        this.context = context.getApplicationContext();
        this.textureView = textureView;
        this.listener = listener;
        this.manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
    }

    public void start() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("AutoPlusCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        openCamera();
    }

    public void stop() {
        Handler h = cameraHandler;
        if (h != null) h.post(this::closeCamera);
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try { cameraThread.join(1000); } catch (InterruptedException ignored) {}
        }
        cameraThread = null;
        cameraHandler = null;
    }

    public void shutdown() {
        stop();
        processing.shutdown();
    }

    public void setZoom(float value) {
        LensSpec next = lensForZoom(value);
        requestedZoom = next.zoom;
        Handler h = cameraHandler;
        if (h == null) return;
        h.post(() -> {
            if (captureBusy) {
                listener.onPhotoSaved("Finish the current capture before changing lens");
                return;
            }
            if (activeLens == next && session != null) return;
            activeLens = next;
            listener.onPhotoSaved("Switching to " + next.label + " optical camera…");
            loadPhysicalCharacteristics();
            chooseCaptureSize();
            createSession(true);
        });
    }

    public void setAiEnabled(boolean value) { aiEnabled = value; }
    public void setAutoLevel(boolean value) { autoLevel = value; }
    public void setLook(String value) { look = value == null ? "TRUE" : value; }
    public void setMotion(float value) { motion = value; }
    public void setRoll(float value) { rollDeg = value; }
    public void setDeviceOrientation(int value) { deviceOrientationDeg = ((value % 360) + 360) % 360; }

    private LensSpec lensForZoom(float value) {
        if (value < 0.8f) return ULTRA;
        if (value < 2.0f) return MAIN;
        if (value < 6.0f) return TELE3;
        return TELE10;
    }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        try {
            logicalCharacteristics = manager.getCameraCharacteristics(LOGICAL_ID);
            loadPhysicalCharacteristics();
            chooseCaptureSize();
            manager.openCamera(LOGICAL_ID, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    camera = c;
                    listener.onPhotoSaved("Camera ready • " + activeLens.label + " physical " + activeLens.physicalId);
                    createSession(true);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    c.close(); camera = null;
                    notifyError("Camera disconnected", null);
                }
                @Override public void onError(CameraDevice c, int error) {
                    c.close(); camera = null;
                    notifyError("Camera open error " + error, null);
                }
            }, cameraHandler);
        } catch (Exception e) {
            notifyError("Unable to open camera", e);
        }
    }

    private void loadPhysicalCharacteristics() {
        try {
            physicalCharacteristics = manager.getCameraCharacteristics(activeLens.physicalId);
        } catch (Exception ignored) {
            physicalCharacteristics = null;
        }
    }

    private void chooseCaptureSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] yuv = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    .getOutputSizes(ImageFormat.YUV_420_888);
            if (yuv == null || yuv.length == 0) return;
            Size best = null;
            for (Size s : yuv) {
                if (s.getWidth() == activeLens.preferredW && s.getHeight() == activeLens.preferredH) {
                    best = s;
                    break;
                }
                float aspect = s.getWidth() / (float)Math.max(1, s.getHeight());
                if (Math.abs(aspect - 4f/3f) > 0.03f) continue;
                if (best == null || (long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
            }
            if (best == null) best = yuv[0];
            captureSize = best;
        } catch (Exception ignored) {}
    }

    private void createSession(boolean bindPhysical) {
        if (camera == null || !textureView.isAvailable()) return;
        closeSessionOnly();
        physicalBinding = bindPhysical;
        try {
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            previewSize = choosePreviewSize();
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            refreshPreviewGeometry();
            previewSurface = new Surface(st);

            captureReader = ImageReader.newInstance(captureSize.getWidth(), captureSize.getHeight(), ImageFormat.YUV_420_888, 3);
            captureReader.setOnImageAvailableListener(this::onCaptureYuvAvailable, cameraHandler);

            OutputConfiguration previewOut = new OutputConfiguration(previewSurface);
            OutputConfiguration captureOut = new OutputConfiguration(captureReader.getSurface());
            if (bindPhysical) {
                previewOut.setPhysicalCameraId(activeLens.physicalId);
                captureOut.setPhysicalCameraId(activeLens.physicalId);
            }
            List<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(previewOut);
            outputs.add(captureOut);

            Executor executor = command -> {
                Handler h = cameraHandler;
                if (h != null) h.post(command);
            };
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR,
                    outputs,
                    executor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            if (camera == null) { s.close(); return; }
                            session = s;
                            try {
                                previewBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                previewBuilder.addTarget(previewSurface);
                                applySafeAuto(previewBuilder, false);
                                session.setRepeatingRequest(previewBuilder.build(), previewCaptureCallback, cameraHandler);
                                lastActivePhysicalId = physicalBinding ? activeLens.physicalId : "logical";
                                listener.onPhotoSaved((physicalBinding ? "Optical " + activeLens.label : "Logical fallback") +
                                        " ready • " + captureSize.getWidth() + "×" + captureSize.getHeight());
                                listener.onTelemetry(lastAnalysis, lastFaceCount, lastActivePhysicalId, activeLens.zoom, lastAppliedEvSteps);
                            } catch (Exception e) {
                                notifyError("Unable to start preview", e);
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            if (bindPhysical) {
                                listener.onPhotoSaved("Physical " + activeLens.label + " route rejected • trying logical fallback");
                                createSession(false);
                            } else {
                                notifyError("Camera session configuration failed", null);
                            }
                        }
                    });
            camera.createCaptureSession(config);
        } catch (Exception e) {
            if (bindPhysical) {
                listener.onPhotoSaved("Physical " + activeLens.label + " route error • trying logical fallback");
                createSession(false);
            } else {
                notifyError("Unable to create capture session", e);
            }
        }
    }

    private Size choosePreviewSize() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Size[] sizes = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(SurfaceTexture.class);
            if (sizes != null && sizes.length > 0) {
                for (Size s : sizes) if (s.getWidth() == 1440 && s.getHeight() == 1080) return s;
                for (Size s : sizes) if (s.getWidth() == 1920 && s.getHeight() == 1440) return s;
                Size best = null;
                for (Size s : sizes) {
                    float a = s.getWidth() / (float)Math.max(1, s.getHeight());
                    if (Math.abs(a - 4f/3f) > 0.03f || s.getWidth() > 1920) continue;
                    if (best == null || (long)s.getWidth()*s.getHeight() > (long)best.getWidth()*best.getHeight()) best = s;
                }
                if (best != null) return best;
                return sizes[0];
            }
        } catch (Exception ignored) {}
        return new Size(1440,1080);
    }

    private void applySafeAuto(CaptureRequest.Builder b, boolean still) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
        try { b.set(CaptureRequest.CONTROL_ZOOM_RATIO, physicalBinding ? 1.0f : activeLens.zoom); } catch (Exception ignored) {}
        try { b.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, CaptureRequest.STATISTICS_FACE_DETECT_MODE_SIMPLE); } catch (Exception ignored) {}
        if (still) {
            try { b.set(CaptureRequest.CONTROL_ENABLE_ZSL, true); } catch (Exception ignored) {}
        }
    }

    private final CameraCaptureSession.CaptureCallback previewCaptureCallback = new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
            try {
                Face[] faces = result.get(CaptureResult.STATISTICS_FACES);
                if (faces != null) lastFaceCount = faces.length;
                String active = result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
                if (active != null && !active.isEmpty()) lastActivePhysicalId = active;
            } catch (Exception ignored) {}
        }
    };

    public void capture() {
        Handler h = cameraHandler;
        if (h == null) {
            notifyError("Capture unavailable: camera thread is not running", null);
            return;
        }
        h.post(() -> {
            if (captureBusy) {
                listener.onPhotoSaved("Capture already in progress");
                return;
            }
            if (camera == null || session == null || captureReader == null) {
                notifyError("Capture unavailable: session/YUV output not ready", null);
                return;
            }
            captureBusy = true;
            final int gen = ++captureGeneration;
            listener.onPhotoSaved("Capturing " + activeLens.label + "…");
            try {
                CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                b.addTarget(captureReader.getSurface());
                applySafeAuto(b, true);
                int evSteps = chooseHighlightEvSteps();
                lastAppliedEvSteps = evSteps;
                if (evSteps != 0) {
                    try { b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evSteps); } catch (Exception ignored) {}
                }
                b.set(CaptureRequest.CONTROL_CAPTURE_INTENT, CaptureRequest.CONTROL_CAPTURE_INTENT_STILL_CAPTURE);
                listener.onTelemetry(lastAnalysis, lastFaceCount, lastActivePhysicalId, activeLens.zoom, lastAppliedEvSteps);
                session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                    @Override public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request, TotalCaptureResult result) {
                        try {
                            String active = result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID);
                            if (active != null && !active.isEmpty()) lastActivePhysicalId = active;
                            Face[] faces = result.get(CaptureResult.STATISTICS_FACES);
                            if (faces != null) lastFaceCount = faces.length;
                            if (physicalBinding && active != null && !activeLens.physicalId.equals(active)) {
                                listener.onPhotoSaved("Lens fallback detected: requested " + activeLens.physicalId + " / active " + active);
                            }
                        } catch (Exception ignored) {}
                    }
                    @Override public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                        if (captureGeneration == gen) captureBusy = false;
                        notifyError("Still capture failed: reason " + failure.getReason(), null);
                    }
                    @Override public void onCaptureSequenceAborted(CameraCaptureSession s, int sequenceId) {
                        if (captureGeneration == gen) captureBusy = false;
                        notifyError("Still capture sequence aborted", null);
                    }
                }, cameraHandler);

                h.postDelayed(() -> {
                    if (captureBusy && captureGeneration == gen) {
                        captureBusy = false;
                        notifyError("Capture timed out before the YUV frame arrived", null);
                    }
                }, 8000);
            } catch (Exception e) {
                captureBusy = false;
                notifyError("Unable to submit still capture", e);
            }
        });
    }

    private void onCaptureYuvAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) {
                captureBusy = false;
                notifyError("YUV callback fired but no image was available", null);
                return;
            }
            final Image frame = image;
            image = null;
            captureBusy = false;

            FrameAnalysis measured = YuvAnalyzer.analyze(frame);
            String scene = classifyScene(measured, lastFaceCount, activeLens);
            lastAnalysis = new FrameAnalysis(measured.meanLuma, measured.p05, measured.p95,
                    measured.highlights, measured.shadows, measured.bestZone,
                    measured.bestXNorm, measured.bestYNorm, measured.evSteps, scene);
            listener.onTelemetry(lastAnalysis, lastFaceCount, lastActivePhysicalId, activeLens.zoom, lastAppliedEvSteps);

            final int orientation = jpegOrientation();
            final String mode = look;
            final boolean makeAi = aiEnabled;
            final boolean level = autoLevel;
            final float roll = rollDeg;
            final LensSpec lens = activeLens;
            final FrameAnalysis shotAnalysis = lastAnalysis;
            final int faces = lastFaceCount;
            final String activePhysical = lastActivePhysicalId;
            final long started = System.nanoTime();

            if (faces > 0 && lens == ULTRA) {
                listener.onPhotoSaved("Portrait warning: 0.6× can stretch faces near frame edges");
            } else {
                listener.onPhotoSaved("Frame received • processing " + mode + "…");
            }

            processing.execute(() -> {
                try {
                    long t0 = System.nanoTime();
                    byte[] jpeg = YuvStillEncoder.encodeJpeg(frame, 100, orientation);
                    long encodeMs = (System.nanoTime() - t0) / 1_000_000L;
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
                    String lensToken = lens.label.replace("×", "x").replace(".", "p");
                    String base = "AutoPlus_" + lensToken + "_" + stamp;

                    byte[] output = jpeg;
                    String suffix = "_REF.jpg";
                    long processMs = 0L;
                    if (makeAi) {
                        suffix = ".jpg";
                        boolean levelNeeded = level && Math.abs(roll) >= 0.90f && Math.abs(roll) <= 5.0f;
                        boolean lookNeeded = !"TRUE".equals(mode);
                        boolean teleStandardize = lens == TELE3 || lens == TELE10;
                        if (levelNeeded || lookNeeded || teleStandardize) {
                            long p0 = System.nanoTime();
                            output = ImageProcessor.process(jpeg, mode, level, roll, orientation, lens.label);
                            processMs = (System.nanoTime() - p0) / 1_000_000L;
                        }
                    }

                    Uri saved = saveImage(base + suffix, output);
                    long totalMs = (System.nanoTime() - started) / 1_000_000L;
                    String route = physicalBinding ? lens.physicalId : "logical";
                    float outputMp = (lens == TELE3 || lens == TELE10) ? 12.0f : (captureSize.getWidth()*captureSize.getHeight())/1_000_000f;
                    listener.onPhotoSaved(String.format(Locale.US,
                            "Saved ✓  %s • %s • %.1f MP • %d ms",
                            lens.label, mode, outputMp, totalMs));

                    try {
                        JSONObject d = new JSONObject();
                        d.put("version", "0.1.8");
                        d.put("logicalCamera", LOGICAL_ID);
                        d.put("requestedLens", lens.label);
                        d.put("expectedPhysicalId", lens.physicalId);
                        d.put("activePhysicalId", activePhysical);
                        d.put("physicalBinding", physicalBinding);
                        d.put("captureSize", captureSize.toString());
                        d.put("outputStandardized12MP", lens == TELE3 || lens == TELE10);
                        d.put("savedUri", saved.toString());
                        d.put("aiEnabled", makeAi);
                        d.put("look", mode);
                        d.put("autoLevel", level);
                        d.put("rollDeg", roll);
                        d.put("deviceOrientationDeg", deviceOrientationDeg);
                        d.put("appliedEvSteps", lastAppliedEvSteps);
                        d.put("motion", motion);
                        d.put("faces", faces);
                        d.put("scene", shotAnalysis.scene);
                        d.put("meanLuma", shotAnalysis.meanLuma);
                        d.put("p05", shotAnalysis.p05);
                        d.put("p95", shotAnalysis.p95);
                        d.put("encodeMs", encodeMs);
                        d.put("processMs", processMs);
                        d.put("totalMs", totalMs);
                        d.put("route", route);
                        saveJson(base + "_DIAG.json", d.toString(2));
                    } catch (Exception ignored) {}
                } catch (Exception e) {
                    notifyError("YUV encode/save failed", e);
                } finally {
                    try { frame.close(); } catch (Exception ignored) {}
                }
            });
        } catch (Exception e) {
            captureBusy = false;
            notifyError("Unable to acquire YUV frame", e);
        } finally {
            if (image != null) image.close();
        }
    }

    private String classifyScene(FrameAnalysis a, int faces, LensSpec lens) {
        if (faces > 0) {
            if (a.meanLuma < 52) return "NIGHT_PORTRAIT";
            if (lens == ULTRA) return "PORTRAIT_WIDE_RISK";
            return "PORTRAIT";
        }
        if (a.meanLuma < 48) return "NIGHT";
        if (a.p95 - a.p05 > 170) return "HIGH_DR";
        if (a.p95 > 242 && a.p05 < 32) return "BACKLIT";
        if (motion > 1.25f) return "ACTION";
        if (lens == ULTRA && a.meanLuma > 90) return "LANDSCAPE_WIDE";
        return a.scene;
    }

    private Uri saveImage(String name, byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0) throw new IllegalArgumentException("JPEG byte array is empty");
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AutoPlusAI");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) throw new IllegalStateException("MediaStore insert returned null");
        boolean ok = false;
        try {
            try (OutputStream os = cr.openOutputStream(uri)) {
                if (os == null) throw new IllegalStateException("MediaStore stream returned null");
                os.write(bytes);
                os.flush();
            }
            ContentValues publish = new ContentValues();
            publish.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(uri, publish, null, null);
            ok = true;
            return uri;
        } finally {
            if (!ok) try { cr.delete(uri, null, null); } catch (Exception ignored) {}
        }
    }

    private Uri saveJson(String name, String text) throws Exception {
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, name);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AutoPlusAI");
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri uri = cr.insert(collection, values);
        if (uri == null) return null;
        try (OutputStream os = cr.openOutputStream(uri)) {
            if (os == null) return null;
            os.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            os.flush();
        }
        ContentValues publish = new ContentValues();
        publish.put(MediaStore.Downloads.IS_PENDING, 0);
        cr.update(uri, publish, null, null);
        return uri;
    }

    private int jpegOrientation() {
        try {
            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Integer sensor = cc == null ? 90 : cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (sensor == null) sensor = 90;
            return (sensor + deviceOrientationDeg + 360) % 360;
        } catch (Exception ignored) {
            return 90;
        }
    }

    /**
     * Tiny viewfinder meter used only at shutter time. It does not add another
     * camera output stream, so the proven S23U capture session stays intact.
     * The adjustment is deliberately conservative and mainly protects bright
     * skies/windows behind a detected face. On this device one AE step is 0.1 EV.
     */
    private int chooseHighlightEvSteps() {
        Bitmap thumb = null;
        try {
            if (!textureView.isAvailable()) return 0;
            thumb = textureView.getBitmap(64, 48);
            if (thumb == null) return 0;
            int w = thumb.getWidth(), h = thumb.getHeight();
            int[] pixels = new int[w * h];
            thumb.getPixels(pixels, 0, w, 0, 0, w, h);
            int[] hist = new int[256];
            int bright = 0;
            for (int c : pixels) {
                int r = (c >>> 16) & 255;
                int g = (c >>> 8) & 255;
                int b = c & 255;
                int y = Math.max(0, Math.min(255, Math.round(0.2126f * r + 0.7152f * g + 0.0722f * b)));
                hist[y]++;
                if (y >= 248) bright++;
            }
            int n = Math.max(1, pixels.length);
            int target = (int)Math.ceil(n * 0.95);
            int acc = 0, p95 = 255;
            for (int i = 0; i < 256; i++) {
                acc += hist[i];
                if (acc >= target) { p95 = i; break; }
            }
            float brightFrac = bright / (float)n;
            int steps = 0;
            if (lastFaceCount > 0) {
                if (brightFrac >= 0.18f || p95 >= 252) steps = -5;
                else if (brightFrac >= 0.08f || p95 >= 247) steps = -3;
            } else if (brightFrac >= 0.24f && p95 >= 252) {
                steps = -2;
            }

            CameraCharacteristics cc = physicalCharacteristics != null ? physicalCharacteristics : logicalCharacteristics;
            Range<Integer> range = cc == null ? null : cc.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if (range != null) steps = Math.max(range.getLower(), Math.min(range.getUpper(), steps));
            return steps;
        } catch (Exception ignored) {
            return 0;
        } finally {
            if (thumb != null) thumb.recycle();
        }
    }

    public void refreshPreviewGeometry() {
        textureView.post(() -> {
            if (textureView instanceof AspectTextureView) {
                ((AspectTextureView) textureView).setAspectRatio(3, 4);
            }
        });
    }

    private void closeSessionOnly() {
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        session = null;
        previewBuilder = null;
        try { if (captureReader != null) captureReader.close(); } catch (Exception ignored) {}
        captureReader = null;
        try { if (previewSurface != null) previewSurface.release(); } catch (Exception ignored) {}
        previewSurface = null;
    }

    private void closeCamera() {
        closeSessionOnly();
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        camera = null;
        captureBusy = false;
    }

    private void notifyError(String message, Throwable error) {
        listener.onError(message, error);
    }
}
